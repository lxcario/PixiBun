(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/ai/math/autotileEngine.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * autotileEngine.ts
 *
 * 47-Blob Autotile Interactive Engine for PixiBun Atelier.
 * 100% scratch, zero third-party dependencies.
 *
 * Implements canonical 8-neighbor Moore bitmasking with cardinal-corner dominance,
 * constant-time O(1) 256-element lookup into the 47 Wang/Blob equivalence classes,
 * Chebyshev-bounded 3x3 dirty neighborhood reactive updates, and procedural 47-tile rendering.
 */ /**
 * The 47 canonical bitmasks derived from 8-neighbor Moore adjacency
 * under cardinal corner masking rules:
 * - NE is masked out unless N && E
 * - SE is masked out unless S && E
 * - SW is masked out unless S && W
 * - NW is masked out unless N && W
 */ __turbopack_context__.s([
    "AutotileGrid",
    ()=>AutotileGrid,
    "BITMASK_TO_47_INDEX",
    ()=>BITMASK_TO_47_INDEX,
    "CANONICAL_47_MASKS",
    ()=>CANONICAL_47_MASKS,
    "calculate47TileBitmask",
    ()=>calculate47TileBitmask,
    "calculate47TileIndex",
    ()=>calculate47TileIndex,
    "calculateRawNeighborBitmask",
    ()=>calculateRawNeighborBitmask,
    "renderProceduralAutotileTile",
    ()=>renderProceduralAutotileTile,
    "updateAutotileAt",
    ()=>updateAutotileAt
]);
const CANONICAL_47_MASKS = [
    0,
    1,
    4,
    5,
    7,
    16,
    17,
    20,
    21,
    23,
    28,
    29,
    31,
    64,
    65,
    68,
    69,
    71,
    80,
    81,
    84,
    85,
    87,
    92,
    93,
    95,
    112,
    113,
    116,
    117,
    119,
    124,
    125,
    127,
    193,
    197,
    199,
    209,
    213,
    215,
    221,
    223,
    241,
    245,
    247,
    253,
    255
];
const BITMASK_TO_47_INDEX = new Uint8Array([
    0,
    1,
    0,
    1,
    2,
    3,
    2,
    4,
    0,
    1,
    0,
    1,
    2,
    3,
    2,
    4,
    5,
    6,
    5,
    6,
    7,
    8,
    7,
    9,
    5,
    6,
    5,
    6,
    10,
    11,
    10,
    12,
    0,
    1,
    0,
    1,
    2,
    3,
    2,
    4,
    0,
    1,
    0,
    1,
    2,
    3,
    2,
    4,
    5,
    6,
    5,
    6,
    7,
    8,
    7,
    9,
    5,
    6,
    5,
    6,
    10,
    11,
    10,
    12,
    13,
    14,
    13,
    14,
    15,
    16,
    15,
    17,
    13,
    14,
    13,
    14,
    15,
    16,
    15,
    17,
    18,
    19,
    18,
    19,
    20,
    21,
    20,
    22,
    18,
    19,
    18,
    19,
    23,
    24,
    23,
    25,
    13,
    14,
    13,
    14,
    15,
    16,
    15,
    17,
    13,
    14,
    13,
    14,
    15,
    16,
    15,
    17,
    26,
    27,
    26,
    27,
    28,
    29,
    28,
    30,
    26,
    27,
    26,
    27,
    31,
    32,
    31,
    33,
    0,
    1,
    0,
    1,
    2,
    3,
    2,
    4,
    0,
    1,
    0,
    1,
    2,
    3,
    2,
    4,
    5,
    6,
    5,
    6,
    7,
    8,
    7,
    9,
    5,
    6,
    5,
    6,
    10,
    11,
    10,
    12,
    0,
    1,
    0,
    1,
    2,
    3,
    2,
    4,
    0,
    1,
    0,
    1,
    2,
    3,
    2,
    4,
    5,
    6,
    5,
    6,
    7,
    8,
    7,
    9,
    5,
    6,
    5,
    6,
    10,
    11,
    10,
    12,
    13,
    34,
    13,
    34,
    15,
    35,
    15,
    36,
    13,
    34,
    13,
    34,
    15,
    35,
    15,
    36,
    18,
    37,
    18,
    37,
    20,
    38,
    20,
    39,
    18,
    37,
    18,
    37,
    23,
    40,
    23,
    41,
    13,
    34,
    13,
    34,
    15,
    35,
    15,
    36,
    13,
    34,
    13,
    34,
    15,
    35,
    15,
    36,
    26,
    42,
    26,
    42,
    28,
    43,
    28,
    44,
    26,
    42,
    26,
    42,
    31,
    45,
    31,
    46
]);
function calculateRawNeighborBitmask(isMatchingNeighbor, x, y) {
    const N = isMatchingNeighbor(x, y - 1) ? 1 : 0;
    const NE = isMatchingNeighbor(x + 1, y - 1) ? 2 : 0;
    const E = isMatchingNeighbor(x + 1, y) ? 4 : 0;
    const SE = isMatchingNeighbor(x + 1, y + 1) ? 8 : 0;
    const S = isMatchingNeighbor(x, y + 1) ? 16 : 0;
    const SW = isMatchingNeighbor(x - 1, y + 1) ? 32 : 0;
    const W = isMatchingNeighbor(x - 1, y) ? 64 : 0;
    const NW = isMatchingNeighbor(x - 1, y - 1) ? 128 : 0;
    return N | NE | E | SE | S | SW | W | NW;
}
function calculate47TileBitmask(isMatchingNeighbor, x, y) {
    const N = isMatchingNeighbor(x, y - 1) ? 1 : 0;
    const E = isMatchingNeighbor(x + 1, y) ? 1 : 0;
    const S = isMatchingNeighbor(x, y + 1) ? 1 : 0;
    const W = isMatchingNeighbor(x - 1, y) ? 1 : 0;
    const NE = N && E && isMatchingNeighbor(x + 1, y - 1) ? 1 : 0;
    const SE = S && E && isMatchingNeighbor(x + 1, y + 1) ? 1 : 0;
    const SW = S && W && isMatchingNeighbor(x - 1, y + 1) ? 1 : 0;
    const NW = N && W && isMatchingNeighbor(x - 1, y - 1) ? 1 : 0;
    return N * 1 + NE * 2 + E * 4 + SE * 8 + S * 16 + SW * 32 + W * 64 + NW * 128;
}
function calculate47TileIndex(isMatchingNeighbor, x, y) {
    const rawMask = calculateRawNeighborBitmask(isMatchingNeighbor, x, y);
    return BITMASK_TO_47_INDEX[rawMask];
}
function updateAutotileAt(tileGrid, gridWidth, gridHeight, cx, cy, isPlacing) {
    const isMatching = (nx, ny)=>{
        if (nx < 0 || nx >= gridWidth || ny < 0 || ny >= gridHeight) return false;
        return tileGrid.has(`${nx},${ny}`);
    };
    const key = `${cx},${cy}`;
    if (isPlacing) {
        tileGrid.set(key, 0); // temporary
    } else {
        tileGrid.delete(key);
    }
    const updates = [];
    for(let dy = -1; dy <= 1; dy++){
        for(let dx = -1; dx <= 1; dx++){
            const tx = cx + dx;
            const ty = cy + dy;
            if (tx < 0 || tx >= gridWidth || ty < 0 || ty >= gridHeight) continue;
            const tKey = `${tx},${ty}`;
            if (!tileGrid.has(tKey)) {
                if (tx === cx && ty === cy && !isPlacing) {
                    updates.push({
                        x: tx,
                        y: ty,
                        tileId: null
                    });
                }
                continue;
            }
            const tileIndex = calculate47TileIndex(isMatching, tx, ty);
            tileGrid.set(tKey, tileIndex);
            updates.push({
                x: tx,
                y: ty,
                tileId: tileIndex
            });
        }
    }
    return updates;
}
function renderProceduralAutotileTile(ctx, tileIndex, px, py, tileSize, strokeColor = '#1E1B4B', fillColor = '#6366F1') {
    const mask = CANONICAL_47_MASKS[tileIndex] ?? 0;
    const hasN = (mask & 1) !== 0;
    const hasNE = (mask & 2) !== 0;
    const hasE = (mask & 4) !== 0;
    const hasSE = (mask & 8) !== 0;
    const hasS = (mask & 16) !== 0;
    const hasSW = (mask & 32) !== 0;
    const hasW = (mask & 64) !== 0;
    const hasNW = (mask & 128) !== 0;
    const inset = Math.max(1, Math.floor(tileSize / 4));
    // Fill base body
    ctx.fillStyle = fillColor;
    ctx.fillRect(px, py, tileSize, tileSize);
    ctx.fillStyle = strokeColor;
    // Cardinal Borders (if no neighbor on that side)
    if (!hasN) ctx.fillRect(px, py, tileSize, inset);
    if (!hasS) ctx.fillRect(px, py + tileSize - inset, tileSize, inset);
    if (!hasW) ctx.fillRect(px, py, inset, tileSize);
    if (!hasE) ctx.fillRect(px + tileSize - inset, py, inset, tileSize);
    // Inner Corners (when cardinal neighbors exist but diagonal does not)
    if (hasN && hasE && !hasNE) {
        ctx.fillRect(px + tileSize - inset, py, inset, inset);
    }
    if (hasS && hasE && !hasSE) {
        ctx.fillRect(px + tileSize - inset, py + tileSize - inset, inset, inset);
    }
    if (hasS && hasW && !hasSW) {
        ctx.fillRect(px, py + tileSize - inset, inset, inset);
    }
    if (hasN && hasW && !hasNW) {
        ctx.fillRect(px, py, inset, inset);
    }
}
class AutotileGrid {
    tiles = new Map();
    width;
    height;
    tileSize;
    constructor(width, height, tileSize = 8){
        this.width = width;
        this.height = height;
        this.tileSize = tileSize;
    }
    getTile(gx, gy) {
        return this.tiles.get(`${gx},${gy}`);
    }
    hasTile(gx, gy) {
        return this.tiles.has(`${gx},${gy}`);
    }
    place(gx, gy) {
        return updateAutotileAt(this.tiles, this.width, this.height, gx, gy, true);
    }
    erase(gx, gy) {
        return updateAutotileAt(this.tiles, this.width, this.height, gx, gy, false);
    }
    clear() {
        this.tiles.clear();
    }
    getAllTiles() {
        const list = [];
        for (const [k, tileId] of this.tiles.entries()){
            const [x, y] = k.split(',').map(Number);
            list.push({
                x,
                y,
                tileId
            });
        }
        return list;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/colorSpace.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * OKLab & OKLCH Color Space Transforms.
 *
 * Citation: Björn Ottosson, "A perceptual color space for image processing" (2020).
 * Provides uniform perceptual spacing for delta E color quantization,
 * lightness adjustments, and color grading.
 */ __turbopack_context__.s([
    "deltaEOKLab",
    ()=>deltaEOKLab,
    "deltaEOklab",
    ()=>deltaEOklab,
    "linearToSrgb",
    ()=>linearToSrgb,
    "okLabToOKLCH",
    ()=>okLabToOKLCH,
    "okLabToRGB",
    ()=>okLabToRGB,
    "oklabDistance",
    ()=>oklabDistance,
    "oklabToRgb",
    ()=>oklabToRgb,
    "oklchToOKLab",
    ()=>oklchToOKLab,
    "oklchToRgb",
    ()=>oklchToRgb,
    "rgbToOKLab",
    ()=>rgbToOKLab,
    "rgbToOklab",
    ()=>rgbToOklab,
    "rgbToOklch",
    ()=>rgbToOklch,
    "shiftHue",
    ()=>shiftHue,
    "shiftHueToward",
    ()=>shiftHueToward,
    "srgbToLinear",
    ()=>srgbToLinear
]);
function srgbToLinear(c) {
    const norm = c / 255;
    return norm <= 0.04045 ? norm / 12.92 : Math.pow((norm + 0.055) / 1.055, 2.4);
}
function linearToSrgb(c) {
    const clamped = Math.max(0, Math.min(1, c));
    const srgb = clamped <= 0.0031308 ? clamped * 12.92 : 1.055 * Math.pow(clamped, 1.0 / 2.4) - 0.055;
    return Math.round(Math.max(0, Math.min(255, srgb * 255)));
}
function rgbToOKLab(r, g, b) {
    const lr = srgbToLinear(r);
    const lg = srgbToLinear(g);
    const lb = srgbToLinear(b);
    const l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb);
    const m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb);
    const s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb);
    return {
        L: 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
        a: 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
        b: 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s
    };
}
function okLabToRGB(L, a, b) {
    const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
    const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
    const s_ = L - 0.0894841775 * a - 1.2914855480 * b;
    const l = l_ * l_ * l_;
    const m = m_ * m_ * m_;
    const s = s_ * s_ * s_;
    const lr = +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
    const lg = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
    const lb = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s;
    return {
        r: linearToSrgb(lr),
        g: linearToSrgb(lg),
        b: linearToSrgb(lb)
    };
}
function oklabToRgb(L, a, b) {
    const rgb = okLabToRGB(L, a, b);
    return [
        rgb.r,
        rgb.g,
        rgb.b
    ];
}
function deltaEOKLab(c1, c2) {
    const dL = c1.L - c2.L;
    const da = c1.a - c2.a;
    const db = c1.b - c2.b;
    return Math.sqrt(dL * dL + da * da + db * db);
}
function okLabToOKLCH(L, a, b) {
    const C = Math.sqrt(a * a + b * b);
    let h = Math.atan2(b, a) * 180 / Math.PI;
    if (h < 0) h += 360;
    return {
        L,
        C,
        h
    };
}
function oklchToOKLab(L, C, h) {
    const hRad = h * Math.PI / 180;
    return {
        L,
        a: C * Math.cos(hRad),
        b: C * Math.sin(hRad)
    };
}
function rgbToOklch(r, g, b) {
    const lab = rgbToOKLab(r, g, b);
    const C = Math.sqrt(lab.a * lab.a + lab.b * lab.b);
    let H = Math.atan2(lab.b, lab.a) * 180 / Math.PI;
    if (H < 0) H += 360;
    return [
        lab.L,
        C,
        H
    ];
}
function oklchToRgb(L, C, H) {
    const hRad = H * Math.PI / 180;
    const a = C * Math.cos(hRad);
    const b = C * Math.sin(hRad);
    return oklabToRgb(L, a, b);
}
function shiftHue(currentH, targetH, maxShiftDeg) {
    let diff = (targetH - currentH + 360) % 360;
    if (diff > 180) diff -= 360;
    const shift = Math.sign(diff) * Math.min(Math.abs(diff), maxShiftDeg);
    return (currentH + shift + 360) % 360;
}
const rgbToOklab = rgbToOKLab;
const deltaEOklab = deltaEOKLab;
const oklabDistance = deltaEOKLab;
const shiftHueToward = shiftHue;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/curvesAndLines.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * Quadratic Bézier Curves, Isometric 2:1 Lines, and 47-Tile Blob Autotile Bitmasks.
 */ __turbopack_context__.s([
    "getIsometric2p1Line",
    ()=>getIsometric2p1Line,
    "getQuadraticBezierPoints",
    ()=>getQuadraticBezierPoints
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$autotileEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/autotileEngine.ts [app-client] (ecmascript)");
function getQuadraticBezierPoints(p0, p1, p2, customSteps) {
    const points = [];
    const seen = new Set();
    const approxDist = Math.hypot(p1.x - p0.x, p1.y - p0.y) + Math.hypot(p2.x - p1.x, p2.y - p1.y);
    const steps = customSteps ?? Math.max(16, Math.ceil(approxDist * 1.5));
    for(let i = 0; i <= steps; i++){
        const t = i / steps;
        const mt = 1 - t;
        const x = Math.round(mt * mt * p0.x + 2 * mt * t * p1.x + t * t * p2.x);
        const y = Math.round(mt * mt * p0.y + 2 * mt * t * p1.y + t * t * p2.y);
        const key = `${x},${y}`;
        if (!seen.has(key)) {
            seen.add(key);
            points.push({
                x,
                y
            });
        }
    }
    return points;
}
function getIsometric2p1Line(x0, y0, x1, y1) {
    const dx = x1 - x0;
    const dy = y1 - y0;
    if (dx === 0 && dy === 0) return [
        {
            x: x0,
            y: y0
        }
    ];
    // Pure vertical line
    if (dx === 0) {
        const sy = dy >= 0 ? 1 : -1;
        const count = Math.abs(dy);
        const pts = [];
        for(let k = 0; k <= count; k++){
            pts.push({
                x: x0,
                y: y0 + k * sy
            });
        }
        return pts;
    }
    // Pure horizontal line
    if (dy === 0) {
        const sx = dx >= 0 ? 1 : -1;
        const count = Math.abs(dx);
        const pts = [];
        for(let k = 0; k <= count; k++){
            pts.push({
                x: x0 + k * sx,
                y: y0
            });
        }
        return pts;
    }
    const sx = dx >= 0 ? 1 : -1;
    const sy = dy >= 0 ? 1 : -1;
    const absDx = Math.abs(dx);
    const absDy = Math.abs(dy);
    // Scalar projection of (|dx|, |dy|) onto the 2:1 dimetric direction vector (2, 1):
    // t = (2 * absDx + absDy) / (2^2 + 1^2) = (2 * absDx + absDy) / 5
    const numSteps = Math.max(1, Math.round((2 * absDx + absDy) / 5));
    const points = [];
    const seen = new Set();
    for(let k = 0; k < numSteps; k++){
        const curY = y0 + k * sy;
        const curX1 = x0 + k * 2 * sx;
        const curX2 = x0 + (k * 2 + 1) * sx;
        const key1 = `${curX1},${curY}`;
        if (!seen.has(key1)) {
            seen.add(key1);
            points.push({
                x: curX1,
                y: curY
            });
        }
        const key2 = `${curX2},${curY}`;
        if (!seen.has(key2)) {
            seen.add(key2);
            points.push({
                x: curX2,
                y: curY
            });
        }
    }
    // Snapped endpoint cap on the projected 2:1 ray
    const finalX = x0 + numSteps * 2 * sx;
    const finalY = y0 + numSteps * sy;
    const finalKey = `${finalX},${finalY}`;
    if (!seen.has(finalKey)) {
        seen.add(finalKey);
        points.push({
            x: finalX,
            y: finalY
        });
    }
    return points;
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/dithering.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyAtkinsonDither",
    ()=>applyAtkinsonDither,
    "applyRiemersmaDither",
    ()=>applyRiemersmaDither,
    "getBayerMatrixThreshold",
    ()=>getBayerMatrixThreshold
]);
/**
 * Dithering Algorithms: Bayer, Atkinson, and Riemersma Hilbert Space-Filling Curve.
 *
 * Citations:
 * 1. Bryce E. Bayer, "An optimum method for two-level rendition of continuous-tone pictures",
 *    IEEE International Conference on Communications (ICC), 1973.
 * 2. Bill Atkinson, Atkinson Dithering Algorithm, Apple Computer, 1984.
 *    Fractional (1/8) error diffusion distributing error to 6 neighboring pixels, preserving specular highlights.
 * 3. Thiadmer Riemersma, "A Balanced Dithering Technique",
 *    C/C++ Users Journal, Vol. 16, No. 12, December 1998.
 *    https://www.compuphase.com/articles_pub_en.htm
 *    1D error diffusion along a recursive 2D Hilbert space-filling curve with exponential error decay.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/floodFill.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$rampGenerator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/rampGenerator.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$ditherMatrix$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/ditherMatrix.ts [app-client] (ecmascript)");
;
;
;
function getBayerMatrixThreshold(x, y, size) {
    if (size === '2x2') {
        return (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$ditherMatrix$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BAYER_2X2"][(y % 2 + 2) % 2][(x % 2 + 2) % 2] + 0.5) / 4.0;
    }
    if (size === '4x4') {
        return (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$ditherMatrix$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BAYER_4X4"][(y % 4 + 4) % 4][(x % 4 + 4) % 4] + 0.5) / 16.0;
    }
    return (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$ditherMatrix$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BAYER_8X8"][(y % 8 + 8) % 8][(x % 8 + 8) % 8] + 0.5) / 64.0;
}
function applyAtkinsonDither(srcCtx, width, height, paletteHex) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    let effectivePalette = paletteHex;
    if (!effectivePalette || effectivePalette.length < 2) {
        const canvasColors = new Set();
        for(let i = 0; i < data.length; i += 4){
            if (data[i + 3] > 30) {
                canvasColors.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbaToHex"])(data[i], data[i + 1], data[i + 2], 255));
            }
        }
        const customPalette = new Set();
        canvasColors.forEach((c)=>{
            customPalette.add(c);
            const ramp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$rampGenerator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateOklchRamp"])(c);
            ramp.forEach((rc)=>customPalette.add(rc));
        });
        effectivePalette = Array.from(customPalette).slice(0, 16);
    }
    if (effectivePalette.length === 0) return;
    const palRgba = effectivePalette.map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgba"]);
    const rBuf = new Float32Array(width * height);
    const gBuf = new Float32Array(width * height);
    const bBuf = new Float32Array(width * height);
    for(let i = 0; i < width * height; i++){
        rBuf[i] = data[i * 4];
        gBuf[i] = data[i * 4 + 1];
        bBuf[i] = data[i * 4 + 2];
    }
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            if (data[idx * 4 + 3] <= 30) continue;
            const oldR = Math.max(0, Math.min(255, rBuf[idx]));
            const oldG = Math.max(0, Math.min(255, gBuf[idx]));
            const oldB = Math.max(0, Math.min(255, bBuf[idx]));
            let closest = palRgba[0];
            let minDiff = Infinity;
            for (const c of palRgba){
                const diff = (oldR - c.r) ** 2 + (oldG - c.g) ** 2 + (oldB - c.b) ** 2;
                if (diff < minDiff) {
                    minDiff = diff;
                    closest = c;
                }
            }
            data[idx * 4] = closest.r;
            data[idx * 4 + 1] = closest.g;
            data[idx * 4 + 2] = closest.b;
            const errR = (oldR - closest.r) / 8;
            const errG = (oldG - closest.g) / 8;
            const errB = (oldB - closest.b) / 8;
            const offsets = [
                [
                    x + 1,
                    y
                ],
                [
                    x + 2,
                    y
                ],
                [
                    x - 1,
                    y + 1
                ],
                [
                    x,
                    y + 1
                ],
                [
                    x + 1,
                    y + 1
                ],
                [
                    x,
                    y + 2
                ]
            ];
            for (const [nx, ny] of offsets){
                if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                    const nIdx = ny * width + nx;
                    if (data[nIdx * 4 + 3] > 30) {
                        rBuf[nIdx] += errR;
                        gBuf[nIdx] += errG;
                        bBuf[nIdx] += errB;
                    }
                }
            }
        }
    }
    srcCtx.putImageData(imgData, 0, 0);
}
function applyRiemersmaDither(srcCtx, width, height, paletteHex) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    let effectivePalette = paletteHex;
    if (!effectivePalette || effectivePalette.length < 2) {
        const canvasColors = new Set();
        for(let i = 0; i < data.length; i += 4){
            if (data[i + 3] > 30) {
                canvasColors.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbaToHex"])(data[i], data[i + 1], data[i + 2], 255));
            }
        }
        const customPalette = new Set();
        canvasColors.forEach((c)=>{
            customPalette.add(c);
            const ramp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$rampGenerator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateOklchRamp"])(c);
            ramp.forEach((rc)=>customPalette.add(rc));
        });
        effectivePalette = Array.from(customPalette).slice(0, 16);
    }
    if (effectivePalette.length === 0) return;
    const palRgba = effectivePalette.map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgba"]);
    let order = 1;
    while(order < Math.max(width, height)){
        order *= 2;
    }
    const numPoints = order * order;
    const historyLength = 16;
    const errR = new Array(historyLength).fill(0);
    const errG = new Array(historyLength).fill(0);
    const errB = new Array(historyLength).fill(0);
    // A 16:1 newest-to-oldest weight ratio keeps recent quantization error
    // strong enough to dither while retaining spatial context along the curve.
    const decay = Math.pow(1 / 16, 1 / (historyLength - 1));
    for(let d = 0; d < numPoints; d++){
        let rx, ry, s;
        let t = d;
        let x = 0;
        let y = 0;
        for(s = 1; s < order; s *= 2){
            rx = 1 & Math.floor(t / 2);
            ry = 1 & (t ^ rx);
            if (ry === 0) {
                if (rx === 1) {
                    x = s - 1 - x;
                    y = s - 1 - y;
                }
                const temp = x;
                x = y;
                y = temp;
            }
            x += s * rx;
            y += s * ry;
            t = Math.floor(t / 4);
        }
        if (x >= width || y >= height) continue;
        const idx = y * width + x;
        if (data[idx * 4 + 3] <= 30) continue;
        let totalErrR = 0;
        let totalErrG = 0;
        let totalErrB = 0;
        for(let i = 0; i < historyLength; i++){
            const weight = Math.pow(decay, historyLength - 1 - i);
            totalErrR += errR[i] * weight;
            totalErrG += errG[i] * weight;
            totalErrB += errB[i] * weight;
        }
        const r = Math.max(0, Math.min(255, data[idx * 4] + totalErrR));
        const g = Math.max(0, Math.min(255, data[idx * 4 + 1] + totalErrG));
        const b = Math.max(0, Math.min(255, data[idx * 4 + 2] + totalErrB));
        let closest = palRgba[0];
        let minDiff = Infinity;
        for (const c of palRgba){
            const diff = (r - c.r) ** 2 + (g - c.g) ** 2 + (b - c.b) ** 2;
            if (diff < minDiff) {
                minDiff = diff;
                closest = c;
            }
        }
        const qErrR = data[idx * 4] + totalErrR - closest.r;
        const qErrG = data[idx * 4 + 1] + totalErrG - closest.g;
        const qErrB = data[idx * 4 + 2] + totalErrB - closest.b;
        data[idx * 4] = closest.r;
        data[idx * 4 + 1] = closest.g;
        data[idx * 4 + 2] = closest.b;
        errR.shift();
        errR.push(qErrR);
        errG.shift();
        errG.push(qErrG);
        errB.shift();
        errB.push(qErrB);
    }
    srcCtx.putImageData(imgData, 0, 0);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/edtNormalMap.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyAppendageStabilization",
    ()=>applyAppendageStabilization,
    "applyBilateralFilter",
    ()=>applyBilateralFilter,
    "bakeNormalMapToCanvas",
    ()=>bakeNormalMapToCanvas,
    "bakeNormalMapToRgba",
    ()=>bakeNormalMapToRgba,
    "computeContentAwareHeightmap",
    ()=>computeContentAwareHeightmap,
    "computeDiscreteLaplaceCavity",
    ()=>computeDiscreteLaplaceCavity,
    "computeSeparableEDT",
    ()=>computeSeparableEDT,
    "computeTangentNormalField",
    ()=>computeTangentNormalField,
    "generateInflatedHeightmap",
    ()=>generateInflatedHeightmap
]);
/**
 * Linear-Time Euclidean Distance Transform (EDT), Dome Heightmap Inflation & Normal Map Generator.
 *
 * Citations:
 * 1. Pedro F. Felzenszwalb & Daniel P. Huttenlocher, "Distance Transforms of Sampled Functions",
 *    Theory of Computing, 8(19): 415–428, 2012 (orig. Cornell Computing and Information Science TR2004-1963, 2004).
 *    Provides linear-time O(W * H) exact 2D squared Euclidean distance transform via lower parabolic envelopes.
 * 2. C. Tomasi & R. Manduchi, "Bilateral Filtering for Gray and Color Images",
 *    IEEE International Conference on Computer Vision (ICCV), 1998.
 *    Non-linear edge-preserving height smoothing preserving silhouette boundaries.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferPool.ts [app-client] (ecmascript)");
;
const INF = 1e9;
/**
 * Computes the 1D squared distance transform of an array in O(N) time using lower parabolic envelopes.
 */ function dt1D(f, n, d, v, z) {
    let k = 0;
    v[0] = 0;
    z[0] = -INF;
    z[1] = INF;
    for(let q = 1; q < n; q++){
        let s = (f[q] + q * q - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]);
        while(s <= z[k]){
            k--;
            s = (f[q] + q * q - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]);
        }
        k++;
        v[k] = q;
        z[k] = s;
        z[k + 1] = INF;
    }
    k = 0;
    for(let q = 0; q < n; q++){
        while(z[k + 1] < q){
            k++;
        }
        const dx = q - v[k];
        d[q] = dx * dx + f[v[k]];
    }
}
function computeSeparableEDT(isOpaque, width, height) {
    const maxDim = Math.max(width, height);
    const fScratch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["acquireFloat32Buffer"])(maxDim);
    const dScratch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["acquireFloat32Buffer"])(maxDim);
    const vScratch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["acquireInt32Buffer"])(maxDim);
    const zScratch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["acquireFloat32Buffer"])(maxDim + 1);
    try {
        const grid = new Float32Array(width * height);
        for(let x = 0; x < width; x++){
            for(let y = 0; y < height; y++){
                fScratch[y] = isOpaque(x, y) ? INF : 0;
            }
            dt1D(fScratch, height, dScratch, vScratch, zScratch);
            for(let y = 0; y < height; y++){
                grid[y * width + x] = dScratch[y];
            }
        }
        const distance = new Float32Array(width * height);
        for(let y = 0; y < height; y++){
            for(let x = 0; x < width; x++){
                fScratch[x] = grid[y * width + x];
            }
            dt1D(fScratch, width, dScratch, vScratch, zScratch);
            for(let x = 0; x < width; x++){
                distance[y * width + x] = Math.sqrt(dScratch[x]);
            }
        }
        return distance;
    } finally{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["releaseFloat32Buffer"])(fScratch);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["releaseFloat32Buffer"])(dScratch);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["releaseInt32Buffer"])(vScratch);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["releaseFloat32Buffer"])(zScratch);
    }
}
function generateInflatedHeightmap(distanceMap, width, height, gamma = 0.5) {
    let maxD = 0;
    for(let i = 0; i < distanceMap.length; i++){
        if (distanceMap[i] > maxD) maxD = distanceMap[i];
    }
    if (maxD <= 0) maxD = 1;
    const heightmap = new Float32Array(width * height);
    for(let i = 0; i < distanceMap.length; i++){
        if (distanceMap[i] > 0) {
            const normalizedD = Math.min(1.0, distanceMap[i] / maxD);
            // Spherical dome inflation: z = sqrt(1 - (1 - d)^2).
            // The spherical term flattens at the apex; the 25% gamma blend retains a nonzero slope.
            const u = 1.0 - normalizedD;
            const sphereDome = Math.sqrt(Math.max(0, 1.0 - u * u));
            const gammaDome = Math.pow(normalizedD, gamma);
            heightmap[i] = maxD * (sphereDome * 0.75 + gammaDome * 0.25);
        }
    }
    return heightmap;
}
function applyBilateralFilter(src, width, height, sigmaSpatial = 1.5, sigmaRange = 2.0) {
    if (width <= 0 || height <= 0) return new Float32Array(0);
    if (sigmaSpatial <= 0 || sigmaRange <= 0) return new Float32Array(src);
    const dst = new Float32Array(width * height);
    const radius = Math.ceil(sigmaSpatial * 2);
    const twoSigmaSpatialSq = 2 * sigmaSpatial * sigmaSpatial;
    const twoSigmaRangeSq = 2 * sigmaRange * sigmaRange;
    // Precompute 2D spatial Gaussian distance lookup table (spatialLUT) once per (radius, sigmaSpatial)
    const kernelDim = 2 * radius + 1;
    const spatialLUT = new Float32Array(kernelDim * kernelDim);
    for(let dy = -radius; dy <= radius; dy++){
        for(let dx = -radius; dx <= radius; dx++){
            const spatialDistSq = dx * dx + dy * dy;
            spatialLUT[(dy + radius) * kernelDim + (dx + radius)] = Math.exp(-spatialDistSq / twoSigmaSpatialSq);
        }
    }
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const centerH = src[y * width + x];
            if (centerH <= 0) continue;
            let sum = 0;
            let totalWeight = 0;
            for(let dy = -radius; dy <= radius; dy++){
                const ny = y + dy;
                if (ny < 0 || ny >= height) continue;
                const rowOffset = (dy + radius) * kernelDim;
                for(let dx = -radius; dx <= radius; dx++){
                    const nx = x + dx;
                    if (nx < 0 || nx >= width) continue;
                    const neighborH = src[ny * width + nx];
                    if (neighborH <= 0) continue;
                    const rangeDistSq = (centerH - neighborH) * (centerH - neighborH);
                    const spatialWeight = spatialLUT[rowOffset + (dx + radius)];
                    const w = spatialWeight * Math.exp(-rangeDistSq / twoSigmaRangeSq);
                    sum += neighborH * w;
                    totalWeight += w;
                }
            }
            dst[y * width + x] = totalWeight > 0 ? sum / totalWeight : centerH;
        }
    }
    return dst;
}
function computeTangentNormalField(heightmap, width, height, depthScale = 2.0) {
    const nx = new Float32Array(width * height);
    const ny = new Float32Array(width * height);
    const nz = new Float32Array(width * height);
    const getH = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return 0;
        return heightmap[y * width + x];
    };
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            if (heightmap[idx] <= 0) {
                nx[idx] = 0;
                ny[idx] = 0;
                nz[idx] = 1;
                continue;
            }
            // Sobel kernel for Gx (dH/dx)
            const Gx = (-1 * getH(x - 1, y - 1) + 1 * getH(x + 1, y - 1) + -2 * getH(x - 1, y) + 2 * getH(x + 1, y) + -1 * getH(x - 1, y + 1) + 1 * getH(x + 1, y + 1)) / 8.0;
            // Sobel kernel for Gy (dH/dy)
            const Gy = (-1 * getH(x - 1, y - 1) - 2 * getH(x, y - 1) - 1 * getH(x + 1, y - 1) + 1 * getH(x - 1, y + 1) + 2 * getH(x, y + 1) + 1 * getH(x + 1, y + 1)) / 8.0;
            const sx = -Gx * depthScale;
            const sy = -Gy * depthScale;
            const sz = 1.0;
            const len = Math.sqrt(sx * sx + sy * sy + sz * sz) || 1;
            nx[idx] = sx / len;
            ny[idx] = sy / len;
            nz[idx] = sz / len;
        }
    }
    return {
        nx,
        ny,
        nz,
        width,
        height
    };
}
function bakeNormalMapToRgba(normalField, width, height, mask) {
    const data = new Uint8ClampedArray(width * height * 4);
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            const pIdx = idx * 4;
            if (mask && !mask(x, y)) {
                data[pIdx] = 0;
                data[pIdx + 1] = 0;
                data[pIdx + 2] = 0;
                data[pIdx + 3] = 0;
                continue;
            }
            // Encode normal [-1, 1] to RGB [0, 255]
            const r = Math.round((normalField.nx[idx] + 1) / 2 * 255);
            const g = Math.round((-normalField.ny[idx] + 1) / 2 * 255); // Invert Y for OpenGL tangent map convention
            const b = Math.round((normalField.nz[idx] + 1) / 2 * 255);
            data[pIdx] = r;
            data[pIdx + 1] = g;
            data[pIdx + 2] = b;
            data[pIdx + 3] = 255;
        }
    }
    return data;
}
function bakeNormalMapToCanvas(normalField, width, height, mask) {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    const rgba = bakeNormalMapToRgba(normalField, width, height, mask);
    const imgData = new ImageData(new Uint8ClampedArray(rgba.buffer), width, height);
    ctx.putImageData(imgData, 0, 0);
    return canvas;
}
function computeDiscreteLaplaceCavity(heightmap, width, height, cavityStrength = 1.0) {
    const cavity = new Float32Array(width * height);
    const neighborDx = [
        0,
        -1,
        1,
        0
    ];
    const neighborDy = [
        -1,
        0,
        0,
        1
    ];
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            const center = heightmap[idx];
            if (center <= 0) {
                cavity[idx] = 1.0;
                continue;
            }
            // Cavity occurs where surrounding opaque geometry rises higher than center (concave valley/crevice/seam)
            // Transparent background pixels (nH <= 0) represent open environment and do not occlude.
            let occlusion = 0;
            let count = 0;
            for(let n = 0; n < 4; n++){
                const nx = x + neighborDx[n];
                const ny = y + neighborDy[n];
                if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                    const nH = heightmap[ny * width + nx];
                    if (nH > 0) {
                        count++;
                        if (nH > center) {
                            occlusion += nH - center;
                        }
                    }
                }
            }
            const meanOcclusion = count > 0 ? occlusion / count : 0;
            cavity[idx] = Math.max(0.0, Math.min(1.0, 1.0 - cavityStrength * (meanOcclusion * 2.0)));
        }
    }
    return cavity;
}
function applyAppendageStabilization(targetNormals, baseNormals, appendageData, lightAzimuth) {
    const azRad = lightAzimuth * Math.PI / 180;
    const lightDirX = Math.sin(azRad);
    const { charCenterX, pixels } = appendageData;
    for(let i = 0; i < pixels.length; i++){
        const { idx, segLeft, segRight } = pixels[i];
        let nx = baseNormals.nx[idx];
        const ny = baseNormals.ny[idx];
        let nz = baseNormals.nz[idx];
        const isLitSide = lightDirX <= 0 && segRight <= charCenterX || lightDirX > 0 && segLeft >= charCenterX;
        if (isLitSide) {
            if (lightDirX <= 0 && nx > 0) {
                nx = 0;
            } else if (lightDirX > 0 && nx < 0) {
                nx = 0;
            }
            nz = Math.max(0.88, nz);
        } else {
            nz = Math.max(0.78, nz);
        }
        const len = Math.hypot(nx, ny, nz) || 1;
        targetNormals.nx[idx] = nx / len;
        targetNormals.ny[idx] = ny / len;
        targetNormals.nz[idx] = nz / len;
    }
}
function computeContentAwareHeightmap(data, width, height, cavityStrength = 1.0, depthScale = 2.0, lightAzimuth) {
    const totalPixels = width * height;
    const isInkLine = new Uint8Array(totalPixels);
    const isFeature = new Uint8Array(totalPixels);
    const componentMap = new Int32Array(totalPixels);
    const colorHue = new Float32Array(totalPixels);
    const colorChroma = new Float32Array(totalPixels);
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    // 1. Calculate luminance & local contrast to detect line art and contours
    const lum = new Float32Array(totalPixels);
    let opaqueCount = 0;
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            const p = idx * 4;
            if (data[p + 3] <= 30) continue;
            opaqueCount++;
            const r = data[p];
            const g = data[p + 1];
            const b = data[p + 2];
            lum[idx] = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
            const maxChannel = Math.max(r, g, b);
            const minChannel = Math.min(r, g, b);
            const chroma = maxChannel - minChannel;
            colorChroma[idx] = chroma / 255;
            if (chroma > 0) {
                let hueSector;
                if (maxChannel === r) {
                    hueSector = (g - b) / chroma % 6;
                } else if (maxChannel === g) {
                    hueSector = (b - r) / chroma + 2;
                } else {
                    hueSector = (r - g) / chroma + 4;
                }
                colorHue[idx] = (hueSector * 60 + 360) % 360;
            }
        }
    }
    if (opaqueCount === 0) {
        const emptyH = new Float32Array(totalPixels);
        const emptyNorm = {
            nx: new Float32Array(totalPixels),
            ny: new Float32Array(totalPixels),
            nz: new Float32Array(totalPixels).fill(1.0),
            width,
            height
        };
        return {
            isInkLine,
            isFeature,
            componentMap,
            numComponents: 0,
            macroHeightmap: emptyH,
            microHeightmap: new Float32Array(totalPixels),
            compositeHeightmap: new Float32Array(totalPixels),
            smoothHeightmap: new Float32Array(totalPixels),
            normalField: emptyNorm,
            cavityAO: new Float32Array(totalPixels).fill(1.0)
        };
    }
    // 2. Identify line art / dark ink lines / crevices
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            if (!isOpaque(x, y)) continue;
            const myLum = lum[idx];
            let touchesTransparent = false;
            let maxNeighborLum = 0;
            const neighborLum = {};
            const neighbors = [
                [
                    x + 1,
                    y,
                    'right'
                ],
                [
                    x - 1,
                    y,
                    'left'
                ],
                [
                    x,
                    y + 1,
                    'down'
                ],
                [
                    x,
                    y - 1,
                    'up'
                ]
            ];
            for (const [nx, ny, direction] of neighbors){
                if (!isOpaque(nx, ny)) {
                    touchesTransparent = true;
                } else {
                    const nLum = lum[ny * width + nx];
                    neighborLum[direction] = nLum;
                    if (nLum > maxNeighborLum) maxNeighborLum = nLum;
                }
            }
            // Outer dark contour: touches transparent background AND is very dark (black/dark border)
            if (touchesTransparent && myLum < 0.30) {
                isInkLine[idx] = 1;
                continue;
            }
            // Interior ink is a thin stroke with brighter artwork on both opposing
            // sides. A one-sided luminance step is usually the boundary of a painted
            // shadow, not permanent line art; treating it as ink bakes that old
            // lighting direction into every subsequent relight.
            const horizontalStroke = (neighborLum.left ?? myLum) - myLum >= 0.12 && (neighborLum.right ?? myLum) - myLum >= 0.12;
            const verticalStroke = (neighborLum.up ?? myLum) - myLum >= 0.12 && (neighborLum.down ?? myLum) - myLum >= 0.12;
            if (horizontalStroke || verticalStroke) {
                isInkLine[idx] = 1;
                continue;
            }
            // True pure black pixels (#000000 or near-black) at or near boundary
            if (myLum < 0.035 && (touchesTransparent || maxNeighborLum > 0.07)) {
                isInkLine[idx] = 1;
            }
        }
    }
    // 3. Identify dark facial / internal features (eyes, mouth)
    const visitedFeature = new Uint8Array(totalPixels);
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            if (isInkLine[idx] !== 1 || visitedFeature[idx]) continue;
            const queue = [
                idx
            ];
            visitedFeature[idx] = 1;
            const cluster = [];
            let touchesBackground = false;
            let clusterMinX = width, clusterMaxX = 0, clusterMinY = height, clusterMaxY = 0;
            let qHead = 0;
            while(qHead < queue.length){
                const cur = queue[qHead++];
                cluster.push(cur);
                const cx = cur % width;
                const cy = Math.floor(cur / width);
                if (cx < clusterMinX) clusterMinX = cx;
                if (cx > clusterMaxX) clusterMaxX = cx;
                if (cy < clusterMinY) clusterMinY = cy;
                if (cy > clusterMaxY) clusterMaxY = cy;
                for(let dy = -1; dy <= 1; dy++){
                    for(let dx = -1; dx <= 1; dx++){
                        if (dx === 0 && dy === 0) continue;
                        const nx = cx + dx;
                        const ny = cy + dy;
                        if (nx < 0 || nx >= width || ny < 0 || ny >= height || !isOpaque(nx, ny)) {
                            touchesBackground = true;
                            continue;
                        }
                        const nIdx = ny * width + nx;
                        if (isInkLine[nIdx] === 1 && !visitedFeature[nIdx]) {
                            visitedFeature[nIdx] = 1;
                            queue.push(nIdx);
                        }
                    }
                }
            }
            const clusterW = clusterMaxX - clusterMinX + 1;
            const clusterH = clusterMaxY - clusterMinY + 1;
            // Facial features (eyes, pupils, nostrils, mouth) are compact islands.
            // Longitudinal seams (arm outlines) and transverse strokes (chin/jawline, collar) are structural ink lines.
            const isLongitudinalStroke = clusterH >= Math.max(6, Math.floor(height * 0.14)) && clusterH > clusterW * 1.8;
            const isTransverseStroke = clusterW >= Math.max(7, Math.floor(width * 0.20)) && clusterW > clusterH * 1.8;
            const isCompactFeature = !isLongitudinalStroke && !isTransverseStroke && cluster.length <= Math.max(24, Math.floor(opaqueCount * 0.08));
            if (!touchesBackground && isCompactFeature) {
                for (const fIdx of cluster){
                    isFeature[fIdx] = 1;
                }
            }
        }
    }
    // 4. Connected Components for Non-Ink Interior Parts
    let currentComponent = 0;
    const visitedComp = new Uint8Array(totalPixels);
    const compMembers = [
        []
    ];
    const neighborDx = [
        1,
        -1,
        0,
        0
    ];
    const neighborDy = [
        0,
        0,
        1,
        -1
    ];
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            if (!isOpaque(x, y) || isInkLine[idx] === 1 || visitedComp[idx]) continue;
            currentComponent++;
            const compId = currentComponent;
            const queue = [
                idx
            ];
            visitedComp[idx] = 1;
            componentMap[idx] = compId;
            const p0 = idx * 4;
            const baseR = data[p0];
            const baseG = data[p0 + 1];
            const baseB = data[p0 + 2];
            const baseHue = colorHue[idx];
            const baseChroma = colorChroma[idx];
            let qHead = 0;
            while(qHead < queue.length){
                const cur = queue[qHead++];
                const cx = cur % width;
                const cy = Math.floor(cur / width);
                for(let direction = 0; direction < 4; direction++){
                    const nx = cx + neighborDx[direction];
                    const ny = cy + neighborDy[direction];
                    if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
                    const nIdx = ny * width + nx;
                    if (!isOpaque(nx, ny) || isInkLine[nIdx] === 1 || visitedComp[nIdx]) continue;
                    const np = nIdx * 4;
                    const dr = Math.abs(data[np] - baseR);
                    const dg = Math.abs(data[np + 1] - baseG);
                    const db = Math.abs(data[np + 2] - baseB);
                    const rawHueDistance = Math.abs(colorHue[nIdx] - baseHue);
                    const hueDistance = Math.min(rawHueDistance, 360 - rawHueDistance);
                    const sameAuthoredRamp = baseChroma >= 0.05 && colorChroma[nIdx] >= 0.05 && hueDistance <= 35 && Math.abs(colorChroma[nIdx] - baseChroma) <= 0.25;
                    if (dr < 48 && dg < 48 && db < 48 || sameAuthoredRamp) {
                        visitedComp[nIdx] = 1;
                        componentMap[nIdx] = compId;
                        queue.push(nIdx);
                    }
                }
            }
            compMembers.push(queue);
        }
    }
    // 5. Global Macro Distance Field (Overall Form)
    const macroDist = computeSeparableEDT(isOpaque, width, height);
    let maxMacroD = 0;
    for(let i = 0; i < totalPixels; i++){
        if (macroDist[i] > maxMacroD) maxMacroD = macroDist[i];
    }
    if (maxMacroD <= 0) maxMacroD = 1;
    // Determine if artwork represents a character/creature (ears or internal facial features)
    let isCharacter = false;
    for(let i = 0; i < totalPixels; i++){
        if (isFeature[i] === 1) {
            isCharacter = true;
            break;
        }
    }
    let minX = width, maxX = 0, minY = height, maxY = 0;
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            if (isOpaque(x, y)) {
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
    }
    const boxH = Math.max(1, maxY - minY + 1);
    if (!isCharacter) {
        const scanRows = Math.max(4, Math.floor(boxH * 0.45));
        for(let y = minY; y < minY + scanRows; y++){
            let segments = 0;
            let inSeg = false;
            for(let x = minX; x <= maxX; x++){
                const op = isOpaque(x, y);
                if (op && !inSeg) {
                    segments++;
                    inSeg = true;
                } else if (!op && inSeg) {
                    inSeg = false;
                }
            }
            if (segments >= 2) {
                isCharacter = true;
                break;
            }
        }
    }
    const scaleFactor = Math.max(1.0, Math.min(width, height) / 32);
    const charBevelRadius = 2.8 * scaleFactor;
    const macroHeightmap = new Float32Array(totalPixels);
    for(let i = 0; i < totalPixels; i++){
        if (macroDist[i] > 0) {
            if (isCharacter) {
                // Frontal face cushion: scaled outer bevel rim proportional to canvas scale, level camera-facing plateau across face interior
                const rimRatio = Math.min(1.0, macroDist[i] / charBevelRadius);
                macroHeightmap[i] = maxMacroD * Math.pow(rimRatio, 0.5);
            } else {
                macroHeightmap[i] = maxMacroD * Math.pow(Math.min(1.0, macroDist[i] / maxMacroD), 0.5);
            }
        }
    }
    // 6. Micro Local Part Distance & Beveling Field
    const microDist = new Float32Array(totalPixels);
    const bevelRadius = Math.max(2.5, Math.min(6.0 * scaleFactor, maxMacroD * 0.45));
    if (currentComponent > 0) {
        // Components are disjoint, so each cell in this shared buffer is written
        // only by its owning component. No per-component canvas or bbox clear is needed.
        const cDist = new Float32Array(totalPixels);
        for(let c = 1; c <= currentComponent; c++){
            const compPixels = compMembers[c];
            const borderQueue = [];
            for (const idx of compPixels){
                const x = idx % width;
                const y = Math.floor(idx / width);
                const isBorder = x === 0 || x === width - 1 || y === 0 || y === height - 1 || componentMap[idx + 1] !== c || componentMap[idx - 1] !== c || componentMap[idx + width] !== c || componentMap[idx - width] !== c;
                if (isBorder) {
                    cDist[idx] = 1.0;
                    borderQueue.push(idx);
                }
            }
            let bHead = 0;
            let maxPartD = 1.0;
            while(bHead < borderQueue.length){
                const cur = borderQueue[bHead++];
                const curD = cDist[cur];
                if (curD > maxPartD) maxPartD = curD;
                const cx = cur % width;
                const cy = Math.floor(cur / width);
                for(let direction = 0; direction < 4; direction++){
                    const nx = cx + neighborDx[direction];
                    const ny = cy + neighborDy[direction];
                    if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
                    const nIdx = ny * width + nx;
                    if (componentMap[nIdx] === c) {
                        if (cDist[nIdx] === 0) {
                            cDist[nIdx] = curD + 1.0;
                            borderQueue.push(nIdx);
                        }
                    }
                }
            }
            for (const idx of compPixels){
                const norm = Math.min(1.0, cDist[idx] / Math.max(1.0, maxPartD));
                microDist[idx] = Math.pow(norm, 0.55) * Math.min(maxPartD, bevelRadius);
            }
        }
    }
    const microHeightmap = new Float32Array(totalPixels);
    for(let i = 0; i < totalPixels; i++){
        if (macroDist[i] > 0) {
            const generalBevel = Math.min(1.0, macroDist[i] / bevelRadius);
            const generalBevelH = Math.pow(generalBevel, 0.5) * bevelRadius;
            microHeightmap[i] = Math.max(microDist[i], generalBevelH);
        }
    }
    // 7. Composite Heightmap: neutral macro form plus local material detail.
    // Keep geometry independent of light direction. The renderer moves light and
    // shadow over this surface instead of baking guessed head/neck/limb zones into it.
    const compositeHeightmap = new Float32Array(totalPixels);
    for(let i = 0; i < totalPixels; i++){
        if (macroDist[i] <= 0) continue;
        if (isFeature[i] === 1) {
            compositeHeightmap[i] = macroHeightmap[i];
        } else if (isInkLine[i] === 1) {
            compositeHeightmap[i] = macroHeightmap[i] * (isCharacter ? 0.70 : 0.28);
        } else {
            const microScaled = microHeightmap[i] / bevelRadius * maxMacroD;
            if (isCharacter) {
                compositeHeightmap[i] = macroHeightmap[i] * 0.70 + microScaled * 0.30;
            } else {
                compositeHeightmap[i] = macroHeightmap[i] * 0.58 + microScaled * 0.42;
            }
        }
    }
    // 8. Bilateral Filtering
    const smoothHeightmap = applyBilateralFilter(compositeHeightmap, width, height, 1.2, 1.6);
    // 9. Tangent-Space Normal Vector Field
    const normalField = computeTangentNormalField(smoothHeightmap, width, height, depthScale);
    let baseNormalField = undefined;
    let appendageData = null;
    if (isCharacter) {
        const charCenterX = (minX + maxX) / 2;
        const appendagePixels = [];
        // Flatten normals across facial features, thin whiskers, and collect narrow lit-side appendages
        for(let y = 0; y < height; y++){
            for(let x = 0; x < width; x++){
                const idx = y * width + x;
                if (!isOpaque(x, y)) continue;
                if (isFeature[idx] === 1) {
                    // Pure frontal normal for eyes/mouth
                    normalField.nx[idx] = 0;
                    normalField.ny[idx] = 0;
                    normalField.nz[idx] = 1.0;
                    continue;
                }
                // Whisker / thin lateral 1px protrusion detection
                const hasLeft = isOpaque(x - 1, y);
                const hasRight = isOpaque(x + 1, y);
                const hasTop = isOpaque(x, y - 1);
                const hasBottom = isOpaque(x, y + 1);
                const isThinHorizontal = !hasTop && !hasBottom && (hasLeft || hasRight);
                const isThinVertical = !hasLeft && !hasRight && (hasTop || hasBottom);
                if (isThinHorizontal || isThinVertical) {
                    normalField.nx[idx] = 0;
                    normalField.ny[idx] = 0;
                    normalField.nz[idx] = 1.0;
                    continue;
                }
                // Narrow appendage (ear / horn / antenna) candidate detection
                if (y <= minY + boxH * 0.45) {
                    let segLeft = x;
                    while(segLeft > 0 && isOpaque(segLeft - 1, y))segLeft--;
                    let segRight = x;
                    while(segRight < width - 1 && isOpaque(segRight + 1, y))segRight++;
                    const segW = segRight - segLeft + 1;
                    const maxAppendageWidth = Math.max(5, Math.round(5 * scaleFactor));
                    if (segW <= maxAppendageWidth) {
                        appendagePixels.push({
                            idx,
                            segLeft,
                            segRight
                        });
                    }
                }
            }
        }
        if (appendagePixels.length > 0) {
            appendageData = {
                charCenterX,
                pixels: appendagePixels
            };
            baseNormalField = {
                nx: new Float32Array(normalField.nx),
                ny: new Float32Array(normalField.ny),
                nz: new Float32Array(normalField.nz),
                width,
                height
            };
            applyAppendageStabilization(normalField, baseNormalField, appendageData, lightAzimuth ?? 315);
        }
    }
    // 10. Discrete Laplace Cavity Map / Ambient Occlusion
    const cavityAO = computeDiscreteLaplaceCavity(smoothHeightmap, width, height, cavityStrength);
    return {
        isInkLine,
        isFeature,
        componentMap,
        numComponents: currentComponent,
        macroHeightmap,
        microHeightmap,
        compositeHeightmap,
        smoothHeightmap,
        normalField,
        cavityAO,
        baseNormalField,
        appendageData
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/minecraftSkin.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Minecraft Player Skin UV Texture Detection, Normal Fields & Photometric Shading Engine.
 *
 * Based on the 64x64 and 64x32 Minecraft player-skin UV layouts.
 * Implements 3D cuboid normal projection, anatomical contact ambient occlusion,
 * sky hemisphere gradients, and OKLCH non-destructive warm/cool hue modulation.
 */ __turbopack_context__.s([
    "analyzeMinecraftSkinTopology",
    ()=>analyzeMinecraftSkinTopology,
    "computeMinecraftSkinNormalField",
    ()=>computeMinecraftSkinNormalField,
    "detectMinecraftSkin",
    ()=>detectMinecraftSkin,
    "executeMinecraftSkinShadingPipeline",
    ()=>executeMinecraftSkinShadingPipeline
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/colorSpace.ts [app-client] (ecmascript)");
;
function analyzeMinecraftSkinTopology(isOpaque, width, height) {
    if (width !== 64 || height !== 64 && height !== 32) {
        return {
            isSkin: false,
            confidence: 0,
            islandCount: 0,
            largestComponentRatio: 0,
            voidOpaqueRatio: 0,
            hasHeadFaces: false,
            hasTorsoOrLimbs: false,
            isContiguousSingleSilhouette: false,
            rationale: `Dimensions ${width}x${height} do not match Minecraft skin format (64x64 or 64x32).`
        };
    }
    // 1. Gather all opaque pixels and compute 8-connected components
    const visited = new Uint8Array(width * height);
    const components = [];
    let totalOpaque = 0;
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            if (isOpaque(x, y)) {
                totalOpaque++;
                if (!visited[idx]) {
                    // BFS / flood fill for connected component
                    let compSize = 0;
                    const queue = [
                        x,
                        y
                    ];
                    visited[idx] = 1;
                    let qHead = 0;
                    while(qHead < queue.length){
                        const qx = queue[qHead++];
                        const qy = queue[qHead++];
                        compSize++;
                        for(let dy = -1; dy <= 1; dy++){
                            for(let dx = -1; dx <= 1; dx++){
                                if (dx === 0 && dy === 0) continue;
                                const nx = qx + dx;
                                const ny = qy + dy;
                                if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                                    const nIdx = ny * width + nx;
                                    if (!visited[nIdx] && isOpaque(nx, ny)) {
                                        visited[nIdx] = 1;
                                        queue.push(nx, ny);
                                    }
                                }
                            }
                        }
                    }
                    components.push(compSize);
                }
            }
        }
    }
    if (totalOpaque < 16) {
        return {
            isSkin: false,
            confidence: 0,
            islandCount: 0,
            largestComponentRatio: 0,
            voidOpaqueRatio: 0,
            hasHeadFaces: false,
            hasTorsoOrLimbs: false,
            isContiguousSingleSilhouette: false,
            rationale: 'Fewer than 16 opaque pixels on canvas.'
        };
    }
    components.sort((a, b)=>b - a);
    const largestComp = components[0];
    const largestRatio = largestComp / totalOpaque;
    let minX = width;
    let maxX = -1;
    let minY = height;
    let maxY = -1;
    for(let py = 0; py < height; py++){
        for(let px = 0; px < width; px++){
            if (isOpaque(px, py)) {
                if (px < minX) minX = px;
                if (px > maxX) maxX = px;
                if (py < minY) minY = py;
                if (py > maxY) maxY = py;
            }
        }
    }
    // 2. Canonical Void Zones Check
    const voidZones = [
        {
            x: 0,
            y: 0,
            w: 8,
            h: 8
        },
        {
            x: 24,
            y: 0,
            w: 8,
            h: 8
        },
        {
            x: 32,
            y: 0,
            w: 8,
            h: 8
        },
        {
            x: 56,
            y: 0,
            w: 8,
            h: 8
        },
        {
            x: 0,
            y: 16,
            w: 4,
            h: 4
        },
        {
            x: 12,
            y: 16,
            w: 4,
            h: 4
        },
        {
            x: 36,
            y: 16,
            w: 4,
            h: 4
        },
        {
            x: 56,
            y: 16,
            w: 8,
            h: 4
        }
    ];
    let voidPixels = 0;
    let voidOpaque = 0;
    for (const z of voidZones){
        if (z.y + z.h <= height) {
            for(let py = z.y; py < z.y + z.h; py++){
                for(let px = z.x; px < z.x + z.w; px++){
                    voidPixels++;
                    if (isOpaque(px, py)) voidOpaque++;
                }
            }
        }
    }
    const voidOpaqueRatio = voidOpaque / (voidPixels || 1);
    // 3. Check Head Faces (x: 0..32, y: 0..16)
    let headPixels = 0;
    for(let py = 0; py < 16; py++){
        for(let px = 0; px < 32; px++){
            if (isOpaque(px, py)) headPixels++;
        }
    }
    const hasHeadFaces = headPixels >= 16;
    // 4. Check Torso (x: 16..40, y: 16..32) and Lateral Limbs (x: 0..16, y: 16..32 and x: 40..56, y: 16..32)
    let torsoPixels = 0;
    for(let py = 16; py < 32; py++){
        for(let px = 16; px < 40; px++){
            if (isOpaque(px, py)) torsoPixels++;
        }
    }
    let leftLimbPixels = 0;
    let rightLimbPixels = 0;
    for(let py = 16; py < 32; py++){
        for(let px = 0; px < 16; px++){
            if (isOpaque(px, py)) leftLimbPixels++;
        }
        for(let px = 40; px < 56; px++){
            if (isOpaque(px, py)) rightLimbPixels++;
        }
    }
    const hasTorso = torsoPixels >= 16;
    const hasLeftLimb = leftLimbPixels >= 16;
    const hasRightLimb = rightLimbPixels >= 16;
    const hasBothLimbs = hasLeftLimb && hasRightLimb;
    const hasTorsoOrLimbs = hasTorso && (hasLeftLimb || hasRightLimb);
    // 5. Check if pixels form a centered single-character silhouette
    // Centered character sprites have empty lateral flanks (minX >= 10 || maxX <= 48),
    // lack dual lateral limbs, or have a single dominant body component covering >= 68% of pixels without dual limbs.
    const isCenteredSpriteBounds = minX >= 10 || maxX <= 48;
    const isContiguousSingleSilhouette = !hasBothLimbs && isCenteredSpriteBounds || largestRatio >= 0.68 && !hasBothLimbs;
    // 6. Scoring
    let confidence = 0.0;
    if (voidOpaqueRatio < 0.20) confidence += 0.25;
    if (hasHeadFaces) confidence += 0.25;
    if (hasTorso) confidence += 0.25;
    if (hasBothLimbs && !isContiguousSingleSilhouette) confidence += 0.25;
    const isSkin = !isContiguousSingleSilhouette && voidOpaqueRatio < 0.25 && hasHeadFaces && hasTorso && hasBothLimbs && confidence >= 0.70;
    const rationale = isSkin ? `Disjoint multi-island UV unwrap detected (${components.length} islands, left/right limbs confirmed, void pollution ${(voidOpaqueRatio * 100).toFixed(0)}%). Confidence: ${(confidence * 100).toFixed(0)}%.` : isContiguousSingleSilhouette ? `Centered contiguous character silhouette detected (bounds: [${minX}..${maxX}], dominant component ${(largestRatio * 100).toFixed(0)}%, both limbs: ${hasBothLimbs}). Classified as 2.5D Sprite/Character.` : `Topology does not match Minecraft skin atlas (void pollution ${(voidOpaqueRatio * 100).toFixed(0)}%, head: ${hasHeadFaces}, torso: ${hasTorso}, limbs: ${hasBothLimbs}). Classified as 2.5D Sprite/Character.`;
    return {
        isSkin,
        confidence,
        islandCount: components.length,
        largestComponentRatio: largestRatio,
        voidOpaqueRatio,
        hasHeadFaces,
        hasTorsoOrLimbs,
        isContiguousSingleSilhouette,
        rationale
    };
}
function detectMinecraftSkin(isOpaque, width, height) {
    return analyzeMinecraftSkinTopology(isOpaque, width, height).isSkin;
}
function computeMinecraftSkinNormalField(width, height) {
    const nx = new Float32Array(width * height);
    const ny = new Float32Array(width * height);
    const nz = new Float32Array(width * height);
    const sky = new Float32Array(width * height);
    const material = new Uint8Array(width * height); // 0 = skin (base), 1 = fabric (overlay), 2 = eye protection
    for(let i = 0; i < width * height; i++){
        nz[i] = 1.0;
        sky[i] = 1.0;
        material[i] = 0;
    }
    const paintFace = (fx, fy, fw, fh, baseNorm, leftNeighborNorm = baseNorm, rightNeighborNorm = baseNorm, faceType = 'SIDE', bodyPart = 'torso', layer = 'base')=>{
        if (fx + fw > width || fy + fh > height) return;
        for(let py = fy; py < fy + fh; py++){
            for(let px = fx; px < fx + fw; px++){
                const idx = py * width + px;
                let [bx, by, bz] = baseNorm;
                // 1px narrow boundary linear interpolation to remove harsh barcode/step transitions
                if (fw > 1) {
                    if (px === fx) {
                        // Left border column: blend 75% base + 25% left neighbor
                        bx = bx * 0.75 + leftNeighborNorm[0] * 0.25;
                        by = by * 0.75 + leftNeighborNorm[1] * 0.25;
                        bz = bz * 0.75 + leftNeighborNorm[2] * 0.25;
                    } else if (px === fx + fw - 1) {
                        // Right border column: blend 75% base + 25% right neighbor
                        bx = bx * 0.75 + rightNeighborNorm[0] * 0.25;
                        by = by * 0.75 + rightNeighborNorm[1] * 0.25;
                        bz = bz * 0.75 + rightNeighborNorm[2] * 0.25;
                    }
                }
                const len = Math.sqrt(bx * bx + by * by + bz * bz) || 1;
                nx[idx] = bx / len;
                ny[idx] = by / len;
                nz[idx] = bz / len;
                // Material assignment
                if (layer === 'overlay') {
                    material[idx] = 1; // Fabric / Clothing overlay
                } else {
                    // Base layer: check if this is the Head Front Eye region (x: 8..15, y: 12..14)
                    if (bodyPart === 'head' && fx === 8 && fy === 8 && py >= 12 && py <= 14) {
                        material[idx] = 2; // Eye row
                    } else {
                        material[idx] = 0; // Skin / Organic base
                    }
                }
                // Sky factor
                if (faceType === 'UP') {
                    sky[idx] = 1.08;
                } else if (faceType === 'DOWN') {
                    sky[idx] = 0.80;
                } else {
                    sky[idx] = 1.0; // Flat neutral sky (no vertical 1D gradient lines)
                }
            }
        }
    };
    const UP = [
        0,
        -0.60,
        0.80
    ];
    const DOWN = [
        0,
        0.60,
        0.80
    ];
    const LEFT = [
        0.60,
        0,
        0.80
    ];
    const RIGHT = [
        -0.60,
        0,
        0.80
    ];
    const FRONT = [
        0,
        0,
        1.0
    ];
    const BACK = [
        0,
        0,
        0.65
    ];
    // Head (0, 0, 32, 16) - Base Layer
    paintFace(8, 0, 8, 8, UP, UP, UP, 'UP', 'head', 'base');
    paintFace(16, 0, 8, 8, DOWN, DOWN, DOWN, 'DOWN', 'head', 'base');
    paintFace(0, 8, 8, 8, RIGHT, BACK, FRONT, 'SIDE', 'head', 'base');
    paintFace(8, 8, 8, 8, FRONT, RIGHT, LEFT, 'SIDE', 'head', 'base');
    paintFace(16, 8, 8, 8, LEFT, FRONT, BACK, 'SIDE', 'head', 'base');
    paintFace(24, 8, 8, 8, BACK, LEFT, RIGHT, 'SIDE', 'head', 'base');
    // Hat Layer 2 (32, 0, 32, 16) - Overlay Layer (Clothing/Hair)
    paintFace(40, 0, 8, 8, UP, UP, UP, 'UP', 'head', 'overlay');
    paintFace(48, 0, 8, 8, DOWN, DOWN, DOWN, 'DOWN', 'head', 'overlay');
    paintFace(32, 8, 8, 8, RIGHT, BACK, FRONT, 'SIDE', 'head', 'overlay');
    paintFace(40, 8, 8, 8, FRONT, RIGHT, LEFT, 'SIDE', 'head', 'overlay');
    paintFace(48, 8, 8, 8, LEFT, FRONT, BACK, 'SIDE', 'head', 'overlay');
    paintFace(56, 8, 8, 8, BACK, LEFT, RIGHT, 'SIDE', 'head', 'overlay');
    // Body / Torso (16, 16, 24, 16) - Base Layer
    paintFace(20, 16, 8, 4, UP, UP, UP, 'UP', 'torso', 'base');
    paintFace(28, 16, 8, 4, DOWN, DOWN, DOWN, 'DOWN', 'torso', 'base');
    paintFace(16, 20, 4, 12, RIGHT, BACK, FRONT, 'SIDE', 'torso', 'base');
    paintFace(20, 20, 8, 12, FRONT, RIGHT, LEFT, 'SIDE', 'torso', 'base');
    paintFace(28, 20, 4, 12, LEFT, FRONT, BACK, 'SIDE', 'torso', 'base');
    paintFace(32, 20, 8, 12, BACK, LEFT, RIGHT, 'SIDE', 'torso', 'base');
    // Right Arm (40, 16, 16, 16) - Base Layer
    paintFace(44, 16, 4, 4, UP, UP, UP, 'UP', 'arm', 'base');
    paintFace(48, 16, 4, 4, DOWN, DOWN, DOWN, 'DOWN', 'arm', 'base');
    paintFace(40, 20, 4, 12, RIGHT, BACK, FRONT, 'SIDE', 'arm', 'base');
    paintFace(44, 20, 4, 12, FRONT, RIGHT, LEFT, 'SIDE', 'arm', 'base');
    paintFace(48, 20, 4, 12, LEFT, FRONT, BACK, 'SIDE', 'arm', 'base');
    paintFace(52, 20, 4, 12, BACK, LEFT, RIGHT, 'SIDE', 'arm', 'base');
    // Right Leg (0, 16, 16, 16) - Base Layer
    paintFace(4, 16, 4, 4, UP, UP, UP, 'UP', 'leg', 'base');
    paintFace(8, 16, 4, 4, DOWN, DOWN, DOWN, 'DOWN', 'leg', 'base');
    paintFace(0, 20, 4, 12, RIGHT, BACK, FRONT, 'SIDE', 'leg', 'base');
    paintFace(4, 20, 4, 12, FRONT, RIGHT, LEFT, 'SIDE', 'leg', 'base');
    paintFace(8, 20, 4, 12, LEFT, FRONT, BACK, 'SIDE', 'leg', 'base');
    paintFace(12, 20, 4, 12, BACK, LEFT, RIGHT, 'SIDE', 'leg', 'base');
    if (height >= 64) {
        // Left Leg Base (16, 48, 16, 16) - Base Layer
        paintFace(20, 48, 4, 4, UP, UP, UP, 'UP', 'leg', 'base');
        paintFace(24, 48, 4, 4, DOWN, DOWN, DOWN, 'DOWN', 'leg', 'base');
        paintFace(16, 52, 4, 12, RIGHT, BACK, FRONT, 'SIDE', 'leg', 'base');
        paintFace(20, 52, 4, 12, FRONT, RIGHT, LEFT, 'SIDE', 'leg', 'base');
        paintFace(24, 52, 4, 12, LEFT, FRONT, BACK, 'SIDE', 'leg', 'base');
        paintFace(28, 52, 4, 12, BACK, LEFT, RIGHT, 'SIDE', 'leg', 'base');
        // Left Arm Base (32, 48, 16, 16) - Base Layer
        paintFace(36, 48, 4, 4, UP, UP, UP, 'UP', 'arm', 'base');
        paintFace(40, 48, 4, 4, DOWN, DOWN, DOWN, 'DOWN', 'arm', 'base');
        paintFace(32, 52, 4, 12, RIGHT, BACK, FRONT, 'SIDE', 'arm', 'base');
        paintFace(36, 52, 4, 12, FRONT, RIGHT, LEFT, 'SIDE', 'arm', 'base');
        paintFace(40, 52, 4, 12, LEFT, FRONT, BACK, 'SIDE', 'arm', 'base');
        paintFace(44, 52, 4, 12, BACK, LEFT, RIGHT, 'SIDE', 'arm', 'base');
        // Jacket Layer 2 (16, 32, 24, 16) - Overlay Layer (Clothing)
        paintFace(20, 32, 8, 4, UP, UP, UP, 'UP', 'torso', 'overlay');
        paintFace(28, 32, 8, 4, DOWN, DOWN, DOWN, 'DOWN', 'torso', 'overlay');
        paintFace(16, 36, 4, 12, RIGHT, BACK, FRONT, 'SIDE', 'torso', 'overlay');
        paintFace(20, 36, 8, 12, FRONT, RIGHT, LEFT, 'SIDE', 'torso', 'overlay');
        paintFace(28, 36, 4, 12, LEFT, FRONT, BACK, 'SIDE', 'torso', 'overlay');
        paintFace(32, 36, 8, 12, BACK, LEFT, RIGHT, 'SIDE', 'torso', 'overlay');
        // Right Sleeve Layer 2 (40, 32, 16, 16) - Overlay Layer (Clothing)
        paintFace(44, 32, 4, 4, UP, UP, UP, 'UP', 'arm', 'overlay');
        paintFace(48, 32, 4, 4, DOWN, DOWN, DOWN, 'DOWN', 'arm', 'overlay');
        paintFace(40, 36, 4, 12, RIGHT, BACK, FRONT, 'SIDE', 'arm', 'overlay');
        paintFace(44, 36, 4, 12, FRONT, RIGHT, LEFT, 'SIDE', 'arm', 'overlay');
        paintFace(48, 36, 4, 12, LEFT, FRONT, BACK, 'SIDE', 'arm', 'overlay');
        paintFace(52, 36, 4, 12, BACK, LEFT, RIGHT, 'SIDE', 'arm', 'overlay');
        // Right Pants Layer 2 (0, 32, 16, 16) - Overlay Layer (Clothing)
        paintFace(4, 32, 4, 4, UP, UP, UP, 'UP', 'leg', 'overlay');
        paintFace(8, 32, 4, 4, DOWN, DOWN, DOWN, 'DOWN', 'leg', 'overlay');
        paintFace(0, 36, 4, 12, RIGHT, BACK, FRONT, 'SIDE', 'leg', 'overlay');
        paintFace(4, 36, 4, 12, FRONT, RIGHT, LEFT, 'SIDE', 'leg', 'overlay');
        paintFace(8, 36, 4, 12, LEFT, FRONT, BACK, 'SIDE', 'leg', 'overlay');
        paintFace(12, 36, 4, 12, BACK, LEFT, RIGHT, 'SIDE', 'leg', 'overlay');
        // Left Pants Layer 2 (0, 48, 16, 16) - Overlay Layer (Clothing)
        paintFace(4, 48, 4, 4, UP, UP, UP, 'UP', 'leg', 'overlay');
        paintFace(8, 48, 4, 4, DOWN, DOWN, DOWN, 'DOWN', 'leg', 'overlay');
        paintFace(0, 52, 4, 12, RIGHT, BACK, FRONT, 'SIDE', 'leg', 'overlay');
        paintFace(4, 52, 4, 12, FRONT, RIGHT, LEFT, 'SIDE', 'leg', 'overlay');
        paintFace(8, 52, 4, 12, LEFT, FRONT, BACK, 'SIDE', 'leg', 'overlay');
        paintFace(12, 52, 4, 12, BACK, LEFT, RIGHT, 'SIDE', 'leg', 'overlay');
        // Left Sleeve Layer 2 (48, 48, 16, 16) - Overlay Layer (Clothing)
        paintFace(52, 48, 4, 4, UP, UP, UP, 'UP', 'arm', 'overlay');
        paintFace(56, 48, 4, 4, DOWN, DOWN, DOWN, 'DOWN', 'arm', 'overlay');
        paintFace(48, 52, 4, 12, RIGHT, BACK, FRONT, 'SIDE', 'arm', 'overlay');
        paintFace(52, 52, 4, 12, FRONT, RIGHT, LEFT, 'SIDE', 'arm', 'overlay');
        paintFace(56, 52, 4, 12, LEFT, FRONT, BACK, 'SIDE', 'arm', 'overlay');
        paintFace(60, 52, 4, 12, BACK, LEFT, RIGHT, 'SIDE', 'arm', 'overlay');
    }
    return {
        nx,
        ny,
        nz,
        sky,
        material,
        width,
        height
    };
}
function executeMinecraftSkinShadingPipeline(srcCtx, width, height, params) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const outputCanvas = document.createElement('canvas');
    outputCanvas.width = width;
    outputCanvas.height = height;
    const outCtx = outputCanvas.getContext('2d');
    const outImgData = outCtx.createImageData(width, height);
    const outData = outImgData.data;
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    const normalField = computeMinecraftSkinNormalField(width, height);
    const azRad = params.lightAzimuth * Math.PI / 180;
    const elRad = Math.max(15, params.lightElevation) * Math.PI / 180;
    const Lx = Math.sin(azRad) * Math.cos(elRad);
    const Ly = -Math.cos(azRad) * Math.cos(elRad);
    const Lz = Math.sin(elRad);
    const brightness = params.lightBrightness ?? 1.15;
    const cavityStr = params.cavityStrength ?? 1.0;
    // Pre-calculate anatomical contact ambient occlusion map
    const aoMap = new Float32Array(width * height).fill(1.0);
    const applyContactAO = (x, y, w, h, aoFactor)=>{
        for(let py = y; py < y + h && py < height; py++){
            for(let px = x; px < x + w && px < width; px++){
                if (px >= 0 && py >= 0) {
                    aoMap[py * width + px] = Math.min(aoMap[py * width + px], aoFactor);
                }
            }
        }
    };
    // 1. Head Under-Neck Occlusion (Bottom face of head)
    applyContactAO(16, 0, 8, 8, 0.85);
    // 2. Overlap Layer (Hat, Jacket, Sleeve, Pants) subtle shadow on base layer
    const applyOverlapShadow = (ox, oy, w, h, bx, by)=>{
        for(let py = 0; py < h; py++){
            for(let px = 0; px < w; px++){
                if (isOpaque(ox + px, oy + py) && isOpaque(bx + px, by + py)) {
                    aoMap[(by + py) * width + (bx + px)] *= 0.90;
                }
            }
        }
    };
    // Hat shadow on head
    applyOverlapShadow(32, 0, 32, 16, 0, 0);
    // Jacket shadow on torso
    if (height >= 64) {
        applyOverlapShadow(16, 32, 24, 16, 16, 16);
        applyOverlapShadow(40, 32, 16, 16, 40, 16); // Right sleeve
        applyOverlapShadow(0, 32, 16, 16, 0, 16); // Right pants
        applyOverlapShadow(0, 48, 16, 16, 16, 48); // Left pants
        applyOverlapShadow(48, 48, 16, 16, 32, 48); // Left sleeve
    }
    // Shift hue helper in degrees
    const shiftHue = (currentH, targetH, maxShiftDeg)=>{
        let diff = (targetH - currentH + 360) % 360;
        if (diff > 180) diff -= 360;
        const shift = Math.sign(diff) * Math.min(Math.abs(diff), maxShiftDeg);
        return (currentH + shift + 360) % 360;
    };
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            const pIdx = idx * 4;
            if (!isOpaque(x, y)) {
                outData[pIdx + 3] = 0;
                continue;
            }
            const origR = data[pIdx];
            const origG = data[pIdx + 1];
            const origB = data[pIdx + 2];
            const lab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(origR, origG, origB);
            const C = Math.sqrt(lab.a * lab.a + lab.b * lab.b);
            let H = Math.atan2(lab.b, lab.a) * 180 / Math.PI;
            if (H < 0) H += 360;
            const L = lab.L;
            // Normal vector of cuboid face
            const Nx = normalField.nx[idx];
            const Ny = normalField.ny[idx];
            const Nz = normalField.nz[idx];
            // 1. Half-Lambert Directional Shading
            const NdotL = Nx * Lx + Ny * Ly + Nz * Lz;
            const directionalFactor = Math.pow(Math.max(0, (NdotL + 0.5) / 1.5), 1.15);
            // 2. Anatomical Ambient Occlusion
            const ao = 1.0 - (1.0 - aoMap[idx]) * cavityStr;
            // 3. Anatomical Sky Lighting (Calculated per UV island based on 3D face orientation)
            const skyFactor = normalField.sky ? normalField.sky[idx] : 1.0;
            // Total continuous lighting multiplier
            const totalFactor = directionalFactor * ao * skyFactor * (brightness * 0.95);
            let newL;
            let newC;
            let newH;
            const matType = normalField.material ? normalField.material[idx] : 0;
            if (matType === 2) {
                // --- 1. EYE PROTECTION (Head Front Eye Row) ---
                const eyeFactor = 1.0 + (totalFactor - 1.0) * 0.10;
                newH = H;
                newL = Math.max(0.05, Math.min(0.99, L + (eyeFactor - 1.0) * 0.08));
                newC = C;
            } else if (matType === 1) {
                // --- 2. FABRIC / CLOTHING OVERLAY ---
                if (totalFactor >= 1.0) {
                    const intensity = Math.min(1.0, (totalFactor - 1.0) * 0.70);
                    newH = shiftHue(H, 65, intensity * 8);
                    newL = Math.min(0.99, L + intensity * (0.99 - L) * 0.20);
                    newC = Math.min(0.35, C * (1.0 + intensity * 0.04));
                } else {
                    const intensity = Math.min(1.0, (1.0 - totalFactor) * 0.75);
                    newH = shiftHue(H, 260, intensity * 10);
                    newL = Math.max(0.20, L - intensity * L * 0.22);
                    newC = Math.min(0.35, C * (1.0 + intensity * 0.06));
                }
            } else {
                // --- 3. SKIN / ORGANIC BASE LAYER ---
                if (totalFactor >= 1.0) {
                    const intensity = Math.min(1.0, (totalFactor - 1.0) * 1.4);
                    newH = shiftHue(H, 65, intensity * 26);
                    newL = Math.min(0.98, L + intensity * (0.98 - L) * 0.48);
                    newC = Math.min(0.35, C * (1.0 + intensity * 0.15));
                } else {
                    const intensity = Math.min(1.0, (1.0 - totalFactor) * 1.5);
                    newH = shiftHue(H, 260, intensity * 24);
                    newL = Math.max(0.12, L - intensity * L * 0.42);
                    newC = Math.min(0.35, C * (1.0 + intensity * 0.20));
                }
            }
            const hRad = newH * Math.PI / 180;
            const targetA = newC * Math.cos(hRad);
            const targetB = newC * Math.sin(hRad);
            const rgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToRGB"])(newL, targetA, targetB);
            outData[pIdx] = rgb.r;
            outData[pIdx + 1] = rgb.g;
            outData[pIdx + 2] = rgb.b;
            outData[pIdx + 3] = data[pIdx + 3];
        }
    }
    outCtx.putImageData(outImgData, 0, 0);
    return outputCanvas;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/morphology.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Binary Raster Morphology & Parallel Skeleton Line Thinning.
 *
 * Citation:
 * T. Y. Zhang & C. Y. Suen, "A fast parallel algorithm for thinning digital patterns",
 * Communications of the ACM, Vol. 27, No. 3, pp. 236–239, March 1984.
 *
 * Reduces thick raster strokes to 1-pixel-wide medial axis skeletons while preserving
 * 8-connected topology and line endpoints across two alternating sub-iterations.
 * The outermost one-pixel canvas border is left unchanged because each update
 * requires all eight neighbors; artwork touching that border may remain thicker.
 */ __turbopack_context__.s([
    "applyZhangSuenThinning",
    ()=>applyZhangSuenThinning
]);
function applyZhangSuenThinning(srcCtx, width, height) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const binary = new Uint8Array(width * height);
    for(let i = 0; i < width * height; i++){
        binary[i] = data[i * 4 + 3] > 30 ? 1 : 0;
    }
    let count = 0;
    let hasChanged = true;
    while(hasChanged){
        hasChanged = false;
        // Sub-iteration 1
        const toDelete1 = [];
        for(let y = 1; y < height - 1; y++){
            for(let x = 1; x < width - 1; x++){
                const idx = y * width + x;
                if (!binary[idx]) continue;
                const p2 = binary[(y - 1) * width + x];
                const p3 = binary[(y - 1) * width + (x + 1)];
                const p4 = binary[y * width + (x + 1)];
                const p5 = binary[(y + 1) * width + (x + 1)];
                const p6 = binary[(y + 1) * width + x];
                const p7 = binary[(y + 1) * width + (x - 1)];
                const p8 = binary[y * width + (x - 1)];
                const p9 = binary[(y - 1) * width + (x - 1)];
                const B = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9;
                if (B < 2 || B > 6) continue;
                const neighbors = [
                    p2,
                    p3,
                    p4,
                    p5,
                    p6,
                    p7,
                    p8,
                    p9,
                    p2
                ];
                let A = 0;
                for(let k = 0; k < 8; k++){
                    if (neighbors[k] === 0 && neighbors[k + 1] === 1) A++;
                }
                if (A !== 1) continue;
                if (p2 * p4 * p6 !== 0) continue;
                if (p4 * p6 * p8 !== 0) continue;
                toDelete1.push(idx);
            }
        }
        for (const idx of toDelete1){
            binary[idx] = 0;
            data[idx * 4 + 3] = 0;
            count++;
            hasChanged = true;
        }
        // Sub-iteration 2
        const toDelete2 = [];
        for(let y = 1; y < height - 1; y++){
            for(let x = 1; x < width - 1; x++){
                const idx = y * width + x;
                if (!binary[idx]) continue;
                const p2 = binary[(y - 1) * width + x];
                const p3 = binary[(y - 1) * width + (x + 1)];
                const p4 = binary[y * width + (x + 1)];
                const p5 = binary[(y + 1) * width + (x + 1)];
                const p6 = binary[(y + 1) * width + x];
                const p7 = binary[(y + 1) * width + (x - 1)];
                const p8 = binary[y * width + (x - 1)];
                const p9 = binary[(y - 1) * width + (x - 1)];
                const B = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9;
                if (B < 2 || B > 6) continue;
                const neighbors = [
                    p2,
                    p3,
                    p4,
                    p5,
                    p6,
                    p7,
                    p8,
                    p9,
                    p2
                ];
                let A = 0;
                for(let k = 0; k < 8; k++){
                    if (neighbors[k] === 0 && neighbors[k + 1] === 1) A++;
                }
                if (A !== 1) continue;
                if (p2 * p4 * p8 !== 0) continue;
                if (p2 * p6 * p8 !== 0) continue;
                toDelete2.push(idx);
            }
        }
        for (const idx of toDelete2){
            binary[idx] = 0;
            data[idx * 4 + 3] = 0;
            count++;
            hasChanged = true;
        }
    }
    srcCtx.putImageData(imgData, 0, 0);
    return {
        thinnedCount: count
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/photometricAuto.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Photometric Auto-Analysis Engine ("understands the art, then lights it").
 *
 * Analyzes the composited canvas artwork and infers the photometric studio
 * settings a lighting artist would pick by hand:
 *
 * 1. Light azimuth — direction from the sprite's geometric centroid toward its
 *    luminance centroid (the art's own brightest mass reads as the light side).
 * 2. Light elevation — how strongly that bright mass biases toward the top of
 *    the sprite silhouette (top-lit art => high sun, center/flat => overhead).
 * 3. Material — scores Blinn-Phong families from pixel statistics:
 *    highlight prevalence (specular share), chromatic warmth of the bright
 *    mass (conductor gold), cool clarity (dielectric glass), and overall
 *    contrast softness (matte clay vs velvet fabric).
 * 4. Brightness — exposure compensation for dark or blown-out palettes.
 *
 * Pure, DOM-free and deterministic so it is unit-testable.
 */ __turbopack_context__.s([
    "inferPhotometricSettings",
    ()=>inferPhotometricSettings
]);
const OPAQUE_ALPHA = 30;
function inferPhotometricSettings(data, width, height) {
    const DEFAULTS = {
        lightAzimuth: 315,
        lightElevation: 45,
        material: 'matte',
        brightness: 1.15,
        formType: 'prop',
        cavityStrength: 1.0,
        directionalShadingCue: 0,
        rationale: 'Canvas is empty — default top-left studio light.'
    };
    let count = 0;
    let sumX = 0;
    let sumY = 0;
    let lumSumX = 0;
    let lumSumY = 0;
    let lumTotal = 0;
    let sumR = 0;
    let sumB = 0;
    let sumSat = 0;
    let brightCount = 0;
    let brightR = 0;
    let brightB = 0;
    // 32-bin luminance histogram for percentile + contrast statistics
    const histogram = new Uint32Array(32);
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const p = (y * width + x) * 4;
            if (data[p + 3] <= OPAQUE_ALPHA) continue;
            const r = data[p];
            const g = data[p + 1];
            const b = data[p + 2];
            const lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
            count++;
            sumX += x;
            sumY += y;
            lumSumX += x * lum;
            lumSumY += y * lum;
            lumTotal += lum;
            sumR += r;
            sumB += b;
            sumSat += (Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b))) / 255;
            histogram[Math.min(31, Math.floor(lum * 32))]++;
            if (lum >= 0.82) {
                brightCount++;
                brightR += r;
                brightB += b;
            }
        }
    }
    if (count === 0 || lumTotal === 0) return DEFAULTS;
    // --- 1) Morphological & Silhouette Analysis ---------------------------------
    let minX = width, maxX = 0, minY = height, maxY = 0;
    let perimeter = 0;
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const p = (y * width + x) * 4;
            if (data[p + 3] <= OPAQUE_ALPHA) continue;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
            const isEdge = x === 0 || x === width - 1 || y === 0 || y === height - 1 || data[((y - 1) * width + x) * 4 + 3] <= OPAQUE_ALPHA || data[((y + 1) * width + x) * 4 + 3] <= OPAQUE_ALPHA || data[(y * width + (x - 1)) * 4 + 3] <= OPAQUE_ALPHA || data[(y * width + (x + 1)) * 4 + 3] <= OPAQUE_ALPHA;
            if (isEdge) perimeter++;
        }
    }
    const boxW = Math.max(1, maxX - minX + 1);
    const boxH = Math.max(1, maxY - minY + 1);
    const aspectRatio = boxW / boxH;
    const circularity = perimeter > 0 ? 4 * Math.PI * count / (perimeter * perimeter) : 0;
    const isOrb = circularity > 0.65 && aspectRatio >= 0.8 && aspectRatio <= 1.25;
    // Detect top appendages/ears/horns: check if upper 15-45% of sprite bounding box splits into 2+ distinct islands
    let hasEarsOrHorns = false;
    let maxUpperSegments = 0;
    const earScanRows = Math.max(4, Math.floor(boxH * 0.45));
    for(let y = minY; y < minY + earScanRows; y++){
        let segments = 0;
        let inSegment = false;
        for(let x = minX; x <= maxX; x++){
            const opaque = data[(y * width + x) * 4 + 3] > OPAQUE_ALPHA;
            if (opaque && !inSegment) {
                segments++;
                inSegment = true;
            } else if (!opaque && inSegment) {
                inSegment = false;
            }
        }
        if (segments > maxUpperSegments) maxUpperSegments = segments;
        if (segments >= 2) {
            hasEarsOrHorns = true;
        }
    }
    // Also check vertical columns in upper region for lateral appendages (e.g. side ears, wings, cheek tufts)
    if (boxW >= 12) {
        const earScanCols = Math.max(4, Math.floor(boxW * 0.35));
        for(let x = minX; x < minX + earScanCols; x++){
            let segments = 0;
            let inSegment = false;
            for(let y = minY; y <= minY + earScanRows; y++){
                const opaque = data[(y * width + x) * 4 + 3] > OPAQUE_ALPHA;
                if (opaque && !inSegment) {
                    segments++;
                    inSegment = true;
                } else if (!opaque && inSegment) {
                    inSegment = false;
                }
            }
            if (segments > maxUpperSegments) maxUpperSegments = segments;
            if (segments >= 2) {
                hasEarsOrHorns = true;
            }
        }
    }
    // Detect internal facial features (eyes, mouth, nose, whiskers, brow ticks):
    // Find dark/contrast pixels enclosed within the interior body (not touching transparent background)
    let hasFacialFeatures = false;
    const isOpaqueAt = (px, py)=>{
        if (px < 0 || px >= width || py < 0 || py >= height) return false;
        return data[(py * width + px) * 4 + 3] > OPAQUE_ALPHA;
    };
    const internalDarkSet = new Set();
    const meanLum = lumTotal / count;
    for(let y = minY + 1; y < maxY; y++){
        for(let x = minX + 1; x < maxX; x++){
            const p = (y * width + x) * 4;
            if (data[p + 3] <= OPAQUE_ALPHA) continue;
            // Must have opaque neighbors on all sides (fully interior)
            if (!isOpaqueAt(x - 1, y) || !isOpaqueAt(x + 1, y) || !isOpaqueAt(x, y - 1) || !isOpaqueAt(x, y + 1)) {
                continue;
            }
            const r = data[p];
            const g = data[p + 1];
            const b = data[p + 2];
            const pLum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
            const isDarkFeature = pLum < 0.25 || pLum < meanLum - 0.18 || pLum < 0.35 && meanLum > 0.30;
            if (isDarkFeature) {
                internalDarkSet.add(y * width + x);
            }
        }
    }
    if (internalDarkSet.size > 0 && internalDarkSet.size <= Math.max(64, Math.floor(count * 0.28))) {
        const visitedSet = new Set();
        let featureClusterCount = 0;
        for (const pIdx of internalDarkSet){
            if (visitedSet.has(pIdx)) continue;
            featureClusterCount++;
            const queue = [
                pIdx
            ];
            visitedSet.add(pIdx);
            let qHead = 0;
            while(qHead < queue.length){
                const cur = queue[qHead++];
                const cx = cur % width;
                const cy = Math.floor(cur / width);
                for(let dy = -1; dy <= 1; dy++){
                    for(let dx = -1; dx <= 1; dx++){
                        if (dx === 0 && dy === 0) continue;
                        const nIdx = (cy + dy) * width + (cx + dx);
                        if (internalDarkSet.has(nIdx) && !visitedSet.has(nIdx)) {
                            visitedSet.add(nIdx);
                            queue.push(nIdx);
                        }
                    }
                }
            }
        }
        if (featureClusterCount >= 1 && featureClusterCount <= 32) {
            hasFacialFeatures = true;
        }
    }
    const isCharacter = hasEarsOrHorns || hasFacialFeatures;
    let formType = 'prop';
    if (isCharacter) {
        formType = 'character';
    } else if (isOrb) {
        formType = 'orb';
    }
    // --- 1b) Silhouette Complexity & Cavity AO Auto-Scaling ----------------------
    // Spiky, appendage-dense silhouettes (hair spikes, fur tufts) cause discrete Laplace
    // cavity AO to falsely interpret adjacent strands as deep crevices, engulfing up to 46%
    // of the sprite in non-directional crevice tone.
    // We scale cavityStrength down from 1.0 toward 0.35–0.50 based on circularity deficiency
    // and multi-segment appendage density.
    let cavityStrength = 1.0;
    if (!isOrb) {
        const isoperimetricRatio = circularity > 0 ? 1 / circularity : 5;
        if (isoperimetricRatio > 2.0 || maxUpperSegments >= 3) {
            const ratioExcess = Math.min(1.0, Math.max(0, (isoperimetricRatio - 2.0) / 3.0));
            const segmentExcess = Math.min(1.0, Math.max(0, (maxUpperSegments - 2) / 2.0));
            const complexity = Math.max(ratioExcess, segmentExcess);
            cavityStrength = +(1.0 - complexity * 0.60).toFixed(2); // Scales smoothly down from 1.0 to 0.40
        }
    }
    // --- 2) Light azimuth: geometric centroid -> luminance centroid -------------
    const cx = sumX / count;
    const cy = sumY / count;
    const lx = lumSumX / lumTotal;
    const ly = lumSumY / lumTotal;
    const dx = lx - cx;
    const dy = ly - cy;
    const spriteRadius = Math.sqrt(count / Math.PI) || 1;
    const offsetMag = Math.sqrt(dx * dx + dy * dy);
    // A smooth heuristic avoids the former 0 -> 65% jump. This is deliberately
    // described as a cue, not confidence: single-image intrinsic decomposition
    // is underconstrained and this value is not statistically calibrated.
    const cueStart = Math.max(0.6, spriteRadius * 0.06);
    const cueFull = Math.max(cueStart + 1, spriteRadius * 0.30);
    const cueT = Math.max(0, Math.min(1, (offsetMag - cueStart) / (cueFull - cueStart)));
    const directionalShadingCue = cueT * cueT * (3 - 2 * cueT);
    const hasPaintedShadingCues = directionalShadingCue > 0.08;
    let azimuthDeg;
    if (!hasPaintedShadingCues) {
        // Subject has flat or unshaded base colors — assign optimal studio key light based on form
        if (formType === 'character') {
            // Flattering 3/4 studio key light for character/creature: lights left ear, sculpts face, casts subtle right shadow
            azimuthDeg = 315;
        } else if (isOrb) {
            // Classic 336° high-key studio light for rounded spheres / orbs (matching Photo 2!)
            azimuthDeg = 336;
        } else {
            azimuthDeg = 315; // Classic 3/4 studio key
        }
    } else {
        // Artist already painted shading cues: align azimuth with brightest mass
        azimuthDeg = Math.round((Math.atan2(dx, -dy) * 180 / Math.PI + 360) % 360);
    }
    // --- 3) Light elevation: vertical bias of the bright mass ------------------
    const verticalBias = Math.max(-1, Math.min(1, -dy / (spriteRadius * 0.55)));
    let elevationDeg = Math.round(Math.max(15, Math.min(90, 45 + 40 * verticalBias)));
    if (formType === 'character' && !hasPaintedShadingCues) {
        elevationDeg = 48; // Optimal anatomical elevation for character features
    }
    // --- 4) Material scoring ----------------------------------------------------
    let variance = 0;
    let binSum = 0;
    for(let bin = 0; bin < 32; bin++){
        const mid = (bin + 0.5) / 32;
        variance += histogram[bin] * (mid - meanLum) * (mid - meanLum);
        binSum += histogram[bin];
    }
    const stdLum = Math.sqrt(variance / Math.max(1, binSum));
    // Approximate 95th percentile from the histogram tail
    let acc = 0;
    let p95 = 1;
    for(let bin = 31; bin >= 0; bin--){
        acc += histogram[bin];
        if (acc >= count * 0.05) {
            p95 = (bin + 1) / 32;
            break;
        }
    }
    const specRatio = brightCount / count; // share of true highlight pixels
    const peakPush = Math.max(0, p95 - meanLum); // how far highlights outrun the mean
    const warmth = (sumR - sumB) / (255 * count); // +warm / -cool
    const meanSat = sumSat / count;
    const contrast = stdLum / 0.29; // normalized: ~1.0 for full-range art
    const brightWarmth = brightCount > 0 ? (brightR - brightB) / (255 * brightCount) : 0;
    const scores = {
        // Soft, even falloff: low contrast, few blown highlights
        matte: 0.45 + Math.max(0, 1 - contrast) * 0.5 - specRatio * 1.2,
        // Mirror-like: strong highlight share pushed far above the mean
        metal: specRatio * 2.2 + peakPush * 1.6 - Math.abs(warmth) * 0.3,
        // Cool, wet dielectric clarity: highlights + cool tint + low saturation
        glass: specRatio * 1.6 + peakPush * 1.2 - Math.max(0, warmth) * 1.4 - meanSat * 0.35,
        // Velvet: mid contrast with muted highlights, rich saturation
        fabric: (1 - Math.abs(contrast - 0.65)) * 0.55 + meanSat * 0.55 - specRatio * 0.9,
        // Conductor gold: highlights rendered warm, not neutral
        gold: specRatio * 1.7 + Math.max(0, brightWarmth) * 1.9 + Math.max(0, warmth) * 0.7
    };
    let material = 'matte';
    let bestScore = -Infinity;
    Object.keys(scores).forEach((key)=>{
        if (scores[key] > bestScore) {
            bestScore = scores[key];
            material = key;
        }
    });
    // --- 5) Exposure compensation ----------------------------------------------
    let brightness = 1.15;
    if (meanLum < 0.25) brightness = 1.35;
    else if (meanLum > 0.7) brightness = 0.95;
    const specPct = Math.round(specRatio * 100);
    let formDesc = 'canvas art';
    if (hasEarsOrHorns && hasFacialFeatures) formDesc = 'character with anatomical features (ears & facial details)';
    else if (hasEarsOrHorns) formDesc = 'character with anatomical features';
    else if (hasFacialFeatures) formDesc = 'character with facial features';
    else if (isOrb) formDesc = 'spherical form';
    let cavityDesc = '';
    if (cavityStrength < 0.95) {
        cavityDesc = `, cavity AO auto-scaled to ${cavityStrength} (complex silhouette)`;
    }
    const rationale = `Recognized ${formDesc} (highlight mass ${azimuthDeg}° / ${elevationDeg}°, ` + `spec share ${specPct}%, contrast ${contrast.toFixed(2)}${cavityDesc}) → ${material} shading.`;
    return {
        lightAzimuth: azimuthDeg,
        lightElevation: elevationDeg,
        material,
        brightness,
        formType,
        cavityStrength,
        directionalShadingCue,
        rationale
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/photometricLighting.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * Photometric 2.5D Shading, Blinn-Phong Specular, Volumetric Optics & SSS Pipeline.
 *
 * Citations:
 * 1. J. F. Blinn, "Models of light reflection for computer synthesized pictures",
 *    ACM SIGGRAPH Computer Graphics, 11(2): 192–198, 1977 (Blinn-Phong half-vector specular model).
 * 2. L. G. Henyey & J. L. Greenstein, "Diffuse radiation in the galaxy",
 *    The Astrophysical Journal, 93: 70–83, 1941 (Henyey-Greenstein 3D phase function, adapted with 2D circumference prefactor for empirical sprite subsurface scattering).
 * 3. J. T. Kajiya & T. L. Kay, "Rendering fur with three dimensional textures",
 *    ACM SIGGRAPH Computer Graphics, 23(3): 271–280, 1989 (Kajiya-Kay anisotropic specular reflection).
 * 4. S. R. Marschner, H. W. Jensen, M. Cammarano, S. Worley, and P. Hanrahan, "Light scattering from human hair fibers",
 *    ACM Transactions on Graphics (SIGGRAPH 2003), 22(3): 780–791 (Hair cuticle scale angle shift).
 * 5. T. Scheuermann, "Practical real-time hair rendering and shading",
 *    ACM SIGGRAPH 2004 Sketches (Tangent offset dual-specular approximation for Kajiya-Kay).
 * 6. Augustin-Jean Fresnel, "Mémoire sur la loi des modifications que la réflexion imprime à la lumière polarisée",
 *    Mémoires de l'Académie des Sciences, 1827 (Dielectric Fresnel reflectance with Cauchy chromatic dispersion delta).
 */ __turbopack_context__.s([
    "MATERIAL_PROFILES",
    ()=>MATERIAL_PROFILES,
    "OPTICAL_PROFILES",
    ()=>OPTICAL_PROFILES,
    "buildCelRamp",
    ()=>buildCelRamp,
    "cleanOrphanPixelConfetti",
    ()=>cleanOrphanPixelConfetti,
    "computeAnisotropicTangentField",
    ()=>computeAnisotropicTangentField,
    "computePhotometricAnalysis",
    ()=>computePhotometricAnalysis,
    "evaluateDielectricFresnel",
    ()=>evaluateDielectricFresnel,
    "executePhotometricPipeline",
    ()=>executePhotometricPipeline,
    "executeVolumetricOpticalPipeline",
    ()=>executeVolumetricOpticalPipeline,
    "phaseHG2D",
    ()=>phaseHG2D,
    "renderParametric2p5DLighting",
    ()=>renderParametric2p5DLighting,
    "snapToGemstoneFacets",
    ()=>snapToGemstoneFacets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/floodFill.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/art/normalSculptor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/colorSpace.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricAuto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/photometricAuto.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/edtNormalMap.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/dithering.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$minecraftSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/minecraftSkin.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$pixelGlint$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/pixelGlint.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
const MATERIAL_PROFILES = {
    matte: {
        kd: 1.0,
        ks: 0.08,
        shininess: 8,
        isMetallic: false,
        isDielectric: false,
        hasRim: false
    },
    metal: {
        kd: 0.45,
        ks: 1.35,
        shininess: 32,
        isMetallic: true,
        isDielectric: false,
        hasRim: false
    },
    glass: {
        kd: 0.2,
        ks: 1.8,
        shininess: 64,
        isMetallic: false,
        isDielectric: true,
        hasRim: true
    },
    fabric: {
        kd: 1.15,
        ks: 0.05,
        shininess: 4,
        isMetallic: false,
        isDielectric: false,
        hasRim: true
    },
    gold: {
        kd: 0.55,
        ks: 1.5,
        shininess: 28,
        isMetallic: true,
        isDielectric: false,
        hasRim: false
    }
};
const OPTICAL_PROFILES = {
    gemstone: {
        sigmaT: [
            0.35,
            2.4,
            2.8
        ],
        gForward: 0.78,
        distortion: 0.35,
        wrap: 0.3,
        fresnelEta: 1.77,
        fresnelPower: 4.5,
        dispersion: 0.035,
        roughness: 0.08,
        anisoStrength: 0.85,
        kajiyaPower1: 64,
        kajiyaPower2: 24,
        kajiyaSpec1: 1.2,
        kajiyaSpec2: 0.4
    },
    slime: {
        sigmaT: [
            2.9,
            0.4,
            2.6
        ],
        gForward: 0.82,
        distortion: 0.25,
        wrap: 0.45,
        fresnelEta: 1.33,
        fresnelPower: 3.0,
        dispersion: 0.015,
        roughness: 0.12,
        anisoStrength: 0.35,
        kajiyaPower1: 32,
        kajiyaPower2: 12,
        kajiyaSpec1: 0.6,
        kajiyaSpec2: 0.5
    },
    hair: {
        sigmaT: [
            1.5,
            1.5,
            1.5
        ],
        gForward: 0.55,
        distortion: 0.15,
        wrap: 0.35,
        fresnelEta: 1.55,
        fresnelPower: 3.5,
        dispersion: 0.01,
        roughness: 0.25,
        anisoStrength: 1.4,
        kajiyaPower1: 48,
        kajiyaPower2: 16,
        kajiyaSpec1: 1.3,
        kajiyaSpec2: 0.7
    },
    foliage: {
        sigmaT: [
            2.5,
            0.5,
            3.2
        ],
        gForward: 0.68,
        distortion: 0.2,
        wrap: 0.4,
        fresnelEta: 1.45,
        fresnelPower: 2.8,
        dispersion: 0.015,
        roughness: 0.35,
        anisoStrength: 0.3,
        kajiyaPower1: 24,
        kajiyaPower2: 8,
        kajiyaSpec1: 0.5,
        kajiyaSpec2: 0.3
    },
    metal_aniso: {
        sigmaT: [
            0.8,
            0.8,
            0.8
        ],
        gForward: 0.5,
        distortion: 0.1,
        wrap: 0.2,
        fresnelEta: 2.4,
        fresnelPower: 5.0,
        dispersion: 0.04,
        roughness: 0.15,
        anisoStrength: 1.5,
        kajiyaPower1: 80,
        kajiyaPower2: 32,
        kajiyaSpec1: 1.6,
        kajiyaSpec2: 0.8
    }
};
function phaseHG2D(cosTheta, g) {
    const gClamped = Math.max(-0.95, Math.min(0.95, g));
    const g2 = gClamped * gClamped;
    const cosT = Math.max(-1.0, Math.min(1.0, cosTheta));
    const denom = Math.max(1e-4, 1.0 + g2 - 2.0 * gClamped * cosT);
    return (1.0 - g2) / (2.0 * Math.PI * Math.pow(denom, 1.5));
}
function evaluateDielectricFresnel(cosTheta, etaBase, dispersion, roughness, fresnelPower = 5.0) {
    const cosT = Math.max(0.0, Math.min(1.0, cosTheta));
    const etaR = Math.max(1.01, etaBase - dispersion);
    const etaG = Math.max(1.01, etaBase);
    const etaB = Math.max(1.01, etaBase + dispersion);
    const f0R = Math.pow((etaR - 1) / (etaR + 1), 2);
    const f0G = Math.pow((etaG - 1) / (etaG + 1), 2);
    const f0B = Math.pow((etaB - 1) / (etaB + 1), 2);
    const fMax = Math.max(0.0, 1.0 - roughness);
    const grazingTerm = Math.pow(1.0 - cosT, fresnelPower);
    return [
        f0R + (Math.max(fMax, f0R) - f0R) * grazingTerm,
        f0G + (Math.max(fMax, f0G) - f0G) * grazingTerm,
        f0B + (Math.max(fMax, f0B) - f0B) * grazingTerm
    ];
}
function computeAnisotropicTangentField(normalField, width, height, flowPreset, angleDeg) {
    const tx = new Float32Array(width * height);
    const ty = new Float32Array(width * height);
    const angleRad = angleDeg * Math.PI / 180;
    const cosA = Math.cos(angleRad);
    const sinA = Math.sin(angleRad);
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            const nx = normalField.nx[idx];
            const ny = normalField.ny[idx];
            let bx = 0;
            let by = 0;
            if (flowPreset === 'vertical') {
                bx = 0;
                by = 1;
            } else if (flowPreset === 'horizontal') {
                bx = 1;
                by = 0;
            } else if (flowPreset === 'radial') {
                const cx = width / 2;
                const cy = height / 2;
                const dx = x - cx;
                const dy = y - cy;
                const len = Math.sqrt(dx * dx + dy * dy) || 1;
                bx = -dy / len;
                by = dx / len;
            } else {
                const len = Math.sqrt(nx * nx + ny * ny) || 1;
                bx = -ny / len;
                by = nx / len;
            }
            const rx = bx * cosA - by * sinA;
            const ry = bx * sinA + by * cosA;
            const rLen = Math.sqrt(rx * rx + ry * ry) || 1;
            tx[idx] = rx / rLen;
            ty[idx] = ry / rLen;
        }
    }
    return {
        tx,
        ty
    };
}
function snapToGemstoneFacets(nx, ny, nz, width, height, numSectors = 8) {
    const outNx = new Float32Array(width * height);
    const outNy = new Float32Array(width * height);
    const outNz = new Float32Array(width * height);
    const sectorAngle = 2 * Math.PI / numSectors;
    for(let i = 0; i < width * height; i++){
        const x = nx[i];
        const y = ny[i];
        const z = nz[i];
        const planarLen = Math.sqrt(x * x + y * y);
        if (planarLen < 0.08) {
            outNx[i] = 0;
            outNy[i] = 0;
            outNz[i] = 1.0;
        } else {
            let angle = Math.atan2(y, x);
            if (angle < 0) angle += 2 * Math.PI;
            const snappedAngle = Math.round(angle / sectorAngle) * sectorAngle;
            const snappedElevation = Math.max(0.35, Math.round(z * 3) / 3);
            const snappedPlanar = Math.sqrt(Math.max(0, 1 - snappedElevation * snappedElevation));
            outNx[i] = snappedPlanar * Math.cos(snappedAngle);
            outNy[i] = snappedPlanar * Math.sin(snappedAngle);
            outNz[i] = snappedElevation;
        }
    }
    return {
        nx: outNx,
        ny: outNy,
        nz: outNz,
        width,
        height
    };
}
function cleanOrphanPixelConfetti(data, width, height) {
    const copy = new Uint8ClampedArray(data);
    for(let y = 1; y < height - 1; y++){
        for(let x = 1; x < width - 1; x++){
            const idx = (y * width + x) * 4;
            if (copy[idx + 3] === 0) continue;
            const r = copy[idx];
            const g = copy[idx + 1];
            const b = copy[idx + 2];
            const up = ((y - 1) * width + x) * 4;
            const down = ((y + 1) * width + x) * 4;
            const left = (y * width + (x - 1)) * 4;
            const right = (y * width + (x + 1)) * 4;
            const matches = (nIdx)=>{
                if (copy[nIdx + 3] === 0) return false;
                return copy[nIdx] === r && copy[nIdx + 1] === g && copy[nIdx + 2] === b;
            };
            const neighborMatches = (matches(up) ? 1 : 0) + (matches(down) ? 1 : 0) + (matches(left) ? 1 : 0) + (matches(right) ? 1 : 0);
            if (neighborMatches === 0) {
                const neighbors = [
                    up,
                    down,
                    left,
                    right
                ].filter((n)=>copy[n + 3] > 0);
                if (neighbors.length > 0) {
                    const target = neighbors[0];
                    data[idx] = copy[target];
                    data[idx + 1] = copy[target + 1];
                    data[idx + 2] = copy[target + 2];
                }
            }
        }
    }
}
function buildCelRamp(r, g, b) {
    const lab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(r, g, b);
    const lch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToOKLCH"])(lab.L, lab.a, lab.b);
    // Preserve the authored hue/chroma family. Earlier blue-violet hue shifts
    // visibly repainted sprites and made the lighting look like corruption.
    // 1. Soft / Half-Tone Transition Shadow (penumbra step between base and core shadow)
    const softL = Math.max(0.05, Math.min(lch.L * 0.93, lch.L - 0.015));
    const softLab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToOKLab"])(softL, lch.C, lch.h);
    const softRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToRGB"])(softLab.L, softLab.a, softLab.b);
    // 2. Directional Mid-Shadow (core shadow)
    const shadowL = Math.max(0.04, Math.min(lch.L * 0.86, lch.L - 0.025));
    const shadowH = lch.h;
    const shadowC = lch.C;
    const shadowLab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToOKLab"])(shadowL, shadowC, shadowH);
    const shadowRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToRGB"])(shadowLab.L, shadowLab.a, shadowLab.b);
    // 3. Deep Crevice / Umbra Tone (occluded seams, under-chin, inner folds)
    const deepL = Math.max(0.02, Math.min(lch.L * 0.72, lch.L - 0.05));
    const deepH = lch.h;
    const deepC = lch.C;
    const deepLab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToOKLab"])(deepL, deepC, deepH);
    const deepRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToRGB"])(deepLab.L, deepLab.a, deepLab.b);
    // 4. Highlight raises lightness without changing the artwork's hue identity.
    const hiL = Math.min(0.98, lch.L + (0.98 - lch.L) * 0.22);
    const hiH = lch.h;
    const hiC = lch.C;
    const hiLab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToOKLab"])(hiL, hiC, hiH);
    const hiRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToRGB"])(hiLab.L, hiLab.a, hiLab.b);
    return {
        baseR: r,
        baseG: g,
        baseB: b,
        softR: softRgb.r,
        softG: softRgb.g,
        softB: softRgb.b,
        shadowR: shadowRgb.r,
        shadowG: shadowRgb.g,
        shadowB: shadowRgb.b,
        deepR: deepRgb.r,
        deepG: deepRgb.g,
        deepB: deepRgb.b,
        hiR: hiRgb.r,
        hiG: hiRgb.g,
        hiB: hiRgb.b
    };
}
function hueDistance(a, b) {
    const distance = Math.abs(a - b) % 360;
    return Math.min(distance, 360 - distance);
}
/**
 * Finds likely authored palette ramps without flattening them. The returned
 * lightness bounds are only a guardrail for ratio-image relighting: they let us
 * lift a painted shadow toward an existing light tone, while preserving every
 * pixel's hue, chroma, texture, and local value differences.
 */ function buildArtworkRampBounds(data, isFeatureMask) {
    const stats = new Map();
    for(let pIdx = 0, idx = 0; pIdx < data.length; pIdx += 4, idx++){
        if (data[pIdx + 3] <= 30 || isFeatureMask?.[idx] === 1) continue;
        const r = data[pIdx];
        const g = data[pIdx + 1];
        const b = data[pIdx + 2];
        const key = r << 16 | g << 8 | b;
        const existing = stats.get(key);
        if (existing) {
            existing.count++;
        } else {
            stats.set(key, {
                r,
                g,
                b,
                count: 1
            });
        }
    }
    const samples = Array.from(stats.entries()).map(([key, color])=>{
        const lab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(color.r, color.g, color.b);
        const lch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToOKLCH"])(lab.L, lab.a, lab.b);
        return {
            key,
            count: color.count,
            L: lch.L,
            a: lab.a,
            b: lab.b,
            C: lch.C,
            h: lch.h
        };
    });
    const clusters = [];
    for (const sample of samples.sort((a, b)=>b.count - a.count)){
        // Near-neutral ramps cannot be separated reliably by hue. Leaving them
        // untouched prevents white, grey, and black costume regions from merging.
        if (sample.C < 0.025) continue;
        let bestCluster = null;
        let bestDistance = Number.POSITIVE_INFINITY;
        for (const cluster of clusters){
            const anchor = cluster[0];
            const hDistance = hueDistance(sample.h, anchor.h);
            const cDistance = Math.abs(sample.C - anchor.C);
            const distance = hDistance / 24 + cDistance / 0.10;
            if (hDistance <= 24 && cDistance <= 0.10 && distance < bestDistance) {
                bestCluster = cluster;
                bestDistance = distance;
            }
        }
        if (bestCluster) {
            bestCluster.push(sample);
        } else {
            clusters.push([
                sample
            ]);
        }
    }
    const rampBounds = new Map();
    for (const cluster of clusters){
        if (cluster.length < 2) continue;
        const minL = Math.min(...cluster.map((sample)=>sample.L));
        const maxL = Math.max(...cluster.map((sample)=>sample.L));
        if (maxL - minL < 0.08) continue;
        const candidates = cluster.filter((sample)=>sample.L >= maxL - 0.12);
        const reference = candidates.reduce((best, sample)=>{
            if (sample.count !== best.count) return sample.count > best.count ? sample : best;
            return sample.L > best.L ? sample : best;
        });
        for (const sample of cluster){
            rampBounds.set(sample.key, {
                minL,
                maxL,
                referenceL: reference.L,
                referenceA: reference.a,
                referenceB: reference.b
            });
        }
    }
    return rampBounds;
}
function computePhotometricAnalysis(srcCtx, width, height, params, precomputedInference, precomputedData) {
    const data = precomputedData && precomputedData.length === width * height * 4 ? precomputedData : srcCtx.getImageData(0, 0, width, height).data;
    const sourceLighting = precomputedInference ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricAuto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inferPhotometricSettings"])(data, width, height);
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    let formType = params.formType;
    let inferredCavity = 1.0;
    if (!formType || formType === 'auto' || params.cavityStrength === undefined) {
        const inferred = sourceLighting;
        if (!formType || formType === 'auto') formType = inferred.formType;
        inferredCavity = inferred.cavityStrength;
    }
    const effectiveCavity = params.cavityStrength ?? inferredCavity ?? 1.0;
    let normalField;
    let baseNormalField = undefined;
    let appendageData = null;
    let cavityAO;
    let isFeatureMask = null;
    let isInkLineMask = null;
    if (formType === 'character') {
        const analysis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeContentAwareHeightmap"])(data, width, height, effectiveCavity, 2.0, params.lightAzimuth);
        normalField = analysis.normalField;
        baseNormalField = analysis.baseNormalField;
        appendageData = analysis.appendageData ?? null;
        cavityAO = analysis.cavityAO;
        isFeatureMask = analysis.isFeature;
        isInkLineMask = analysis.isInkLine;
    } else if (formType === 'orb') {
        const distanceMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])(isOpaque, width, height);
        const rawHeightmap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateInflatedHeightmap"])(distanceMap, width, height, 0.5);
        const smoothHeightmap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyBilateralFilter"])(rawHeightmap, width, height, 1.5, 2.0);
        normalField = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeTangentNormalField"])(smoothHeightmap, width, height, 2.0);
        cavityAO = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeDiscreteLaplaceCavity"])(smoothHeightmap, width, height, effectiveCavity);
    } else {
        // Props and general shapes: computeContentAwareHeightmap decomposes artwork into parts, lines, and crevices
        const analysis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeContentAwareHeightmap"])(data, width, height, effectiveCavity, 2.0, params.lightAzimuth);
        normalField = analysis.normalField;
        baseNormalField = analysis.baseNormalField;
        appendageData = analysis.appendageData ?? null;
        cavityAO = analysis.cavityAO;
        isFeatureMask = analysis.isFeature;
        isInkLineMask = analysis.isInkLine;
    }
    // Keep reflected light independent of palette boundaries. Reuse orb geometry;
    // other forms get a cached silhouette estimate, overridden by painted normals.
    const glintNormalField = params.glintStyle !== undefined ? formType === 'orb' ? normalField : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeTangentNormalField"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyBilateralFilter"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateInflatedHeightmap"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])(isOpaque, width, height), width, height, 0.5), width, height, 1.5, 2), width, height, 2) : undefined;
    // Pre-blend custom manual sculpt normals (from dedicated normal layers or chisel strokes) using RNM
    if (params.normalMapData) {
        const nData = params.normalMapData instanceof ImageData ? params.normalMapData.data : params.normalMapData;
        for(let y = 0; y < height; y++){
            for(let x = 0; x < width; x++){
                const pIdx = (y * width + x) * 4;
                const idx = y * width + x;
                if (nData[pIdx + 3] > 20) {
                    const detail = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodeNormalRGB"])(nData[pIdx], nData[pIdx + 1], nData[pIdx + 2], true);
                    const base = [
                        normalField.nx[idx],
                        normalField.ny[idx],
                        normalField.nz[idx]
                    ];
                    const blended = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["blendNormalsRNM"])(base, detail);
                    normalField.nx[idx] = blended[0];
                    normalField.ny[idx] = blended[1];
                    normalField.nz[idx] = blended[2];
                    if (baseNormalField) {
                        const baseOrig = [
                            baseNormalField.nx[idx],
                            baseNormalField.ny[idx],
                            baseNormalField.nz[idx]
                        ];
                        const blendedBase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["blendNormalsRNM"])(baseOrig, detail);
                        baseNormalField.nx[idx] = blendedBase[0];
                        baseNormalField.ny[idx] = blendedBase[1];
                        baseNormalField.nz[idx] = blendedBase[2];
                    }
                }
            }
        }
    }
    return {
        formType,
        normalField,
        baseNormalField,
        glintNormalField,
        appendageData,
        cavityAO,
        isFeatureMask,
        isInkLineMask,
        sourceLightAzimuth: sourceLighting.lightAzimuth,
        sourceLightElevation: sourceLighting.lightElevation,
        directionalShadingCue: sourceLighting.directionalShadingCue,
        artworkRampBounds: buildArtworkRampBounds(data, isFeatureMask)
    };
}
function executePhotometricPipeline(srcCtx, width, height, params, paletteHex = [], precomputedData) {
    const data = precomputedData && precomputedData.length === width * height * 4 ? precomputedData : srcCtx.getImageData(0, 0, width, height).data;
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    const skinMode = params.minecraftSkinMode ?? 'auto';
    let isMcSkin = false;
    if (width === 64 && (height === 64 || height === 32)) {
        if (skinMode === 'enabled') {
            isMcSkin = true;
        } else if (skinMode === 'auto' && params.formType !== 'character' && params.formType !== 'orb' && params.formType !== 'prop') {
            isMcSkin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$minecraftSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["detectMinecraftSkin"])(isOpaque, width, height);
        }
    }
    if (isMcSkin) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$minecraftSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["executeMinecraftSkinShadingPipeline"])(srcCtx, width, height, params);
    }
    let formType;
    let normalField;
    let cavityAO;
    let isFeatureMask = null;
    let isInkLineMask = null;
    let artworkRampBounds;
    let geometry = params.precomputedAnalysis;
    if (params.precomputedAnalysis) {
        formType = params.precomputedAnalysis.formType;
        normalField = params.precomputedAnalysis.normalField;
        if (params.precomputedAnalysis.baseNormalField && params.precomputedAnalysis.appendageData) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyAppendageStabilization"])(normalField, params.precomputedAnalysis.baseNormalField, params.precomputedAnalysis.appendageData, params.lightAzimuth);
        }
        cavityAO = params.precomputedAnalysis.cavityAO;
        isFeatureMask = params.precomputedAnalysis.isFeatureMask ?? null;
        isInkLineMask = params.precomputedAnalysis.isInkLineMask ?? null;
        artworkRampBounds = params.precomputedAnalysis.artworkRampBounds;
    } else {
        const analysis = computePhotometricAnalysis(srcCtx, width, height, params);
        geometry = analysis;
        formType = analysis.formType;
        normalField = analysis.normalField;
        cavityAO = analysis.cavityAO;
        isFeatureMask = analysis.isFeatureMask ?? null;
        isInkLineMask = analysis.isInkLineMask ?? null;
        artworkRampBounds = analysis.artworkRampBounds;
    }
    const mat = MATERIAL_PROFILES[params.material] || MATERIAL_PROFILES.matte;
    const brightness = params.lightBrightness ?? 1.15;
    const azRad = params.lightAzimuth * Math.PI / 180;
    const elRad = Math.max(10, params.lightElevation) * Math.PI / 180;
    const Lx = Math.sin(azRad) * Math.cos(elRad);
    const Ly = -Math.cos(azRad) * Math.cos(elRad);
    const Lz = Math.sin(elRad);
    const Vx = 0;
    const Vy = 0;
    const Vz = 1.0;
    const Hx = Lx + Vx;
    const Hy = Ly + Vy;
    const Hz = Lz + Vz;
    const hLen = Math.sqrt(Hx * Hx + Hy * Hy + Hz * Hz) || 1;
    const normHx = Hx / hLen;
    const normHy = Hy / hLen;
    const normHz = Hz / hLen;
    const lightRgba = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgba"])(params.lightColor || '#FFFFFF');
    const lightR = lightRgba.r / 255;
    const lightG = lightRgba.g / 255;
    const lightB = lightRgba.b / 255;
    const paletteRgba = paletteHex.map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgba"]);
    const paletteOKLab = paletteRgba.map((c)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(c.r, c.g, c.b));
    const celRampCache = new Map();
    const getCelRamp = (r, g, b)=>{
        const key = r << 16 | g << 8 | b;
        let ramp = celRampCache.get(key);
        if (!ramp) {
            ramp = buildCelRamp(r, g, b);
            celRampCache.set(key, ramp);
        }
        return ramp;
    };
    artworkRampBounds = paletteOKLab.length === 0 ? artworkRampBounds ?? buildArtworkRampBounds(data, isFeatureMask) : undefined;
    // Headless fallback uses only canvas/context methods shared with HTMLCanvasElement.
    const outputCanvas = typeof document !== 'undefined' ? document.createElement('canvas') : new OffscreenCanvas(width, height);
    outputCanvas.width = width;
    outputCanvas.height = height;
    const outCtx = outputCanvas.getContext('2d');
    const outImgData = outCtx.createImageData(width, height);
    const outData = outImgData.data;
    const hasCustomCenter = params.lightCenterX !== undefined && params.lightCenterY !== undefined;
    const lCenterX = hasCustomCenter ? params.lightCenterX : width / 2;
    const lCenterY = hasCustomCenter ? params.lightCenterY : height / 2;
    const sceneScale = Math.max(width, height);
    const lightOrbitDistance = Math.max(8, sceneScale * 1.25);
    const pointLightX = lCenterX + Lx * lightOrbitDistance;
    const pointLightY = lCenterY + Ly * lightOrbitDistance;
    const pointLightZ = Lz * lightOrbitDistance;
    const radiusScale = Math.max(0.35, Math.min(2, (params.lightRadius ?? 64) / 64));
    const focusRadius = Math.max(4, sceneScale * 0.65 * radiusScale);
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            const pIdx = idx * 4;
            if (!isOpaque(x, y)) {
                outData[pIdx + 3] = 0;
                continue;
            }
            // 1. Feature protection: eyes, pupils, mouth, nose retain exact artist colors
            if (isFeatureMask && isFeatureMask[idx] === 1) {
                outData[pIdx] = data[pIdx];
                outData[pIdx + 1] = data[pIdx + 1];
                outData[pIdx + 2] = data[pIdx + 2];
                outData[pIdx + 3] = data[pIdx + 3];
                continue;
            }
            // 2. Outline & whisker protection: keep dark line art crisp
            if (isInkLineMask && isInkLineMask[idx] === 1) {
                const origLum = (0.2126 * data[pIdx] + 0.7152 * data[pIdx + 1] + 0.0722 * data[pIdx + 2]) / 255;
                if (origLum < 0.22) {
                    outData[pIdx] = data[pIdx];
                    outData[pIdx + 1] = data[pIdx + 1];
                    outData[pIdx + 2] = data[pIdx + 2];
                    outData[pIdx + 3] = data[pIdx + 3];
                    continue;
                }
            }
            const Nx = normalField.nx[idx];
            const Ny = normalField.ny[idx];
            const Nz = normalField.nz[idx];
            const ao = cavityAO[idx];
            let pixLx = Lx;
            let pixLy = Ly;
            let pixLz = Lz;
            let pixNormHx = normHx;
            let pixNormHy = normHy;
            let pixNormHz = normHz;
            let effectiveFalloff = 1.0;
            if (hasCustomCenter) {
                // Treat the dragged center as the point light's target position. The
                // bulb's azimuth/elevation offsets a virtual light from that target;
                // translating the center therefore changes both local direction and
                // spatial intensity instead of merely nudging a global multiplier.
                const toLightX = pointLightX - x;
                const toLightY = pointLightY - y;
                const toLightZ = pointLightZ;
                const toLightLength = Math.sqrt(toLightX * toLightX + toLightY * toLightY + toLightZ * toLightZ) || 1;
                pixLx = toLightX / toLightLength;
                pixLy = toLightY / toLightLength;
                pixLz = toLightZ / toLightLength;
                const localHx = pixLx + Vx;
                const localHy = pixLy + Vy;
                const localHz = pixLz + Vz;
                const localHLength = Math.sqrt(localHx * localHx + localHy * localHy + localHz * localHz) || 1;
                pixNormHx = localHx / localHLength;
                pixNormHy = localHy / localHLength;
                pixNormHz = localHz / localHLength;
                const focusDx = lCenterX - x;
                const focusDy = lCenterY - y;
                const focusDistance = Math.sqrt(focusDx * focusDx + focusDy * focusDy);
                const normalizedFocusDistance = focusDistance / focusRadius;
                const inverseQuadratic = 1 / (1 + 1.8 * normalizedFocusDistance * normalizedFocusDistance);
                // Retain a small fill contribution outside the focus so moving the
                // handle never punches a hard circular hole into pixel art.
                effectiveFalloff = 0.18 + inverseQuadratic * 0.82;
            }
            // Half-Lambert Wrap Lighting (Valve Mitchell/McTaggart/Green 2006 formulation)
            // w = 0.55 softens the shadow terminator so light wraps gently around rounded volumes.
            const rawNdotL = Nx * pixLx + Ny * pixLy + Nz * pixLz;
            const wrapNdotL = Math.pow(Math.max(0, (rawNdotL + 0.55) / 1.55), 1.25);
            // Light strength controls the lamp, not the room. Multiplying ambient by
            // strength (and then multiplying the final result again) previously
            // clipped most pixels at 250%, erasing the bulb direction.
            const effectiveAmbient = Math.max(0.08, Math.min(0.65, params.ambientIntensity ?? 0.42));
            const sourceKey = data[pIdx] << 16 | data[pIdx + 1] << 8 | data[pIdx + 2];
            const rampBounds = artworkRampBounds?.get(sourceKey);
            let byteR = data[pIdx];
            let byteG = data[pIdx + 1];
            let byteB = data[pIdx + 2];
            if (rampBounds && (params.sourceShadingRemoval ?? 0) > 0) {
                const sourceLab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(byteR, byteG, byteB);
                const sourceLch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToOKLCH"])(sourceLab.L, sourceLab.a, sourceLab.b);
                const rampSpan = Math.max(0.08, rampBounds.maxL - rampBounds.minL);
                const authoredDarkness = Math.max(0, Math.min(1, (rampBounds.maxL - sourceLch.L) / rampSpan));
                // At 100%, every non-feature color in a detected hue ramp converges on
                // one albedo representative. The current N┬╖L then creates all visible
                // cel tones, so an old purple shadow cannot remain fixed in place.
                const removalAmount = authoredDarkness > 0.02 ? Math.max(0, Math.min(1, params.sourceShadingRemoval ?? 0)) : 0;
                if (removalAmount > 0.01) {
                    // Bounded intrinsic-style normalization: only colors belonging to a
                    // detected chromatic ramp are lifted toward that ramp's representative
                    // albedo. Protected features, ink, neutral colors, hue and chroma
                    // families remain separate.
                    const recoveredLab = {
                        L: sourceLab.L + (rampBounds.referenceL - sourceLab.L) * removalAmount,
                        a: sourceLab.a + (rampBounds.referenceA - sourceLab.a) * removalAmount,
                        b: sourceLab.b + (rampBounds.referenceB - sourceLab.b) * removalAmount
                    };
                    const recoveredRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToRGB"])(recoveredLab.L, recoveredLab.a, recoveredLab.b);
                    byteR = recoveredRgb.r;
                    byteG = recoveredRgb.g;
                    byteB = recoveredRgb.b;
                }
            }
            const origR = byteR / 255;
            const origG = byteG / 255;
            const origB = byteB / 255;
            const useCelShading = (params.shadingBands !== undefined || formType === 'character') && paletteOKLab.length === 0;
            if (useCelShading) {
                // Discrete OKLCH cel-shading mode: discrete OKLCH tone stepping with cached ramps for character anatomy & pixel art forms.
                // Preserves hand-drawn pixel art palette purity instead of generating muddy 24-bit float gradients.
                //
                // Shadow placement is driven PURELY by the directional diffuse signal (wrapNdotL).
                // The ambient contribution must NOT factor into shadow threshold decisions ΓÇö it fills all
                // surfaces equally and would overwhelm the directional terminator (ambSignal Γëê 1.27 makes
                // lightLevel > shadowThresh everywhere, producing a visually flat result with zero shadow).
                const diffSignal = wrapNdotL * effectiveFalloff;
                const ramp = getCelRamp(byteR, byteG, byteB);
                // Directional cel shadow terminator threshold:
                // diffSignal ranges from 0 (surface facing away from light) to ~1 (surface facing light).
                // Modulated inversely by lamp strength (brightness): higher strength pushes the shadow boundary back
                // (fewer shadow pixels, illuminating more of the character anatomy), while dimmer strength
                // causes shadows to encroach forward across the surface (more shadow pixels).
                let shadowThresh;
                if (brightness <= 1.15) {
                    const t = Math.max(0, Math.min(1, (1.15 - brightness) / 0.85));
                    shadowThresh = 0.52 + t * 0.30;
                } else {
                    const t = Math.max(0, Math.min(1, (brightness - 1.15) / 1.35));
                    shadowThresh = 0.52 - t * 0.32;
                }
                if (params.ditherModulation > 0) {
                    const ditherVal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBayerMatrixThreshold"])(x, y, params.bayerSize);
                    shadowThresh += (ditherVal - 0.5) * 0.16 * params.ditherModulation;
                }
                // Cavity AO crevice threshold: deep concave seams trigger the darkest tone.
                // Dynamically scales with cavityStrength to prevent dense thin-appendage geometry from being engulfed.
                const cavStrength = params.cavityStrength ?? 1.0;
                const creviceAOThresh = Math.min(0.30, Math.max(0.12, 0.12 + 0.16 * cavStrength));
                // Highlight condition: only for shiny/metallic materials (never on matte clay or velvet fabric)
                const isShinyMaterial = params.glintStyle === undefined && mat.ks > 0.1 && params.material !== 'matte' && params.material !== 'fabric';
                // Highlight uses the full directional signal amplified by brightness
                const highlightLevel = diffSignal * brightness;
                // Shading bands mode: 1 = Single (1 shadow color), 2 = Dual (2 shadow colors), 3 = Trio (3 shadow colors)
                const bands = params.shadingBands ?? 2;
                let toneR;
                let toneG;
                let toneB;
                if (ao < creviceAOThresh && diffSignal < shadowThresh + 0.10) {
                    // Deep crevice tone (ambient cavity occlusion)
                    toneR = ramp.deepR;
                    toneG = ramp.deepG;
                    toneB = ramp.deepB;
                } else if (diffSignal < shadowThresh) {
                    // Directional shadow tones partitioned by shading band count
                    if (bands === 1) {
                        // Single shading mode: 1 shadow tone across entire shadow side
                        toneR = ramp.shadowR;
                        toneG = ramp.shadowG;
                        toneB = ramp.shadowB;
                    } else if (bands === 3) {
                        // Trio shading mode: 3 shadow tones (soft penumbra -> core mid-shadow -> deep umbra)
                        const splitUmbra = shadowThresh * 0.32;
                        const splitCore = shadowThresh * 0.65;
                        if (diffSignal < splitUmbra) {
                            toneR = ramp.deepR;
                            toneG = ramp.deepG;
                            toneB = ramp.deepB;
                        } else if (diffSignal < splitCore) {
                            toneR = ramp.shadowR;
                            toneG = ramp.shadowG;
                            toneB = ramp.shadowB;
                        } else {
                            toneR = ramp.softR;
                            toneG = ramp.softG;
                            toneB = ramp.softB;
                        }
                    } else {
                        // Dual shading mode (default): 2 shadow tones (core mid-shadow + deep shadow)
                        const splitCore = shadowThresh * 0.48;
                        if (diffSignal < splitCore) {
                            toneR = ramp.deepR;
                            toneG = ramp.deepG;
                            toneB = ramp.deepB;
                        } else {
                            toneR = ramp.shadowR;
                            toneG = ramp.shadowG;
                            toneB = ramp.shadowB;
                        }
                    }
                } else if (highlightLevel > 1.10 && isShinyMaterial) {
                    // Specular highlight tone (only for shiny/metallic materials, suppressed on fabric/matte)
                    toneR = ramp.hiR;
                    toneG = ramp.hiG;
                    toneB = ramp.hiB;
                } else {
                    // Base authored artist color
                    toneR = ramp.baseR;
                    toneG = ramp.baseG;
                    toneB = ramp.baseB;
                }
                outData[pIdx] = toneR;
                outData[pIdx + 1] = toneG;
                outData[pIdx + 2] = toneB;
                outData[pIdx + 3] = data[pIdx + 3];
                continue;
            }
            // Standard diffuse + specular shading (for orbs, props, or when palette snapping)
            const lightIntensity = Math.max(0.3, Math.min(2.5, brightness));
            const diffR = mat.kd * wrapNdotL * (origR * lightR) * effectiveFalloff * lightIntensity;
            const diffG = mat.kd * wrapNdotL * (origG * lightG) * effectiveFalloff * lightIntensity;
            const diffB = mat.kd * wrapNdotL * (origB * lightB) * effectiveFalloff * lightIntensity;
            const NdotH = Math.max(0, Nx * pixNormHx + Ny * pixNormHy + Nz * pixNormHz);
            const Ispec = params.glintStyle === undefined ? mat.ks * Math.pow(NdotH, mat.shininess) : 0;
            let specR = Ispec * lightR * lightIntensity;
            let specG = Ispec * lightG * lightIntensity;
            let specB = Ispec * lightB * lightIntensity;
            if (mat.isMetallic) {
                specR *= origR;
                specG *= origG;
                specB *= origB;
            }
            const effectiveAO = formType === 'orb' ? Math.max(0.85, ao) : ao;
            const ambR = origR * effectiveAmbient * effectiveAO;
            const ambG = origG * effectiveAmbient * effectiveAO;
            const ambB = origB * effectiveAmbient * effectiveAO;
            let totalR = Math.max(0, Math.min(1.0, ambR + diffR + specR));
            let totalG = Math.max(0, Math.min(1.0, ambG + diffG + specG));
            let totalB = Math.max(0, Math.min(1.0, ambB + diffB + specB));
            if (params.ditherModulation > 0) {
                const threshold = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBayerMatrixThreshold"])(x, y, params.bayerSize);
                const offset = params.ditherModulation * (threshold - 0.5) * 0.25;
                totalR = Math.max(0, Math.min(1.0, totalR + offset));
                totalG = Math.max(0, Math.min(1.0, totalG + offset));
                totalB = Math.max(0, Math.min(1.0, totalB + offset));
            }
            const evalR = Math.round(totalR * 255);
            const evalG = Math.round(totalG * 255);
            const evalB = Math.round(totalB * 255);
            if (paletteOKLab.length > 0) {
                const pixelOKLab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(evalR, evalG, evalB);
                let closestIdx = 0;
                let minDiff = Infinity;
                for(let k = 0; k < paletteOKLab.length; k++){
                    const diff = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deltaEOKLab"])(pixelOKLab, paletteOKLab[k]);
                    if (diff < minDiff) {
                        minDiff = diff;
                        closestIdx = k;
                    }
                }
                const chosen = paletteRgba[closestIdx];
                outData[pIdx] = chosen.r;
                outData[pIdx + 1] = chosen.g;
                outData[pIdx + 2] = chosen.b;
                outData[pIdx + 3] = 255;
            } else {
                outData[pIdx] = evalR;
                outData[pIdx + 1] = evalG;
                outData[pIdx + 2] = evalB;
                outData[pIdx + 3] = 255;
            }
        }
    }
    if (params.glintStyle !== undefined && geometry) {
        const glints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$pixelGlint$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderPixelGlints"])(data, width, height, {
            ...params,
            glintStyle: params.glintStyle
        }, geometry);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$pixelGlint$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyPixelGlints"])(outData, width, glints);
        // Explicit palette snapping still constrains the finished highlight colors.
        if (paletteRgba.length > 0) {
            for (const pixel of glints){
                const offset = (pixel.y * width + pixel.x) * 4;
                const lab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(outData[offset], outData[offset + 1], outData[offset + 2]);
                let nearest = 0, distance = Infinity;
                for(let k = 0; k < paletteOKLab.length; k++){
                    const candidate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deltaEOKLab"])(lab, paletteOKLab[k]);
                    if (candidate < distance) {
                        distance = candidate;
                        nearest = k;
                    }
                }
                outData[offset] = paletteRgba[nearest].r;
                outData[offset + 1] = paletteRgba[nearest].g;
                outData[offset + 2] = paletteRgba[nearest].b;
            }
        }
        for(let offset = 3; offset < data.length; offset += 4){
            outData[offset] = data[offset];
            if (data[offset] <= 30) {
                outData[offset - 3] = data[offset - 3];
                outData[offset - 2] = data[offset - 2];
                outData[offset - 1] = data[offset - 1];
            }
        }
    }
    outCtx.putImageData(outImgData, 0, 0);
    return outputCanvas;
}
function renderParametric2p5DLighting(srcCtx, width, height, params) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    const skinMode = params.minecraftSkinMode ?? 'auto';
    let isMcSkin = false;
    if (width === 64 && (height === 64 || height === 32)) {
        if (skinMode === 'enabled') {
            isMcSkin = true;
        } else if (skinMode === 'auto') {
            isMcSkin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$minecraftSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["detectMinecraftSkin"])(isOpaque, width, height);
        }
    }
    const inferred = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricAuto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inferPhotometricSettings"])(data, width, height);
    const isCharacter = inferred.formType === 'character';
    const photometricParams = {
        lightAzimuth: params.azimuthDeg,
        lightElevation: params.elevationDeg,
        lightRadius: 64,
        lightColor: '#FFFFFF',
        ambientIntensity: 0.45,
        lightBrightness: 1.2,
        material: params.material || 'matte',
        shadingBands: params.shadingBands,
        cavityStrength: 1.0,
        ditherModulation: 0,
        bayerSize: '4x4',
        formType: inferred.formType,
        minecraftSkinMode: params.minecraftSkinMode
    };
    // Hoist analysis: execute computePhotometricAnalysis once locally
    // (which runs computeContentAwareHeightmap once for characters/props) and feed into executePhotometricPipeline.
    const analysis = !isMcSkin ? computePhotometricAnalysis(srcCtx, width, height, photometricParams, inferred, data) : undefined;
    const charFeatureMask = isCharacter && analysis ? analysis.isFeatureMask ?? null : null;
    const charInkMask = isCharacter && analysis ? analysis.isInkLineMask ?? null : null;
    // Smooth macro silhouette normal field for specular reflections:
    // Continuous 3D cushion without eye-socket cliffs or color-boundary cuts.
    const specularNormalField = isMcSkin ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$minecraftSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeMinecraftSkinNormalField"])(width, height) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeTangentNormalField"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyBilateralFilter"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateInflatedHeightmap"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])(isOpaque, width, height), width, height, 0.5), width, height, 1.5, 2.0), width, height, 2.0);
    const azRad = params.azimuthDeg * Math.PI / 180;
    const elRad = Math.max(15, params.elevationDeg) * Math.PI / 180;
    const Lx = Math.sin(azRad) * Math.cos(elRad);
    const Ly = -Math.cos(azRad) * Math.cos(elRad);
    const Lz = Math.sin(elRad);
    const Vx = 0;
    const Vy = 0;
    const Vz = 1.0;
    const Hx = Lx + Vx;
    const Hy = Ly + Vy;
    const Hz = Lz + Vz;
    const hLen = Math.sqrt(Hx * Hx + Hy * Hy + Hz * Hz) || 1;
    const normHx = Hx / hLen;
    const normHy = Hy / hLen;
    const normHz = Hz / hLen;
    const photometricCanvas = executePhotometricPipeline(srcCtx, width, height, {
        ...photometricParams,
        precomputedAnalysis: analysis
    }, [], data);
    const pData = photometricCanvas.getContext('2d').getImageData(0, 0, width, height).data;
    const shadedPixels = [];
    const specularPixels = [];
    const isMetallic = params.material === 'gold' || params.material === 'metal';
    const shininess = params.specularShininess || 16;
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            const pIdx = idx * 4;
            if (pData[pIdx + 3] > 30) {
                shadedPixels.push({
                    x,
                    y,
                    r: pData[pIdx],
                    g: pData[pIdx + 1],
                    b: pData[pIdx + 2],
                    a: pData[pIdx + 3]
                });
                // Exclude facial features (eyes, mouth) and line art/outlines from receiving specular highlight
                if (charFeatureMask && charFeatureMask[idx] === 1) continue;
                if (charInkMask && charInkMask[idx] === 1) continue;
                const isBlackOutline = data[pIdx] < 30 && data[pIdx + 1] < 30 && data[pIdx + 2] < 30;
                if (isBlackOutline) continue;
                // When illuminated from above (Ly < 0) on characters, exclude bottom limbs from stealing
                // key specular reflections from the head/face/torso.
                if (isCharacter && Ly < 0 && y > height * 0.70) continue;
                const Nx = specularNormalField.nx[idx];
                const Ny = specularNormalField.ny[idx];
                const Nz = specularNormalField.nz[idx];
                // 1. Physical 2.5D Line-of-Sight Visibility Gate:
                // A surface must be oriented towards the light in both 3D space and on the 2D illuminated slope:
                const NdotL3D = Nx * Lx + Ny * Ly + Nz * Lz;
                const NdotL2D = Nx * Lx + Ny * Ly;
                const isZenith = elRad > 75 * Math.PI / 180;
                if (NdotL3D <= 0 || !isZenith && NdotL2D <= 0) continue;
                const NdotH = Math.max(0, Nx * normHx + Ny * normHy + Nz * normHz);
                const Ispec = Math.pow(NdotH, shininess);
                if (Ispec > 0.35) {
                    const alpha = Math.min(255, Math.round(Ispec * 255));
                    let r = 255;
                    let g = 255;
                    let b = 255;
                    if (isMetallic) {
                        r = Math.min(255, Math.round(pData[pIdx] * 0.35 + 255 * 0.65));
                        g = Math.min(255, Math.round(pData[pIdx + 1] * 0.35 + 245 * 0.65));
                        b = Math.min(255, Math.round(pData[pIdx + 2] * 0.35 + 160 * 0.65));
                    }
                    specularPixels.push({
                        x,
                        y,
                        r,
                        g,
                        b,
                        a: alpha
                    });
                }
            }
        }
    }
    return {
        shadedPixels,
        specularPixels
    };
}
function executeVolumetricOpticalPipeline(srcCtx, width, height, params) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    const isBorder = (x, y)=>{
        if (!isOpaque(x, y)) return false;
        return !isOpaque(x + 1, y) || !isOpaque(x - 1, y) || !isOpaque(x, y + 1) || !isOpaque(x, y - 1);
    };
    const distanceMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])(isOpaque, width, height);
    let maxDist = 1;
    for(let i = 0; i < width * height; i++){
        if (distanceMap[i] > maxDist) maxDist = distanceMap[i];
    }
    const rawHeightmap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateInflatedHeightmap"])(distanceMap, width, height, 0.5);
    const smoothHeightmap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyBilateralFilter"])(rawHeightmap, width, height, 1.5, 2.0);
    let normalField = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeTangentNormalField"])(smoothHeightmap, width, height, 2.0);
    if (params.preset === 'gemstone' || params.facetedGems) {
        normalField = snapToGemstoneFacets(normalField.nx, normalField.ny, normalField.nz, width, height, 8);
    }
    const tangentField = computeAnisotropicTangentField(normalField, width, height, params.anisoFlow, params.anisoAngle);
    const profile = OPTICAL_PROFILES[params.preset] || OPTICAL_PROFILES.gemstone;
    const azRad = params.lightAzimuth * Math.PI / 180;
    const elRad = Math.max(10, params.lightElevation) * Math.PI / 180;
    const Lx = Math.sin(azRad) * Math.cos(elRad);
    const Ly = -Math.cos(azRad) * Math.cos(elRad);
    const Lz = Math.sin(elRad);
    const Vx = 0;
    const Vy = 0;
    const Vz = 1.0;
    const Hx = Lx + Vx;
    const Hy = Ly + Vy;
    const Hz = Lz + Vz;
    const hLen = Math.sqrt(Hx * Hx + Hy * Hy + Hz * Hz) || 1;
    const normHx = Hx / hLen;
    const normHy = Hy / hLen;
    const lightRgba = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgba"])(params.lightColor || '#FFFFFF');
    const lightR = lightRgba.r / 255;
    const lightG = lightRgba.g / 255;
    const lightB = lightRgba.b / 255;
    const paletteRgba = (params.paletteColors || []).map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgba"]);
    const paletteOKLab = paletteRgba.map((c)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(c.r, c.g, c.b));
    // Headless fallback uses only canvas/context methods shared with HTMLCanvasElement.
    const outputCanvas = typeof document !== 'undefined' ? document.createElement('canvas') : new OffscreenCanvas(width, height);
    outputCanvas.width = width;
    outputCanvas.height = height;
    const outCtx = outputCanvas.getContext('2d');
    const outImgData = outCtx.createImageData(width, height);
    const outData = outImgData.data;
    const celTones = params.celTones ?? 3;
    const numTones = typeof celTones === 'number' ? celTones : 3;
    const celRampCache = new Map();
    const getCelRamp = (r, g, b)=>{
        const key = r << 16 | g << 8 | b;
        let ramp = celRampCache.get(key);
        if (!ramp) {
            ramp = buildCelRamp(r, g, b);
            celRampCache.set(key, ramp);
        }
        return ramp;
    };
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const idx = y * width + x;
            const pIdx = idx * 4;
            if (!isOpaque(x, y)) {
                outData[pIdx + 3] = 0;
                continue;
            }
            const origR = data[pIdx] / 255;
            const origG = data[pIdx + 1] / 255;
            const origB = data[pIdx + 2] / 255;
            const origA = data[pIdx + 3];
            const Nx = normalField.nx[idx];
            const Ny = normalField.ny[idx];
            const Nz = normalField.nz[idx];
            const Tx = tangentField.tx[idx];
            const Ty = tangentField.ty[idx];
            const dist = distanceMap[idx];
            const NdotL = Nx * Lx + Ny * Ly + Nz * Lz;
            const effectiveDepth = Math.max(1, params.translucencyDepth);
            const opticalChord = 2.0 * Math.max(0.5, dist) / Math.max(0.08, NdotL + profile.wrap);
            const scaledChord = opticalChord / effectiveDepth;
            let sigmaR = profile.sigmaT[0];
            let sigmaG = profile.sigmaT[1];
            let sigmaB = profile.sigmaT[2];
            if (params.preset === 'gemstone' || params.preset === 'slime') {
                // Mineral & colloidal extinction adapts to the artwork's base pigment
                // Transmits the crystal's own hue while absorbing complementary wavelengths
                sigmaR = 0.35 + 2.5 * Math.max(0, 1 - origR);
                sigmaG = 0.35 + 2.5 * Math.max(0, 1 - origG);
                sigmaB = 0.35 + 2.5 * Math.max(0, 1 - origB);
            }
            const sssR = Math.exp(-sigmaR * scaledChord);
            const sssG = Math.exp(-sigmaG * scaledChord);
            const sssB = Math.exp(-sigmaB * scaledChord);
            const sLx = -(Lx + Nx * profile.distortion);
            const sLy = -(Ly + Ny * profile.distortion);
            const sLz = -(Lz + Nz * profile.distortion);
            const sLen = Math.sqrt(sLx * sLx + sLy * sLy + sLz * sLz) || 1;
            const cosTheta = (sLx * Vx + sLy * Vy + sLz * Vz) / sLen;
            const forwardScatter = phaseHG2D(cosTheta, profile.gForward);
            const coreMask = Math.pow(Math.max(0, (dist - 1.0) / Math.max(1.0, maxDist - 1.0)), 1.1);
            const forwardGlow = Math.min(1.0, Math.max(0, 1.8 * forwardScatter));
            const sssCoreFactor = (profile.wrap * 0.4 + (1 - profile.wrap * 0.4) * coreMask) * (0.3 + 0.7 * forwardGlow);
            const sssRadianceR = sssR * sssCoreFactor * lightR * 1.5;
            const sssRadianceG = sssG * sssCoreFactor * lightG * 1.5;
            const sssRadianceB = sssB * sssCoreFactor * lightB * 1.5;
            const cosView = Math.max(0, Nz);
            const fresnelPower = params.fresnelPower ?? profile.fresnelPower;
            const [fresR, fresG, fresB] = evaluateDielectricFresnel(cosView, profile.fresnelEta, profile.dispersion, profile.roughness, fresnelPower);
            const isSilBorder = isBorder(x, y);
            const rimLightGate = Math.max(0, NdotL + 0.25);
            const crescentRimBoost = isSilBorder ? 1.6 : 0.8;
            const rimRadianceR = fresR * rimLightGate * crescentRimBoost * lightR;
            const rimRadianceG = fresG * rimLightGate * crescentRimBoost * lightG;
            const rimRadianceB = fresB * rimLightGate * crescentRimBoost * lightB;
            const t1x = Tx + Nx * 0.1;
            const t1y = Ty + Ny * 0.1;
            const t1Len = Math.sqrt(t1x * t1x + t1y * t1y) || 1;
            const t2x = Tx - Nx * 0.15;
            const t2y = Ty - Ny * 0.15;
            const t2Len = Math.sqrt(t2x * t2x + t2y * t2y) || 1;
            const dotTH1 = t1x / t1Len * normHx + t1y / t1Len * normHy;
            const dotTH2 = t2x / t2Len * normHx + t2y / t2Len * normHy;
            const sinTH1 = Math.sqrt(Math.max(0.0, 1.0 - dotTH1 * dotTH1));
            const sinTH2 = Math.sqrt(Math.max(0.0, 1.0 - dotTH2 * dotTH2));
            let spec1 = profile.kajiyaSpec1 * Math.pow(sinTH1, profile.kajiyaPower1);
            const spec2 = profile.kajiyaSpec2 * Math.pow(sinTH2, profile.kajiyaPower2);
            if (params.preset === 'hair') {
                spec1 = sinTH1 > 0.65 ? Math.pow((sinTH1 - 0.65) / 0.35, 1.4) * 1.5 : 0;
            }
            const anisoHighlightR = (spec1 * lightR + spec2 * origR * lightR) * profile.anisoStrength;
            const anisoHighlightG = (spec1 * lightG + spec2 * origG * lightG) * profile.anisoStrength;
            const anisoHighlightB = (spec1 * lightB + spec2 * origB * lightB) * profile.anisoStrength;
            const diffuseLight = Math.max(0, NdotL);
            const totalLightSignal = 0.30 * diffuseLight + 0.45 * ((sssRadianceR + sssRadianceG + sssRadianceB) / 3) + 0.55 * ((rimRadianceR + rimRadianceG + rimRadianceB) / 3) + 0.50 * ((anisoHighlightR + anisoHighlightG + anisoHighlightB) / 3);
            let r255;
            let g255;
            let b255;
            let toneStep = 0;
            if (celTones === 'smooth') {
                const finalR = origR * 0.4 + origR * diffuseLight * 0.6 + sssRadianceR * 0.8 + rimRadianceR * 0.6 + anisoHighlightR * 0.7;
                const finalG = origG * 0.4 + origG * diffuseLight * 0.6 + sssRadianceG * 0.8 + rimRadianceG * 0.6 + anisoHighlightG * 0.7;
                const finalB = origB * 0.4 + origB * diffuseLight * 0.6 + sssRadianceB * 0.8 + rimRadianceB * 0.6 + anisoHighlightB * 0.7;
                r255 = Math.max(0, Math.min(255, Math.round(finalR * 255)));
                g255 = Math.max(0, Math.min(255, Math.round(finalG * 255)));
                b255 = Math.max(0, Math.min(255, Math.round(finalB * 255)));
            } else {
                let lightSignal = totalLightSignal;
                if (params.ditherModulation && params.ditherModulation > 0) {
                    const ditherVal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBayerMatrixThreshold"])(x, y, '4x4');
                    lightSignal += (ditherVal - 0.5) * 0.22 * params.ditherModulation;
                }
                toneStep = Math.min(numTones - 1, Math.max(0, Math.floor(lightSignal * (numTones + 0.3))));
                const ramp = getCelRamp(data[pIdx], data[pIdx + 1], data[pIdx + 2]);
                if (numTones === 2) {
                    if (toneStep === 0) {
                        r255 = ramp.shadowR;
                        g255 = ramp.shadowG;
                        b255 = ramp.shadowB;
                    } else {
                        r255 = ramp.hiR;
                        g255 = ramp.hiG;
                        b255 = ramp.hiB;
                    }
                } else if (numTones === 3) {
                    if (toneStep === 0) {
                        r255 = ramp.shadowR;
                        g255 = ramp.shadowG;
                        b255 = ramp.shadowB;
                    } else if (toneStep === 1) {
                        r255 = ramp.baseR;
                        g255 = ramp.baseG;
                        b255 = ramp.baseB;
                    } else {
                        r255 = ramp.hiR;
                        g255 = ramp.hiG;
                        b255 = ramp.hiB;
                    }
                } else {
                    // 4 tones
                    if (toneStep === 0) {
                        r255 = ramp.deepR;
                        g255 = ramp.deepG;
                        b255 = ramp.deepB;
                    } else if (toneStep === 1) {
                        r255 = ramp.shadowR;
                        g255 = ramp.shadowG;
                        b255 = ramp.shadowB;
                    } else if (toneStep === 2) {
                        r255 = ramp.baseR;
                        g255 = ramp.baseG;
                        b255 = ramp.baseB;
                    } else {
                        r255 = ramp.hiR;
                        g255 = ramp.hiG;
                        b255 = ramp.hiB;
                    }
                }
            }
            if (paletteOKLab.length > 0) {
                const pixelLab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(r255, g255, b255);
                let bestDist = Infinity;
                let bestColor = paletteRgba[0];
                for(let i = 0; i < paletteOKLab.length; i++){
                    const pLab = paletteOKLab[i];
                    const dist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deltaEOKLab"])(pixelLab, pLab);
                    if (dist < bestDist) {
                        bestDist = dist;
                        bestColor = paletteRgba[i];
                    }
                }
                r255 = bestColor.r;
                g255 = bestColor.g;
                b255 = bestColor.b;
            }
            outData[pIdx] = r255;
            outData[pIdx + 1] = g255;
            outData[pIdx + 2] = b255;
            outData[pIdx + 3] = origA;
        }
    }
    if (celTones !== 'smooth') {
        cleanOrphanPixelConfetti(outData, width, height);
    }
    outCtx.putImageData(outImgData, 0, 0);
    return outputCanvas;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/pixelGlint.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyPixelGlints",
    ()=>applyPixelGlints,
    "renderPixelGlints",
    ()=>renderPixelGlints
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/art/normalSculptor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/colorSpace.ts [app-client] (ecmascript)");
;
;
function renderPixelGlints(data, width, height, params, analysis) {
    if (params.glintStyle === 'off') return [];
    const normals = analysis.glintNormalField ?? analysis.normalField;
    const painted = params.normalMapData;
    const normalData = painted && ('data' in painted ? painted.data : painted);
    const azimuth = params.lightAzimuth * Math.PI / 180;
    const elevation = Math.max(10, Math.min(90, params.lightElevation)) * Math.PI / 180;
    const lx = Math.sin(azimuth) * Math.cos(elevation);
    const ly = -Math.cos(azimuth) * Math.cos(elevation);
    const lz = Math.sin(elevation);
    const orbit = Math.max(8, Math.max(width, height) * 1.25);
    const centered = params.lightCenterX !== undefined && params.lightCenterY !== undefined;
    const lightX = (params.lightCenterX ?? width / 2) + lx * orbit;
    const lightY = (params.lightCenterY ?? height / 2) + ly * orbit;
    const lightZ = lz * orbit;
    const soft = params.glintStyle === 'soft';
    // A finite lobe avoids the subpixel sparkle of a zero-roughness point light.
    const roughness = soft ? 0.52 : 0.38;
    const alphaSquared = roughness ** 4;
    const strength = Math.max(0.3, Math.min(2.5, params.lightBrightness ?? 1.15));
    // Material changes the reflection's weight without making matte highlights
    // disappear. Two flat coverage levels keep the result on the native pixel grid.
    const materialGain = {
        matte: 1,
        fabric: 0.85,
        metal: 1.08,
        gold: 1.08,
        glass: 1.04
    }[params.material] ?? 1;
    const colors = new Map();
    const pixels = [];
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const index = y * width + x;
            const offset = index * 4;
            if (data[offset + 3] <= 30 || analysis.isFeatureMask?.[index] || analysis.isInkLineMask?.[index]) continue;
            // Protect colored ink too; the old path only recognized near-black outlines.
            const luminance = (data[offset] * 0.2126 + data[offset + 1] * 0.7152 + data[offset + 2] * 0.0722) / 255;
            const border = x === 0 || y === 0 || x === width - 1 || y === height - 1 || data[offset - 4 + 3] <= 30 || data[offset + 4 + 3] <= 30 || data[offset - width * 4 + 3] <= 30 || data[offset + width * 4 + 3] <= 30;
            if (luminance < 0.045 || border && luminance < 0.28) continue;
            let nx = normals.nx[index], ny = normals.ny[index], nz = normals.nz[index];
            if (normalData && normalData[offset + 3] > 20) {
                // Painted surface normals override the estimated cushion for reflections.
                [nx, ny, nz] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodeNormalRGB"])(normalData[offset], normalData[offset + 1], normalData[offset + 2], true);
                ny = -ny; // Painted OpenGL +Y is up; the bulb and estimated field use screen +Y down.
            }
            const normalLength = Math.hypot(nx, ny, nz);
            if (!Number.isFinite(normalLength) || normalLength < 1e-6) continue;
            nx /= normalLength;
            ny /= normalLength;
            nz /= normalLength;
            let px = lx, py = ly, pz = lz;
            if (centered) {
                const distance = Math.hypot(lightX - x, lightY - y, lightZ) || 1;
                px = (lightX - x) / distance;
                py = (lightY - y) / distance;
                pz = lightZ / distance;
            }
            const noLight = nx * px + ny * py + nz * pz;
            if (noLight <= 0 || nz <= 0) continue;
            const halfLength = Math.hypot(px, py, pz + 1) || 1;
            const noHalf = Math.max(0, Math.min(1, (nx * px + ny * py + nz * (pz + 1)) / halfLength));
            const denominator = noHalf * noHalf * (alphaSquared - 1) + 1;
            const lobe = (alphaSquared / denominator) ** 2;
            if (lobe < 0.16) continue;
            // A bright core and a distinct shoulder, rather than translucent gradients.
            // Strength changes these two tones together; local NoL never adds extra shades.
            const core = lobe >= 0.5;
            const coverage = core ? soft ? 0.95 : 1 : soft ? 0.75 : 0.9;
            const opacity = Math.min(0.96, coverage * materialGain);
            const key = (data[offset] << 16 | data[offset + 1] << 8 | data[offset + 2]) * 2 + Number(core);
            let color = colors.get(key);
            if (!color) {
                const lab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(data[offset], data[offset + 1], data[offset + 2]);
                const lch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToOKLCH"])(lab.L, lab.a, lab.b);
                const lift = (core ? soft ? 0.32 : 0.4 : soft ? 0.2 : 0.28) * strength;
                const lifted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToOKLab"])(Math.min(0.98, lch.L + lift), lch.C, lch.h);
                color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToRGB"])(lifted.L, lifted.a, lifted.b);
                colors.set(key, color);
            }
            const alpha = Math.round(opacity * 255);
            // Canvas stores premultiplied bytes. Choose representable straight RGB so
            // reading/restoring a translucent layer through Undo cannot change its color.
            const stableChannel = (channel)=>alpha > 0 ? Math.round(Math.round(channel * alpha / 255) * 255 / alpha) : 0;
            pixels.push({
                x,
                y,
                r: stableChannel(color.r),
                g: stableChannel(color.g),
                b: stableChannel(color.b),
                a: alpha
            });
        }
    }
    return pixels;
}
function applyPixelGlints(data, width, pixels) {
    for (const pixel of pixels){
        const offset = (pixel.y * width + pixel.x) * 4;
        const opacity = pixel.a / 255;
        data[offset] = Math.round(data[offset] * (1 - opacity) + pixel.r * opacity);
        data[offset + 1] = Math.round(data[offset + 1] * (1 - opacity) + pixel.g * opacity);
        data[offset + 2] = Math.round(data[offset + 2] * (1 - opacity) + pixel.b * opacity);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/rotSprite.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "rotateWithRotSprite",
    ()=>rotateWithRotSprite
]);
/**
 * RotSprite-inspired pixel-art rotation adapter.
 *
 * Citations:
 * 1. Xenowhirl, "RotSprite: An algorithm for scaling and rotating pixel art", 2007.
 * 2. Eric Johnston, EPX (Eric's Pixel Expansion), LucasArts, 1992.
 * 3. Andrea Mazzoleni, Scale2x for AdvanceMAME, 2001 (equivalent output to EPX).
 *
 * Thin DOM adapter delegating to PixiBun's RotSprite-inspired engine in '@/lib/canvas/rotSprite'.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rotSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/rotSprite.ts [app-client] (ecmascript)");
;
;
function rotateWithRotSprite(srcCtx, width, height, angleDeg) {
    const angleRad = angleDeg * Math.PI / 180;
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rotSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotSprite"])({
        width,
        height,
        data: imgData.data
    }, angleRad);
    const outputCanvas = document.createElement('canvas');
    outputCanvas.width = result.width;
    outputCanvas.height = result.height;
    const outCtx = outputCanvas.getContext('2d');
    if (!outCtx) {
        throw new Error('Failed to acquire 2D context from destination canvas in rotateWithRotSprite');
    }
    const outImgData = outCtx.createImageData(result.width, result.height);
    outImgData.data.set(result.data);
    outCtx.putImageData(outImgData, 0, 0);
    return outputCanvas;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/math/shadowAuto.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Raymarched Soft Shadows Auto-Analysis Engine ("understands the art, then casts realistic soft shadows").
 *
 * Analyzes the composited canvas artwork and infers physically plausible
 * 2D cone tracing shadow parameters:
 *
 * 1. Silhouette & Spatial Bounding Box:
 *    - Scans non-transparent pixels (alpha > 30) to find bounding box [minX, maxX, minY, maxY]
 *    - Finds geometric center of mass (cx, cy) and contact ground baseline (maxY)
 *    - Identifies whether the sprite is standing grounded or floating
 *
 * 2. Directional Key Light Alignment:
 *    - Detects internal painted highlight mass bias, or harmonizes with studio key light azimuth/elevation
 *    - Places the 2D raymarching area light source (lightX, lightY) outside the silhouette along the light vector
 *    - Elevates light above the ground plane so rays cast realistic downward shadows across the floor
 *
 * 3. Scale-Aware Penumbra Sizing (Aaltonen Contact Hardening):
 *    - Scales area light radius (lightRadius) with sprite dimensions for razor-sharp contact shadows
 *      at the feet and soft, smooth penumbra falloff further away
 *
 * 4. Atmospheric Shadow Tinting (Color Theory):
 *    - Warm artwork (reds, oranges, warm golds) receives complementary cool atmospheric shadows (Indigo #180B26 or Violet #2E1065)
 *    - Cool artwork (blues, cyans, cold slates) receives grounded warm shadows (Umber #26140B or Obsidian #0A0612)
 *    - Nature/foliage receives deep forest tint (Teal/Fog #062419)
 *
 * 5. Ordered Bayer Dither:
 *    - Retro 4x4 matrix dither for authentic pixel art stippling
 *
 * Pure, DOM-free and deterministic for robust unit testing.
 */ __turbopack_context__.s([
    "inferRaymarchedShadowSettings",
    ()=>inferRaymarchedShadowSettings
]);
const OPAQUE_ALPHA = 30;
function inferRaymarchedShadowSettings(data, width, height, options) {
    const DEFAULTS = {
        lightX: Math.round(width / 2),
        lightY: Math.max(2, Math.round(height * 0.15)),
        lightRadius: 16,
        shadowOpacity: 0.6,
        shadowColor: '#180B26',
        ditherMode: 'none',
        rationale: 'Canvas is empty — assigned centered overhead studio light with clean flat shadow.',
        spriteBounds: {
            minX: 0,
            maxX: width - 1,
            minY: 0,
            maxY: height - 1,
            width,
            height,
            cx: Math.round(width / 2),
            cy: Math.round(height / 2)
        },
        isFloating: false,
        lightAzimuth: 315,
        lightElevation: 45
    };
    let minX = width;
    let maxX = 0;
    let minY = height;
    let maxY = 0;
    let count = 0;
    let sumX = 0;
    let sumY = 0;
    let lumSumX = 0;
    let lumSumY = 0;
    let lumTotal = 0;
    let sumR = 0;
    let sumG = 0;
    let sumB = 0;
    for(let y = 0; y < height; y++){
        const rowOffset = y * width;
        for(let x = 0; x < width; x++){
            const p = (rowOffset + x) * 4;
            const a = data[p + 3];
            if (a <= OPAQUE_ALPHA) continue;
            count++;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
            const r = data[p];
            const g = data[p + 1];
            const b = data[p + 2];
            const lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
            sumX += x;
            sumY += y;
            lumSumX += x * lum;
            lumSumY += y * lum;
            lumTotal += lum;
            sumR += r;
            sumG += g;
            sumB += b;
        }
    }
    if (count === 0 || lumTotal === 0) {
        return DEFAULTS;
    }
    const boxW = Math.max(1, maxX - minX + 1);
    const boxH = Math.max(1, maxY - minY + 1);
    const cx = Math.round(sumX / count);
    const cy = Math.round(sumY / count);
    // Detect whether sprite touches or floats above canvas bottom
    const distanceFromBottom = height - 1 - maxY;
    const isFloating = distanceFromBottom > Math.max(3, Math.round(height * 0.1));
    // --- 1. Light Direction (Azimuth & Elevation) -------------------------------
    const lx = lumSumX / lumTotal;
    const ly = lumSumY / lumTotal;
    const dx = lx - sumX / count;
    const dy = ly - sumY / count;
    const offsetMag = Math.sqrt(dx * dx + dy * dy);
    let azimuthDeg;
    let elevationDeg;
    if (offsetMag >= 0.35) {
        // Artwork has clear painted internal directional shading cues
        azimuthDeg = Math.round((Math.atan2(dx, -dy) * 180 / Math.PI + 360) % 360);
        const spriteRadius = Math.sqrt(count / Math.PI) || 1;
        const verticalBias = Math.max(-1, Math.min(1, -dy / (spriteRadius * 0.55)));
        elevationDeg = Math.round(Math.max(15, Math.min(85, 45 + 35 * verticalBias)));
    } else if (options?.keyLightAzimuth !== undefined) {
        // Align with scene/studio key light azimuth and elevation
        azimuthDeg = options.keyLightAzimuth;
        elevationDeg = options.keyLightElevation ?? 45;
    } else {
        // Default classic 3/4 top-left studio key light
        azimuthDeg = 315;
        elevationDeg = 45;
    }
    // --- 2. Calculate 2D Area Light Coordinates (lightX, lightY) -----------------
    // Raymarching traces rays from background receiver pixels towards (lightX, lightY).
    // Any receiver pixel where the sprite blocks the light ray receives a cast shadow.
    // Placing the light source in the direction of azimuth (above/around the sprite)
    // projects the shadow onto the ground on the opposite side of the sprite.
    const azRad = azimuthDeg * Math.PI / 180;
    const elRad = Math.max(15, elevationDeg) * Math.PI / 180;
    // Direction vector in screen space pointing towards the light source
    const dirX = Math.sin(azRad);
    const dirY = -Math.cos(azRad);
    // Distance from sprite center to light source (proportional to sprite scale and elevation)
    const maxDim = Math.max(boxW, boxH);
    const distanceMultiplier = 1.1 + 0.6 * (1.0 - Math.sin(elRad));
    const offsetDist = Math.max(12, maxDim * distanceMultiplier);
    const lightX = Math.round(cx + dirX * offsetDist);
    let lightY = Math.round(cy + dirY * offsetDist);
    // Guarantee light is placed above the ground contact baseline so rays cast downward
    const minLightYLimit = Math.round(minY - Math.max(4, boxH * 0.25));
    if (lightY > minLightYLimit && dirY < 0.2) {
        lightY = minLightYLimit;
    }
    // --- 3. Light Size (Penumbra Softness with Aaltonen Contact Hardening) --------
    // Proportional to sprite scale: small sprites get a tight 8-12px light to preserve
    // clear contact shadow umbra, while large sprites get a 16-24px light for rich penumbra.
    const lightRadius = Math.max(8, Math.min(32, Math.round(Math.sqrt(boxW * boxH) * 0.45)));
    // --- 4. Atmospheric Shadow Tint (Artistic Color Harmony) ---------------------
    const meanR = sumR / count;
    const meanG = sumG / count;
    const meanB = sumB / count;
    const warmth = (meanR - meanB) / 255;
    const maxChannel = Math.max(meanR, Math.max(meanG, meanB));
    const minChannel = Math.min(meanR, Math.min(meanG, meanB));
    const saturation = maxChannel > 0 ? (maxChannel - minChannel) / maxChannel : 0;
    let shadowColor = '#180B26'; // Indigo default (balanced atmospheric depth)
    if (saturation < 0.15) {
        // Neutral / Grayscale / Metal art -> Obsidian (pure dark value)
        shadowColor = '#0A0612';
    } else if (meanG > meanR * 1.2 && meanG > meanB * 1.15) {
        // Foliage / Nature art -> Teal/Fog
        shadowColor = '#062419';
    } else if (warmth > 0.08) {
        // Warm artwork (reds, oranges, golds, peachy skin tones) -> Complementary cool Indigo or Violet
        shadowColor = warmth > 0.25 ? '#2E1065' : '#180B26';
    } else if (warmth < -0.08) {
        // Cool artwork (blues, cyans, icy slates) -> Grounding deep Umber
        shadowColor = '#26140B';
    }
    // --- 5. Opacity & Dithering -------------------------------------------------
    const shadowOpacity = isFloating ? 0.5 : 0.65;
    const ditherMode = 'none';
    const formName = isFloating ? 'floating subject' : `grounded subject (${boxW}x${boxH}px, base Y=${maxY})`;
    const rationale = `Recognized ${formName}. Projecting 2.5D grounded cast shadow along ${azimuthDeg}° / ${elevationDeg}° light vector, ` + `with ${lightRadius}px penumbra radius and ${shadowColor} atmospheric tint.`;
    return {
        lightX,
        lightY,
        lightRadius,
        shadowOpacity,
        shadowColor,
        ditherMode,
        rationale,
        spriteBounds: {
            minX,
            maxX,
            minY,
            maxY,
            width: boxW,
            height: boxH,
            cx,
            cy
        },
        isFloating,
        lightAzimuth: azimuthDeg,
        lightElevation: elevationDeg
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/pixelAiEngine.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// -----------------------------------------------------------------------------
// PixiBun Smart Pixel AI & Mathematical Raster Engine
// Professional Real Data Algorithms:
// - Optical Flow & SDF 2D In-Between Frame Morphing
// - Sub-Pixel Anti-Aliasing (De-Jaggy) & Staircase Corner Smoothing
// - Directional Selective Outlining (Sel-Out) with Light Normal Vectors
// - OKLCH hue-based atmospheric color grading presets
// - 47-Tile Wang / Blob Autotiling Bitmask Analysis
// -----------------------------------------------------------------------------
__turbopack_context__.s([
    "applyAtmosphericColorGrade",
    ()=>applyAtmosphericColorGrade,
    "cleanJaggiesOnCanvas",
    ()=>cleanJaggiesOnCanvas,
    "cleanStrayPixelsOnCanvas",
    ()=>cleanStrayPixelsOnCanvas,
    "generate47BlobEdgeData",
    ()=>generate47BlobEdgeData,
    "generateGroundShadowData",
    ()=>generateGroundShadowData,
    "generateOuterStrokeData",
    ()=>generateOuterStrokeData,
    "generateSelOutData",
    ()=>generateSelOutData,
    "generateSelOutDataSync",
    ()=>generateSelOutDataSync,
    "getHighlightRgb",
    ()=>getHighlightRgb,
    "getShadedRgb",
    ()=>getShadedRgb,
    "harmonizePaletteColors",
    ()=>harmonizePaletteColors,
    "morphInBetweenFrameAtFraction",
    ()=>morphInBetweenFrameAtFraction,
    "morphInBetweenFrames",
    ()=>morphInBetweenFrames,
    "morphInBetweenFramesSync",
    ()=>morphInBetweenFramesSync,
    "quantizeToActivePalette",
    ()=>quantizeToActivePalette
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$smartMathEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/smartMathEngine.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/colorSpace.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/edtNormalMap.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$autotileEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/autotileEngine.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/floodFill.ts [app-client] (ecmascript)");
;
;
;
function getShadedRgb(r, g, b, type) {
    const [L, C, H] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOklch"])(r, g, b);
    if (type === 'light') {
        const newH = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, 275, 8);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(Math.min(1.0, L * 1.15 + 0.05), Math.min(0.4, C * 1.05), newH);
    }
    if (type === 'mid') {
        const newH = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, 275, 15);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(Math.max(0, L * 0.78 - 0.02), Math.min(0.4, C * 1.12), newH);
    }
    const newH = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, 275, 25);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(Math.max(0, L * 0.55 - 0.05), Math.min(0.4, C * 1.25), newH);
}
function getHighlightRgb(r, g, b) {
    const [L, C, H] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOklch"])(r, g, b);
    const newH = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, 80, 15);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(Math.min(1.0, L * 1.35 + 0.12), Math.min(0.4, C * 0.95), newH);
}
function generateSelOutDataSync(image, lightAzimuthDeg = 315, _lightElevationDeg) {
    const { width, height, data } = image;
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    const azRad = lightAzimuthDeg * Math.PI / 180;
    const Lx = Math.sin(azRad);
    const Ly = -Math.cos(azRad);
    const selOutPixels = [];
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            if (!isOpaque(x, y)) continue;
            const idx = (y * width + x) * 4;
            const r = data[idx];
            const g = data[idx + 1];
            const b = data[idx + 2];
            const lum = 0.299 * r + 0.587 * g + 0.114 * b;
            // Check if this pixel is on the perimeter or is a dark outline pixel
            const nN = isOpaque(x, y - 1);
            const nS = isOpaque(x, y + 1);
            const nW = isOpaque(x - 1, y);
            const nE = isOpaque(x + 1, y);
            const touchesAlpha = !nN || !nS || !nW || !nE;
            const isOutlineCandidate = touchesAlpha || lum < 70;
            if (!isOutlineCandidate) continue;
            // Find interior sample color
            let sampleR = r, sampleG = g, sampleB = b;
            if (lum < 70) {
                const neighbors = [
                    [
                        x + 1,
                        y
                    ],
                    [
                        x - 1,
                        y
                    ],
                    [
                        x,
                        y + 1
                    ],
                    [
                        x,
                        y - 1
                    ],
                    [
                        x + 1,
                        y + 1
                    ],
                    [
                        x - 1,
                        y - 1
                    ],
                    [
                        x + 1,
                        y - 1
                    ],
                    [
                        x - 1,
                        y + 1
                    ]
                ];
                for (const [nx, ny] of neighbors){
                    if (isOpaque(nx, ny)) {
                        const nIdx = (ny * width + nx) * 4;
                        const nLum = 0.299 * data[nIdx] + 0.587 * data[nIdx + 1] + 0.114 * data[nIdx + 2];
                        if (nLum >= 70) {
                            sampleR = data[nIdx];
                            sampleG = data[nIdx + 1];
                            sampleB = data[nIdx + 2];
                            break;
                        }
                    }
                }
            }
            // Normal vector pointing outward toward open air
            let nx = 0, ny = 0;
            if (!nW) nx -= 1;
            if (!nE) nx += 1;
            if (!nN) ny -= 1;
            if (!nS) ny += 1;
            const len = Math.sqrt(nx * nx + ny * ny) || 1;
            const normX = nx / len;
            const normY = ny / len;
            // Alignment with light vector
            const NdotL = normX * Lx + normY * Ly;
            if (NdotL > 0.1) {
                // Light-facing border: soft illuminated rim
                const [hr, hg, hb] = getShadedRgb(sampleR, sampleG, sampleB, 'mid');
                selOutPixels.push({
                    x,
                    y,
                    r: hr,
                    g: hg,
                    b: hb,
                    a: 255
                });
            } else {
                // Shadow-facing border: deep colored shadow (never pure flat black)
                const [sr, sg, sb] = getShadedRgb(sampleR, sampleG, sampleB, 'deep');
                selOutPixels.push({
                    x,
                    y,
                    r: sr,
                    g: sg,
                    b: sb,
                    a: 255
                });
            }
        }
    }
    return {
        selOutPixels
    };
}
function generateSelOutData(srcCtx, width, height, lightAzimuthDeg = 315) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    return generateSelOutDataSync({
        width,
        height,
        data: imgData.data
    }, lightAzimuthDeg);
}
function cleanJaggiesOnCanvas(srcCtx, width, height) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    const getPixel = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return null;
        const idx = (y * width + x) * 4;
        return {
            r: data[idx],
            g: data[idx + 1],
            b: data[idx + 2],
            a: data[idx + 3]
        };
    };
    const blendPixels = new Map();
    // Scan for 2x2 staircase L-crooks
    for(let y = 0; y < height - 1; y++){
        for(let x = 0; x < width - 1; x++){
            const p00 = isOpaque(x, y);
            const p10 = isOpaque(x + 1, y);
            const p01 = isOpaque(x, y + 1);
            const p11 = isOpaque(x + 1, y + 1);
            const sum = (p00 ? 1 : 0) + (p10 ? 1 : 0) + (p01 ? 1 : 0) + (p11 ? 1 : 0);
            // 3 opaque, 1 transparent -> an L-crook where anti-aliasing smooths the staircase
            if (sum === 3) {
                let emptyX = x, emptyY = y;
                let c1 = getPixel(x, y), c2 = getPixel(x + 1, y);
                if (!p00) {
                    emptyX = x;
                    emptyY = y;
                    c1 = getPixel(x + 1, y);
                    c2 = getPixel(x, y + 1);
                } else if (!p10) {
                    emptyX = x + 1;
                    emptyY = y;
                    c1 = getPixel(x, y);
                    c2 = getPixel(x + 1, y + 1);
                } else if (!p01) {
                    emptyX = x;
                    emptyY = y + 1;
                    c1 = getPixel(x, y);
                    c2 = getPixel(x + 1, y + 1);
                } else if (!p11) {
                    emptyX = x + 1;
                    emptyY = y + 1;
                    c1 = getPixel(x + 1, y);
                    c2 = getPixel(x, y + 1);
                }
                if (c1 && c2 && c1.a > 30 && c2.a > 30) {
                    const lab1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(c1.r, c1.g, c1.b);
                    const lab2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(c2.r, c2.g, c2.b);
                    const avgLab = {
                        L: (lab1.L + lab2.L) / 2,
                        a: (lab1.a + lab2.a) / 2,
                        b: (lab1.b + lab2.b) / 2
                    };
                    const rgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["okLabToRGB"])(avgLab.L, avgLab.a, avgLab.b);
                    blendPixels.set(`${emptyX},${emptyY}`, {
                        r: rgb.r,
                        g: rgb.g,
                        b: rgb.b,
                        a: 160
                    });
                }
            }
        }
    }
    blendPixels.forEach((p, key)=>{
        const [px, py] = key.split(',').map(Number);
        const idx = (py * width + px) * 4;
        // Only place AA if cell was empty
        if (data[idx + 3] <= 30) {
            data[idx] = p.r;
            data[idx + 1] = p.g;
            data[idx + 2] = p.b;
            data[idx + 3] = p.a;
        }
    });
    srcCtx.putImageData(imgData, 0, 0);
    return {
        cleanedCount: blendPixels.size
    };
}
function applyAtmosphericColorGrade(srcCtx, width, height, grade) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const DMG_PALETTE = [
        {
            r: 15,
            g: 56,
            b: 15
        },
        {
            r: 48,
            g: 98,
            b: 48
        },
        {
            r: 139,
            g: 172,
            b: 15
        },
        {
            r: 155,
            g: 188,
            b: 15
        }
    ];
    for(let i = 0; i < data.length; i += 4){
        if (data[i + 3] <= 30) continue;
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const [L, C, H] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOklch"])(r, g, b);
        if (grade === 'sunset') {
            // Golden Hour: shift hue toward warm amber with brighter, more saturated color.
            const newH = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, 65, 30);
            const newL = Math.min(0.96, L * 1.08 + 0.02);
            const newC = Math.min(0.35, C * 1.25);
            const [nr, ng, nb] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(newL, newC, newH);
            data[i] = nr;
            data[i + 1] = ng;
            data[i + 2] = nb;
        } else if (grade === 'moonlight') {
            // Moonlight / Cool Night: shift hue toward cobalt with lower lightness and chroma.
            const newH = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, 260, 35);
            const newL = Math.max(0.06, L * 0.92);
            const newC = Math.max(0.02, C * 0.85);
            const [nr, ng, nb] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(newL, newC, newH);
            data[i] = nr;
            data[i + 1] = ng;
            data[i + 2] = nb;
        } else if (grade === 'neon') {
            // Cyberpunk Dusk: Split-toning with cyan/teal highlights and vivid magenta/violet shadows
            const isHighlight = L > 0.5;
            const targetHue = isHighlight ? 185 : 320; // Cyan vs Magenta
            const newH = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, targetHue, 45);
            const newL = isHighlight ? Math.min(0.98, L * 1.12) : Math.max(0.04, L * 0.88);
            const newC = Math.min(0.38, C * 1.4);
            const [nr, ng, nb] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(newL, newC, newH);
            data[i] = nr;
            data[i + 1] = ng;
            data[i + 2] = nb;
        } else if (grade === 'gameboy') {
            // Authentic 4-shade Game Boy DMG LCD green matrix
            const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
            const shadeIdx = Math.min(3, Math.floor(lum * 4));
            const chosen = DMG_PALETTE[shadeIdx];
            data[i] = chosen.r;
            data[i + 1] = chosen.g;
            data[i + 2] = chosen.b;
        }
    }
    srcCtx.putImageData(imgData, 0, 0);
}
/**
 * Precomputes a nearby opaque pixel index for all pixels in O(W * H) using
 * 8-connected multi-source BFS. This uses Chebyshev path distance and can pick
 * a different seed than a Euclidean nearest-neighbor search.
 */ function computeNearestColorMap(data, width, height) {
    const totalPixels = width * height;
    const nearest = new Int32Array(totalPixels).fill(-1);
    const queue = new Int32Array(totalPixels);
    let head = 0;
    let tail = 0;
    for(let i = 0; i < totalPixels; i++){
        if (data[i * 4 + 3] > 10) {
            nearest[i] = i;
            queue[tail++] = i;
        }
    }
    const dx = [
        -1,
        0,
        1,
        -1,
        1,
        -1,
        0,
        1
    ];
    const dy = [
        -1,
        -1,
        -1,
        0,
        0,
        1,
        1,
        1
    ];
    while(head < tail){
        const curr = queue[head++];
        const cx = curr % width;
        const cy = Math.floor(curr / width);
        const seed = nearest[curr];
        for(let k = 0; k < 8; k++){
            const nx = cx + dx[k];
            const ny = cy + dy[k];
            if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                const nIdx = ny * width + nx;
                if (nearest[nIdx] === -1) {
                    nearest[nIdx] = seed;
                    queue[tail++] = nIdx;
                }
            }
        }
    }
    return nearest;
}
/**
 * Generates an in-between frame at arbitrary fraction t in [0, 1] using Signed Distance Field
 * interpolation with multi-source nearest-color sampling and linear sRGB cross-fading.
 */ function assertMorphFramesCompatible(frameA, frameB) {
    const pixels = frameA.width * frameA.height;
    if (!Number.isSafeInteger(frameA.width) || !Number.isSafeInteger(frameA.height) || frameA.width <= 0 || frameA.height <= 0 || frameB.width !== frameA.width || frameB.height !== frameA.height || !Number.isSafeInteger(pixels) || frameA.data.length !== pixels * 4 || frameB.data.length !== pixels * 4) {
        throw new RangeError('SDF morph frames must have identical positive dimensions and RGBA buffer lengths.');
    }
}
function morphInBetweenFrameAtFraction(frameA, frameB, fraction) {
    assertMorphFramesCompatible(frameA, frameB);
    const { width, height } = frameA;
    const t = Math.max(0, Math.min(1, fraction));
    if (t === 0) {
        return {
            width,
            height,
            data: new Uint8ClampedArray(frameA.data)
        };
    }
    if (t === 1) {
        return {
            width,
            height,
            data: new Uint8ClampedArray(frameB.data)
        };
    }
    const dataA = frameA.data;
    const dataB = frameB.data;
    const getSDF = (data)=>{
        const insideDist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])((x, y)=>data[(y * width + x) * 4 + 3] > 10, width, height);
        const outsideDist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])((x, y)=>data[(y * width + x) * 4 + 3] <= 10, width, height);
        const sdf = new Float32Array(width * height);
        for(let i = 0; i < width * height; i++){
            sdf[i] = outsideDist[i] - insideDist[i];
        }
        return sdf;
    };
    const sdfA = getSDF(dataA);
    const sdfB = getSDF(dataB);
    const nearestA = computeNearestColorMap(dataA, width, height);
    const nearestB = computeNearestColorMap(dataB, width, height);
    const outData = new Uint8ClampedArray(width * height * 4);
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const i = y * width + x;
            const outIdx = i * 4;
            const tweenedSDF = sdfA[i] * (1 - t) + sdfB[i] * t;
            if (tweenedSDF <= 0) {
                const seedA = nearestA[i];
                const seedB = nearestB[i];
                const hasA = seedA >= 0;
                const hasB = seedB >= 0;
                if (!hasA && !hasB) continue;
                const aIdx = hasA ? seedA * 4 : 0;
                const bIdx = hasB ? seedB * 4 : 0;
                const rA = hasA ? dataA[aIdx] : hasB ? dataB[bIdx] : 0;
                const gA = hasA ? dataA[aIdx + 1] : hasB ? dataB[bIdx + 1] : 0;
                const bA = hasA ? dataA[aIdx + 2] : hasB ? dataB[bIdx + 2] : 0;
                const rB = hasB ? dataB[bIdx] : hasA ? dataA[aIdx] : 0;
                const gB = hasB ? dataB[bIdx + 1] : hasA ? dataA[aIdx + 1] : 0;
                const bB = hasB ? dataB[bIdx + 2] : hasA ? dataA[aIdx + 2] : 0;
                const alphaA = hasA ? dataA[aIdx + 3] : 0;
                const alphaB = hasB ? dataB[bIdx + 3] : 0;
                outData[outIdx] = Math.round(rA * (1 - t) + rB * t);
                outData[outIdx + 1] = Math.round(gA * (1 - t) + gB * t);
                outData[outIdx + 2] = Math.round(bA * (1 - t) + bB * t);
                outData[outIdx + 3] = Math.round(alphaA * (1 - t) + alphaB * t);
            }
        }
    }
    return {
        width,
        height,
        data: outData
    };
}
function morphInBetweenFramesSync(frameA, frameB, steps = 1) {
    assertMorphFramesCompatible(frameA, frameB);
    const { width, height } = frameA;
    const dataA = frameA.data;
    const dataB = frameB.data;
    const getSDF = (data)=>{
        const insideDist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])((x, y)=>data[(y * width + x) * 4 + 3] > 10, width, height);
        const outsideDist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])((x, y)=>data[(y * width + x) * 4 + 3] <= 10, width, height);
        const sdf = new Float32Array(width * height);
        for(let i = 0; i < width * height; i++){
            sdf[i] = outsideDist[i] - insideDist[i];
        }
        return sdf;
    };
    const sdfA = getSDF(dataA);
    const sdfB = getSDF(dataB);
    const nearestA = computeNearestColorMap(dataA, width, height);
    const nearestB = computeNearestColorMap(dataB, width, height);
    const results = [];
    for(let s = 1; s <= steps; s++){
        const t = s / (steps + 1);
        const outData = new Uint8ClampedArray(width * height * 4);
        for(let y = 0; y < height; y++){
            for(let x = 0; x < width; x++){
                const i = y * width + x;
                const outIdx = i * 4;
                const tweenedSDF = sdfA[i] * (1 - t) + sdfB[i] * t;
                if (tweenedSDF <= 0) {
                    const seedA = nearestA[i];
                    const seedB = nearestB[i];
                    const hasA = seedA >= 0;
                    const hasB = seedB >= 0;
                    if (!hasA && !hasB) continue;
                    const aIdx = hasA ? seedA * 4 : 0;
                    const bIdx = hasB ? seedB * 4 : 0;
                    const rA = hasA ? dataA[aIdx] : hasB ? dataB[bIdx] : 0;
                    const gA = hasA ? dataA[aIdx + 1] : hasB ? dataB[bIdx + 1] : 0;
                    const bA = hasA ? dataA[aIdx + 2] : hasB ? dataB[bIdx + 2] : 0;
                    const rB = hasB ? dataB[bIdx] : hasA ? dataA[aIdx] : 0;
                    const gB = hasB ? dataB[bIdx + 1] : hasA ? dataA[aIdx + 1] : 0;
                    const bB = hasB ? dataB[bIdx + 2] : hasA ? dataA[aIdx + 2] : 0;
                    const alphaA = hasA ? dataA[aIdx + 3] : 0;
                    const alphaB = hasB ? dataB[bIdx + 3] : 0;
                    outData[outIdx] = Math.round(rA * (1 - t) + rB * t);
                    outData[outIdx + 1] = Math.round(gA * (1 - t) + gB * t);
                    outData[outIdx + 2] = Math.round(bA * (1 - t) + bB * t);
                    outData[outIdx + 3] = Math.round(alphaA * (1 - t) + alphaB * t);
                }
            }
        }
        results.push({
            width,
            height,
            data: outData
        });
    }
    return results;
}
function morphInBetweenFrames(ctxA, ctxB, width, height, t = 0.5) {
    const dataA = ctxA.getImageData(0, 0, width, height).data;
    const dataB = ctxB.getImageData(0, 0, width, height).data;
    const outCanvas = document.createElement('canvas');
    outCanvas.width = width;
    outCanvas.height = height;
    const outCtx = outCanvas.getContext('2d');
    const outImgData = outCtx.createImageData(width, height);
    const result = morphInBetweenFrameAtFraction({
        width,
        height,
        data: dataA
    }, {
        width,
        height,
        data: dataB
    }, t);
    outImgData.data.set(result.data);
    outCtx.putImageData(outImgData, 0, 0);
    return outCanvas;
}
function quantizeToActivePalette(srcCtx, width, height, paletteHexColors) {
    if (paletteHexColors.length === 0) return;
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const palRgba = paletteHexColors.map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgba"]);
    const palLab = palRgba.map((c)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(c.r, c.g, c.b));
    for(let i = 0; i < data.length; i += 4){
        if (data[i + 3] <= 30) continue;
        const lab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(data[i], data[i + 1], data[i + 2]);
        let closestIdx = 0;
        let minDiff = Infinity;
        for(let k = 0; k < palLab.length; k++){
            const diff = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deltaEOKLab"])(lab, palLab[k]);
            if (diff < minDiff) {
                minDiff = diff;
                closestIdx = k;
            }
        }
        const chosen = palRgba[closestIdx];
        data[i] = chosen.r;
        data[i + 1] = chosen.g;
        data[i + 2] = chosen.b;
    }
    srcCtx.putImageData(imgData, 0, 0);
}
function cleanStrayPixelsOnCanvas(srcCtx, width, height) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    let cleanedCount = 0;
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            if (!isOpaque(x, y)) continue;
            let neighborsCount = 0;
            const neighbors = [
                [
                    x + 1,
                    y
                ],
                [
                    x - 1,
                    y
                ],
                [
                    x,
                    y + 1
                ],
                [
                    x,
                    y - 1
                ]
            ];
            for (const [nx, ny] of neighbors){
                if (isOpaque(nx, ny)) neighborsCount++;
            }
            // Single disconnected pixel surrounded by air
            if (neighborsCount === 0) {
                data[(y * width + x) * 4 + 3] = 0;
                cleanedCount++;
            }
        }
    }
    srcCtx.putImageData(imgData, 0, 0);
    return {
        cleanedCount
    };
}
function harmonizePaletteColors(existingColors) {
    const harmonics = [
        '#3A2E4C',
        '#6A5880',
        '#A86EC6',
        '#C792DF',
        '#DCABDF',
        '#D0C4DF',
        '#F0BE7C',
        '#FFF8DB'
    ];
    const newColors = [];
    harmonics.forEach((c)=>{
        if (!existingColors.includes(c)) {
            newColors.push(c);
        }
    });
    return newColors.slice(0, 4);
}
function generate47BlobEdgeData(srcCtx, width, height) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    const blobPixels = [];
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            if (!isOpaque(x, y)) continue;
            const bitmask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$autotileEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculate47TileBitmask"])(isOpaque, x, y);
            if (bitmask === 255) continue;
            const idx = (y * width + x) * 4;
            const r = data[idx];
            const g = data[idx + 1];
            const b = data[idx + 2];
            const hasNorth = (bitmask & 1) !== 0;
            const hasWest = (bitmask & 64) !== 0;
            const hasSouth = (bitmask & 16) !== 0;
            const hasEast = (bitmask & 4) !== 0;
            if (!hasNorth || !hasWest) {
                const [hr, hg, hb] = getHighlightRgb(r, g, b);
                blobPixels.push({
                    x,
                    y,
                    r: hr,
                    g: hg,
                    b: hb,
                    a: 220
                });
            } else if (!hasSouth || !hasEast) {
                const [sr, sg, sb] = getShadedRgb(r, g, b, 'deep');
                blobPixels.push({
                    x,
                    y,
                    r: sr,
                    g: sg,
                    b: sb,
                    a: 220
                });
            } else {
                const [sr, sg, sb] = getShadedRgb(r, g, b, 'mid');
                blobPixels.push({
                    x,
                    y,
                    r: sr,
                    g: sg,
                    b: sb,
                    a: 200
                });
            }
        }
    }
    return {
        blobPixels
    };
}
function generateOuterStrokeData(srcCtx, width, height, strokeColorHex = '#2B2038', thickness = 1) {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const isOpaque = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return data[(y * width + x) * 4 + 3] > 30;
    };
    const strokeRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgba"])(strokeColorHex);
    const strokePixels = [];
    const radius = Math.max(1, Math.min(8, Math.round(thickness)));
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            if (isOpaque(x, y)) continue;
            let hasOpaqueNeighbor = false;
            for(let dy = -radius; dy <= radius && !hasOpaqueNeighbor; dy++){
                const maxDx = radius - Math.abs(dy);
                for(let dx = -maxDx; dx <= maxDx; dx++){
                    if ((dx !== 0 || dy !== 0) && isOpaque(x + dx, y + dy)) {
                        hasOpaqueNeighbor = true;
                        break;
                    }
                }
            }
            if (hasOpaqueNeighbor) {
                strokePixels.push({
                    x,
                    y,
                    r: strokeRgb.r,
                    g: strokeRgb.g,
                    b: strokeRgb.b,
                    a: 255
                });
            }
        }
    }
    return {
        strokePixels
    };
}
function generateGroundShadowData(srcCtx, width, height, shadowColorHex = '#2B2038') {
    const imgData = srcCtx.getImageData(0, 0, width, height);
    const data = imgData.data;
    let minX = width, maxX = 0, minY = height, maxY = 0;
    let hasPixels = false;
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            if (data[(y * width + x) * 4 + 3] > 30) {
                minX = Math.min(minX, x);
                maxX = Math.max(maxX, x);
                minY = Math.min(minY, y);
                maxY = Math.max(maxY, y);
                hasPixels = true;
            }
        }
    }
    if (!hasPixels) return {
        shadowPixels: []
    };
    const shadowPixels = [];
    const cx = (minX + maxX) / 2;
    const shadowY = Math.min(height - 2, maxY + 2);
    const rx = Math.max(3, (maxX - minX) / 2 + 1);
    const ry = 2;
    const shadowRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgba"])(shadowColorHex);
    for(let y = shadowY - ry; y <= shadowY + ry; y++){
        for(let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++){
            if (x < 0 || x >= width || y < 0 || y >= height) continue;
            const dx = (x - cx) / rx;
            const dy = (y - shadowY) / ry;
            if (dx * dx + dy * dy <= 1.0) {
                shadowPixels.push({
                    x,
                    y,
                    r: shadowRgb.r,
                    g: shadowRgb.g,
                    b: shadowRgb.b,
                    a: 160
                });
            }
        }
    }
    return {
        shadowPixels
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/shadowRayMarcher.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "executeBoundedCastShadowPipeline",
    ()=>executeBoundedCastShadowPipeline,
    "executeClassic2DRaymarchedShadow",
    ()=>executeClassic2DRaymarchedShadow,
    "executeRaymarchedCastShadowPipeline",
    ()=>executeRaymarchedCastShadowPipeline,
    "generateRaymarchedShadowMap",
    ()=>generateRaymarchedShadowMap,
    "renderBoundedSpriteCastShadow",
    ()=>renderBoundedSpriteCastShadow,
    "sampleEDTBilinear",
    ()=>sampleEDTBilinear,
    "tracePhysical2DSoftShadow",
    ()=>tracePhysical2DSoftShadow
]);
/**
 * PixiBun 2D Ray Marching & Physically Accurate Soft Shadows Engine
 * 
 * High-performance CPU ray marcher operating on discrete 2D Euclidean Distance Fields (EDT/UDF):
 * 1. Branchless C0 continuous bilinear distance field sampling.
 * 2. Sebastian Aaltonen geometric contact-hardening tangent correction (Claybook / GDC 2018).
 * 3. True physical area light cone tracing (RL disk radius).
 * 4. Cubic Hermite smoothstep area occlusion falloff.
 * 5. Bayer matrix ordered dither modulation for authentic retro pixel art stippling.
 * 6. Zero-allocation Float32Array buffer pooling for V8 JIT efficiency.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferPool.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$smartMathEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/smartMathEngine.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/dithering.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$shadowAuto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/shadowAuto.ts [app-client] (ecmascript)");
;
;
/**
 * Creates an ImageData object safely in both Browser and Node/Testing environments.
 */ function createImageDataBuffer(width, height) {
    if (typeof ImageData !== 'undefined') {
        return new ImageData(width, height);
    }
    return {
        width,
        height,
        data: new Uint8ClampedArray(width * height * 4)
    };
}
/**
 * Parses Hex or RGB tuple into normalized 0-255 [r, g, b] array.
 */ function parseShadowColor(color) {
    if (!color) return [
        24,
        11,
        38
    ]; // Default deep atmospheric indigo/plum #180B26
    if (Array.isArray(color)) return color;
    let clean = color.replace('#', '');
    if (clean.length === 3 || clean.length === 4) {
        // Expand shorthand: #RGB → #RRGGBB, #RGBA → #RRGGBBAA
        clean = clean.split('').map((c)=>c + c).join('');
    }
    // Strip alpha channel from 8-digit hex (RRGGBBAA → RRGGBB)
    if (clean.length === 8) {
        clean = clean.slice(0, 6);
    }
    const num = parseInt(clean, 16);
    if (isNaN(num)) return [
        24,
        11,
        38
    ];
    return [
        num >> 16 & 255,
        num >> 8 & 255,
        num & 255
    ];
}
function sampleEDTBilinear(edt, width, height, x, y) {
    // Clamp coordinates to valid grid bounds to avoid out-of-bounds memory errors
    const cx = Math.max(0.0, Math.min(width - 1, x));
    const cy = Math.max(0.0, Math.min(height - 1, y));
    // Integer coordinates for the top-left of the 2x2 sampling grid (Bitwise OR for fast V8 int cast)
    const x0 = cx | 0;
    const y0 = cy | 0;
    const x1 = Math.min(x0 + 1, width - 1);
    const y1 = Math.min(y0 + 1, height - 1);
    // Fractional interpolation weights
    const u = cx - x0;
    const v = cy - y0;
    // 1D array index calculations
    const row0 = y0 * width;
    const row1 = y1 * width;
    // Fetch the 4 neighboring discrete distances
    const d00 = edt[row0 + x0];
    const d10 = edt[row0 + x1];
    const d01 = edt[row1 + x0];
    const d11 = edt[row1 + x1];
    // Bilinear interpolation calculation
    const d0 = d00 + u * (d10 - d00);
    const d1 = d01 + u * (d11 - d01);
    return d0 + v * (d1 - d0);
}
function tracePhysical2DSoftShadow(edt, width, height, px, py, lx, ly, lightRadius, maxSteps = 64) {
    const dx = lx - px;
    const dy = ly - py;
    const totalDist = Math.sqrt(dx * dx + dy * dy);
    // If the light is right at the pixel coordinate, it is fully lit
    if (totalDist < 0.0001) return 1.0;
    const dirX = dx / totalDist;
    const dirY = dy / totalDist;
    // Initial sample to check if receiver is inside solid geometry
    let h = sampleEDTBilinear(edt, width, height, px, py);
    if (h <= 0.0) return 0.0;
    // Start slightly off the surface to prevent self-shadowing
    let t = Math.max(1.0, h * 0.9);
    let visibility = 1.0;
    // Initialize previous clearance to a large number to prevent division by zero on step 1
    let ph = 1e10;
    for(let step = 0; step < maxSteps; step++){
        // If the ray has reached the light source coordinate, terminate march
        if (t >= totalDist) break;
        const curX = px + t * dirX;
        const curY = py + t * dirY;
        h = sampleEDTBilinear(edt, width, height, curX, curY);
        // Solid hit threshold - if the ray enters a solid geometry wall
        if (h < 0.1) return 0.0;
        // Aaltonen geometric correction to find exact closest approach distance 'd'
        // 'y' is the distance along the ray segment back to the closest point
        const y = h * h / (2.0 * ph);
        // 'd' is the perpendicular distance from the ray to the tangent surface
        const dSquared = Math.max(0.0, h * h - y * y);
        const d = Math.sqrt(dSquared);
        // 'tClosest' is the absolute distance from origin to the point of closest approach
        const tClosest = Math.max(0.001, t - y);
        // Physical radius of the expanding light cone at tClosest
        const rCone = lightRadius * (tClosest / totalDist);
        if (rCone > 0.0001) {
            // Linear visibility ratio: how much of the cone is unobstructed
            const s = Math.max(0.0, d / rCone);
            if (s < 1.0) {
                // Cubic Hermite smoothstep to model circular area light occlusion falloff
                const smoothPenumbra = s * s * (3.0 - 2.0 * s);
                visibility = Math.min(visibility, smoothPenumbra);
            }
        }
        // Early out if fully occluded (umbra reached)
        if (visibility < 0.005) return 0.0;
        ph = h;
        // Advance ray. Enforce a minimum step of 0.5px to prevent infinite stalls on grazing angles
        t += Math.max(0.5, h);
    }
    return Math.max(0.0, Math.min(1.0, visibility));
}
function generateRaymarchedShadowMap(edt, width, height, lx, ly, lightRadius, maxSteps = 64) {
    const shadowMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["acquireFloat32Buffer"])(width * height);
    try {
        for(let y = 0; y < height; y++){
            const row = y * width;
            for(let x = 0; x < width; x++){
                const idx = row + x;
                // If inside an obstacle/solid pixel, it is completely shadowed
                if (edt[idx] <= 0) {
                    shadowMap[idx] = 0.0;
                } else {
                    shadowMap[idx] = tracePhysical2DSoftShadow(edt, width, height, x, y, lx, ly, lightRadius, maxSteps);
                }
            }
        }
        return shadowMap;
    } catch (err) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["releaseFloat32Buffer"])(shadowMap);
        throw err;
    }
}
function renderBoundedSpriteCastShadow(edt, width, height, params) {
    const { shadowOpacity = 0.65, shadowColor, ditherMode = 'none', perspectiveForeshortening = 0.5, volumetricDepthBias = 0.25, shadowStyle = 'cast' } = params;
    // 1. Scan Sprite Bounding Box & Baseline from EDT field (solid pixels have edt <= 0.001)
    let minX = width;
    let maxX = -1;
    let minY = height;
    let maxY = -1;
    let count = 0;
    let sumX = 0;
    let sumY = 0;
    for(let y = 0; y < height; y++){
        const row = y * width;
        for(let x = 0; x < width; x++){
            if (edt[row + x] <= 0.001) {
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
                count++;
                sumX += x;
                sumY += y;
            }
        }
    }
    const outImgData = createImageDataBuffer(width, height);
    if (count === 0) return outImgData;
    const boxW = Math.max(1, maxX - minX + 1);
    const boxH = Math.max(1, maxY - minY + 1);
    const cx = sumX / count;
    const cy = sumY / count;
    const yBase = maxY;
    const distanceFromBottom = height - 1 - maxY;
    const isFloating = params.isFloating === true;
    // For floating sprites, ground is lower than the sprite; for grounded, ground is at baseline
    const yGround = isFloating ? Math.min(height - 2, maxY + Math.min(8, Math.max(3, Math.round(distanceFromBottom * 0.6)))) : yBase;
    // 2. Resolve Azimuth and Elevation
    let azimuthDeg = params.lightAzimuth;
    let elevationDeg = params.lightElevation;
    if (azimuthDeg === undefined || elevationDeg === undefined) {
        const lx = params.lightX ?? Math.round(width / 2);
        const ly = params.lightY ?? Math.round(height / 4);
        const dx = lx - cx;
        const dy = ly - cy;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (azimuthDeg === undefined) {
            if (dist < 0.001) {
                azimuthDeg = 0;
            } else {
                const azRad = Math.atan2(dx, -dy);
                azimuthDeg = Math.round((azRad * 180 / Math.PI + 360) % 360);
            }
        }
        if (elevationDeg === undefined) {
            const maxDim = Math.max(width, height);
            elevationDeg = Math.round(Math.max(15, Math.min(85, 90 - dist / maxDim * 70)));
        }
    }
    // 3. Compute Directional Shear Factors
    const azRad = azimuthDeg * Math.PI / 180;
    const elRad = Math.max(12, Math.min(88, elevationDeg)) * Math.PI / 180;
    const cotEl = 1.0 / Math.tan(elRad);
    // Shadow direction on ground is opposite the light
    const sx = -Math.sin(azRad);
    let sy = Math.cos(azRad);
    // Volumetric character depth bias prevents 1D line collapse when sun is at East/West (90°/270°)
    const signY = sy >= 0 ? 1 : -1;
    sy = signY * Math.max(Math.abs(sy), volumetricDepthBias);
    const shearX = cotEl * sx;
    const shearY = cotEl * sy * perspectiveForeshortening;
    // 4. Rasterize Bounded Ground Shadow into Pooled Float32 Density Map
    const densityMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["acquireFloat32Buffer"])(width * height);
    densityMap.fill(0);
    try {
        if (shadowStyle === 'drop') {
            // Classic Top-Down RPG Ground Drop Shadow (Pokémon, Zelda: Minish Cap)
            // Crisp pixel ellipse centered under the character's contact base
            const rx = Math.max(2.5, Math.round(boxW * 0.42));
            const ry = Math.max(1.5, Math.round(rx * 0.35));
            const floorY = isFloating ? yGround : Math.min(height - 1, yGround + 1);
            const minYDrop = Math.max(0, Math.floor(floorY - ry));
            const maxYDrop = Math.min(height - 1, Math.ceil(floorY + ry));
            const minXDrop = Math.max(0, Math.floor(cx - rx));
            const maxXDrop = Math.min(width - 1, Math.ceil(cx + rx));
            for(let cy_ = minYDrop; cy_ <= maxYDrop; cy_++){
                const dy = (cy_ - floorY) / ry;
                const rowOffset = cy_ * width;
                for(let cx_ = minXDrop; cx_ <= maxXDrop; cx_++){
                    const dx = (cx_ - cx) / rx;
                    if (dx * dx + dy * dy <= 1.0) {
                        densityMap[rowOffset + cx_] = 1.0;
                    }
                }
            }
        } else {
            // Directional 1-to-1 Pixel Silhouette Projection
            // Iterates exact opaque sprite pixels without bounding box bloating or filling hollow leg gaps
            const numSubSteps = Math.min(4, Math.ceil(Math.max(1, Math.abs(shearX), Math.abs(shearY))));
            const stepInv = 1.0 / numSubSteps;
            for(let ys = minY; ys <= maxY; ys++){
                const h = yBase - ys; // Height above baseline: 0 at feet, boxH at head
                const u = boxH > 1 ? Math.min(1.0, h / boxH) : 0;
                const falloff = Math.max(0.0, 1.0 - Math.pow(u, 1.4));
                if (falloff <= 0.02) continue;
                for(let xs = minX; xs <= maxX; xs++){
                    if (edt[ys * width + xs] > 0.001) continue; // Only project opaque pixels
                    for(let s = 0; s < numSubSteps; s++){
                        const subH = h + s * stepInv;
                        const px = Math.round(xs + subH * shearX);
                        const py = Math.round(yGround + subH * shearY);
                        if (px >= 0 && px < width && py >= 0 && py < height) {
                            const pIdx = py * width + px;
                            if (falloff > densityMap[pIdx]) {
                                densityMap[pIdx] = falloff;
                            }
                        }
                    }
                }
            }
        }
        // 5. Composite into Output Buffer with Color, Opacity & Bayer Dither
        const data = outImgData.data;
        const [sr, sg, sb] = parseShadowColor(shadowColor);
        const opacity = Math.max(0.0, Math.min(1.0, shadowOpacity));
        const expectedAlpha = Math.round(opacity * 255);
        for(let y = 0; y < height; y++){
            const row = y * width;
            for(let x = 0; x < width; x++){
                const idx = row + x;
                const pIdx = idx * 4;
                // Solid sprite pixels must remain 100% transparent in the shadow layer
                if (edt[idx] <= 0.001) {
                    data[pIdx + 3] = 0;
                    continue;
                }
                const density = densityMap[idx];
                if (density <= 0.05) {
                    data[pIdx + 3] = 0;
                    continue;
                }
                let finalAlpha = 0;
                if (ditherMode !== 'none') {
                    const threshold = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBayerMatrixThreshold"])(x, y, ditherMode);
                    finalAlpha = density * opacity >= threshold ? expectedAlpha : 0;
                } else {
                    // Authentic pixel art uniform flat opacity (no 256-level blurry airbrush gradient)
                    finalAlpha = expectedAlpha;
                }
                if (finalAlpha > 0) {
                    data[pIdx] = sr;
                    data[pIdx + 1] = sg;
                    data[pIdx + 2] = sb;
                    data[pIdx + 3] = finalAlpha;
                } else {
                    data[pIdx + 3] = 0;
                }
            }
        }
        return outImgData;
    } finally{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["releaseFloat32Buffer"])(densityMap);
    }
}
const executeBoundedCastShadowPipeline = renderBoundedSpriteCastShadow;
function executeClassic2DRaymarchedShadow(edt, width, height, params) {
    const { lightX = Math.round(width / 2), lightY = Math.round(height / 4), lightRadius = 16, shadowOpacity = 0.7, shadowColor, ditherMode = 'none', maxSteps = 64 } = params;
    const [sr, sg, sb] = parseShadowColor(shadowColor);
    const opacity = Math.max(0.0, Math.min(1.0, shadowOpacity));
    const visibilityMap = generateRaymarchedShadowMap(edt, width, height, lightX, lightY, lightRadius, maxSteps);
    const imgData = createImageDataBuffer(width, height);
    const data = imgData.data;
    try {
        for(let y = 0; y < height; y++){
            const row = y * width;
            for(let x = 0; x < width; x++){
                const idx = row + x;
                const pIdx = idx * 4;
                let vis = visibilityMap[idx];
                if (ditherMode !== 'none') {
                    const threshold = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBayerMatrixThreshold"])(x, y, ditherMode);
                    vis = vis < threshold ? 0.0 : 1.0;
                }
                const shadowFactor = (1.0 - vis) * opacity;
                let alpha = 0;
                if (ditherMode !== 'none') {
                    alpha = Math.round(shadowFactor * 255);
                } else {
                    alpha = shadowFactor > 0.05 ? Math.round(opacity * 255) : 0;
                }
                if (edt[idx] <= 0) {
                    alpha = 0;
                }
                if (alpha > 0) {
                    data[pIdx] = sr;
                    data[pIdx + 1] = sg;
                    data[pIdx + 2] = sb;
                    data[pIdx + 3] = alpha;
                } else {
                    data[pIdx + 3] = 0;
                }
            }
        }
        return imgData;
    } finally{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferPool$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["releaseFloat32Buffer"])(visibilityMap);
    }
}
function executeRaymarchedCastShadowPipeline(edt, width, height, params) {
    if (params.mode === 'bounded-2.5d') {
        return renderBoundedSpriteCastShadow(edt, width, height, params);
    }
    return executeClassic2DRaymarchedShadow(edt, width, height, params);
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/smartMathEngine.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
/**
 * PixiBud Smart Math & Computer Graphics Engine (Barrel Module).
 *
 * Modularized architecture (Phase 33.3) organizing mathematically rigorous algorithms:
 * 1. Linear-Time O(W*H) Exact 2D Euclidean Distance Transform (Felzenszwalb & Huttenlocher 2012, Theory of Computing; orig. Cornell TR 2004)
 * 2. Edge-Preserving Bilateral Filtering (Tomasi & Manduchi 1998, ICCV)
 * 3. Discrete Sobel Gradient Fields & Tangent Space Unit Normal Generation
 * 4. Normal Map Texture Baker (Standard Tangent Space RGB 128, 128, 255)
 * 5. Discrete Laplace Cavity Map / Ambient Occlusion (AO)
 * 6. Photometric Lighting Pipeline (Blinn-Phong 1977, SIGGRAPH)
 * 7. 2D Volumetric Optics & Subsurface Scattering (Henyey & Greenstein 1941, ApJ; Poisson kernel on S¹)
 * 8. Anisotropic Specular Highlights & Dual Cuticle Shifts (Kajiya & Kay 1989, SIGGRAPH; Marschner et al. 2003; Scheuermann 2004)
 * 9. Dielectric Fresnel Reflection with Cauchy Chromatic Dispersion
 * 10. OKLab / OKLCH Perceptual Color Spaces (Ottosson 2020)
 * 11. Dithering: Bayer Matrix (1973), Atkinson (1984), Riemersma Hilbert Space-Filling Curve (1998)
 * 12. RotSprite 8x Scale2X Distortion-Free Rotation (Xenowhirl 2007; EPX Johnston 1992)
 * 13. Zhang-Suen Morphological Skeleton Line Thinning (Zhang & Suen 1984, CACM)
 * 14. Quadratic Bézier Curves, Isometric Lines & 47-Tile Blob Autotiling
 * 15. Minecraft Skin UV Projection & Normal Mapping
 * 16. Physically Accurate 2D Soft Shadows (Aaltonen Cone Tracing 2018)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/colorSpace.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/edtNormalMap.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/dithering.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$rotSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/math/rotSprite.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$morphology$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/morphology.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$curvesAndLines$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/math/curvesAndLines.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$minecraftSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/minecraftSkin.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/math/photometricLighting.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$shadowRayMarcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/shadowRayMarcher.ts [app-client] (ecmascript) <locals>");
;
;
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/ai/spriteCleanup.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "planSpriteCleanup",
    ()=>planSpriteCleanup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/animation/reviewMetadata.ts [app-client] (ecmascript)");
;
const luminance = (r, g, b)=>(r * 54 + g * 183 + b * 19) / 256;
function colorCount(data) {
    const colors = new Set();
    for(let i = 0; i < data.length; i += 4){
        if (data[i + 3] === 0) continue;
        colors.add(data[i] << 16 | data[i + 1] << 8 | data[i + 2]);
    }
    return colors.size;
}
function planSpriteCleanup(image, options, protectedRegions = []) {
    const { width, height } = image;
    const pixels = width * height;
    if (width < 1 || height < 1 || image.data.length !== pixels * 4) {
        throw new Error('Invalid sprite cleanup image dimensions');
    }
    const source = image.data;
    const data = new Uint8ClampedArray(source);
    const stats = {
        removedFaint: 0,
        hardenedAlpha: 0,
        removedSpecks: 0,
        simplifiedColors: 0,
        thinnedLinePixels: 0,
        changedPixels: 0,
        sourceColors: colorCount(source),
        resultColors: 0
    };
    const cutoff = Math.max(0, Math.min(254, Math.floor(options.alphaCutoff)));
    const maxSpeck = Math.max(0, Math.min(8, Math.floor(options.maxSpeckPixels)));
    // Remove faint alpha and make surviving pixels fully opaque for crisp edges.
    for(let pixel = 0; pixel < pixels; pixel++){
        const offset = pixel * 4;
        const alpha = data[offset + 3];
        if (alpha === 0) continue;
        if (alpha <= cutoff) {
            data.fill(0, offset, offset + 4);
            stats.removedFaint++;
        } else if (alpha < 255) {
            data[offset + 3] = 255;
            stats.hardenedAlpha++;
        }
    }
    // Classify 8-connected components before deleting tiny detached islands.
    if (maxSpeck > 0) {
        const visited = new Uint8Array(pixels);
        const queue = new Int32Array(pixels);
        let largest = {
            start: -1,
            count: 0
        };
        for(let pixel = 0; pixel < pixels; pixel++){
            if (visited[pixel] || data[pixel * 4 + 3] === 0) continue;
            let head = 0;
            let tail = 1;
            queue[0] = pixel;
            visited[pixel] = 1;
            while(head < tail){
                const current = queue[head++];
                const x = current % width;
                const y = Math.floor(current / width);
                for(let dy = -1; dy <= 1; dy++)for(let dx = -1; dx <= 1; dx++){
                    if (dx === 0 && dy === 0) continue;
                    const nx = x + dx;
                    const ny = y + dy;
                    if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
                    const neighbor = ny * width + nx;
                    if (visited[neighbor] || data[neighbor * 4 + 3] === 0) continue;
                    visited[neighbor] = 1;
                    queue[tail++] = neighbor;
                }
            }
            if (tail > largest.count) largest = {
                start: pixel,
                count: tail
            };
        }
        // A second bounded traversal avoids keeping every large component in memory.
        visited.fill(0);
        for(let pixel = 0; pixel < pixels; pixel++){
            if (visited[pixel] || data[pixel * 4 + 3] === 0) continue;
            let head = 0;
            let tail = 1;
            queue[0] = pixel;
            visited[pixel] = 1;
            while(head < tail){
                const current = queue[head++];
                const x = current % width;
                const y = Math.floor(current / width);
                for(let dy = -1; dy <= 1; dy++)for(let dx = -1; dx <= 1; dx++){
                    if (dx === 0 && dy === 0) continue;
                    const nx = x + dx;
                    const ny = y + dy;
                    if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
                    const neighbor = ny * width + nx;
                    if (visited[neighbor] || data[neighbor * 4 + 3] === 0) continue;
                    visited[neighbor] = 1;
                    queue[tail++] = neighbor;
                }
            }
            let neutralSpeck = true;
            for(let i = 0; i < tail; i++){
                const offset = queue[i] * 4;
                if (Math.max(data[offset], data[offset + 1], data[offset + 2]) - Math.min(data[offset], data[offset + 1], data[offset + 2]) > 28) neutralSpeck = false;
            }
            if (tail <= maxSpeck && pixel !== largest.start && neutralSpeck) {
                for(let i = 0; i < tail; i++)data.fill(0, queue[i] * 4, queue[i] * 4 + 4);
                stats.removedSpecks += tail;
            }
        }
    }
    // Imported screenshots can have fully opaque white paper, so gray noise is
    // connected in alpha even when it is visually detached from the drawing.
    if (maxSpeck > 0) {
        let borderSamples = 0;
        let lightBorder = 0;
        for(let y = 0; y < height; y++)for(let x = 0; x < width; x++){
            if (x !== 0 && y !== 0 && x !== width - 1 && y !== height - 1) continue;
            borderSamples++;
            const offset = (y * width + x) * 4;
            if (data[offset + 3] > 240 && luminance(data[offset], data[offset + 1], data[offset + 2]) >= 235) {
                lightBorder++;
            }
        }
        if (lightBorder > borderSamples * 0.65) {
            const ink = new Uint8Array(pixels);
            for(let pixel = 0; pixel < pixels; pixel++){
                const offset = pixel * 4;
                if (data[offset + 3] === 0) continue;
                const r = data[offset], g = data[offset + 1], b = data[offset + 2];
                if (luminance(r, g, b) < 245 || Math.max(r, g, b) - Math.min(r, g, b) > 28) ink[pixel] = 1;
            }
            const visited = new Uint8Array(pixels);
            const queue = new Int32Array(pixels);
            let largestStart = -1;
            let largestCount = 0;
            const traverse = (start)=>{
                let head = 0, tail = 1;
                queue[0] = start;
                visited[start] = 1;
                while(head < tail){
                    const current = queue[head++];
                    const x = current % width;
                    const y = Math.floor(current / width);
                    for(let dy = -1; dy <= 1; dy++)for(let dx = -1; dx <= 1; dx++){
                        if (dx === 0 && dy === 0) continue;
                        const nx = x + dx, ny = y + dy;
                        if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
                        const neighbor = ny * width + nx;
                        if (!ink[neighbor] || visited[neighbor]) continue;
                        visited[neighbor] = 1;
                        queue[tail++] = neighbor;
                    }
                }
                return tail;
            };
            for(let pixel = 0; pixel < pixels; pixel++){
                if (!ink[pixel] || visited[pixel]) continue;
                const count = traverse(pixel);
                if (count > largestCount) {
                    largestStart = pixel;
                    largestCount = count;
                }
            }
            visited.fill(0);
            for(let pixel = 0; pixel < pixels; pixel++){
                if (!ink[pixel] || visited[pixel]) continue;
                const count = traverse(pixel);
                if (count > maxSpeck || pixel === largestStart) continue;
                let neutralSpeck = true;
                for(let i = 0; i < count; i++){
                    const offset = queue[i] * 4;
                    if (Math.max(data[offset], data[offset + 1], data[offset + 2]) - Math.min(data[offset], data[offset + 1], data[offset + 2]) > 28) neutralSpeck = false;
                }
                if (!neutralSpeck) continue;
                for(let i = 0; i < count; i++){
                    const offset = queue[i] * 4;
                    data.set([
                        255,
                        255,
                        255,
                        255
                    ], offset);
                }
                stats.removedSpecks += count;
            }
        }
    }
    if (options.simplifyColors) {
        const isNeutral = (r, g, b)=>Math.max(r, g, b) - Math.min(r, g, b) <= 28;
        const neutralBands = Array.from({
            length: 3
        }, ()=>({
                count: 0,
                whiteCount: 0,
                r: 0,
                g: 0,
                b: 0
            }));
        const bandFor = (r, g, b)=>{
            const lightness = luminance(r, g, b);
            return lightness <= 85 ? 0 : lightness <= 185 ? 1 : 2;
        };
        for(let offset = 0; offset < data.length; offset += 4){
            if (data[offset + 3] === 0 || !isNeutral(data[offset], data[offset + 1], data[offset + 2])) continue;
            const band = neutralBands[bandFor(data[offset], data[offset + 1], data[offset + 2])];
            band.count++;
            band.r += data[offset];
            band.g += data[offset + 1];
            band.b += data[offset + 2];
            if (data[offset] >= 250 && data[offset + 1] >= 250 && data[offset + 2] >= 250) band.whiteCount++;
        }
        const neutralColors = neutralBands.map((band, index)=>{
            if (band.count === 0) return null;
            if (index === 2 && band.whiteCount > band.count / 2) return [
                255,
                255,
                255
            ];
            return [
                Math.round(band.r / band.count),
                Math.round(band.g / band.count),
                Math.round(band.b / band.count)
            ];
        });
        for(let offset = 0; offset < data.length; offset += 4){
            if (data[offset + 3] === 0 || !isNeutral(data[offset], data[offset + 1], data[offset + 2])) continue;
            const color = neutralColors[bandFor(data[offset], data[offset + 1], data[offset + 2])];
            if (!color) continue;
            if (data[offset] !== color[0] || data[offset + 1] !== color[1] || data[offset + 2] !== color[2]) {
                data[offset] = color[0];
                data[offset + 1] = color[1];
                data[offset + 2] = color[2];
                stats.simplifiedColors++;
            }
        }
        const bins = new Map();
        for(let offset = 0; offset < data.length; offset += 4){
            if (data[offset + 3] === 0 || isNeutral(data[offset], data[offset + 1], data[offset + 2])) continue;
            const r = data[offset];
            const g = data[offset + 1];
            const b = data[offset + 2];
            const key = r >> 4 << 8 | g >> 4 << 4 | b >> 4;
            const bin = bins.get(key);
            if (bin) {
                bin.count++;
                bin.r += r;
                bin.g += g;
                bin.b += b;
            } else bins.set(key, {
                count: 1,
                r,
                g,
                b
            });
        }
        const palette = [
            ...bins.values()
        ].sort((a, b)=>b.count - a.count).slice(0, Math.max(2, Math.min(64, Math.floor(options.paletteSize)))).map((bin)=>[
                Math.round(bin.r / bin.count),
                Math.round(bin.g / bin.count),
                Math.round(bin.b / bin.count)
            ]);
        for(let offset = 0; offset < data.length; offset += 4){
            if (data[offset + 3] === 0 || isNeutral(data[offset], data[offset + 1], data[offset + 2])) continue;
            let bestDistance = Infinity;
            let best = palette[0];
            for (const color of palette){
                const distance = (data[offset] - color[0]) ** 2 + (data[offset + 1] - color[1]) ** 2 + (data[offset + 2] - color[2]) ** 2;
                if (distance < bestDistance) {
                    bestDistance = distance;
                    best = color;
                }
            }
            // Preserve unique accent colors if no plausible palette representative exists.
            if (best && bestDistance <= 48 ** 2 && (data[offset] !== best[0] || data[offset + 1] !== best[1] || data[offset + 2] !== best[2])) {
                data[offset] = best[0];
                data[offset + 1] = best[1];
                data[offset + 2] = best[2];
                stats.simplifiedColors++;
            }
        }
    }
    if (options.thinDarkLines) {
        const snapshot = new Uint8ClampedArray(data);
        const isDark = (pixel)=>{
            const offset = pixel * 4;
            return snapshot[offset + 3] > 0 && luminance(snapshot[offset], snapshot[offset + 1], snapshot[offset + 2]) < 90;
        };
        for(let y = 1; y < height - 1; y++)for(let x = 1; x < width - 1; x++){
            const pixel = y * width + x;
            if (!isDark(pixel)) continue;
            const cardinal = [
                pixel - width,
                pixel + 1,
                pixel + width,
                pixel - 1
            ];
            if (cardinal.some((neighbor)=>snapshot[neighbor * 4 + 3] === 0)) continue;
            let darkNeighbors = 0;
            for(let dy = -1; dy <= 1; dy++)for(let dx = -1; dx <= 1; dx++){
                if ((dx !== 0 || dy !== 0) && isDark((y + dy) * width + x + dx)) darkNeighbors++;
            }
            if (darkNeighbors < 3) continue;
            const fill = cardinal.find((neighbor)=>{
                const offset = neighbor * 4;
                return snapshot[offset + 3] > 0 && luminance(snapshot[offset], snapshot[offset + 1], snapshot[offset + 2]) >= 140;
            });
            if (fill === undefined) continue;
            const offset = pixel * 4;
            const fillOffset = fill * 4;
            data.set(snapshot.subarray(fillOffset, fillOffset + 3), offset);
            stats.thinnedLinePixels++;
        }
    }
    stats.protectedPixels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["restoreProtectedPixels"])(source, data, width, height, protectedRegions);
    stats.changedPixels = 0;
    for(let offset = 0; offset < data.length; offset += 4){
        if (data[offset] !== source[offset] || data[offset + 1] !== source[offset + 1] || data[offset + 2] !== source[offset + 2] || data[offset + 3] !== source[offset + 3]) stats.changedPixels++;
    }
    stats.resultColors = colorCount(data);
    return {
        data,
        stats
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/art/applyLessonEdit.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyLessonEdit",
    ()=>applyLessonEdit
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/historyEngine.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sync/coDrawBridge.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
;
;
;
;
;
;
function applyLessonEdit(description, draw) {
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    const layer = state.frames[state.activeFrameIndex]?.layers.find((candidate)=>candidate.id === state.activeLayerId);
    const history = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalHistoryEngine"])();
    if (!layer || layer.locked || state.isPlaying || !history) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
            type: 'error',
            message: 'Pause playback and choose an unlocked layer before editing. If the canvas is still loading, try again in a moment.'
        });
        return false;
    }
    let rollback;
    try {
        const buf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layer.id, state.canvasWidth, state.canvasHeight);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertMemoryAvailable"])(state.canvasWidth * state.canvasHeight * 4, description);
        const snapshot = {
            type: 'pixel',
            description,
            frameIndex: state.activeFrameIndex,
            layerId: layer.id,
            imageData: buf.ctx.getImageData(0, 0, state.canvasWidth, state.canvasHeight),
            layerName: layer.name,
            layerTag: layer.tag,
            layerBlendMode: layer.blendMode,
            layerEffect: layer.effect ? structuredClone(layer.effect) : undefined
        };
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateStepBytes"])(snapshot) > history.maxBytes) {
            throw new Error('This lesson edit is too large to undo. Choose a smaller canvas before trying again.');
        }
        rollback = ()=>buf.ctx.putImageData(snapshot.imageData, 0, 0);
        // Canvas state (for example fillStyle) is not part of the artwork snapshot.
        buf.ctx.save();
        try {
            draw(buf.ctx);
        } finally{
            buf.ctx.restore();
        }
        history.push(snapshot);
        rollback = undefined;
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState((draft)=>{
            const edited = draft.frames[snapshot.frameIndex]?.layers.find((candidate)=>candidate.id === layer.id);
            if (edited) edited.effect = undefined;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(layer.id);
        state.setCanUndo(history.canUndo);
        state.setCanRedo(history.canRedo);
        state.bumpBufferVersion();
        state.setDirty(true);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:request-composite');
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].notifyStrokeCommitted(layer.id, snapshot.imageData);
        return true;
    } catch (error) {
        rollback?.();
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
            type: 'error',
            message: error instanceof Error ? error.message : 'The lesson edit could not be applied.'
        });
        return false;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/art/bunSprite.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BUN_BODY",
    ()=>BUN_BODY,
    "BUN_INK",
    ()=>BUN_INK,
    "BUN_POSES",
    ()=>BUN_POSES,
    "bunOutline",
    ()=>bunOutline,
    "bunPixels",
    ()=>bunPixels,
    "drawBun",
    ()=>drawBun
]);
const BUN_INK = '#3a2e4c';
const FUR = '#f2ecf7';
const SHADE = '#d9cde8';
const INNER = '#f0b7cf';
const BLUSH = '#f2b8c6';
const BELLY = '#faf6fc';
const BUN_BODY = [
    // Left ear
    [
        4,
        0,
        1,
        1,
        FUR
    ],
    [
        3,
        1,
        3,
        1,
        FUR
    ],
    [
        3,
        2,
        3,
        3,
        FUR
    ],
    [
        4,
        2,
        1,
        3,
        INNER
    ],
    // Right ear
    [
        11,
        0,
        1,
        1,
        FUR
    ],
    [
        10,
        1,
        3,
        1,
        FUR
    ],
    [
        10,
        2,
        3,
        3,
        FUR
    ],
    [
        11,
        2,
        1,
        3,
        INNER
    ],
    // Head, rounded corners
    [
        4,
        5,
        8,
        1,
        FUR
    ],
    [
        3,
        6,
        10,
        1,
        FUR
    ],
    [
        2,
        7,
        12,
        4,
        FUR
    ],
    [
        3,
        11,
        10,
        1,
        SHADE
    ],
    // Body
    [
        3,
        12,
        10,
        3,
        FUR
    ],
    [
        3,
        12,
        1,
        3,
        SHADE
    ],
    [
        12,
        12,
        1,
        3,
        SHADE
    ],
    [
        6,
        13,
        4,
        2,
        BELLY
    ],
    [
        3,
        15,
        10,
        1,
        SHADE
    ]
];
const BUN_POSES = {
    idle: [
        [
            5,
            8,
            1,
            2,
            BUN_INK
        ],
        [
            10,
            8,
            1,
            2,
            BUN_INK
        ]
    ],
    blink: [
        [
            5,
            9,
            1,
            1,
            BUN_INK
        ],
        [
            10,
            9,
            1,
            1,
            BUN_INK
        ]
    ],
    happy: [
        [
            5,
            7,
            1,
            1,
            BUN_INK
        ],
        [
            4,
            8,
            1,
            1,
            BUN_INK
        ],
        [
            6,
            8,
            1,
            1,
            BUN_INK
        ],
        [
            10,
            7,
            1,
            1,
            BUN_INK
        ],
        [
            9,
            8,
            1,
            1,
            BUN_INK
        ],
        [
            11,
            8,
            1,
            1,
            BUN_INK
        ]
    ]
};
// Rosy cheeks survive every pose.
const BUN_BLUSH = [
    [
        3,
        9,
        2,
        1,
        BLUSH
    ],
    [
        11,
        9,
        2,
        1,
        BLUSH
    ]
];
function bunPixels(pose) {
    return [
        ...BUN_BODY,
        ...BUN_BLUSH,
        ...BUN_POSES[pose]
    ];
}
function bunOutline(pose) {
    const covered = new Set();
    const ring = [];
    for (const [x, y, w, h] of bunPixels(pose)){
        for(let dx = -1; dx <= w; dx++){
            for(let dy = -1; dy <= h; dy++){
                const px = x + dx;
                const py = y + dy;
                const key = `${px},${py}`;
                if (covered.has(key)) continue;
                covered.add(key);
                const inside = dx >= 0 && dx < w && dy >= 0 && dy < h;
                if (!inside) ring.push([
                    px,
                    py
                ]);
            }
        }
    }
    return ring;
}
function drawBun(ctx, ox, oy, pose, outline = true) {
    if (outline) {
        ctx.fillStyle = BUN_INK;
        for (const [x, y] of bunOutline(pose)){
            ctx.fillRect(ox + x, oy + y, 1, 1);
        }
    }
    for (const [x, y, w, h, fill] of bunPixels(pose)){
        ctx.fillStyle = fill;
        ctx.fillRect(ox + x, oy + y, w, h);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/art/normalSculptor.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * normalSculptor.ts
 * 2.5D Normal Chisel & Bas-Relief Sculptor
 * 
 * Tangent-space normal vector encoding/decoding, directional bevel & chamfer geometry,
 * Reoriented Normal Mapping (RNM, Barré-Brisebois & Hill 2012),
 * and two-phase stroke envelope buffer to eliminate intra-stroke angular accumulation.
 */ __turbopack_context__.s([
    "ChiselStrokeSession",
    ()=>ChiselStrokeSession,
    "blendNormals",
    ()=>blendNormals,
    "blendNormalsRNM",
    ()=>blendNormalsRNM,
    "blendNormalsUDN",
    ()=>blendNormalsUDN,
    "computeDirectionalBevelNormal",
    ()=>computeDirectionalBevelNormal,
    "decodeNormalRGB",
    ()=>decodeNormalRGB,
    "encodeNormalRGB",
    ()=>encodeNormalRGB
]);
function encodeNormalRGB(nx, ny, nz, openGLConvention = true) {
    // Ensure unit vector length
    const len = Math.hypot(nx, ny, nz);
    const unx = len > 1e-6 ? nx / len : 0;
    const uny = len > 1e-6 ? ny / len : 0;
    const unz = len > 1e-6 ? nz / len : 1;
    // OpenGL tangent space: +Y is Up. Screen space: +Y is Down.
    const yComp = openGLConvention ? uny : -uny;
    const r = Math.round(Math.max(0, Math.min(255, (unx + 1) * 127.5)));
    const g = Math.round(Math.max(0, Math.min(255, (yComp + 1) * 127.5)));
    const b = Math.round(Math.max(0, Math.min(255, (unz + 1) * 127.5)));
    return [
        r,
        g,
        b
    ];
}
function decodeNormalRGB(r, g, b, openGLConvention = true) {
    const rawX = r / 255 * 2 - 1;
    const rawY = g / 255 * 2 - 1;
    const rawZ = b / 255 * 2 - 1;
    const yComp = openGLConvention ? rawY : -rawY;
    const len = Math.hypot(rawX, yComp, rawZ);
    if (len < 1e-6) {
        return [
            0,
            0,
            1
        ];
    }
    return [
        rawX / len,
        yComp / len,
        rawZ / len
    ];
}
function computeDirectionalBevelNormal(azimuthDeg, inclineDeg, openGLConvention = true) {
    const alphaRad = azimuthDeg * Math.PI / 180;
    const phiRad = Math.max(1, Math.min(90, inclineDeg)) * Math.PI / 180;
    const sinPhi = Math.sin(phiRad);
    const cosPhi = Math.cos(phiRad);
    // Compass azimuth: 0° points North (+Y OpenGL, -Y screen), 90° points East (+X)
    const nx = sinPhi * Math.sin(alphaRad);
    const nyOpenGL = sinPhi * Math.cos(alphaRad);
    const nyScreen = -sinPhi * Math.cos(alphaRad);
    const nz = cosPhi;
    const ny = openGLConvention ? nyOpenGL : nyScreen;
    const len = Math.hypot(nx, ny, nz) || 1;
    return [
        nx / len,
        ny / len,
        nz / len
    ];
}
function blendNormalsRNM(base, detail) {
    // Base normal shifted: t = (base.x, base.y, base.z + 1)
    const tx = base[0];
    const ty = base[1];
    const tz = Math.max(1e-5, base[2] + 1);
    // Detail normal with inverted X/Y: u = (-detail.x, -detail.y, detail.z)
    const ux = -detail[0];
    const uy = -detail[1];
    const uz = detail[2];
    // dot(t, u)
    const dotTU = tx * ux + ty * uy + tz * uz;
    // r = t * dot(t, u) - u * t.z
    const rx = tx * dotTU - ux * tz;
    const ry = ty * dotTU - uy * tz;
    const rz = tz * dotTU - uz * tz;
    const clampedZ = Math.max(0, rz);
    const len = Math.hypot(rx, ry, clampedZ);
    if (len < 1e-6) {
        return [
            0,
            0,
            1
        ];
    }
    return [
        rx / len,
        ry / len,
        clampedZ / len
    ];
}
function blendNormalsUDN(base, detail) {
    const rx = base[0] + detail[0];
    const ry = base[1] + detail[1];
    const rz = Math.max(1e-5, base[2]);
    const len = Math.hypot(rx, ry, rz) || 1;
    return [
        rx / len,
        ry / len,
        Math.max(0, rz / len)
    ];
}
function blendNormals(base, detail, mode) {
    switch(mode){
        case 'rnm':
            return blendNormalsRNM(base, detail);
        case 'udn':
            return blendNormalsUDN(base, detail);
        case 'overwrite':
        default:
            return detail;
    }
}
class ChiselStrokeSession {
    width;
    height;
    strokeNx;
    strokeNy;
    strokeNz;
    strokeAlpha;
    modifiedIndices;
    constructor(width, height){
        this.width = width;
        this.height = height;
        const size = width * height;
        this.strokeNx = new Float32Array(size);
        this.strokeNy = new Float32Array(size);
        this.strokeNz = new Float32Array(size);
        this.strokeAlpha = new Float32Array(size);
        this.modifiedIndices = new Set();
    }
    /**
   * Clears the current stroke buffer.
   */ clear() {
        this.strokeNx.fill(0);
        this.strokeNy.fill(0);
        this.strokeNz.fill(0);
        this.strokeAlpha.fill(0);
        this.modifiedIndices.clear();
    }
    /**
   * Applies a directional chisel stamp at canvas coordinate (cx, cy).
   */ stampChisel(cx, cy, settings, strokeTangent) {
        const radius = Math.max(0.5, settings.width / 2);
        const rInt = Math.ceil(radius);
        // If ridge mode is active and we have a drag vector, use the perpendicular flank normal
        let normal;
        if (settings.ridgeMode && strokeTangent && (strokeTangent.dx !== 0 || strokeTangent.dy !== 0)) {
            const len = Math.hypot(strokeTangent.dx, strokeTangent.dy);
            const perpX = -strokeTangent.dy / len;
            const perpY = strokeTangent.dx / len;
            const phiRad = Math.max(15, Math.min(75, settings.incline)) * Math.PI / 180;
            const sinPhi = Math.sin(phiRad);
            const cosPhi = Math.cos(phiRad);
            normal = [
                sinPhi * perpX,
                sinPhi * perpY,
                cosPhi
            ];
        } else {
            normal = computeDirectionalBevelNormal(settings.azimuth, settings.incline, true);
        }
        for(let dy = -rInt; dy <= rInt; dy++){
            const py = cy + dy;
            if (py < 0 || py >= this.height) continue;
            for(let dx = -rInt; dx <= rInt; dx++){
                const px = cx + dx;
                if (px < 0 || px >= this.width) continue;
                const dist = Math.hypot(dx, dy);
                if (dist > radius) continue;
                const idx = py * this.width + px;
                let facetNormal = normal;
                // In dual-flank ridge mode, flip cross-flank slope on opposite side of stroke
                if (settings.ridgeMode && strokeTangent && (strokeTangent.dx !== 0 || strokeTangent.dy !== 0)) {
                    const crossDot = dx * -strokeTangent.dy + dy * strokeTangent.dx;
                    if (crossDot < 0) {
                        facetNormal = [
                            -normal[0],
                            -normal[1],
                            normal[2]
                        ];
                    }
                }
                // Two-phase envelope update: within this stroke, overwrite the normal facet
                // without recursive RNM self-rotation.
                this.strokeNx[idx] = facetNormal[0];
                this.strokeNy[idx] = facetNormal[1];
                this.strokeNz[idx] = facetNormal[2];
                this.strokeAlpha[idx] = 1.0;
                this.modifiedIndices.add(idx);
            }
        }
    }
    /**
   * Composites the stroke buffer onto base image data using RNM or specified blend mode.
   * Modifies the target image data in-place and returns it.
   */ compositeOnto(baseImageData, blendMode = 'rnm') {
        const data = baseImageData.data;
        for (const idx of this.modifiedIndices){
            const pIdx = idx * 4;
            const alpha = this.strokeAlpha[idx];
            if (alpha <= 0) continue;
            const detailNormal = [
                this.strokeNx[idx],
                this.strokeNy[idx],
                this.strokeNz[idx]
            ];
            const baseAlpha = data[pIdx + 3];
            let finalNormal;
            if (baseAlpha > 20) {
                const baseNormal = decodeNormalRGB(data[pIdx], data[pIdx + 1], data[pIdx + 2], true);
                finalNormal = blendNormals(baseNormal, detailNormal, blendMode);
            } else {
                finalNormal = detailNormal;
            }
            const [r, g, b] = encodeNormalRGB(finalNormal[0], finalNormal[1], finalNormal[2], true);
            data[pIdx] = r;
            data[pIdx + 1] = g;
            data[pIdx + 2] = b;
            data[pIdx + 3] = 255;
        }
        return baseImageData;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/art/playgroundLessons.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Dedicated master lesson templates and animation theory for the PixiBun Playground.
// Grounded in verified classical animation principles adapted to discrete pixel grids:
// Pedro Medeiros (Saint11), Michael Azzi (Pixel Logic), and Richard Williams (Animator's Survival Kit).
__turbopack_context__.s([
    "PLAYGROUND_LESSONS",
    ()=>PLAYGROUND_LESSONS,
    "getTemplateGridSize",
    ()=>getTemplateGridSize,
    "getTemplateRows",
    ()=>getTemplateRows
]);
const EMPTY_ROW_16 = '................';
const EMPTY_ROW_32 = '................................';
function rows(arr) {
    const r = Array(16).fill(EMPTY_ROW_16);
    for (const [idx, str] of arr){
        r[idx] = str;
    }
    return r;
}
function rows32(arr) {
    const r = Array(32).fill(EMPTY_ROW_32);
    for (const [idx, str] of arr){
        if (str.length !== 32) throw new Error(`Row ${idx} length is ${str.length}, expected 32`);
        r[idx] = str;
    }
    return r;
}
function getTemplateRows(template) {
    return template.gridRows || template.grid16 || [];
}
function getTemplateGridSize(template) {
    if (template.canvasSize) return template.canvasSize;
    if (template.gridRows && template.gridRows.length > 0) return template.gridRows.length;
    if (template.grid16 && template.grid16.length > 0) return template.grid16.length;
    return 16;
}
// Master Bouncing Ball (12-Frame Complete Cycle at 32x32)
const MASTER_BOUNCING_BALL_FRAMES = [
    {
        frameIndex: 0,
        name: "Frame 1: Apex Float",
        subhead: "Apex Float (112 px area, ~120 ms)",
        principle: "Apex Float",
        explanation: "Keyframe 1 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 120,
        kineticPhase: "Apex Float",
        effectivePixelArea: 112,
        opticalTrick: "Apex Hang Time: Gravitational balance at crest (0px velocity)",
        gridRows: rows32([
            [
                4,
                "..............oooo.............."
            ],
            [
                5,
                "............oooAAooo............"
            ],
            [
                6,
                "...........ooAAAAAAoo..........."
            ],
            [
                7,
                "...........oAAAAAAAAo..........."
            ],
            [
                8,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                9,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                10,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                11,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                12,
                "...........oAAAAAAAAo..........."
            ],
            [
                13,
                "...........ooAAAAAAoo..........."
            ],
            [
                14,
                "............oooAAooo............"
            ],
            [
                15,
                "..............oooo.............."
            ],
            [
                27,
                "..............pppp.............."
            ]
        ])
    },
    {
        frameIndex: 1,
        name: "Frame 2: Apex Cushioning",
        subhead: "Apex Cushioning (112 px area, ~80 ms)",
        principle: "Apex Cushioning",
        explanation: "Keyframe 2 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 80,
        kineticPhase: "Apex Cushioning",
        effectivePixelArea: 112,
        opticalTrick: "Deceleration Halving: 1px initial descent cushions away from apex",
        gridRows: rows32([
            [
                5,
                "..............oooo.............."
            ],
            [
                6,
                "............oooAAooo............"
            ],
            [
                7,
                "...........ooAAAAAAoo..........."
            ],
            [
                8,
                "...........oAAAAAAAAo..........."
            ],
            [
                9,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                10,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                11,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                12,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                13,
                "...........oAAAAAAAAo..........."
            ],
            [
                14,
                "...........ooAAAAAAoo..........."
            ],
            [
                15,
                "............oooAAooo............"
            ],
            [
                16,
                "..............oooo.............."
            ],
            [
                27,
                ".............pppppp............."
            ]
        ])
    },
    {
        frameIndex: 2,
        name: "Frame 3: Fall Acceleration",
        subhead: "Fall Acceleration (112 px area, ~60 ms)",
        principle: "Fall Acceleration",
        explanation: "Keyframe 3 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 60,
        kineticPhase: "Fall Acceleration",
        effectivePixelArea: 112,
        opticalTrick: "Kinetic Stretch: 1px lateral narrowing balances vertical elongation",
        gridRows: rows32([
            [
                8,
                "..............oooo.............."
            ],
            [
                9,
                ".............ooAAoo............."
            ],
            [
                10,
                "............ooAAAAoo............"
            ],
            [
                11,
                "............oAAAAAAo............"
            ],
            [
                12,
                "...........ooAAAAAAoo..........."
            ],
            [
                13,
                "...........oAAAAAAAAo..........."
            ],
            [
                14,
                "...........oAAAAAAAAo..........."
            ],
            [
                15,
                "...........oAAAAAAAAo..........."
            ],
            [
                16,
                "...........oAAAAAAAAo..........."
            ],
            [
                17,
                "...........ooAAAAAAoo..........."
            ],
            [
                18,
                "............oAAAAAAo............"
            ],
            [
                19,
                "............ooAAAAoo............"
            ],
            [
                20,
                ".............ooAAoo............."
            ],
            [
                21,
                "..............oooo.............."
            ],
            [
                27,
                "............pppppppp............"
            ]
        ])
    },
    {
        frameIndex: 3,
        name: "Frame 4: Terminal Velocity Stretch",
        subhead: "Terminal Velocity Stretch (112 px area, ~50 ms)",
        principle: "Terminal Velocity Stretch",
        explanation: "Keyframe 4 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 50,
        kineticPhase: "Terminal Velocity Stretch",
        effectivePixelArea: 112,
        opticalTrick: "Terminal Velocity: Maximum kinetic stretch bridges distance to ground",
        gridRows: rows32([
            [
                11,
                "..............oooo.............."
            ],
            [
                12,
                ".............ooAAoo............."
            ],
            [
                13,
                "............ooAAAAoo............"
            ],
            [
                14,
                "............oAAAAAAo............"
            ],
            [
                15,
                "............oAAAAAAo............"
            ],
            [
                16,
                "............oAAAAAAo............"
            ],
            [
                17,
                "...........ooAAAAAAoo..........."
            ],
            [
                18,
                "...........ooAAAAAAoo..........."
            ],
            [
                19,
                "............oAAAAAAo............"
            ],
            [
                20,
                "............oAAAAAAo............"
            ],
            [
                21,
                "............oAAAAAAo............"
            ],
            [
                22,
                "............oAAAAAAo............"
            ],
            [
                23,
                "............ooAAAAoo............"
            ],
            [
                24,
                ".............ooAAoo............."
            ],
            [
                25,
                "..............oooo.............."
            ],
            [
                27,
                "...........pppppppppp..........."
            ]
        ])
    },
    {
        frameIndex: 4,
        name: "Frame 5: Ground Contact",
        subhead: "Ground Contact (112 px area, ~40 ms)",
        principle: "Ground Contact",
        explanation: "Keyframe 5 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 40,
        kineticPhase: "Ground Contact",
        effectivePixelArea: 112,
        opticalTrick: "Impact Compression: Base touches ground plane (y=26), initiating squash",
        gridRows: rows32([
            [
                17,
                ".............oooooo............."
            ],
            [
                18,
                "............ooAAAAoo............"
            ],
            [
                19,
                "...........ooAAAAAAoo..........."
            ],
            [
                20,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                21,
                ".........ooAAAAAAAAAAoo........."
            ],
            [
                22,
                "........ooAAAAAAAAAAAAoo........"
            ],
            [
                23,
                "........ooAAAAAAAAAAAAoo........"
            ],
            [
                24,
                ".........oooAAAAAAAAooo........."
            ],
            [
                25,
                "...........oooAAAAooo..........."
            ],
            [
                26,
                ".............oooooo............."
            ],
            [
                27,
                ".........pppppppppppppp........."
            ]
        ])
    },
    {
        frameIndex: 5,
        name: "Frame 6: Impact Squash (Hitstop)",
        subhead: "Impact Squash (Hitstop) (112 px area, ~200 ms)",
        principle: "Impact Squash (Hitstop)",
        explanation: "Keyframe 6 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 200,
        kineticPhase: "Impact Squash (Hitstop)",
        effectivePixelArea: 112,
        opticalTrick: "Weight & Energy Dissipation: Broad flat base absorbs kinetic energy",
        gridRows: rows32([
            [
                21,
                "...........oooooooooo..........."
            ],
            [
                22,
                "........ooooAAAAAAAAoooo........"
            ],
            [
                23,
                ".....ooooAAAAAAAAAAAAAAoooo....."
            ],
            [
                24,
                ".....oAAAAAAAAAAAAAAAAAAAAo....."
            ],
            [
                25,
                ".....ooAAAAAAAAAAAAAAAAAAoo....."
            ],
            [
                26,
                "......oooooooooooooooooooo......"
            ],
            [
                27,
                "......pppppppppppppppppppp......"
            ]
        ])
    },
    {
        frameIndex: 6,
        name: "Frame 7: Elastic Rebound",
        subhead: "Elastic Rebound (112 px area, ~40 ms)",
        principle: "Elastic Rebound",
        explanation: "Keyframe 7 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 40,
        kineticPhase: "Elastic Rebound",
        effectivePixelArea: 112,
        opticalTrick: "Elastic Recoil: Rebound stretch propels ball vertically",
        gridRows: rows32([
            [
                11,
                "..............oooo.............."
            ],
            [
                12,
                ".............ooAAoo............."
            ],
            [
                13,
                "............ooAAAAoo............"
            ],
            [
                14,
                "............oAAAAAAo............"
            ],
            [
                15,
                "............oAAAAAAo............"
            ],
            [
                16,
                "............oAAAAAAo............"
            ],
            [
                17,
                "...........ooAAAAAAoo..........."
            ],
            [
                18,
                "...........ooAAAAAAoo..........."
            ],
            [
                19,
                "............oAAAAAAo............"
            ],
            [
                20,
                "............oAAAAAAo............"
            ],
            [
                21,
                "............oAAAAAAo............"
            ],
            [
                22,
                "............oAAAAAAo............"
            ],
            [
                23,
                "............ooAAAAoo............"
            ],
            [
                24,
                ".............ooAAoo............."
            ],
            [
                25,
                "..............oooo.............."
            ],
            [
                27,
                "...........pppppppppp..........."
            ]
        ])
    },
    {
        frameIndex: 7,
        name: "Frame 8: Ascent Transfer",
        subhead: "Ascent Transfer (112 px area, ~50 ms)",
        principle: "Ascent Transfer",
        explanation: "Keyframe 8 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 50,
        kineticPhase: "Ascent Transfer",
        effectivePixelArea: 112,
        opticalTrick: "Ascent Transition: Deceleration begins restoring circular equilibrium",
        gridRows: rows32([
            [
                9,
                "..............oooo.............."
            ],
            [
                10,
                ".............ooAAoo............."
            ],
            [
                11,
                "............ooAAAAoo............"
            ],
            [
                12,
                "............oAAAAAAo............"
            ],
            [
                13,
                "...........ooAAAAAAoo..........."
            ],
            [
                14,
                "...........oAAAAAAAAo..........."
            ],
            [
                15,
                "...........oAAAAAAAAo..........."
            ],
            [
                16,
                "...........oAAAAAAAAo..........."
            ],
            [
                17,
                "...........oAAAAAAAAo..........."
            ],
            [
                18,
                "...........ooAAAAAAoo..........."
            ],
            [
                19,
                "............oAAAAAAo............"
            ],
            [
                20,
                "............ooAAAAoo............"
            ],
            [
                21,
                ".............ooAAoo............."
            ],
            [
                22,
                "..............oooo.............."
            ],
            [
                27,
                "............pppppppp............"
            ]
        ])
    },
    {
        frameIndex: 8,
        name: "Frame 9: Deceleration Cushion",
        subhead: "Deceleration Cushion (112 px area, ~70 ms)",
        principle: "Deceleration Cushion",
        explanation: "Keyframe 9 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 70,
        kineticPhase: "Deceleration Cushion",
        effectivePixelArea: 112,
        opticalTrick: "Deceleration Halving: Upward speed halves as gravity counteracts inertia",
        gridRows: rows32([
            [
                7,
                "..............oooo.............."
            ],
            [
                8,
                "............oooAAooo............"
            ],
            [
                9,
                "...........ooAAAAAAoo..........."
            ],
            [
                10,
                "...........oAAAAAAAAo..........."
            ],
            [
                11,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                12,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                13,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                14,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                15,
                "...........oAAAAAAAAo..........."
            ],
            [
                16,
                "...........ooAAAAAAoo..........."
            ],
            [
                17,
                "............oooAAooo............"
            ],
            [
                18,
                "..............oooo.............."
            ],
            [
                27,
                ".............pppppp............."
            ]
        ])
    },
    {
        frameIndex: 9,
        name: "Frame 10: Apex Slow-In",
        subhead: "Apex Slow-In (112 px area, ~90 ms)",
        principle: "Apex Slow-In",
        explanation: "Keyframe 10 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 90,
        kineticPhase: "Apex Slow-In",
        effectivePixelArea: 112,
        opticalTrick: "Apex Slow-In: Near-zero velocity creates suspended hang time",
        gridRows: rows32([
            [
                5,
                "..............oooo.............."
            ],
            [
                6,
                "............oooAAooo............"
            ],
            [
                7,
                "...........ooAAAAAAoo..........."
            ],
            [
                8,
                "...........oAAAAAAAAo..........."
            ],
            [
                9,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                10,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                11,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                12,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                13,
                "...........oAAAAAAAAo..........."
            ],
            [
                14,
                "...........ooAAAAAAoo..........."
            ],
            [
                15,
                "............oooAAooo............"
            ],
            [
                16,
                "..............oooo.............."
            ],
            [
                27,
                ".............pppppp............."
            ]
        ])
    },
    {
        frameIndex: 10,
        name: "Frame 11: Overshoot Oscillation",
        subhead: "Overshoot Oscillation (112 px area, ~100 ms)",
        principle: "Overshoot Oscillation",
        explanation: "Keyframe 11 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 100,
        kineticPhase: "Overshoot Oscillation",
        effectivePixelArea: 112,
        opticalTrick: "Micro-Settling: Subtle kinetic settling before final loop reset",
        gridRows: rows32([
            [
                4,
                "..............oooo.............."
            ],
            [
                5,
                "............oooAAooo............"
            ],
            [
                6,
                "...........ooAAAAAAoo..........."
            ],
            [
                7,
                "...........oAAAAAAAAo..........."
            ],
            [
                8,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                9,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                10,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                11,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                12,
                "...........oAAAAAAAAo..........."
            ],
            [
                13,
                "...........ooAAAAAAoo..........."
            ],
            [
                14,
                "............oooAAooo............"
            ],
            [
                15,
                "..............oooo.............."
            ],
            [
                27,
                "..............pppp.............."
            ]
        ])
    },
    {
        frameIndex: 11,
        name: "Frame 12: Cycle Reset",
        subhead: "Cycle Reset (112 px area, ~100 ms)",
        principle: "Cycle Reset",
        explanation: "Keyframe 12 of 12. Volume: 112 px. Symmetrical pixel-art form with fully enclosed, unbroken outline.",
        artisanRule: "Mass Conservation: 112 px effective area preserved with zero outline leaks.",
        canvasSize: 32,
        recommendedHoldMs: 100,
        kineticPhase: "Cycle Reset",
        effectivePixelArea: 112,
        opticalTrick: "Seamless Loop: Identical resting mass connects cleanly back to Frame 1",
        gridRows: rows32([
            [
                4,
                "..............oooo.............."
            ],
            [
                5,
                "............oooAAooo............"
            ],
            [
                6,
                "...........ooAAAAAAoo..........."
            ],
            [
                7,
                "...........oAAAAAAAAo..........."
            ],
            [
                8,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                9,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                10,
                "..........oAAAAAAAAAAo.........."
            ],
            [
                11,
                "..........ooAAAAAAAAoo.........."
            ],
            [
                12,
                "...........oAAAAAAAAo..........."
            ],
            [
                13,
                "...........ooAAAAAAoo..........."
            ],
            [
                14,
                "............oooAAooo............"
            ],
            [
                15,
                "..............oooo.............."
            ],
            [
                27,
                "..............pppp.............."
            ]
        ])
    }
];
const SUBPIXEL_IDLE_FRAMES = [
    {
        frameIndex: 0,
        name: "Frame 1: Resting Chest Stance",
        subhead: "Frame 1: Resting Chest Stance (~250 ms)",
        principle: "Sub-Pixel Luminosity & Anti-Boiling",
        explanation: "Keyframe 1 of 3. Silhouette contour maintains consistent edge alignment without pixel boiling.",
        artisanRule: "Cluster Stability: Locking silhouette clusters minimizes pixel boiling.",
        canvasSize: 32,
        recommendedHoldMs: 250,
        kineticPhase: "Neutral Rest",
        effectivePixelArea: 145,
        opticalTrick: "Sub-Pixel Contrast Modulation: Shifting internal belly shade by 1px simulates breathing.",
        gridRows: rows32([
            [
                7,
                "...........ooo....ooo..........."
            ],
            [
                8,
                "...........oro....oro..........."
            ],
            [
                9,
                "...........oro....oro..........."
            ],
            [
                10,
                "...........oro....oro..........."
            ],
            [
                11,
                "..........oofoooooofoo.........."
            ],
            [
                12,
                ".........ooffffffffffoo........."
            ],
            [
                13,
                ".........offkffffffkffo........."
            ],
            [
                14,
                ".........offkffffffkffo........."
            ],
            [
                15,
                ".........oorfffrrfffroo........."
            ],
            [
                16,
                "..........offffffffffo.........."
            ],
            [
                17,
                ".........ooffffffffffoo........."
            ],
            [
                18,
                "........ooffffffffffffoo........"
            ],
            [
                19,
                "........offffffffffffffo........"
            ],
            [
                20,
                "........offffffffffffffo........"
            ],
            [
                21,
                "........offffffffffffffo........"
            ],
            [
                22,
                "........oossssssssssssoo........"
            ],
            [
                23,
                ".........oossssssssssoo........."
            ],
            [
                24,
                "..........oooooooooooo.........."
            ],
            [
                26,
                "........pppppppppppppppp........"
            ]
        ])
    },
    {
        frameIndex: 1,
        name: "Frame 2: Inhale Chest Rise",
        subhead: "Frame 2: Inhale Chest Rise (~300 ms)",
        principle: "Sub-Pixel Luminosity & Anti-Boiling",
        explanation: "Keyframe 2 of 3. Silhouette contour maintains consistent edge alignment without pixel boiling.",
        artisanRule: "Cluster Stability: Locking silhouette clusters minimizes pixel boiling.",
        canvasSize: 32,
        recommendedHoldMs: 300,
        kineticPhase: "Inhale Expansion",
        effectivePixelArea: 145,
        opticalTrick: "Sub-Pixel Contrast Modulation: Shifting internal belly shade by 1px simulates breathing.",
        gridRows: rows32([
            [
                7,
                "...........ooo....ooo..........."
            ],
            [
                8,
                "...........oro....oro..........."
            ],
            [
                9,
                "...........oro....oro..........."
            ],
            [
                10,
                "...........oro....oro..........."
            ],
            [
                11,
                "..........oofoooooofoo.........."
            ],
            [
                12,
                ".........ooffffffffffoo........."
            ],
            [
                13,
                ".........offkffffffkffo........."
            ],
            [
                14,
                ".........offkffffffkffo........."
            ],
            [
                15,
                ".........oorfffrrfffroo........."
            ],
            [
                16,
                "..........offffffffffo.........."
            ],
            [
                17,
                ".........ooffffffffffoo........."
            ],
            [
                18,
                "........ooffffffffffffoo........"
            ],
            [
                19,
                "........offffffffffffffo........"
            ],
            [
                20,
                "........offffffffffffffo........"
            ],
            [
                21,
                "........osssssssssssssso........"
            ],
            [
                22,
                "........oossssssssssssoo........"
            ],
            [
                23,
                ".........oossssssssssoo........."
            ],
            [
                24,
                "..........oooooooooooo.........."
            ],
            [
                26,
                "........pppppppppppppppp........"
            ]
        ])
    },
    {
        frameIndex: 2,
        name: "Frame 3: Exhale Gravity Settle",
        subhead: "Frame 3: Exhale Gravity Settle (~550 ms)",
        principle: "Sub-Pixel Luminosity & Anti-Boiling",
        explanation: "Keyframe 3 of 3. Silhouette contour maintains consistent edge alignment without pixel boiling.",
        artisanRule: "Cluster Stability: Locking silhouette clusters minimizes pixel boiling.",
        canvasSize: 32,
        recommendedHoldMs: 550,
        kineticPhase: "Exhale Settle",
        effectivePixelArea: 145,
        opticalTrick: "Sub-Pixel Contrast Modulation: Shifting internal belly shade by 1px simulates breathing.",
        gridRows: rows32([
            [
                7,
                "...........ooo....ooo..........."
            ],
            [
                8,
                "...........oro....oro..........."
            ],
            [
                9,
                "...........oro....oro..........."
            ],
            [
                10,
                "...........oro....oro..........."
            ],
            [
                11,
                "..........oofoooooofoo.........."
            ],
            [
                12,
                ".........ooffffffffffoo........."
            ],
            [
                13,
                ".........offkffffffkffo........."
            ],
            [
                14,
                ".........offkffffffkffo........."
            ],
            [
                15,
                ".........oorfffrrfffroo........."
            ],
            [
                16,
                "..........offffffffffo.........."
            ],
            [
                17,
                ".........ooffffffffffoo........."
            ],
            [
                18,
                "........ooffffffffffffoo........"
            ],
            [
                19,
                "........offffffffffffffo........"
            ],
            [
                20,
                "........offffffffffffffo........"
            ],
            [
                21,
                "........offffffffffffffo........"
            ],
            [
                22,
                "........oossssssssssssoo........"
            ],
            [
                23,
                ".........oossssssssssoo........."
            ],
            [
                24,
                "..........oooooooooooo.........."
            ],
            [
                26,
                "........pppppppppppppppp........"
            ]
        ])
    }
];
const COMBAT_SLASH_FRAMES = [
    {
        frameIndex: 0,
        name: "Frame 1: High Windup Hold",
        subhead: "Potential energy stored at 45° angle (~200 ms)",
        principle: "Combat Anticipation",
        explanation: "The blade is held high above the warrior. Clear diagonal silhouette tells the player an attack is imminent.",
        artisanRule: "Silhouette Readability: A strong diagonal communicating high potential energy.",
        canvasSize: 32,
        recommendedHoldMs: 200,
        kineticPhase: "Anticipation Windup",
        effectivePixelArea: 68,
        opticalTrick: "Potential Energy Hold: High 45° angle registers upcoming strike.",
        gridRows: rows32([
            [
                4,
                "....oo.........................."
            ],
            [
                5,
                "....ooo........................."
            ],
            [
                6,
                ".....ooo........................"
            ],
            [
                7,
                "......ooo......................."
            ],
            [
                8,
                ".......ooo......................"
            ],
            [
                9,
                "........ooo....................."
            ],
            [
                10,
                ".........ooo...................."
            ],
            [
                11,
                "..........ooo..................."
            ],
            [
                12,
                "...........ooo.................."
            ],
            [
                13,
                "............ooo................."
            ],
            [
                14,
                ".............o.................."
            ],
            [
                15,
                "...........oooooooooo..........."
            ],
            [
                16,
                "...........offffffffo..........."
            ],
            [
                17,
                "...........offffffffo..........."
            ],
            [
                18,
                "...........offffffffo..........."
            ],
            [
                19,
                "...........offffffffo..........."
            ],
            [
                20,
                "...........offffffffo..........."
            ],
            [
                21,
                "...........offffffffo..........."
            ],
            [
                22,
                "...........offffffffo..........."
            ],
            [
                23,
                "...........offffffffo..........."
            ],
            [
                24,
                "...........oooooooooo..........."
            ],
            [
                26,
                "..........pppppppppppp.........."
            ]
        ])
    },
    {
        frameIndex: 1,
        name: "Frame 2: 180° Crescent Smear",
        subhead: "Single-frame kinetic speed arc (~40 ms)",
        principle: "Action Smear Discipline",
        explanation: "In a single explosive 40ms frame, the blade sweeps 180 degrees. The crescent blur bridges the screen space.",
        artisanRule: "Single-Frame Discipline: Never hold a smear frame for longer than 1 frame (40ms).",
        canvasSize: 32,
        recommendedHoldMs: 40,
        kineticPhase: "Action Smear",
        effectivePixelArea: 96,
        opticalTrick: "180° Crescent Smear: 2px sweeping arc bridges screen space in 40ms.",
        gridRows: rows32([
            [
                4,
                ".............ooooooo............"
            ],
            [
                5,
                "...........ooowwwwwooo.........."
            ],
            [
                6,
                ".........ooowwwwwwwwwooo........"
            ],
            [
                7,
                "........oowwwooooooowwwoo......."
            ],
            [
                8,
                ".......oowwooo.....ooowwoo......"
            ],
            [
                9,
                "......oowooo.........ooowoo....."
            ],
            [
                10,
                "......owwo.............owwo....."
            ],
            [
                11,
                ".....oowoo.............oowoo...."
            ],
            [
                12,
                ".....owwo...............owwo...."
            ],
            [
                13,
                "....oowoo...............oowoo..."
            ],
            [
                14,
                "....owwo.................owwo..."
            ],
            [
                15,
                "....owwo.................owwo..."
            ],
            [
                16,
                "....oooo...oooooooooo....oooo..."
            ],
            [
                17,
                "...........offffffffo..........."
            ],
            [
                18,
                "...........offffffffo..........."
            ],
            [
                19,
                "...........offffffffo..........."
            ],
            [
                20,
                "...........offffffffo..........."
            ],
            [
                21,
                "...........offffffffo..........."
            ],
            [
                22,
                "...........offffffffo..........."
            ],
            [
                23,
                "...........offffffffo..........."
            ],
            [
                24,
                "...........oooooooooo..........."
            ],
            [
                26,
                "..........pppppppppppp.........."
            ]
        ])
    },
    {
        frameIndex: 2,
        name: "Frame 3: Impact Hitstop & Spark",
        subhead: "Kinetic strike freeze with impact sparks (~180 ms)",
        principle: "Hitstop Impact Pause",
        explanation: "On impact, the motion freezes completely for 180ms. The contrast communicates bone-crunching strike weight.",
        artisanRule: "Impact Freeze: Hitstop holds sell physical impact better than continuous tweening.",
        canvasSize: 32,
        recommendedHoldMs: 180,
        kineticPhase: "Impact Hitstop",
        effectivePixelArea: 84,
        opticalTrick: "Visceral Hitstop: 180ms freeze registers strike contact and delivers punchy feedback.",
        gridRows: rows32([
            [
                6,
                "...............ooo.............."
            ],
            [
                7,
                "...............owo.............."
            ],
            [
                8,
                "...............owo.............."
            ],
            [
                9,
                "..........o....owo....o........."
            ],
            [
                10,
                "...........o...owo...o.........."
            ],
            [
                11,
                "...............owo.............."
            ],
            [
                12,
                "...............owo.............."
            ],
            [
                13,
                "....oooooooooooowooooooooooo...."
            ],
            [
                14,
                "....owwwwwwwwwwwwwwwwwwwwwwo...."
            ],
            [
                15,
                "....oooooooowwwwwwwwoooooooo...."
            ],
            [
                16,
                "...........offffffffo..........."
            ],
            [
                17,
                "...........offffffffo..........."
            ],
            [
                18,
                "...........offffffffoo.........."
            ],
            [
                19,
                "..........ooffffffffo.o........."
            ],
            [
                20,
                "...........offffffffo..........."
            ],
            [
                21,
                "...........offffffffo..........."
            ],
            [
                22,
                "...........offffffffo..........."
            ],
            [
                23,
                "...........offffffffo..........."
            ],
            [
                24,
                "...........oooooooooo..........."
            ],
            [
                26,
                "..........pppppppppppp.........."
            ]
        ])
    },
    {
        frameIndex: 3,
        name: "Frame 4: Recovery Overshoot & Guard",
        subhead: "Settling back into ready combat guard (~120 ms)",
        principle: "Recovery & Settle",
        explanation: "After impact, the blade momentum settles downward into a solid guard stance, resetting combat balance.",
        artisanRule: "Recovery Momentum: Dissipate kinetic energy smoothly into defensive guard posture.",
        canvasSize: 32,
        recommendedHoldMs: 120,
        kineticPhase: "Recovery Settle",
        effectivePixelArea: 76,
        opticalTrick: "Follow-Through Dampening: Deceleration back into resting combat guard.",
        gridRows: rows32([
            [
                14,
                "...........oooooooooo..........."
            ],
            [
                15,
                "...........offffffffo..........."
            ],
            [
                16,
                "...........offffffffo..........."
            ],
            [
                17,
                "....oo.....offffffffo..........."
            ],
            [
                18,
                ".....oo....offffffffo..........."
            ],
            [
                19,
                "......oo...offffffffo..........."
            ],
            [
                20,
                ".......oo..offffffffo..........."
            ],
            [
                21,
                "........oo.offffffffo..........."
            ],
            [
                22,
                ".........oooffffffffo..........."
            ],
            [
                23,
                "..........ooffffffffo..........."
            ],
            [
                24,
                "...........oooooooooo..........."
            ],
            [
                26,
                "..........pppppppppppp.........."
            ]
        ])
    }
];
const CHARACTER_HOP_SHOCK_FRAMES = [
    {
        frameIndex: 0,
        name: "Frame 1: Crouch Anticipation",
        subhead: "Downward compression stores spring potential (~140 ms)",
        principle: "Crouch Anticipation",
        explanation: "Keyframe 1 of 5. Frame 1: Crouch Anticipation. Symmetrical closed outline with zero leaks.",
        artisanRule: "Secondary Overlap & Ground Hitstop: Trailing ears and impact hold sell weight.",
        canvasSize: 32,
        recommendedHoldMs: 140,
        kineticPhase: "Crouch Anticipation",
        effectivePixelArea: 130,
        opticalTrick: "Secondary Overlap: Kinetic energy transfers through body into trailing ears.",
        gridRows: rows32([
            [
                10,
                "..........ooo......ooo.........."
            ],
            [
                11,
                "..........ofo......ofo.........."
            ],
            [
                12,
                "..........ofo......ofo.........."
            ],
            [
                13,
                "..........ofo......ofo.........."
            ],
            [
                14,
                "........ooofoooooooofooo........"
            ],
            [
                15,
                "........ofrrffffffffrrfo........"
            ],
            [
                16,
                "........offffffffffffffo........"
            ],
            [
                17,
                "........offffffffffffffo........"
            ],
            [
                18,
                "........offffffffffffffo........"
            ],
            [
                19,
                "......oooffffffffffffffooo......"
            ],
            [
                20,
                "......offffffffffffffffffo......"
            ],
            [
                21,
                "......osssssssssssssssssso......"
            ],
            [
                22,
                "......osssssssssssssssssso......"
            ],
            [
                23,
                "......osssssssssssssssssso......"
            ],
            [
                24,
                "......oooooooooooooooooooo......"
            ],
            [
                26,
                "......pppppppppppppppppppp......"
            ]
        ])
    },
    {
        frameIndex: 1,
        name: "Frame 2: Explosive Launch Stretch",
        subhead: "Kinetic elongation leaves the floor (~50 ms)",
        principle: "Launch Stretch",
        explanation: "Keyframe 2 of 5. Frame 2: Explosive Launch Stretch. Symmetrical closed outline with zero leaks.",
        artisanRule: "Secondary Overlap & Ground Hitstop: Trailing ears and impact hold sell weight.",
        canvasSize: 32,
        recommendedHoldMs: 50,
        kineticPhase: "Launch Stretch",
        effectivePixelArea: 130,
        opticalTrick: "Secondary Overlap: Kinetic energy transfers through body into trailing ears.",
        gridRows: rows32([
            [
                1,
                "............oo....oo............"
            ],
            [
                2,
                "............oo....oo............"
            ],
            [
                3,
                "............oo....oo............"
            ],
            [
                4,
                "............oo....oo............"
            ],
            [
                5,
                "............oo....oo............"
            ],
            [
                6,
                "...........oooooooooo..........."
            ],
            [
                7,
                "...........orffffffro..........."
            ],
            [
                8,
                "...........offffffffo..........."
            ],
            [
                9,
                "...........okffffffko..........."
            ],
            [
                10,
                "...........okffffffko..........."
            ],
            [
                11,
                "...........okffffffko..........."
            ],
            [
                12,
                "...........offffffffo..........."
            ],
            [
                13,
                "...........offffffffo..........."
            ],
            [
                14,
                "...........offffffffo..........."
            ],
            [
                15,
                "...........offffffffo..........."
            ],
            [
                16,
                "...........offffffffo..........."
            ],
            [
                17,
                "...........offffffffo..........."
            ],
            [
                18,
                "...........osssssssso..........."
            ],
            [
                19,
                "...........oooooooooo..........."
            ],
            [
                26,
                "............pppppppp............"
            ]
        ])
    },
    {
        frameIndex: 2,
        name: "Frame 3: Apex Hang & Ear Drag",
        subhead: "Secondary overlapping action at zero-G (~160 ms)",
        principle: "Apex Hang",
        explanation: "Keyframe 3 of 5. Frame 3: Apex Hang & Ear Drag. Symmetrical closed outline with zero leaks.",
        artisanRule: "Secondary Overlap & Ground Hitstop: Trailing ears and impact hold sell weight.",
        canvasSize: 32,
        recommendedHoldMs: 160,
        kineticPhase: "Apex Hang",
        effectivePixelArea: 130,
        opticalTrick: "Secondary Overlap: Kinetic energy transfers through body into trailing ears.",
        gridRows: rows32([
            [
                1,
                "...........ooo....ooo..........."
            ],
            [
                2,
                "...........oro....oro..........."
            ],
            [
                3,
                "...........oro....oro..........."
            ],
            [
                4,
                "...........oro....oro..........."
            ],
            [
                5,
                "..........oofoooooofoo.........."
            ],
            [
                6,
                ".........oofkffffffkfoo........."
            ],
            [
                7,
                ".........offkffffffkffo........."
            ],
            [
                8,
                ".........offkffffffkffo........."
            ],
            [
                9,
                ".........oorffffffffroo........."
            ],
            [
                10,
                "..........offffffffffo.........."
            ],
            [
                11,
                ".........ooffffffffffoo........."
            ],
            [
                12,
                ".........offffffffffffo........."
            ],
            [
                13,
                ".........offffffffffffo........."
            ],
            [
                14,
                ".........offffffffffffo........."
            ],
            [
                15,
                ".........osssssssssssso........."
            ],
            [
                16,
                ".........osssssssssssso........."
            ],
            [
                17,
                ".........oossssssssssoo........."
            ],
            [
                18,
                "..........oooooooooooo.........."
            ],
            [
                26,
                ".........pppppppppppppp........."
            ]
        ])
    },
    {
        frameIndex: 3,
        name: "Frame 4: Impact Squash & Hitstop",
        subhead: "Ground impact shock absorption hold (~180 ms)",
        principle: "Impact Squash (Hitstop)",
        explanation: "Keyframe 4 of 5. Frame 4: Impact Squash & Hitstop. Symmetrical closed outline with zero leaks.",
        artisanRule: "Secondary Overlap & Ground Hitstop: Trailing ears and impact hold sell weight.",
        canvasSize: 32,
        recommendedHoldMs: 180,
        kineticPhase: "Impact Squash (Hitstop)",
        effectivePixelArea: 130,
        opticalTrick: "Secondary Overlap: Kinetic energy transfers through body into trailing ears.",
        gridRows: rows32([
            [
                10,
                "..........ooo......ooo.........."
            ],
            [
                11,
                "..........ofo......ofo.........."
            ],
            [
                12,
                "..........ofo......ofo.........."
            ],
            [
                13,
                "..........ofo......ofo.........."
            ],
            [
                14,
                "........ooofoooooooofooo........"
            ],
            [
                15,
                "........ofrrffffffffrrfo........"
            ],
            [
                16,
                "........offffffffffffffo........"
            ],
            [
                17,
                "........offffffffffffffo........"
            ],
            [
                18,
                "........offffffffffffffo........"
            ],
            [
                19,
                "......oooffffffffffffffooo......"
            ],
            [
                20,
                "......offffffffffffffffffo......"
            ],
            [
                21,
                "......osssssssssssssssssso......"
            ],
            [
                22,
                "......osssssssssssssssssso......"
            ],
            [
                23,
                "......osssssssssssssssssso......"
            ],
            [
                24,
                "......oooooooooooooooooooo......"
            ],
            [
                26,
                "......pppppppppppppppppppp......"
            ]
        ])
    },
    {
        frameIndex: 4,
        name: "Frame 5: Sub-Pixel Elastic Settle",
        subhead: "Restoring neutral upright stance (~100 ms)",
        principle: "Sub-Pixel Settle",
        explanation: "Keyframe 5 of 5. Frame 5: Sub-Pixel Elastic Settle. Symmetrical closed outline with zero leaks.",
        artisanRule: "Secondary Overlap & Ground Hitstop: Trailing ears and impact hold sell weight.",
        canvasSize: 32,
        recommendedHoldMs: 100,
        kineticPhase: "Sub-Pixel Settle",
        effectivePixelArea: 130,
        opticalTrick: "Secondary Overlap: Kinetic energy transfers through body into trailing ears.",
        gridRows: rows32([
            [
                7,
                "...........ooo....ooo..........."
            ],
            [
                8,
                "...........oro....oro..........."
            ],
            [
                9,
                "...........oro....oro..........."
            ],
            [
                10,
                "...........oro....oro..........."
            ],
            [
                11,
                "..........oofoooooofoo.........."
            ],
            [
                12,
                ".........oofkffffffkfoo........."
            ],
            [
                13,
                ".........offkffffffkffo........."
            ],
            [
                14,
                ".........offkffffffkffo........."
            ],
            [
                15,
                ".........oorffffffffroo........."
            ],
            [
                16,
                "..........offffffffffo.........."
            ],
            [
                17,
                ".........ooffffffffffoo........."
            ],
            [
                18,
                ".........offffffffffffo........."
            ],
            [
                19,
                ".........offffffffffffo........."
            ],
            [
                20,
                ".........offffffffffffo........."
            ],
            [
                21,
                ".........osssssssssssso........."
            ],
            [
                22,
                ".........osssssssssssso........."
            ],
            [
                23,
                ".........oossssssssssoo........."
            ],
            [
                24,
                "..........oooooooooooo.........."
            ],
            [
                26,
                ".........pppppppppppppp........."
            ]
        ])
    }
];
// 1. The Bouncing Mochi (Squash, Stretch & Mass Invariance)
const BOUNCING_MOCHI_FRAMES = [
    {
        frameIndex: 0,
        name: 'Frame 1: Apex Float',
        subhead: 'Weightless anticipation at highest point',
        principle: 'Anticipation & Hang Time',
        explanation: 'Every jump begins at the apex. Gravity pauses at the highest point, holding the silhouette in neutral, uncompressed form. Draw an 8x8 circular resting mass at the upper center of the canvas.',
        artisanRule: 'Mass Invariance: The resting circular silhouette occupies ~28 outline pixels. All subsequent deformed frames must preserve this approximate volume.',
        recommendedHoldMs: 160,
        grid16: rows([
            [
                2,
                '......oooo......'
            ],
            [
                3,
                '....oo....oo....'
            ],
            [
                4,
                '...o........o...'
            ],
            [
                5,
                '..o..........o..'
            ],
            [
                6,
                '..o..........o..'
            ],
            [
                7,
                '..o..........o..'
            ],
            [
                8,
                '..o..........o..'
            ],
            [
                9,
                '..o..........o..'
            ],
            [
                10,
                '...o........o...'
            ],
            [
                11,
                '....oooooooo....'
            ]
        ])
    },
    {
        frameIndex: 1,
        name: 'Frame 2: Kinetic Plummet',
        subhead: 'Downward velocity stretch along trajectory',
        principle: 'Kinetic Stretch',
        explanation: 'As gravity accelerates the object downward, kinetic speed stretches the silhouette along its motion vector. Narrow the width by 2 pixels and extend the height by 3 pixels.',
        artisanRule: 'Stretch Discipline: Keep side walls parallel to avoid jagged pixel stairs. The elongated shape communicates 60 FPS velocity even at 10 FPS.',
        recommendedHoldMs: 60,
        grid16: rows([
            [
                4,
                '.......oo.......'
            ],
            [
                5,
                '.....oo..oo.....'
            ],
            [
                6,
                '....o......o....'
            ],
            [
                7,
                '....o......o....'
            ],
            [
                8,
                '....o......o....'
            ],
            [
                9,
                '....o......o....'
            ],
            [
                10,
                '....o......o....'
            ],
            [
                11,
                '....o......o....'
            ],
            [
                12,
                '....o......o....'
            ],
            [
                13,
                '.....o....o.....'
            ],
            [
                14,
                '......oooo......'
            ]
        ])
    },
    {
        frameIndex: 2,
        name: 'Frame 3: Impact Squash',
        subhead: 'Floor contact and horizontal dispersion',
        principle: 'Impact Squash & Energy Dissipation',
        explanation: 'Upon striking the floor line, downward kinetic energy pushes outward horizontally. Flatten the height to 4 pixels and spread the base to 12 pixels across the floor baseline.',
        artisanRule: 'Ground Contact: Align the bottom boundary flush with the ground line (Y=14). Flatten the bottom row to establish a firm physical plane.',
        recommendedHoldMs: 90,
        grid16: rows([
            [
                11,
                '....oooooooo....'
            ],
            [
                12,
                '..oo........oo..'
            ],
            [
                13,
                '.o............o.'
            ],
            [
                14,
                'o..............o'
            ],
            [
                15,
                'oooooooooooooooo'
            ]
        ])
    },
    {
        frameIndex: 3,
        name: 'Frame 4: Upward Rebound',
        subhead: 'Elastic release returning to apex',
        principle: 'Elastic Recovery',
        explanation: 'Like a compressed spring releasing its stored energy, the mochi snaps upward. Draw an oval shape slightly taller than resting width as it ascends toward Frame 1.',
        artisanRule: 'Trajectory Loop: Positioning this frame at Y=7 between the impact baseline and the apex to complete a seamless parabolic easing arc.',
        recommendedHoldMs: 70,
        grid16: rows([
            [
                5,
                '......oooo......'
            ],
            [
                6,
                '....oo....oo....'
            ],
            [
                7,
                '...o........o...'
            ],
            [
                8,
                '..o..........o..'
            ],
            [
                9,
                '..o..........o..'
            ],
            [
                10,
                '..o..........o..'
            ],
            [
                11,
                '..o..........o..'
            ],
            [
                12,
                '...o........o...'
            ],
            [
                13,
                '....oooooooo....'
            ]
        ])
    }
];
// 2. The Hearth Flame (Secondary Action & Fluid Loops)
const HEARTH_FLAME_FRAMES = [
    {
        frameIndex: 0,
        name: 'Frame 1: Ember Seed',
        subhead: 'Resting teardrop flame core',
        principle: 'Organic Looping & Fluid Arcs',
        explanation: 'Fire is an upward convection current. Begin with a centered teardrop core with warm outer ink leaning straight up.',
        artisanRule: 'Teardrop Curve: Keep the base anchored wide on the wood hearth while tapering to a 2-pixel point at the apex.',
        recommendedHoldMs: 120,
        grid16: rows([
            [
                5,
                '.......oo.......'
            ],
            [
                6,
                '......o..o......'
            ],
            [
                7,
                '.....o....o.....'
            ],
            [
                8,
                '....o......o....'
            ],
            [
                9,
                '...o........o...'
            ],
            [
                10,
                '...o........o...'
            ],
            [
                11,
                '...o........o...'
            ],
            [
                12,
                '....o......o....'
            ],
            [
                13,
                '.....oooooo.....'
            ]
        ])
    },
    {
        frameIndex: 1,
        name: 'Frame 2: Leaning Crest',
        subhead: 'Flame tip curves with air draft',
        principle: 'Fluid Distortion',
        explanation: 'As hot air rises, the upper tip billows slightly to the right while the base stays anchored on the wood hearth.',
        artisanRule: 'Base Anchor: Keep the bottom 2 rows consistent while letting the upper tip deform with the draft.',
        recommendedHoldMs: 120,
        grid16: rows([
            [
                4,
                '........oo......'
            ],
            [
                5,
                '.......o..o.....'
            ],
            [
                6,
                '......o....o....'
            ],
            [
                7,
                '.....o......o...'
            ],
            [
                8,
                '....o........o..'
            ],
            [
                9,
                '...o..........o.'
            ],
            [
                10,
                '...o.........o..'
            ],
            [
                11,
                '....o.......o...'
            ],
            [
                12,
                '.....ooooooo....'
            ]
        ])
    },
    {
        frameIndex: 2,
        name: 'Frame 3: Spark Detach',
        subhead: 'Upper ember pinches off into a rising spark',
        principle: 'Follow-Through & Particulate Motion',
        explanation: 'The stretched tip pinches off into an independent 2x2 spark cluster above the flame body, while the main base resets.',
        artisanRule: 'Floating Spark: A detached 2x2 pixel cluster floats 2 pixels above the main body before vanishing.',
        recommendedHoldMs: 120,
        grid16: rows([
            [
                2,
                '........oo......'
            ],
            [
                3,
                '........oo......'
            ],
            [
                6,
                '......oo........'
            ],
            [
                7,
                '.....o..oo......'
            ],
            [
                8,
                '....o.....oo....'
            ],
            [
                9,
                '...o........o...'
            ],
            [
                10,
                '...o........o...'
            ],
            [
                11,
                '...o........o...'
            ],
            [
                12,
                '....o......o....'
            ],
            [
                13,
                '.....oooooo.....'
            ]
        ])
    }
];
// 3. The Character Hop (Anticipation & Secondary Follow-Through)
const BUN_HOP_FRAMES = [
    {
        frameIndex: 0,
        name: 'Frame 1: Crouch Anticipation',
        subhead: 'Character compresses downward before leap',
        principle: 'Character Anticipation',
        explanation: 'Before jumping, a character crouches to build upward momentum. Lower the head by 2 pixels and flatten the feet along the floor.',
        artisanRule: 'Ear Drag: Keep ears upright or slightly swept back to show anticipation of the upcoming leap.',
        recommendedHoldMs: 140,
        grid16: rows([
            [
                5,
                '...oo.....oo....'
            ],
            [
                6,
                '..o..o...o..o...'
            ],
            [
                7,
                '..o..o...o..o...'
            ],
            [
                8,
                '..o..ooooo..o...'
            ],
            [
                9,
                '.o..........o...'
            ],
            [
                10,
                '.o..........o...'
            ],
            [
                11,
                '.o..........o...'
            ],
            [
                12,
                '.o..........o...'
            ],
            [
                13,
                '..oooooooooo....'
            ]
        ])
    },
    {
        frameIndex: 1,
        name: 'Frame 2: Airborne Apex',
        subhead: 'Character reaches peak height in air',
        principle: 'Follow-Through on Secondary Elements',
        explanation: 'At the height of the hop, the character body floats at Y=2. Secondary elements like ears trail behind the upward trajectory.',
        artisanRule: 'Secondary Motion: Trailing ears lag 1 frame behind the body velocity.',
        recommendedHoldMs: 160,
        grid16: rows([
            [
                0,
                '...oo.....oo....'
            ],
            [
                1,
                '..o..o...o..o...'
            ],
            [
                2,
                '..o..o...o..o...'
            ],
            [
                3,
                '..o..ooooo..o...'
            ],
            [
                4,
                '.o..........o...'
            ],
            [
                5,
                '.o..........o...'
            ],
            [
                6,
                '.o..........o...'
            ],
            [
                7,
                '.o..........o...'
            ],
            [
                8,
                '..oooooooooo....'
            ]
        ])
    },
    {
        frameIndex: 2,
        name: 'Frame 3: Impact Recovery',
        subhead: 'Feet touch down with soft absorption',
        principle: 'Contact & Settle',
        explanation: 'Upon touching the ground, the body squashes slightly to absorb the landing shock before returning to idle stance.',
        artisanRule: 'Settle Timing: A 1-frame impact hold gives weight to character physics.',
        recommendedHoldMs: 100,
        grid16: rows([
            [
                6,
                '...oo.....oo....'
            ],
            [
                7,
                '..o..o...o..o...'
            ],
            [
                8,
                '..o..ooooo..o...'
            ],
            [
                9,
                '.o..........o...'
            ],
            [
                10,
                '.o..........o...'
            ],
            [
                11,
                '.o..........o...'
            ],
            [
                12,
                '.o..........o...'
            ],
            [
                13,
                '..oooooooooo....'
            ]
        ])
    }
];
// 4. The Magic Potion Bubbles (Buoyancy & Particle Burst)
const POTION_BUBBLE_FRAMES = [
    {
        frameIndex: 0,
        name: 'Frame 1: Nucleating Bubble',
        subhead: 'Small gas seed forming at bottom',
        principle: 'Particle Nucleation',
        explanation: 'Inside the flask, heat generates a small 2x2 bubble sphere near the bottom liquid bed.',
        artisanRule: 'Flask Boundary: Anchor the flask beaker outline while animating the floating bubble core inside.',
        recommendedHoldMs: 120,
        grid16: rows([
            [
                1,
                '.....oooooo.....'
            ],
            [
                2,
                '.....o....o.....'
            ],
            [
                3,
                '....o......o....'
            ],
            [
                4,
                '...o........o...'
            ],
            [
                5,
                '..o..........o..'
            ],
            [
                6,
                '..o..........o..'
            ],
            [
                7,
                '..o..........o..'
            ],
            [
                8,
                '..o..........o..'
            ],
            [
                9,
                '..o..........o..'
            ],
            [
                10,
                '..o....oo....o..'
            ],
            [
                11,
                '..o....oo....o..'
            ],
            [
                12,
                '..o..........o..'
            ],
            [
                13,
                '...oooooooooo...'
            ]
        ])
    },
    {
        frameIndex: 1,
        name: 'Frame 2: Buoyant Ascend',
        subhead: 'Bubble rises and expands through liquid',
        principle: 'Buoyancy & Acceleration',
        explanation: 'As the bubble ascends toward the liquid surface, it accelerates upward and expands to 4x4 pixels.',
        artisanRule: 'Upward Spacing: Move the bubble up by 4 pixels between frames to show accelerating buoyancy.',
        recommendedHoldMs: 100,
        grid16: rows([
            [
                1,
                '.....oooooo.....'
            ],
            [
                2,
                '.....o....o.....'
            ],
            [
                3,
                '....o......o....'
            ],
            [
                4,
                '...o........o...'
            ],
            [
                5,
                '..o...oooo...o..'
            ],
            [
                6,
                '..o..o....o..o..'
            ],
            [
                7,
                '..o..o....o..o..'
            ],
            [
                8,
                '..o...oooo...o..'
            ],
            [
                9,
                '..o..........o..'
            ],
            [
                10,
                '..o..........o..'
            ],
            [
                11,
                '..o..........o..'
            ],
            [
                12,
                '..o..........o..'
            ],
            [
                13,
                '...oooooooooo...'
            ]
        ])
    },
    {
        frameIndex: 2,
        name: 'Frame 3: Surface Meniscus',
        subhead: 'Bubble touches surface dome',
        principle: 'Surface Tension',
        explanation: 'The bubble breaches the liquid waterline, forming a bulging dome ready to burst.',
        artisanRule: 'Tension Dome: Flatten the bottom edge against the liquid line while arching the top dome.',
        recommendedHoldMs: 100,
        grid16: rows([
            [
                1,
                '.....oooooo.....'
            ],
            [
                2,
                '.....o....o.....'
            ],
            [
                3,
                '....o.oooo.o....'
            ],
            [
                4,
                '...o.o....o.o...'
            ],
            [
                5,
                '..o..oooooo..o..'
            ],
            [
                6,
                '..o..........o..'
            ],
            [
                7,
                '..o..........o..'
            ],
            [
                8,
                '..o..........o..'
            ],
            [
                9,
                '..o..........o..'
            ],
            [
                10,
                '..o..........o..'
            ],
            [
                11,
                '..o..........o..'
            ],
            [
                12,
                '..o..........o..'
            ],
            [
                13,
                '...oooooooooo...'
            ]
        ])
    },
    {
        frameIndex: 3,
        name: 'Frame 4: Radial Droplet Burst',
        subhead: 'Bubble pops into dispersing droplets',
        principle: 'Radial Particle Dispersion',
        explanation: 'Surface tension snaps! The bubble ruptures into four 1-pixel droplets dispersing radially outward.',
        artisanRule: 'Radial Dispersion: Place 4 discrete single pixels radiating 2 pixels out from the burst center.',
        recommendedHoldMs: 80,
        grid16: rows([
            [
                1,
                '.....oooooo.....'
            ],
            [
                2,
                '.....o.o..o.....'
            ],
            [
                3,
                '....o.o..o.o....'
            ],
            [
                4,
                '...o...o....o...'
            ],
            [
                5,
                '..o..........o..'
            ],
            [
                6,
                '..o..........o..'
            ],
            [
                7,
                '..o..........o..'
            ],
            [
                8,
                '..o..........o..'
            ],
            [
                9,
                '..o..........o..'
            ],
            [
                10,
                '..o..........o..'
            ],
            [
                11,
                '..o..........o..'
            ],
            [
                12,
                '..o..........o..'
            ],
            [
                13,
                '...oooooooooo...'
            ]
        ])
    }
];
// 5. The Slime Glide (Creature Wave Locomotion)
const SLIME_GLIDE_FRAMES = [
    {
        frameIndex: 0,
        name: 'Frame 1: Idle Gel Stance',
        subhead: 'Resting gelatinous dome',
        principle: 'Organic Mass Balance',
        explanation: 'A resting slime forms a gentle 10x6 pixel hemisphere with rounded corners along the floor line.',
        artisanRule: 'Volume Baseline: Maintain roughly 40 pixels of body volume across all locomotion steps.',
        recommendedHoldMs: 140,
        grid16: rows([
            [
                7,
                '......oooo......'
            ],
            [
                8,
                '....oo....oo....'
            ],
            [
                9,
                '...o........o...'
            ],
            [
                10,
                '..o..........o..'
            ],
            [
                11,
                '..o..........o..'
            ],
            [
                12,
                '..o..........o..'
            ],
            [
                13,
                '..oooooooooooo..'
            ]
        ])
    },
    {
        frameIndex: 1,
        name: 'Frame 2: Forward Surge Reach',
        subhead: 'Front edge stretches forward',
        principle: 'Anticipatory Surge',
        explanation: 'To crawl, the slime extends its front pseudopod forward by 3 pixels while pinning its tail on the ground.',
        artisanRule: 'Directional Asymmetry: Shift the front wall to X=14 while keeping the tail anchored at X=2.',
        recommendedHoldMs: 110,
        grid16: rows([
            [
                8,
                '......oooooo....'
            ],
            [
                9,
                '....oo......oo..'
            ],
            [
                10,
                '...o..........o.'
            ],
            [
                11,
                '..o............o'
            ],
            [
                12,
                '..o............o'
            ],
            [
                13,
                '..oooooooooooooo'
            ]
        ])
    },
    {
        frameIndex: 2,
        name: 'Frame 3: Rear Body Catchup',
        subhead: 'Trailing mass compresses forward',
        principle: 'Follow-Through & Kinetic Drag',
        explanation: 'The tail snaps forward to rejoin the front mass, compressing the body into a tall, compact blob.',
        artisanRule: 'Vertical Bulge: Squeeze the width to 8 pixels and bulge the height up by 2 pixels.',
        recommendedHoldMs: 110,
        grid16: rows([
            [
                6,
                '........oooo....'
            ],
            [
                7,
                '......oo....oo..'
            ],
            [
                8,
                '.....o........o.'
            ],
            [
                9,
                '....o..........o'
            ],
            [
                10,
                '....o..........o'
            ],
            [
                11,
                '....o..........o'
            ],
            [
                12,
                '....o..........o'
            ],
            [
                13,
                '.....oooooooooo.'
            ]
        ])
    },
    {
        frameIndex: 3,
        name: 'Frame 4: Settle Elastic Reset',
        subhead: 'Gel settles back into resting base',
        principle: 'Settle & Damping',
        explanation: 'The momentum dissipates and the gelatinous body relaxes back to its resting stance 2 pixels ahead.',
        artisanRule: 'Loop Alignment: Smoothly connect the final resting frame back to the cycle start.',
        recommendedHoldMs: 130,
        grid16: rows([
            [
                7,
                '.......oooo.....'
            ],
            [
                8,
                '.....oo....oo...'
            ],
            [
                9,
                '....o........o..'
            ],
            [
                10,
                '...o..........o.'
            ],
            [
                11,
                '...o..........o.'
            ],
            [
                12,
                '...o..........o.'
            ],
            [
                13,
                '...oooooooooooo.'
            ]
        ])
    }
];
// 6. The Twinkling Star / Gem (Lighting FX & Optical Pulse)
const TWINKLING_STAR_FRAMES = [
    {
        frameIndex: 0,
        name: 'Frame 1: Micro Spark Core',
        subhead: 'Small dormant glimmer',
        principle: 'Optical Contrast',
        explanation: 'Every twinkle begins as a concentrated, pinpoint 2x2 spark in dark space.',
        artisanRule: 'Center Alignment: Keep the origin centered at (8,8) across all glare pulses.',
        recommendedHoldMs: 110,
        grid16: rows([
            [
                7,
                '.......oo.......'
            ],
            [
                8,
                '.......oo.......'
            ]
        ])
    },
    {
        frameIndex: 1,
        name: 'Frame 2: Cardinal Cross Beams',
        subhead: 'Light shoots along cardinal axes',
        principle: 'Anamorphic Flare',
        explanation: 'Optical diffraction emits sharp 1-pixel rays extending north, south, east, and west.',
        artisanRule: 'Ray Symmetry: Extend 4 cardinal spikes 4 pixels outward from the central core.',
        recommendedHoldMs: 90,
        grid16: rows([
            [
                4,
                '.......oo.......'
            ],
            [
                5,
                '.......oo.......'
            ],
            [
                6,
                '......oooo......'
            ],
            [
                7,
                '..oooooooooooo..'
            ],
            [
                8,
                '..oooooooooooo..'
            ],
            [
                9,
                '......oooo......'
            ],
            [
                10,
                '.......oo.......'
            ],
            [
                11,
                '.......oo.......'
            ]
        ])
    },
    {
        frameIndex: 2,
        name: 'Frame 3: Diamond Flare Bloom',
        subhead: 'Full diagonal lens glare burst',
        principle: 'Peak Bloom',
        explanation: 'At maximum intensity, diagonal glints ignite, turning the star into a brilliant 8-point diamond starburst.',
        artisanRule: 'Diagonal Spikes: Add 1-pixel corners at 45-degree angles to create full bloom.',
        recommendedHoldMs: 90,
        grid16: rows([
            [
                3,
                '.......oo.......'
            ],
            [
                4,
                '..o....oo....o..'
            ],
            [
                5,
                '...o...oo...o...'
            ],
            [
                6,
                '....oooooooo....'
            ],
            [
                7,
                '.oooooooooooooo.'
            ],
            [
                8,
                '.oooooooooooooo.'
            ],
            [
                9,
                '....oooooooo....'
            ],
            [
                10,
                '...o...oo...o...'
            ],
            [
                11,
                '..o....oo....o..'
            ],
            [
                12,
                '.......oo.......'
            ]
        ])
    },
    {
        frameIndex: 3,
        name: 'Frame 4: Soft Pulse Settle',
        subhead: 'Flare retracts into warm halo ring',
        principle: 'Dissipation & Decay',
        explanation: 'The intense glare collapses, leaving a gentle 4x4 diamond ring that dissolves back to the micro spark.',
        artisanRule: 'Hollow Ring: A hollow 1-pixel border simulates decaying optical afterglow.',
        recommendedHoldMs: 120,
        grid16: rows([
            [
                5,
                '.......oo.......'
            ],
            [
                6,
                '.....oo..oo.....'
            ],
            [
                7,
                '....o......o....'
            ],
            [
                8,
                '....o......o....'
            ],
            [
                9,
                '.....oo..oo.....'
            ],
            [
                10,
                '.......oo.......'
            ]
        ])
    }
];
// 7. The Water Droplet Ripple (Fluid Shockwave Dynamics)
const WATER_RIPPLE_FRAMES = [
    {
        frameIndex: 0,
        name: 'Frame 1: Droplet Impact',
        subhead: 'Vertical water needle splash',
        principle: 'Kinetic Impact Spike',
        explanation: 'When a raindrop hits still water, momentum pushes a sharp 2x6 vertical needle splash upward.',
        artisanRule: 'Impact Point: Draw a clean vertical 2-pixel column emerging from the center floor.',
        recommendedHoldMs: 100,
        grid16: rows([
            [
                5,
                '.......oo.......'
            ],
            [
                6,
                '.......oo.......'
            ],
            [
                7,
                '.......oo.......'
            ],
            [
                8,
                '.......oo.......'
            ],
            [
                9,
                '......oooo......'
            ],
            [
                10,
                '.....oooooo.....'
            ]
        ])
    },
    {
        frameIndex: 1,
        name: 'Frame 2: Inner Crown Wave',
        subhead: 'Initial circular splash ring',
        principle: 'Radial Wave Propagation',
        explanation: 'The vertical spike collapses into an expanding 6x3 perspective ring on the water surface.',
        artisanRule: 'Perspective Ratio: Use a 2:1 isometric ratio (width is twice height) for surface ripples.',
        recommendedHoldMs: 110,
        grid16: rows([
            [
                8,
                '......oooo......'
            ],
            [
                9,
                '....oo....oo....'
            ],
            [
                10,
                '...o........o...'
            ],
            [
                11,
                '....oo....oo....'
            ],
            [
                12,
                '......oooo......'
            ]
        ])
    },
    {
        frameIndex: 2,
        name: 'Frame 3: Expanding Ellipse',
        subhead: 'Wide outer ripple wavefront',
        principle: 'Energy Dissipation & Amplitude Decay',
        explanation: 'The wave ring expands outward to 12x4 pixels as its kinetic energy disperses across the pond.',
        artisanRule: 'Thinning Wave: Keep the wave ring strictly 1-pixel thick to show diminishing amplitude.',
        recommendedHoldMs: 120,
        grid16: rows([
            [
                7,
                '....oooooooo....'
            ],
            [
                8,
                '..oo........oo..'
            ],
            [
                9,
                '.o............o.'
            ],
            [
                10,
                '.o............o.'
            ],
            [
                11,
                '..oo........oo..'
            ],
            [
                12,
                '....oooooooo....'
            ]
        ])
    },
    {
        frameIndex: 3,
        name: 'Frame 4: Dissipating Wavefront',
        subhead: 'Faint outer ring fading into calm water',
        principle: 'Wave Attenuation',
        explanation: 'The outer ripple breaks into intermittent corner dashes and vanishes back into calm water.',
        artisanRule: 'Broken Stride: Leaving 2-pixel gaps along the edge creates the illusion of fading water.',
        recommendedHoldMs: 140,
        grid16: rows([
            [
                6,
                '..oo........oo..'
            ],
            [
                7,
                '.o............o.'
            ],
            [
                11,
                '.o............o.'
            ],
            [
                12,
                '..oo........oo..'
            ]
        ])
    }
];
// 8. The Sword Slash Arc (Action Smear & Combat Keyframing)
const SWORD_SLASH_FRAMES = [
    {
        frameIndex: 0,
        name: 'Frame 1: High Windup Hold',
        subhead: 'Blade poised high in anticipation',
        principle: 'Combat Anticipation',
        explanation: 'A warrior raises their sword above their head at a 45-degree angle, building potential energy for the strike.',
        artisanRule: 'Diagonal Tension: A straight diagonal 2-pixel blade line at the upper left creates strong anticipation.',
        recommendedHoldMs: 150,
        grid16: rows([
            [
                1,
                '..oo............'
            ],
            [
                2,
                '...oo...........'
            ],
            [
                3,
                '....oo..........'
            ],
            [
                4,
                '.....oo.........'
            ],
            [
                5,
                '......oo........'
            ],
            [
                6,
                '.......oo.......'
            ],
            [
                7,
                '........oooo....'
            ],
            [
                8,
                '..........oo....'
            ],
            [
                9,
                '...........oo...'
            ]
        ])
    },
    {
        frameIndex: 1,
        name: 'Frame 2: 180° Crescent Smear',
        subhead: 'Kinetic speed-blur arc cuts through space',
        principle: 'Animation Smear & Action Velocity',
        explanation: 'In a single explosive frame, the blade sweeps 180 degrees, leaving a sweeping kinetic smear arc across the entire screen.',
        artisanRule: 'Crescent Smear: A 2-pixel thick curved crescent communicates lightning-fast speed without multi-frame lag.',
        recommendedHoldMs: 70,
        grid16: rows([
            [
                2,
                '....oooooooo....'
            ],
            [
                3,
                '..oo........oo..'
            ],
            [
                4,
                '.o............o.'
            ],
            [
                5,
                'o..............o'
            ],
            [
                6,
                'o..............o'
            ],
            [
                7,
                'o..............o'
            ],
            [
                8,
                'o..............o'
            ],
            [
                9,
                '.o............o.'
            ],
            [
                10,
                '..oo........oo..'
            ],
            [
                11,
                '....oooooooo....'
            ]
        ])
    },
    {
        frameIndex: 2,
        name: 'Frame 3: Blade Follow-Through',
        subhead: 'Blade rests forward with trailing spark',
        principle: 'Follow-Through & Kinetic Settle',
        explanation: 'The blade finishes its stroke pointing low at the bottom right, with a single trailing impact spark settling in air.',
        artisanRule: 'Low Resting Guard: The sword tip rests at (14,14), grounding the weight of the strike.',
        recommendedHoldMs: 130,
        grid16: rows([
            [
                7,
                '....oo..........'
            ],
            [
                8,
                '.....oo.........'
            ],
            [
                9,
                '......oo........'
            ],
            [
                10,
                '.......oo.......'
            ],
            [
                11,
                '........oo......'
            ],
            [
                12,
                '.........oo.....'
            ],
            [
                13,
                '..........oo....'
            ],
            [
                14,
                '...........oo...'
            ]
        ])
    }
];
const PLAYGROUND_LESSONS = [
    {
        id: 'master-bouncing-ball',
        title: 'The Master Bouncing Ball',
        badge: 'Physics 201',
        concept: 'Discrete Volume Preservation & Apex Deceleration',
        description: 'Master classical animation physics on a 32x32 integer grid. Build a complete 12-frame bouncing cycle with mathematical volume preservation (A ≈ 112–114 px), Richard Williams apex cushioning, terminal stretch, and ground hitstop.',
        fps: 12,
        totalFrames: 12,
        canvasSize: 32,
        frames: MASTER_BOUNCING_BALL_FRAMES
    },
    {
        id: 'subpixel-idle',
        title: 'Sub-Pixel Character Idle',
        badge: 'Optical 201',
        concept: 'Sub-Pixel Luminosity & Anti-Boiling',
        description: 'Learn how senior pixel animators produce organic, living character idle cycles without moving the outer silhouette. Shift internal specular glints and modulate anti-aliasing edge tones with zero pixel boiling.',
        fps: 8,
        totalFrames: 3,
        canvasSize: 32,
        frames: SUBPIXEL_IDLE_FRAMES
    },
    {
        id: 'combat-slash-hitstop',
        title: 'Sword Slash & Combat Hitstop',
        badge: 'Combat 201',
        concept: 'Action Smears & Impact Freezes',
        description: 'Master punchy combat animation using arcade fighting game techniques: anticipation windup hold, a single-frame 180° crescent smear arc, visceral hitstop impact pause, and recovery settle.',
        fps: 12,
        totalFrames: 4,
        canvasSize: 32,
        frames: COMBAT_SLASH_FRAMES
    },
    {
        id: 'character-hop-shock',
        title: 'Character Hop & Shock Absorption',
        badge: 'Character 201',
        concept: 'Anticipation, Secondary Action & Hitstop',
        description: 'Animate Bun performing a full athletic leap on a 32x32 canvas. Master downward crouch anticipation, 1-frame explosive stretch, zero-gravity apex hang with trailing ear drag, and visceral impact hitstop absorption on the ground baseline.',
        fps: 10,
        totalFrames: 5,
        canvasSize: 32,
        frames: CHARACTER_HOP_SHOCK_FRAMES
    },
    {
        id: 'bouncing-mochi',
        title: 'The Bouncing Mochi',
        badge: 'Physics 101',
        concept: 'Squash, Stretch & Mass Invariance',
        description: 'Master the core physics of 2D pixel animation: apex float, terminal velocity stretch, ground impact squash, and elastic rebound.',
        fps: 10,
        totalFrames: 4,
        canvasSize: 16,
        frames: BOUNCING_MOCHI_FRAMES
    },
    {
        id: 'hearth-flame',
        title: 'The Hearth Flame',
        badge: 'Fluid FX',
        concept: 'Organic Morphing & Secondary Action',
        description: 'Learn how to animate living, breathing organic elements with upward convection, wave billows, and detaching ember sparks.',
        fps: 8,
        totalFrames: 3,
        canvasSize: 16,
        frames: HEARTH_FLAME_FRAMES
    },
    {
        id: 'bun-hop',
        title: 'The Character Hop',
        badge: 'Character 101',
        concept: 'Anticipation & Secondary Follow-Through',
        description: 'Animate Bun hopping across the desk. Learn how anticipation crouches and trailing ear secondary physics bring characters to life.',
        fps: 9,
        totalFrames: 3,
        canvasSize: 16,
        frames: BUN_HOP_FRAMES
    },
    {
        id: 'potion-bubble',
        title: 'Magic Potion Bubbles',
        badge: 'Alchemy FX',
        concept: 'Buoyancy & Particle Dispersion',
        description: 'Animate bubbling magical potions with accelerating buoyant spheres, surface tension domes, and radial pop droplets.',
        fps: 9,
        totalFrames: 4,
        canvasSize: 16,
        frames: POTION_BUBBLE_FRAMES
    },
    {
        id: 'slime-glide',
        title: 'The Slime Glide',
        badge: 'Creature 101',
        concept: 'Wave Locomotion & Kinetic Friction',
        description: 'Learn how gelatinous creatures crawl forward using pseudopod expansion, rear dragging mass, and elastic settle cycles.',
        fps: 8,
        totalFrames: 4,
        canvasSize: 16,
        frames: SLIME_GLIDE_FRAMES
    },
    {
        id: 'twinkling-star',
        title: 'The Twinkling Star',
        badge: 'Lighting FX',
        concept: 'Optical Flare Bloom & Optical Decay',
        description: 'Master sparkling light effects with diamond starburst blooms, cross anamorphic rays, and smooth pulse loops.',
        fps: 10,
        totalFrames: 4,
        canvasSize: 16,
        frames: TWINKLING_STAR_FRAMES
    },
    {
        id: 'water-ripple',
        title: 'The Water Ripple',
        badge: 'Water FX',
        concept: 'Shockwave Propagation & Perspective Decay',
        description: 'Craft soothing water droplet ripples with vertical impact needles, 2:1 isometric expanding wavefronts, and fading rings.',
        fps: 8,
        totalFrames: 4,
        canvasSize: 16,
        frames: WATER_RIPPLE_FRAMES
    },
    {
        id: 'sword-slash',
        title: 'The Sword Slash',
        badge: 'Combat 101',
        concept: 'Action Smear & Kinetic Anticipation',
        description: 'Design punchy combat keyframes using anticipation windups, full-screen 180° smear arcs, and decisive follow-through poses.',
        fps: 12,
        totalFrames: 3,
        canvasSize: 16,
        frames: SWORD_SLASH_FRAMES
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/art/starterTemplates.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "STARTER_TEMPLATES",
    ()=>STARTER_TEMPLATES,
    "TEMPLATE_PALETTE",
    ()=>TEMPLATE_PALETTE
]);
const TEMPLATE_PALETTE = {
    o: '#3a2e4c',
    l: '#c792df',
    L: '#dcabdf',
    p: '#664b68',
    f: '#ede8f4',
    F: '#ffffff',
    s: '#cdbfdf',
    a: '#d89a55',
    A: '#f0be7c',
    w: '#fbe9c6',
    r: '#e08ca6',
    g: '#7fae6b',
    k: '#1e1730'
};
const EMPTY_ROW_16 = '................';
function blankRows() {
    return [
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16,
        EMPTY_ROW_16
    ];
}
function withRows(partial) {
    const rows = blankRows();
    for (const [index, row] of partial){
        rows[index] = row;
    }
    return rows;
}
// 1. Hearth Ghost: Adorable floating sheet ghost holding a warm hearth ember
const HEARTH_GHOST_ROWS = withRows([
    [
        0,
        '......oooo......'
    ],
    [
        1,
        '....ooFFFFoo....'
    ],
    [
        2,
        '...oFFffffFFo...'
    ],
    [
        3,
        '..oFfffffffffo..'
    ],
    [
        4,
        '..offffffffffo..'
    ],
    [
        5,
        '..offooffooffo..'
    ],
    [
        6,
        '..offffffffffo..'
    ],
    [
        7,
        '..ofrffffffrfo..'
    ],
    [
        8,
        '.oFfffaAAafffFo.'
    ],
    [
        9,
        '.oFffaAwwAAafFo.'
    ],
    [
        10,
        '..offfaAAaffso..'
    ],
    [
        11,
        '..offfffffffso..'
    ],
    [
        12,
        '..osssssssssso..'
    ],
    [
        13,
        '..ofsoffsofsoo..'
    ],
    [
        14,
        '...oo.oo..oo....'
    ]
]);
// 2. Desk Mushroom: Fairytale polka-dot mushroom cap with cute rosy face
const MUSHROOM_ROWS = withRows([
    [
        1,
        '.....oooooo.....'
    ],
    [
        2,
        '...ooLLFLLLLoo..'
    ],
    [
        3,
        '..oLLFFFLLFFLLo.'
    ],
    [
        4,
        '.oLLLFLLLLLFLLpo'
    ],
    [
        5,
        '.olLLLLLLLLLLLpo'
    ],
    [
        6,
        '.olllFFllllFFlpo'
    ],
    [
        7,
        '.opppFFppppFFpo.'
    ],
    [
        8,
        '.oooooooooooooo.'
    ],
    [
        9,
        '....osffffso....'
    ],
    [
        10,
        '....osoffoso....'
    ],
    [
        11,
        '....osroffrso...'
    ],
    [
        12,
        '....osffffso....'
    ],
    [
        13,
        '...oggssssggo...'
    ],
    [
        14,
        '..oggggggggggo..'
    ],
    [
        15,
        '...oooooooooo...'
    ]
]);
// 3. Bun: Adorable studio mascot bunny with pink ear fluff and rosy cheeks
const BUN_ROWS = withRows([
    [
        0,
        '...oo......oo...'
    ],
    [
        1,
        '..oFro....oFro..'
    ],
    [
        2,
        '..oFro....oFro..'
    ],
    [
        3,
        '..oFro....oFro..'
    ],
    [
        4,
        '..oFffoooooFfo..'
    ],
    [
        5,
        '.oFFFFFFFFFFfFo.'
    ],
    [
        6,
        '.oFffffffffffffo'
    ],
    [
        7,
        '.oFfooffffoofffo'
    ],
    [
        8,
        '.oFffffffffffffo'
    ],
    [
        9,
        '.oFfrffroffrfFfo'
    ],
    [
        10,
        '.oFffffffffffffo'
    ],
    [
        11,
        '..ossssssssssso.'
    ],
    [
        12,
        '..offfofffofffo.'
    ],
    [
        13,
        '..oFFFoFFFoFFss.'
    ],
    [
        14,
        '...oooooooooo...'
    ]
]);
// 4. Little Lantern: Cozy brass lantern with glass glints and warm amber glow
const LANTERN_ROWS = withRows([
    [
        1,
        '......oooo......'
    ],
    [
        2,
        '.....oaaaaao....'
    ],
    [
        3,
        '.....oaaaaao....'
    ],
    [
        4,
        '...oooAAAAAooo..'
    ],
    [
        5,
        '..oFFFfffffFFpo.'
    ],
    [
        6,
        '.oFFFAAAAAAAffpo'
    ],
    [
        7,
        '.oFFAAwwAAAFffpo'
    ],
    [
        8,
        '.oFFAwwwwAAAffpo'
    ],
    [
        9,
        '.oFFAAwwAAAFffpo'
    ],
    [
        10,
        '.oFFFAAAAAAAffpo'
    ],
    [
        11,
        '.oFFFfffffFFfpo.'
    ],
    [
        12,
        '..ooAAAAAAAAoo..'
    ],
    [
        13,
        '...oaaaaaaaaao..'
    ],
    [
        14,
        '..oaaaaaaaaaao..'
    ],
    [
        15,
        '...oooooooooo...'
    ]
]);
const STARTER_TEMPLATES = [
    {
        id: 'hearth-ghost',
        name: 'Hearth Ghost',
        blurb: 'A tiny ghost keeping an ember warm.',
        width: 16,
        height: 16,
        rows: HEARTH_GHOST_ROWS
    },
    {
        id: 'mushroom',
        name: 'Little Shroom',
        blurb: "A spotted mushroom with a face you can't say no to.",
        width: 16,
        height: 16,
        rows: MUSHROOM_ROWS
    },
    {
        id: 'bun',
        name: 'Bun',
        blurb: 'Our little studio rabbit. Usually found sitting somewhere nearby.',
        width: 16,
        height: 16,
        rows: BUN_ROWS
    },
    {
        id: 'lantern',
        name: 'Little Lantern',
        blurb: 'A little brass lantern for late-night drawing.',
        width: 16,
        height: 16,
        rows: LANTERN_ROWS
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/art/stencilEvaluator.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "evaluateStencilCoverage",
    ()=>evaluateStencilCoverage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/art/playgroundLessons.ts [app-client] (ecmascript)");
;
function evaluateStencilCoverage(ctx, canvasWidth, canvasHeight, template) {
    const imgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
    const data = imgData.data;
    const rows = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTemplateRows"])(template);
    const gridSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTemplateGridSize"])(template);
    let targetOutlineCells = 0;
    let coveredOutlineCells = 0;
    let totalDrawnPixels = 0;
    let targetMinX = gridSize;
    let targetMinY = gridSize;
    let targetMaxX = 0;
    let targetMaxY = 0;
    let drawnMinX = gridSize;
    let drawnMinY = gridSize;
    let drawnMaxX = 0;
    let drawnMaxY = 0;
    let hasAnyDrawnCell = false;
    const cellW = canvasWidth / gridSize;
    const cellH = canvasHeight / gridSize;
    const totalPixelsPerCell = cellW * cellH;
    for(let gy = 0; gy < gridSize; gy++){
        const row = rows[gy];
        if (!row) continue;
        for(let gx = 0; gx < gridSize; gx++){
            const char = row[gx];
            const isTarget = char !== '.' && char !== undefined;
            if (isTarget) {
                if (gx < targetMinX) targetMinX = gx;
                if (gx > targetMaxX) targetMaxX = gx;
                if (gy < targetMinY) targetMinY = gy;
                if (gy > targetMaxY) targetMaxY = gy;
                targetOutlineCells++;
            }
            // Count non-transparent pixels in this cell block
            let drawnInCell = 0;
            const startX = Math.floor(gx * cellW);
            const startY = Math.floor(gy * cellH);
            const endX = Math.floor((gx + 1) * cellW);
            const endY = Math.floor((gy + 1) * cellH);
            for(let y = startY; y < endY; y++){
                for(let x = startX; x < endX; x++){
                    const idx = (y * canvasWidth + x) * 4;
                    if (data[idx + 3] > 40) {
                        drawnInCell++;
                        totalDrawnPixels++;
                    }
                }
            }
            const cellInked = drawnInCell >= Math.max(1, totalPixelsPerCell * 0.15);
            if (cellInked) {
                hasAnyDrawnCell = true;
                if (gx < drawnMinX) drawnMinX = gx;
                if (gx > drawnMaxX) drawnMaxX = gx;
                if (gy < drawnMinY) drawnMinY = gy;
                if (gy > drawnMaxY) drawnMaxY = gy;
                if (isTarget) {
                    coveredOutlineCells++;
                }
            }
        }
    }
    const totalTargetCells = targetOutlineCells;
    const totalCoveredCells = coveredOutlineCells;
    const outlineCoverage = targetOutlineCells > 0 ? coveredOutlineCells / targetOutlineCells : 1.0;
    const totalCoverage = outlineCoverage;
    // Bounding Box IoU
    let boundingBoxIoU = 0;
    if (hasAnyDrawnCell && totalTargetCells > 0) {
        const interMinX = Math.max(targetMinX, drawnMinX);
        const interMinY = Math.max(targetMinY, drawnMinY);
        const interMaxX = Math.min(targetMaxX, drawnMaxX);
        const interMaxY = Math.min(targetMaxY, drawnMaxY);
        const interW = Math.max(0, interMaxX - interMinX + 1);
        const interH = Math.max(0, interMaxY - interMinY + 1);
        const interArea = interW * interH;
        const targetArea = (targetMaxX - targetMinX + 1) * (targetMaxY - targetMinY + 1);
        const drawnArea = (drawnMaxX - drawnMinX + 1) * (drawnMaxY - drawnMinY + 1);
        const unionArea = targetArea + drawnArea - interArea;
        boundingBoxIoU = unionArea > 0 ? interArea / unionArea : 0;
    }
    const completionScore = Math.min(100, Math.round(outlineCoverage * 100));
    // Strict outline completion criteria: at least 85% of outline pixels must be inked
    const isComplete = outlineCoverage >= 0.85;
    let statusMessage = 'Trace the outline stencil on the canvas.';
    if (isComplete) {
        statusMessage = 'Outline complete! Click Next Frame to proceed.';
    } else if (completionScore > 0) {
        statusMessage = `Outline in progress (${completionScore}%). Finish inking all edges!`;
    }
    const effectivePixelArea = template.effectivePixelArea;
    const areaDeviation = effectivePixelArea ? totalDrawnPixels - effectivePixelArea : 0;
    return {
        targetOutlineCells,
        coveredOutlineCells,
        outlineCoverage,
        totalTargetCells,
        totalCoveredCells,
        totalCoverage,
        targetBoundingBox: {
            minX: targetMinX,
            minY: targetMinY,
            maxX: targetMaxX,
            maxY: targetMaxY
        },
        drawnBoundingBox: hasAnyDrawnCell ? {
            minX: drawnMinX,
            minY: drawnMinY,
            maxX: drawnMaxX,
            maxY: drawnMaxY
        } : null,
        boundingBoxIoU,
        totalDrawnPixels,
        isComplete,
        completionScore,
        statusMessage,
        effectivePixelArea,
        areaDeviation
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/art/teachingBoardData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ALT_COLOURS",
    ()=>ALT_COLOURS,
    "BUN_BUILDING_STEPS",
    ()=>BUN_BUILDING_STEPS,
    "BUN_JUMP_FRAMES",
    ()=>BUN_JUMP_FRAMES,
    "SLIME_BUILDING_STEPS",
    ()=>SLIME_BUILDING_STEPS,
    "SLIME_JUMP_FRAMES",
    ()=>SLIME_JUMP_FRAMES,
    "TEACHING_CHARACTERS",
    ()=>TEACHING_CHARACTERS,
    "loadTeachingAnimationIntoPlayground",
    ()=>loadTeachingAnimationIntoPlayground,
    "resolvePixelColor",
    ()=>resolvePixelColor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
;
;
const ALT_COLOURS = [
    {
        id: 'wisteria',
        name: 'Wisteria Lavender',
        tag: 'Classic PixiBun',
        swatch: '#c792df',
        outline: '#3a2e4c',
        fill: '#f2ecf7',
        shade: '#cdbfdf',
        highlight: '#faf6fc',
        glint: '#ffffff',
        feature: '#3a2e4c',
        blush: '#e08ca6'
    },
    {
        id: 'amber',
        name: 'Lamp Amber',
        tag: 'Honey Glow',
        swatch: '#f0be7c',
        outline: '#3c2410',
        fill: '#fdeed4',
        shade: '#e0ad65',
        highlight: '#fff8eb',
        glint: '#ffffff',
        feature: '#3c2410',
        blush: '#ea7f38'
    },
    {
        id: 'peach',
        name: 'Peachy Rose',
        tag: 'Sweet Strawberry',
        swatch: '#f29bb2',
        outline: '#3e1a26',
        fill: '#fce7ee',
        shade: '#e69bb1',
        highlight: '#fff3f7',
        glint: '#ffffff',
        feature: '#3e1a26',
        blush: '#e64e79'
    },
    {
        id: 'matcha',
        name: 'Matcha Moss',
        tag: 'Fresh Sprout',
        swatch: '#57c728',
        outline: '#152b11',
        fill: '#57c728',
        shade: '#2d7c13',
        highlight: '#aef069',
        glint: '#ffffff',
        feature: '#152b11',
        blush: '#f0be7c'
    },
    {
        id: 'celestine',
        name: 'Celestine Sky',
        tag: 'Frost Crystal',
        swatch: '#7cbbee',
        outline: '#1a273e',
        fill: '#e2f0fc',
        shade: '#9ec7ee',
        highlight: '#f1f8fe',
        glint: '#ffffff',
        feature: '#1a273e',
        blush: '#f29bb2'
    },
    {
        id: 'amethyst',
        name: 'Royal Amethyst',
        tag: 'Deep Velvet',
        swatch: '#a86fd4',
        outline: '#29153a',
        fill: '#ebd9fa',
        shade: '#b78ee0',
        highlight: '#f6ecff',
        glint: '#ffffff',
        feature: '#29153a',
        blush: '#f0be7c'
    },
    {
        id: 'sakura',
        name: 'Sakura Bloom',
        tag: 'Cherry Blossom',
        swatch: '#f7a8d8',
        outline: '#3c182c',
        fill: '#fdedf6',
        shade: '#e3a1c8',
        highlight: '#fff7fc',
        glint: '#ffffff',
        feature: '#3c182c',
        blush: '#e08ca6'
    },
    {
        id: 'obsidian',
        name: 'Obsidian Slate',
        tag: 'Midnight Velvet',
        swatch: '#5c526d',
        outline: '#140c1e',
        fill: '#413552',
        shade: '#2c223a',
        highlight: '#695a7e',
        glint: '#ffffff',
        feature: '#ede8f4',
        blush: '#f0be7c'
    }
];
const BUN_BUILDING_STEPS = [
    {
        "step": 1,
        "label": "1. Silhouette & Bounds",
        "description": "16\u00d716 bounding box establishing overall character mass and ear silhouette.",
        "hasDimensions": true,
        "dimensionW": 16,
        "dimensionH": 16,
        "grid16": [
            "...oo......oo...",
            "..oooo....oooo..",
            "..oooo....oooo..",
            "..oooo....oooo..",
            "..oooooooooooo..",
            ".oooooooooooooo.",
            "oooooooooooooooo",
            "oooooooooooooooo",
            "oooooooooooooooo",
            "oooooooooooooooo",
            "oooooooooooooooo",
            ".oooooooooooooo.",
            ".oooooooooooooo.",
            ".oooooooooooooo.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "step": 2,
        "label": "2. Closed Outline",
        "description": "Crisp 1px outer stroke with zero perimeter leaks for clean flood fills.",
        "grid16": [
            "...oo......oo...",
            "..o..o....o..o..",
            "..o..o....o..o..",
            "..o..o....o..o..",
            "..o..oooooo..o..",
            ".o............o.",
            "o..............o",
            "o..............o",
            "o..............o",
            "o..............o",
            "o..............o",
            ".o............o.",
            ".o............o.",
            ".o............o.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "step": 3,
        "label": "3. Facial Features",
        "description": "Placing eye positions, ear cavities, and rosy cheeks on the face plane.",
        "grid16": [
            "...oo......oo...",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..o..oooooo..o..",
            ".o............o.",
            "o..............o",
            "o....e....e....o",
            "o....e....e....o",
            "o..rr......rr..o",
            "o..............o",
            ".o............o.",
            ".o............o.",
            ".o............o.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "step": 4,
        "label": "4. Base Color Fill",
        "description": "Warm, solid base fill poured inside the closed outer lineart.",
        "grid16": [
            "...oo......oo...",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..offfoooofffo..",
            ".offffffffffffo.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            ".offffffffffffo.",
            ".offffffffffffo.",
            ".offffffffffffo.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "step": 5,
        "label": "5. Core Shading",
        "description": "Under-chin drop shadow and bottom rim occlusion grounding the sphere.",
        "grid16": [
            "...oo......oo...",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..offfoooofffo..",
            ".offffffffffffo.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            ".offffffffffffo.",
            ".osssssssssssso.",
            ".osssssssssssso.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "step": 6,
        "label": "6. Volumetric Highlights",
        "description": "Top-down lamplit warmth on forehead, ear tips, and soft tummy chest.",
        "grid16": [
            "...oo......oo...",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..offfoooofffo..",
            ".ohhhhhhhhhhhho.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            ".offfhhhhhhfffo.",
            ".osssssssssssso.",
            ".osssssssssssso.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "step": 7,
        "label": "7. Specular Glint & Polish",
        "description": "Pure white gleam in the eyes and forehead creating lively, breathing eyes.",
        "grid16": [
            "...oo......oo...",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..offfoooofffo..",
            ".oghhhhhhhhhhho.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            ".offfhhhhhhfffo.",
            ".osssssssssssso.",
            ".osssssssssssso.",
            "..oooooooooooo..",
            "................"
        ]
    }
];
const BUN_JUMP_FRAMES = [
    {
        "frame": 1,
        "label": "Frame 1: Crouch Anticipation",
        "heightPx": 0,
        "principle": "Anticipation",
        "explanation": "Compressing downward to store spring potential along the floor.",
        "holdMs": 120,
        "squashFactor": 1.25,
        "grid16": [
            "................",
            "................",
            "................",
            "................",
            "...oo......oo...",
            "..ofro....ofro..",
            "..offfoooofffo..",
            ".oghhhhhhhhhhho.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            "osssssssssssssso",
            "osssssssssssssso",
            "oooooooooooooooo",
            "................"
        ]
    },
    {
        "frame": 2,
        "label": "Frame 2: Explosive Launch",
        "heightPx": 16,
        "principle": "Launch Stretch",
        "explanation": "Exploding upward off the floor with stored spring energy.",
        "holdMs": 50,
        "squashFactor": 0.7,
        "grid16": [
            "....oo....oo....",
            "...ofro..ofro...",
            "...ofro..ofro...",
            "...ofro..ofro...",
            "...ofro..ofro...",
            "..ooffoooooffo..",
            "..oghhhhhhhhho..",
            "..offffffffffo..",
            "..offfeffefffo..",
            "..offfeffefffo..",
            "..offrrffffrffo.",
            "..offffffffffo..",
            "..osssssssssso..",
            "..osssssssssso..",
            "...oooooooooo...",
            "................"
        ]
    },
    {
        "frame": 3,
        "label": "Frame 3: Ascending Flight",
        "heightPx": 24,
        "principle": "Ascent Stretch",
        "explanation": "Rapid ascent bridging ground to sky; ears trailing velocity vector.",
        "holdMs": 60,
        "squashFactor": 0.75,
        "grid16": [
            "................",
            "...oo......oo...",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..offfoooofffo..",
            ".oghhhhhhhhhhho.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            ".osssssssssssso.",
            ".osssssssssssso.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "frame": 4,
        "label": "Frame 4: Apex Deceleration",
        "heightPx": 30,
        "principle": "Apex Deceleration",
        "explanation": "Decelerating against gravity; vertical velocity nears zero.",
        "holdMs": 80,
        "squashFactor": 0.9,
        "grid16": [
            "...oo......oo...",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..offfoooofffo..",
            ".oghhhhhhhhhhho.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            ".offfhhhhhhfffo.",
            ".osssssssssssso.",
            ".osssssssssssso.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "frame": 5,
        "label": "Frame 5: Apex Hang & Float",
        "heightPx": 32,
        "principle": "Apex Float",
        "explanation": "Maximum altitude. Zero gravity hang time; buoyant ear float.",
        "holdMs": 160,
        "squashFactor": 1.2,
        "grid16": [
            "................",
            "................",
            "................",
            "..oo........oo..",
            ".ofro......ofro.",
            ".ofroooooooofro.",
            ".oghhhhhhhhhhho.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            ".osssssssssssso.",
            "..oooooooooooo..",
            "................",
            "................",
            "................"
        ]
    },
    {
        "frame": 6,
        "label": "Frame 6: Crest Fall",
        "heightPx": 30,
        "principle": "Descent Acceleration",
        "explanation": "Beginning gravitational descent; neutral rounded pose.",
        "holdMs": 80,
        "squashFactor": 0.9,
        "grid16": [
            "...oo......oo...",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..offfoooofffo..",
            ".oghhhhhhhhhhho.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            ".offfhhhhhhfffo.",
            ".osssssssssssso.",
            ".osssssssssssso.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "frame": 7,
        "label": "Frame 7: Accelerated Descent",
        "heightPx": 24,
        "principle": "Gravity Fall",
        "explanation": "Downward acceleration gaining kinetic speed back toward floor.",
        "holdMs": 60,
        "squashFactor": 0.75,
        "grid16": [
            "................",
            "...oo......oo...",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..offfoooofffo..",
            ".oghhhhhhhhhhho.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            ".osssssssssssso.",
            ".osssssssssssso.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "frame": 8,
        "label": "Frame 8: Terminal Velocity",
        "heightPx": 16,
        "principle": "Terminal Smear",
        "explanation": "Maximum fall speed approaching the floor plane.",
        "holdMs": 50,
        "squashFactor": 0.7,
        "grid16": [
            "....oo....oo....",
            "...ofro..ofro...",
            "...ofro..ofro...",
            "...ofro..ofro...",
            "...ofro..ofro...",
            "..ooffoooooffo..",
            "..oghhhhhhhhho..",
            "..offffffffffo..",
            "..offfeffefffo..",
            "..offfeffefffo..",
            "..offrrffffrffo.",
            "..offffffffffo..",
            "..osssssssssso..",
            "..osssssssssso..",
            "...oooooooooo...",
            "................"
        ]
    },
    {
        "frame": 9,
        "label": "Frame 9: Impact Shock",
        "heightPx": 0,
        "principle": "Ground Contact",
        "explanation": "First contact with floor; neutral rabbit touching ground.",
        "holdMs": 60,
        "squashFactor": 1.0,
        "grid16": [
            "...oo......oo...",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..ofro....ofro..",
            "..offfoooofffo..",
            ".oghhhhhhhhhhho.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "offffffffffffffo",
            ".offfhhhhhhfffo.",
            ".osssssssssssso.",
            ".osssssssssssso.",
            "..oooooooooooo..",
            "................"
        ]
    },
    {
        "frame": 10,
        "label": "Frame 10: Ground Squash & Settle",
        "heightPx": 0,
        "principle": "Maximum Squash",
        "explanation": "Maximum horizontal splatter and elastic spring back to neutral pose.",
        "holdMs": 120,
        "squashFactor": 1.5,
        "grid16": [
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
            ".oo..........oo.",
            "ofroooooooooofro",
            ".oghhhhhhhhhhho.",
            "offffffffffffffo",
            "offffeffffeffffo",
            "offrrffffffrrffo",
            "osssssssssssssso",
            "oooooooooooooooo"
        ]
    }
];
const SLIME_BUILDING_STEPS = [
    {
        "step": 1,
        "label": "1. 15\u00d715 Silhouette",
        "description": "Establish the circular mass with 15px width and height brackets.",
        "hasDimensions": true,
        "dimensionW": 15,
        "dimensionH": 15,
        "grid16": [
            ".....oooooo.....",
            "...oooooooooo...",
            "..oooooooooooo..",
            ".oooooooooooooo.",
            ".oooooooooooooo.",
            "oooooooooooooooo",
            "oooooooooooooooo",
            "oooooooooooooooo",
            "oooooooooooooooo",
            "oooooooooooooooo",
            ".oooooooooooooo.",
            ".oooooooooooooo.",
            "..oooooooooooo..",
            "...oooooooooo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "step": 2,
        "label": "2. Closed Outline",
        "description": "Continuous circular perimeter line without leaks or breaks.",
        "grid16": [
            ".....oooooo.....",
            "...oo......oo...",
            "..o..........o..",
            ".o............o.",
            ".o............o.",
            "o..............o",
            "o..............o",
            "o..............o",
            "o..............o",
            "o..............o",
            ".o............o.",
            ".o............o.",
            "..o..........o..",
            "...oo......oo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "step": 3,
        "label": "3. Expressive Face",
        "description": "Twin vertical bead eyes giving life to the gelatinous droplet.",
        "grid16": [
            ".....oooooo.....",
            "...oo......oo...",
            "..o..........o..",
            ".o............o.",
            ".o............o.",
            "o..............o",
            "o..............o",
            "o.....e..e.....o",
            "o.....e..e.....o",
            "o..............o",
            ".o............o.",
            ".o............o.",
            "..o..........o..",
            "...oo......oo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "step": 4,
        "label": "4. Flat Base Color",
        "description": "Lush jelly base tone filled solidly inside the outline.",
        "grid16": [
            ".....oooooo.....",
            "...ooffffffoo...",
            "..offffffffffo..",
            ".offffffffffffo.",
            ".offffffffffffo.",
            "offffffffffffffo",
            "offffffffffffffo",
            "offfffeffefffffo",
            "offfffeffefffffo",
            "offffffffffffffo",
            ".offffffffffffo.",
            ".offffffffffffo.",
            "..offffffffffo..",
            "...ooffffffoo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "step": 5,
        "label": "5. Bottom Shade Rim",
        "description": "Cool shadow curvature anchoring weight at the bottom rim.",
        "grid16": [
            ".....oooooo.....",
            "...ooffffffoo...",
            "..offffffffffo..",
            ".offffffffffffo.",
            ".offffffffffffo.",
            "offffffffffffffo",
            "offffffffffffffo",
            "offfffeffefffffo",
            "offfffeffefffffo",
            "offffffffffffffo",
            ".offsssssssssfo.",
            ".osssssssssssso.",
            "..osssssssssso..",
            "...oossssssoo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "step": 6,
        "label": "6. Crest Highlight",
        "description": "Convex dome highlight wrapping the top hemisphere.",
        "grid16": [
            ".....oooooo.....",
            "...oohhhhhhoo...",
            "..ohhhhhhhhhho..",
            ".ohhhhhhhhhhhfo.",
            ".ohfffffffffffo.",
            "offffffffffffffo",
            "offffffffffffffo",
            "offfffeffefffffo",
            "offfffeffefffffo",
            "offffffffffffffo",
            ".offsssssssssfo.",
            ".osssssssssssso.",
            "..osssssssssso..",
            "...oossssssoo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "step": 7,
        "label": "7. Specular Glint",
        "description": "Pure white specular reflections conveying glistening liquid.",
        "grid16": [
            ".....oooooo.....",
            "...oogghhhhoo...",
            "..oghhhhhhhhho..",
            ".oghhhhhhhhhho..",
            ".ohfffffffffffo.",
            "offffffffffffffo",
            "offffffffffffffo",
            "offfffeffefffffo",
            "offfffeffefffffo",
            "offffffffffffffo",
            ".offsssssssssfo.",
            ".osssssssssssso.",
            "..osssssssssso..",
            "...oossssssoo...",
            ".....oooooo.....",
            "................"
        ]
    }
];
const SLIME_JUMP_FRAMES = [
    {
        "frame": 1,
        "label": "Frame 1: Gel Compression",
        "heightPx": 0,
        "principle": "Anticipation",
        "explanation": "Flattening into a wide pancake puddle storing elastic energy.",
        "holdMs": 120,
        "squashFactor": 1.4,
        "grid16": [
            "................",
            "................",
            "................",
            "................",
            ".....oooooo.....",
            "...oogghhhhhoo..",
            "..oghhhhhhhhffo.",
            ".ohfffffffffffo.",
            "offffffffffffffo",
            "offfffeffefffffo",
            "offfffeffefffffo",
            "osssssssssssssso",
            "osssssssssssssso",
            "osssssssssssssso",
            "oooooooooooooooo",
            "................"
        ]
    },
    {
        "frame": 2,
        "label": "Frame 2: Upward Surge",
        "heightPx": 16,
        "principle": "Launch Stretch",
        "explanation": "Bursting upward off the floor with stored elastic energy.",
        "holdMs": 50,
        "squashFactor": 0.7,
        "grid16": [
            ".....oooooo.....",
            "....oogghhoo....",
            "...ooghhhhffo...",
            "...ohffffffffo..",
            "...ohffffffffo..",
            "...ohffffffffo..",
            "...offeffefffo..",
            "...offeffefffo..",
            "...offeffefffo..",
            "...offfffffffo..",
            "...offfffffffo..",
            "...offsssssffo..",
            "...ossssssssso..",
            "...ossssssssso..",
            "....oossssoo....",
            ".....oooooo....."
        ]
    },
    {
        "frame": 3,
        "label": "Frame 3: Ascending Sphere",
        "heightPx": 24,
        "principle": "Ascent Stretch",
        "explanation": "High speed rising oval transitioning toward apex.",
        "holdMs": 60,
        "squashFactor": 0.75,
        "grid16": [
            ".....oooooo.....",
            "...oogghhhhoo...",
            "..oghhhhhhhhfo..",
            "..ohffffffffffo.",
            "..ohffffffffffo.",
            "..offfffffffffo.",
            "..offfefffefffo.",
            "..offfefffefffo.",
            "..offfefffefffo.",
            "..offfffffffffo.",
            "..offssssssssfo.",
            "..ossssssssssfo.",
            "..ossssssssssfo.",
            "...oossssssoo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "frame": 4,
        "label": "Frame 4: Apex Deceleration",
        "heightPx": 30,
        "principle": "Apex Deceleration",
        "explanation": "Rounding into neutral sphere as upward velocity slows.",
        "holdMs": 80,
        "squashFactor": 0.9,
        "grid16": [
            ".....oooooo.....",
            "...oogghhhhoo...",
            "..oghhhhhhhhho..",
            ".oghhhhhhhhhho..",
            ".ohfffffffffffo.",
            "offffffffffffffo",
            "offffffffffffffo",
            "offfffeffefffffo",
            "offfffeffefffffo",
            "offffffffffffffo",
            ".offsssssssssfo.",
            ".osssssssssssso.",
            "..osssssssssso..",
            "...oossssssoo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "frame": 5,
        "label": "Frame 5: Apex Hang & Float",
        "heightPx": 32,
        "principle": "Apex Float",
        "explanation": "Peak altitude hang time; horizontal cushion before descent.",
        "holdMs": 160,
        "squashFactor": 1.25,
        "grid16": [
            "................",
            "................",
            "....oooooooo....",
            "..oogghhhhhhhhoo",
            ".oghhhhhhhhhfffo",
            "offffffffffffffo",
            "offfffefffeffffo",
            "offfffefffeffffo",
            "offffffffffffffo",
            ".offsssssssssffo",
            "..ossssssssssso.",
            "....oooooooo....",
            "................",
            "................",
            "................",
            "................"
        ]
    },
    {
        "frame": 6,
        "label": "Frame 6: Crest Fall",
        "heightPx": 30,
        "principle": "Descent Acceleration",
        "explanation": "Beginning downward gravitational drop; neutral sphere.",
        "holdMs": 80,
        "squashFactor": 0.9,
        "grid16": [
            ".....oooooo.....",
            "...oogghhhhoo...",
            "..oghhhhhhhhho..",
            ".oghhhhhhhhhho..",
            ".ohfffffffffffo.",
            "offffffffffffffo",
            "offffffffffffffo",
            "offfffeffefffffo",
            "offfffeffefffffo",
            "offffffffffffffo",
            ".offsssssssssfo.",
            ".osssssssssssso.",
            "..osssssssssso..",
            "...oossssssoo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "frame": 7,
        "label": "Frame 7: Accelerated Drop",
        "heightPx": 24,
        "principle": "Gravity Fall",
        "explanation": "Accelerating downward into terminal velocity.",
        "holdMs": 60,
        "squashFactor": 0.75,
        "grid16": [
            ".....oooooo.....",
            "...oogghhhhoo...",
            "..oghhhhhhhhfo..",
            "..ohffffffffffo.",
            "..ohffffffffffo.",
            "..offfffffffffo.",
            "..offfefffefffo.",
            "..offfefffefffo.",
            "..offfefffefffo.",
            "..offfffffffffo.",
            "..offssssssssfo.",
            "..ossssssssssfo.",
            "..ossssssssssfo.",
            "...oossssssoo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "frame": 8,
        "label": "Frame 8: Terminal Fall",
        "heightPx": 16,
        "principle": "Terminal Smear",
        "explanation": "Maximum fall speed approaching the floor plane.",
        "holdMs": 50,
        "squashFactor": 0.7,
        "grid16": [
            ".....oooooo.....",
            "....oogghhoo....",
            "...ooghhhhffo...",
            "...ohffffffffo..",
            "...ohffffffffo..",
            "...ohffffffffo..",
            "...offeffefffo..",
            "...offeffefffo..",
            "...offeffefffo..",
            "...offfffffffo..",
            "...offfffffffo..",
            "...offsssssffo..",
            "...ossssssssso..",
            "...ossssssssso..",
            "....oossssoo....",
            ".....oooooo....."
        ]
    },
    {
        "frame": 9,
        "label": "Frame 9: Floor Impact",
        "heightPx": 0,
        "principle": "Ground Contact",
        "explanation": "Initial impact with floor plane touching baseline.",
        "holdMs": 60,
        "squashFactor": 1.0,
        "grid16": [
            ".....oooooo.....",
            "...oogghhhhoo...",
            "..oghhhhhhhhho..",
            ".oghhhhhhhhhho..",
            ".ohfffffffffffo.",
            "offffffffffffffo",
            "offffffffffffffo",
            "offfffeffefffffo",
            "offfffeffefffffo",
            "offffffffffffffo",
            ".offsssssssssfo.",
            ".osssssssssssso.",
            "..osssssssssso..",
            "...oossssssoo...",
            ".....oooooo.....",
            "................"
        ]
    },
    {
        "frame": 10,
        "label": "Frame 10: Pancake Splatter Squash",
        "heightPx": 0,
        "principle": "Maximum Squash",
        "explanation": "Extreme horizontal flattening before rebounding to rest.",
        "holdMs": 120,
        "squashFactor": 1.6,
        "grid16": [
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
            "...oooooooooo...",
            ".oogghhhhhhhhhoo",
            "offffffffffffffo",
            "offfffeffffefffo",
            "osssssssssssssso",
            "oooooooooooooooo",
            "................"
        ]
    }
];
const TEACHING_CHARACTERS = {
    bun: {
        id: 'bun',
        name: 'Bun',
        tagline: 'PixiBun Mascot (Cozy Rabbit)',
        defaultPaletteId: 'wisteria',
        buildingSteps: BUN_BUILDING_STEPS,
        jumpFrames: BUN_JUMP_FRAMES
    },
    slime: {
        id: 'slime',
        name: 'Gel Slime',
        tagline: 'Classic Atelier Creature',
        defaultPaletteId: 'matcha',
        buildingSteps: SLIME_BUILDING_STEPS,
        jumpFrames: SLIME_JUMP_FRAMES
    }
};
function resolvePixelColor(char, palette) {
    switch(char){
        case 'o':
            return palette.outline;
        case 'f':
            return palette.fill;
        case 's':
            return palette.shade;
        case 'h':
            return palette.highlight;
        case 'g':
            return palette.glint;
        case 'e':
            return palette.feature;
        case 'r':
            return palette.blush;
        case '.':
        case ' ':
        default:
            return null;
    }
}
function loadTeachingAnimationIntoPlayground(char, palette) {
    const studio = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    if (studio.canvasWidth !== 16 || studio.canvasHeight !== 16) {
        studio.setCanvasSize(16, 16);
    }
    studio.setFps(10);
    let freshFrames = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames;
    while(freshFrames.length < char.jumpFrames.length){
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().addFrame();
        freshFrames = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames;
    }
    while(freshFrames.length > char.jumpFrames.length){
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().deleteFrame(freshFrames.length - 1);
        freshFrames = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames;
    }
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    char.jumpFrames.forEach((frameDef, fIdx)=>{
        state.setFrameDuration(fIdx, frameDef.holdMs, true);
        const targetFrame = state.frames[fIdx];
        if (!targetFrame || !targetFrame.layers[0]) return;
        const layerId = targetFrame.layers[0].id;
        const buf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layerId, 16, 16);
        const ctx = buf.ctx;
        ctx.imageSmoothingEnabled = false;
        ctx.clearRect(0, 0, 16, 16);
        frameDef.grid16.forEach((row, y)=>{
            for(let x = 0; x < row.length; x++){
                const color = resolvePixelColor(row[x], palette);
                if (color) {
                    ctx.fillStyle = color;
                    ctx.fillRect(x, y, 1, 1);
                }
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(layerId);
    });
    state.bumpBufferVersion();
    state.setActiveFrame(0);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/ditherMatrix.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Bayer and Blue-Noise Threshold Matrices for Authentic Digital Halftoning.
 *
 * Academic Citations:
 * - Robert Ulichney, "The Void-and-Cluster Method for Dither Array Generation,"
 *   SPIE Proceedings Vol. 1913, Human Vision, Visual Processing, and Digital Display IV, pp. 332-343, 1993.
 * - Bryce E. Bayer, "An Optimum Method for Two-Level Rendition of Continuous-Tone Pictures,"
 *   IEEE International Conference on Communications, Vol. 1, pp. 26-11, 1973.
 */ __turbopack_context__.s([
    "BAYER_2X2",
    ()=>BAYER_2X2,
    "BAYER_4X4",
    ()=>BAYER_4X4,
    "BAYER_8X8",
    ()=>BAYER_8X8,
    "BLUE_NOISE_16X16",
    ()=>BLUE_NOISE_16X16,
    "generateVoidAndClusterMatrix",
    ()=>generateVoidAndClusterMatrix,
    "shouldDitherPixel",
    ()=>shouldDitherPixel
]);
const BAYER_2X2 = [
    [
        0,
        2
    ],
    [
        3,
        1
    ]
];
const BAYER_4X4 = [
    [
        0,
        8,
        2,
        10
    ],
    [
        12,
        4,
        14,
        6
    ],
    [
        3,
        11,
        1,
        9
    ],
    [
        15,
        7,
        13,
        5
    ]
];
const BAYER_8X8 = [
    [
        0,
        32,
        8,
        40,
        2,
        34,
        10,
        42
    ],
    [
        48,
        16,
        56,
        24,
        50,
        18,
        58,
        26
    ],
    [
        12,
        44,
        4,
        36,
        14,
        46,
        6,
        38
    ],
    [
        60,
        28,
        52,
        20,
        62,
        30,
        54,
        22
    ],
    [
        3,
        35,
        11,
        43,
        1,
        33,
        9,
        41
    ],
    [
        51,
        19,
        59,
        27,
        49,
        17,
        57,
        25
    ],
    [
        15,
        47,
        7,
        39,
        13,
        45,
        5,
        37
    ],
    [
        63,
        31,
        55,
        23,
        61,
        29,
        53,
        21
    ]
];
function generateVoidAndClusterMatrix(size = 16, sigma = 1.9) {
    const N = size;
    const twoSigmaSq = 2 * sigma * sigma;
    // Precompute toroidal Gaussian blur kernel
    const K = Array.from({
        length: N
    }, ()=>new Array(N));
    for(let y = 0; y < N; y++){
        const dy = Math.min(y, N - y);
        for(let x = 0; x < N; x++){
            const dx = Math.min(x, N - x);
            K[y][x] = Math.exp(-(dx * dx + dy * dy) / twoSigmaSq);
        }
    }
    const B = Array.from({
        length: N
    }, ()=>new Uint8Array(N));
    const F = Array.from({
        length: N
    }, ()=>new Float64Array(N));
    const dither = Array.from({
        length: N
    }, ()=>new Array(N).fill(0));
    const addPoint = (px, py, sign = 1)=>{
        B[py][px] = B[py][px] + sign & 1;
        for(let y = 0; y < N; y++){
            const ky = (y - py + N) % N;
            for(let x = 0; x < N; x++){
                const kx = (x - px + N) % N;
                F[y][x] += sign * K[ky][kx];
            }
        }
    };
    const findCluster = ()=>{
        let maxVal = -Infinity;
        let cx = 0;
        let cy = 0;
        for(let y = 0; y < N; y++){
            for(let x = 0; x < N; x++){
                if (B[y][x] === 1 && F[y][x] > maxVal) {
                    maxVal = F[y][x];
                    cx = x;
                    cy = y;
                }
            }
        }
        return {
            x: cx,
            y: cy
        };
    };
    const findVoid = ()=>{
        let minVal = Infinity;
        let vx = 0;
        let vy = 0;
        for(let y = 0; y < N; y++){
            for(let x = 0; x < N; x++){
                if (B[y][x] === 0 && F[y][x] < minVal) {
                    minVal = F[y][x];
                    vx = x;
                    vy = y;
                }
            }
        }
        return {
            x: vx,
            y: vy
        };
    };
    // Phase 1: Initialize minority pattern (~10% ones via low-discrepancy sampling)
    const targetM = Math.max(1, Math.round(N * N * 0.1));
    let m = 0;
    for(let i = 0; i < targetM * 2 && m < targetM; i++){
        const px = Math.floor(i * 0.6180339887 % 1 * N);
        const py = Math.floor(i * 0.7548776662 % 1 * N);
        if (B[py][px] === 0) {
            addPoint(px, py, 1);
            m++;
        }
    }
    // Relax minority pattern to global void-and-cluster equilibrium
    for(let iter = 0; iter < 100; iter++){
        const cluster = findCluster();
        addPoint(cluster.x, cluster.y, -1);
        const voidPt = findVoid();
        if (cluster.x === voidPt.x && cluster.y === voidPt.y) {
            addPoint(cluster.x, cluster.y, 1);
            break;
        }
        addPoint(voidPt.x, voidPt.y, 1);
    }
    // Snapshot relaxed initial pattern
    const B_init = Array.from({
        length: N
    }, (_, y)=>Uint8Array.from(B[y]));
    // Phase 2: Successively fill voids up to N*N - 1
    for(let rank = m; rank < N * N; rank++){
        const v = findVoid();
        dither[v.y][v.x] = rank;
        addPoint(v.x, v.y, 1);
    }
    // Reset to initial relaxed minority pattern
    for(let y = 0; y < N; y++){
        B[y].fill(0);
        F[y].fill(0);
    }
    for(let y = 0; y < N; y++){
        for(let x = 0; x < N; x++){
            if (B_init[y][x] === 1) {
                addPoint(x, y, 1);
            }
        }
    }
    // Phase 3: Successively remove tightest clusters down to 0
    for(let rank = m - 1; rank >= 0; rank--){
        const c = findCluster();
        dither[c.y][c.x] = rank;
        addPoint(c.x, c.y, -1);
    }
    return dither;
}
const BLUE_NOISE_16X16 = generateVoidAndClusterMatrix(16, 1.9);
function shouldDitherPixel(x, y, matrixType, density = 0.5 // 0.0 to 1.0 threshold
) {
    if (matrixType === '2x2') {
        const threshold = (BAYER_2X2[(y % 2 + 2) % 2][(x % 2 + 2) % 2] + 0.5) / 4;
        return threshold <= density;
    } else if (matrixType === '4x4') {
        const threshold = (BAYER_4X4[(y % 4 + 4) % 4][(x % 4 + 4) % 4] + 0.5) / 16;
        return threshold <= density;
    } else if (matrixType === '8x8') {
        const threshold = (BAYER_8X8[(y % 8 + 8) % 8][(x % 8 + 8) % 8] + 0.5) / 64;
        return threshold <= density;
    } else if (matrixType === 'blue-noise') {
        const threshold = (BLUE_NOISE_16X16[(y % 16 + 16) % 16][(x % 16 + 16) % 16] + 0.5) / 256;
        return threshold <= density;
    } else if (matrixType === 'atkinson') {
        // Atkinson pseudo-ordered pattern for brush stroke drawing
        const pat = [
            [
                0,
                4,
                1,
                5
            ],
            [
                6,
                2,
                7,
                3
            ],
            [
                1,
                5,
                0,
                4
            ],
            [
                7,
                3,
                6,
                2
            ]
        ];
        const threshold = (pat[(y % 4 + 4) % 4][(x % 4 + 4) % 4] + 0.5) / 8;
        return threshold <= density;
    } else {
        // Riemersma Hilbert-inspired fractal thresholding
        const h = Math.abs((x ^ y) * 7 + (x * 3 + y * 5)) % 16;
        const threshold = (h + 0.5) / 16;
        return threshold <= density;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/eraseMatchingColor.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "eraseMatchingColor",
    ()=>eraseMatchingColor
]);
function eraseMatchingColor(image, color, tolerance, options = {}) {
    const { data, width, height } = image;
    const pixels = width * height;
    if (data.length !== pixels * 4 || options.mask && options.mask.length !== pixels) return 0;
    const limit = Math.max(0, Math.min(255, tolerance)) ** 2;
    const hue = (r, g, b, max, chroma)=>{
        if (max === r) return ((g - b) / chroma + 6) % 6 * 60;
        if (max === g) return ((b - r) / chroma + 2) * 60;
        return ((r - g) / chroma + 4) * 60;
    };
    const sampleMax = Math.max(...color);
    const sampleMin = Math.min(...color);
    const sampleChroma = sampleMax - sampleMin;
    const familyHue = options.family && sampleChroma >= 18 ? hue(color[0], color[1], color[2], sampleMax, sampleChroma) : null;
    const hueLimit = 30 + Math.max(0, Math.min(255, tolerance)) * 60 / 255;
    const matches = (pixel)=>{
        if (options.mask && !options.mask[pixel]) return false;
        const offset = pixel * 4;
        if (data[offset + 3] === 0) return false;
        if (familyHue !== null) {
            const r = data[offset];
            const g = data[offset + 1];
            const b = data[offset + 2];
            const max = Math.max(r, g, b);
            const min = Math.min(r, g, b);
            const chroma = max - min;
            // Pale spill has low saturation; dark outlines still need enough chroma.
            if (chroma < 14 || chroma / max < (max >= 160 ? 0.08 : 0.2)) return false;
            const pixelHue = hue(r, g, b, max, chroma);
            const hueDistance = Math.abs(pixelHue - familyHue);
            return Math.min(hueDistance, 360 - hueDistance) <= hueLimit;
        }
        const dr = data[offset] - color[0];
        const dg = data[offset + 1] - color[1];
        const db = data[offset + 2] - color[2];
        return dr * dr + dg * dg + db * db <= limit;
    };
    const erase = (pixel)=>{
        data.fill(0, pixel * 4, pixel * 4 + 4);
    };
    if (!options.contiguous) {
        // Classify before editing so neighboring colors cannot change the result.
        const familyMask = familyHue === null ? null : new Uint8Array(pixels);
        if (familyMask) {
            for(let pixel = 0; pixel < pixels; pixel++)familyMask[pixel] = matches(pixel) ? 1 : 0;
        }
        const outlineColor = (pixel)=>{
            if (!familyMask) return null;
            const offset = pixel * 4;
            // Only replace dark green spill that sits within a dark outline.
            if (Math.max(data[offset], data[offset + 1], data[offset + 2]) > 72) return null;
            const x = pixel % width;
            const y = Math.floor(pixel / width);
            let candidates = 0;
            let bestDistance = Infinity;
            let best = null;
            for(let dy = -1; dy <= 1; dy++)for(let dx = -1; dx <= 1; dx++){
                if (dx === 0 && dy === 0) continue;
                const nx = x + dx;
                const ny = y + dy;
                if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
                const neighbor = ny * width + nx;
                if (familyMask[neighbor]) continue;
                const n = neighbor * 4;
                if (data[n + 3] === 0) continue;
                const r = data[n];
                const g = data[n + 1];
                const b = data[n + 2];
                if (Math.max(r, g, b) > 80 || Math.max(r, g, b) - Math.min(r, g, b) > 35) continue;
                candidates++;
                const distance = (r - data[offset]) ** 2 + (g - data[offset + 1]) ** 2 + (b - data[offset + 2]) ** 2;
                if (distance < bestDistance) {
                    bestDistance = distance;
                    best = [
                        r,
                        g,
                        b
                    ];
                }
            }
            return candidates >= 2 ? best : null;
        };
        let changed = 0;
        for(let pixel = 0; pixel < pixels; pixel++){
            if (familyMask ? !familyMask[pixel] : !matches(pixel)) continue;
            const replacement = outlineColor(pixel);
            if (replacement) data.set(replacement, pixel * 4);
            else erase(pixel);
            changed++;
        }
        return changed;
    }
    const x = options.x;
    const y = options.y;
    if (x === undefined || y === undefined || !Number.isInteger(x) || !Number.isInteger(y) || x < 0 || y < 0 || x >= width || y >= height) return 0;
    const seed = y * width + x;
    if (!matches(seed)) return 0;
    const visited = new Uint8Array(pixels);
    const queue = new Int32Array(pixels);
    let head = 0;
    let tail = 0;
    queue[tail++] = seed;
    visited[seed] = 1;
    let changed = 0;
    const enqueue = (neighbor)=>{
        if (visited[neighbor]) return;
        visited[neighbor] = 1;
        if (matches(neighbor)) queue[tail++] = neighbor;
    };
    while(head < tail){
        const pixel = queue[head++];
        if (!matches(pixel)) continue;
        erase(pixel);
        changed++;
        const column = pixel % width;
        if (column > 0) enqueue(pixel - 1);
        if (column + 1 < width) enqueue(pixel + 1);
        if (pixel >= width) enqueue(pixel - width);
        if (pixel + width < pixels) enqueue(pixel + width);
    }
    return changed;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/floodFill.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// High-performance Iterative 4-connected stack-based Flood Fill & Color Swap algorithms for pixel buffers
__turbopack_context__.s([
    "colorsMatch",
    ()=>colorsMatch,
    "hexToRgba",
    ()=>hexToRgba,
    "performFloodFill",
    ()=>performFloodFill,
    "replaceLayerColor",
    ()=>replaceLayerColor,
    "rgbToHex",
    ()=>rgbToHex,
    "rgbaToHex",
    ()=>rgbaToHex
]);
function hexToRgba(hex) {
    let cleanHex = hex.replace('#', '');
    if (cleanHex.length === 3) {
        cleanHex = cleanHex.split('').map((c)=>c + c).join('') + 'ff';
    } else if (cleanHex.length === 4) {
        // #RGBA — double each nibble to its RRGGBBAA form (CSS Color 4 shorthand)
        cleanHex = cleanHex.split('').map((c)=>c + c).join('');
    } else if (cleanHex.length === 6) {
        cleanHex += 'ff';
    } else if (cleanHex.length === 8) {
    // Already has alpha
    } else {
        cleanHex = 'ffffffff';
    }
    const num = parseInt(cleanHex, 16);
    return {
        r: num >> 24 & 255,
        g: num >> 16 & 255,
        b: num >> 8 & 255,
        a: num & 255
    };
}
function rgbaToHex(r, g, b, _a = 255) {
    const toHex = (n)=>Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0');
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
const rgbToHex = rgbaToHex;
function colorsMatch(c1, c2, tolerance = 0) {
    // If both are transparent, they match regardless of RGB channel noise
    if (c1.a <= 10 && c2.a <= 10) return true;
    // If one is transparent and one is opaque, they do not match
    if (c1.a <= 10 && c2.a > 10 || c1.a > 10 && c2.a <= 10) return false;
    if (tolerance === 0) {
        return c1.r === c2.r && c1.g === c2.g && c1.b === c2.b && c1.a === c2.a;
    }
    const diff = Math.sqrt(Math.pow(c1.r - c2.r, 2) + Math.pow(c1.g - c2.g, 2) + Math.pow(c1.b - c2.b, 2) + Math.pow(c1.a - c2.a, 2));
    return diff <= tolerance;
}
function replaceLayerColor(imageData, x, y, replacementHex, tolerance = 0) {
    const { width, height, data } = imageData;
    if (x < 0 || x >= width || y < 0 || y >= height) return 0;
    const source = (y * width + x) * 4;
    if (data[source + 3] <= 30) return 0;
    const r = data[source];
    const g = data[source + 1];
    const b = data[source + 2];
    const replacement = hexToRgba(replacementHex);
    const limit = Math.max(0, Math.min(255, tolerance)) ** 2;
    let changed = 0;
    for(let i = 0; i < data.length; i += 4){
        if (data[i + 3] <= 30) continue;
        const dr = data[i] - r;
        const dg = data[i + 1] - g;
        const db = data[i + 2] - b;
        if (dr * dr + dg * dg + db * db > limit) continue;
        if (data[i] === replacement.r && data[i + 1] === replacement.g && data[i + 2] === replacement.b) continue;
        data[i] = replacement.r;
        data[i + 1] = replacement.g;
        data[i + 2] = replacement.b;
        changed++;
    }
    return changed;
}
function performFloodFill(ctx, startX, startY, fillColorHex, contiguous = true, tolerance = 0, fillEnclosedSpecks = false) {
    const width = ctx.canvas.width;
    const height = ctx.canvas.height;
    if (startX < 0 || startX >= width || startY < 0 || startY >= height) return;
    const imgData = ctx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const pixels32 = new Uint32Array(data.buffer, data.byteOffset, data.byteLength >> 2);
    const targetOffset = (startY * width + startX) * 4;
    const targetColor = {
        r: data[targetOffset],
        g: data[targetOffset + 1],
        b: data[targetOffset + 2],
        a: data[targetOffset + 3]
    };
    const replacementColor = hexToRgba(fillColorHex);
    // If target color already matches replacement color, abort to avoid infinite loop
    if (colorsMatch(targetColor, replacementColor, 0) && tolerance === 0 && !fillEnclosedSpecks) return;
    const targetColor32 = (targetColor.a << 24 | targetColor.b << 16 | targetColor.g << 8 | targetColor.r) >>> 0;
    const replacementColor32 = (replacementColor.a << 24 | replacementColor.b << 16 | replacementColor.g << 8 | replacementColor.r) >>> 0;
    if (!contiguous) {
        // Global Color Replacement: Replace all matching pixels across the entire layer
        for(let i = 0; i < pixels32.length; i++){
            const idx = i * 4;
            const currentPixel = {
                r: data[idx],
                g: data[idx + 1],
                b: data[idx + 2],
                a: data[idx + 3]
            };
            if (tolerance === 0) {
                if (pixels32[i] === targetColor32 || data[idx + 3] <= 10 && targetColor.a <= 10) {
                    pixels32[i] = replacementColor32;
                }
            } else if (colorsMatch(currentPixel, targetColor, tolerance)) {
                pixels32[i] = replacementColor32;
            }
        }
    } else {
        // Contiguous Flood Fill with Queue (stack)
        const queue = [
            startX,
            startY
        ];
        const visited = new Uint8Array(width * height);
        visited[startY * width + startX] = 1;
        let minX = startX;
        let maxX = startX;
        let minY = startY;
        let maxY = startY;
        while(queue.length > 0){
            const y = queue.pop();
            const x = queue.pop();
            const index = y * width + x;
            pixels32[index] = replacementColor32;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
            // 4-connected neighbors without allocating a new array for each pixel.
            for(let direction = 0; direction < 4; direction++){
                const nx = x + (direction === 0 ? 1 : direction === 1 ? -1 : 0);
                const ny = y + (direction === 2 ? 1 : direction === 3 ? -1 : 0);
                if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                    const nIndex = ny * width + nx;
                    if (!visited[nIndex]) {
                        const nOffset = nIndex * 4;
                        const nColor = {
                            r: data[nOffset],
                            g: data[nOffset + 1],
                            b: data[nOffset + 2],
                            a: data[nOffset + 3]
                        };
                        let matches;
                        if (tolerance === 0) {
                            matches = pixels32[nIndex] === targetColor32 || data[nOffset + 3] <= 10 && targetColor.a <= 10;
                        } else {
                            matches = colorsMatch(nColor, targetColor, tolerance);
                        }
                        if (matches) {
                            visited[nIndex] = 1;
                            queue.push(nx, ny);
                        }
                    }
                }
            }
        }
        if (fillEnclosedSpecks) {
            // Keep this optional: a small enclosed detail can be intentional artwork.
            // Only islands surrounded by the filled region, never outside the region,
            // are eligible. The 8-pixel limit avoids swallowing larger features.
            const checked = new Uint8Array(width * height);
            const islandQueue = new Uint32Array((maxX - minX + 1) * (maxY - minY + 1));
            let tail = 0;
            const visitIslandNeighbor = (neighbor)=>{
                if (visited[neighbor] || checked[neighbor]) return;
                checked[neighbor] = 1;
                islandQueue[tail++] = neighbor;
            };
            for(let y = minY; y <= maxY; y++){
                for(let x = minX; x <= maxX; x++){
                    const start = y * width + x;
                    if (visited[start] || checked[start]) continue;
                    let head = 0;
                    tail = 1;
                    let enclosed = true;
                    checked[start] = 1;
                    islandQueue[0] = start;
                    while(head < tail){
                        const index = islandQueue[head++];
                        const px = index % width;
                        const py = Math.floor(index / width);
                        if (px === minX || px === maxX || py === minY || py === maxY) enclosed = false;
                        if (data[index * 4 + 3] <= 10) enclosed = false;
                        if (px > minX) visitIslandNeighbor(index - 1);
                        if (px < maxX) visitIslandNeighbor(index + 1);
                        if (py > minY) visitIslandNeighbor(index - width);
                        if (py < maxY) visitIslandNeighbor(index + width);
                    }
                    if (enclosed && tail <= 8) {
                        for(let i = 0; i < tail; i++)pixels32[islandQueue[i]] = replacementColor32;
                    }
                }
            }
        }
    }
    ctx.putImageData(imgData, 0, 0);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/lightGizmoMath.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Direct-Manipulation Light Gizmo Spherical Coordinate Converter.
 *
 * Academic Citation:
 * Ben Shneiderman, "Direct Manipulation: A Step Beyond Programming Languages,"
 * Computer, Vol. 16, No. 8, pp. 57-69, 1983.
 *
 * Principles:
 * 1. Continuous visual representation of the directional light source.
 * 2. Physical pointer dragging instead of abstract angle syntax.
 * 3. Immediately visible, incremental, and reversible illumination state updates.
 */ __turbopack_context__.s([
    "computeArtworkCentroid",
    ()=>computeArtworkCentroid,
    "coordsToLightAngles",
    ()=>coordsToLightAngles,
    "lightAnglesToCoords",
    ()=>lightAnglesToCoords
]);
function coordsToLightAngles(hx, hy, cx, cy, maxRadius) {
    if (maxRadius <= 0) {
        return {
            azimuth: 0,
            elevation: 90
        };
    }
    const dx = hx - cx;
    const dy = hy - cy;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const distClamped = Math.min(dist, maxRadius);
    // At center origin, light shines from zenith (90° elevation)
    if (dist < 1e-6) {
        return {
            azimuth: 0,
            elevation: 90
        };
    }
    // Azimuth: Angle in degrees clockwise from North (dx = r*sin(az), -dy = r*cos(az))
    const azRad = Math.atan2(dx, -dy);
    const azDeg = Math.round((azRad * 180 / Math.PI + 360) % 360);
    // Elevation: Linear radial projection (0 at center -> 90° overhead; maxRadius at edge -> 0° grazing)
    const elDeg = Math.round((1 - distClamped / maxRadius) * 90);
    return {
        azimuth: azDeg % 360,
        elevation: Math.max(0, Math.min(90, elDeg))
    };
}
function lightAnglesToCoords(azimuth, elevation, cx, cy, maxRadius) {
    const safeElev = Math.max(0, Math.min(90, elevation));
    const r = maxRadius * (1 - safeElev / 90);
    const azRad = azimuth * Math.PI / 180;
    const x = cx + r * Math.sin(azRad);
    const y = cy - r * Math.cos(azRad);
    return {
        x,
        y
    };
}
function computeArtworkCentroid(data, width, height) {
    let count = 0;
    let sumX = 0;
    let sumY = 0;
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            const a = data[(y * width + x) * 4 + 3];
            if (a > 30) {
                count++;
                sumX += x;
                sumY += y;
            }
        }
    }
    if (count === 0) {
        return {
            x: Math.round(width / 2),
            y: Math.round(height / 2)
        };
    }
    return {
        x: Math.round(sumX / count),
        y: Math.round(sumY / count)
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/rasterMath.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applySymmetry",
    ()=>applySymmetry,
    "filterPixelPerfect",
    ()=>filterPixelPerfect,
    "getBresenhamLine",
    ()=>getBresenhamLine,
    "getClippedLine",
    ()=>getClippedLine,
    "getDDALine",
    ()=>getDDALine,
    "getEllipsePoints",
    ()=>getEllipsePoints,
    "getRectanglePoints",
    ()=>getRectanglePoints
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/mathInvariants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$wallpaperSymmetry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/wallpaperSymmetry.ts [app-client] (ecmascript)");
// Re-export Bezier curve, isometric helpers, and wallpaper group symmetry
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$smartMathEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/smartMathEngine.ts [app-client] (ecmascript) <locals>");
;
function getBresenhamLine(x0, y0, x1, y1) {
    if (![
        x0,
        y0,
        x1,
        y1
    ].every(Number.isSafeInteger)) {
        throw new RangeError('Bresenham line endpoints must be safe integers.');
    }
    const points = [];
    const dx = Math.abs(x1 - x0);
    const dy = Math.abs(y1 - y0);
    const maxSteps = Math.max(dx, dy) + 1;
    if (!Number.isSafeInteger(maxSteps) || maxSteps > 1_000_000) {
        throw new RangeError('Bresenham line exceeds the supported point count.');
    }
    const sx = x0 < x1 ? 1 : -1;
    const sy = y0 < y1 ? 1 : -1;
    let err = dx - dy;
    let currX = x0;
    let currY = y0;
    for(let step = 0; step < maxSteps; step++){
        points.push({
            x: currX,
            y: currY
        });
        if (currX === x1 && currY === y1) break;
        const e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            currX += sx;
        }
        if (e2 < dx) {
            err += dx;
            currY += sy;
        }
    }
    if (currX !== x1 || currY !== y1) {
        throw new Error('Bresenham line did not reach its endpoint within the step bound.');
    }
    return points;
}
function getDDALine(x0, y0, x1, y1) {
    const points = [];
    const dx = x1 - x0;
    const dy = y1 - y0;
    const steps = Math.round(Math.max(Math.abs(dx), Math.abs(dy)));
    if (steps === 0) {
        return [
            {
                x: Math.round(x0),
                y: Math.round(y0)
            }
        ];
    }
    const xInc = dx / steps;
    const yInc = dy / steps;
    let currX = x0;
    let currY = y0;
    for(let i = 0; i <= steps; i++){
        points.push({
            x: Math.round(currX),
            y: Math.round(currY)
        });
        currX += xInc;
        currY += yInc;
    }
    return points;
}
function getClippedLine(x0, y0, x1, y1, canvasWidth, canvasHeight) {
    if (!canvasWidth || !canvasHeight || canvasWidth <= 0 || canvasHeight <= 0) {
        return [
            x0,
            y0,
            x1,
            y1
        ].every(Number.isSafeInteger) ? getBresenhamLine(x0, y0, x1, y1) : getDDALine(x0, y0, x1, y1);
    }
    const isOutside = x0 < 0 || y0 < 0 || x0 >= canvasWidth || y0 >= canvasHeight || x1 < 0 || y1 < 0 || x1 >= canvasWidth || y1 >= canvasHeight;
    if (!isOutside) {
        return [
            x0,
            y0,
            x1,
            y1
        ].every(Number.isSafeInteger) ? getBresenhamLine(x0, y0, x1, y1) : getDDALine(x0, y0, x1, y1);
    }
    const clipped = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MathInvariants"].clipLineToCanvasSubpixel(x0, y0, x1, y1, canvasWidth, canvasHeight);
    if (!clipped) return [];
    return getDDALine(clipped.x0, clipped.y0, clipped.x1, clipped.y1);
}
function filterPixelPerfect(points) {
    if (points.length < 3) return points;
    const result = [
        points[0]
    ];
    for(let i = 1; i < points.length - 1; i++){
        const prev = result[result.length - 1];
        const curr = points[i];
        const next = points[i + 1];
        // Check if the current point forms an unwanted L-corner with identical step directions
        const sameRowOrColAsPrev = prev.x === curr.x || prev.y === curr.y;
        const sameRowOrColAsNext = curr.x === next.x || curr.y === next.y;
        if (sameRowOrColAsPrev && sameRowOrColAsNext && prev.x !== next.x && prev.y !== next.y) {
            // Ensure 8-way diagonal connectivity between prev and next before skipping
            const dx = Math.abs(next.x - prev.x);
            const dy = Math.abs(next.y - prev.y);
            if (dx <= 1 && dy <= 1) {
                continue;
            }
        }
        result.push(curr);
    }
    result.push(points[points.length - 1]);
    return result;
}
function getEllipsePoints(x0, y0, x1, y1, filled) {
    const points = [];
    const rx = Math.abs(Math.floor((x1 - x0) / 2));
    const ry = Math.abs(Math.floor((y1 - y0) / 2));
    const xc = Math.min(x0, x1) + rx;
    const yc = Math.min(y0, y1) + ry;
    if (rx === 0 || ry === 0) {
        return getBresenhamLine(x0, y0, x1, y1);
    }
    if (filled) {
        for(let y = -ry; y <= ry; y++){
            for(let x = -rx; x <= rx; x++){
                if (x * x / (rx * rx) + y * y / (ry * ry) <= 1) {
                    points.push({
                        x: xc + x,
                        y: yc + y
                    });
                }
            }
        }
        return points;
    }
    // Outline ellipse
    let x = 0;
    let y = ry;
    let d1 = ry * ry - rx * rx * ry + 0.25 * rx * rx;
    let dx = 2 * ry * ry * x;
    let dy = 2 * rx * rx * y;
    while(dx < dy){
        points.push({
            x: xc + x,
            y: yc + y
        });
        points.push({
            x: xc - x,
            y: yc + y
        });
        points.push({
            x: xc + x,
            y: yc - y
        });
        points.push({
            x: xc - x,
            y: yc - y
        });
        if (d1 < 0) {
            x++;
            dx += 2 * ry * ry;
            d1 += dx + ry * ry;
        } else {
            x++;
            y--;
            dx += 2 * ry * ry;
            dy -= 2 * rx * rx;
            d1 += dx - dy + ry * ry;
        }
    }
    let d2 = ry * ry * ((x + 0.5) * (x + 0.5)) + rx * rx * ((y - 1) * (y - 1)) - rx * rx * ry * ry;
    while(y >= 0){
        points.push({
            x: xc + x,
            y: yc + y
        });
        points.push({
            x: xc - x,
            y: yc + y
        });
        points.push({
            x: xc + x,
            y: yc - y
        });
        points.push({
            x: xc - x,
            y: yc - y
        });
        if (d2 > 0) {
            y--;
            dy -= 2 * rx * rx;
            d2 += rx * rx - dy;
        } else {
            y--;
            x++;
            dx += 2 * ry * ry;
            dy -= 2 * rx * rx;
            d2 += dx - dy + rx * rx;
        }
    }
    return points;
}
function getRectanglePoints(x0, y0, x1, y1, filled) {
    const points = [];
    const minX = Math.min(x0, x1);
    const maxX = Math.max(x0, x1);
    const minY = Math.min(y0, y1);
    const maxY = Math.max(y0, y1);
    if (filled) {
        for(let y = minY; y <= maxY; y++){
            for(let x = minX; x <= maxX; x++){
                points.push({
                    x,
                    y
                });
            }
        }
    } else {
        for(let x = minX; x <= maxX; x++){
            points.push({
                x,
                y: minY
            });
            points.push({
                x,
                y: maxY
            });
        }
        for(let y = minY + 1; y < maxY; y++){
            points.push({
                x: minX,
                y
            });
            points.push({
                x: maxX,
                y
            });
        }
    }
    return points;
}
;
function applySymmetry(points, width, height, symH, symV, wallpaperGroup = 'none') {
    if (wallpaperGroup && wallpaperGroup !== 'none') {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$wallpaperSymmetry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyWallpaperSymmetry"])(points, width, height, wallpaperGroup);
    }
    if (!symH && !symV) return points;
    const pointSet = new Set();
    const result = [];
    const addPoint = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return;
        const key = y * width + x;
        if (!pointSet.has(key)) {
            pointSet.add(key);
            result.push({
                x,
                y
            });
        }
    };
    for (const pt of points){
        addPoint(pt.x, pt.y);
        if (symH) {
            addPoint(width - 1 - pt.x, pt.y);
        }
        if (symV) {
            addPoint(pt.x, height - 1 - pt.y);
        }
        if (symH && symV) {
            addPoint(width - 1 - pt.x, height - 1 - pt.y);
        }
    }
    return result;
}
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/rotSprite.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * RotSprite-inspired pixel-art rotation. The canonical rotation-offset search
 * and single-pixel detail-restoration pass are not implemented here.
 *
 * Academic & Historical Reference:
 * - Xenowhirl (2007), "RotSprite: An algorithm for rotating pixel art" (as popularized in Aseprite).
 * - Eric Johnston, EPX (Eric's Pixel Expansion), LucasArts, 1992.
 * - Andrea Mazzoleni, Scale2x for AdvanceMAME, 2001 (equivalent output to EPX).
 *   https://www.scale2x.it/scale2xandepx
 *
 * Architecture:
 * 1. Lossless integer fast-paths for 0°, 90°, 180°, 270°.
 * 2. 3-pass Scale2x / EPX expansion (1x -> 2x -> 4x -> 8x) respecting color similarity thresholds.
 * 3. Inverse affine point sampling on the 8x raster with subpixel center alignment.
 * 4. Parabolic center-weighted majority voting downscaler (8x -> 1x) that strictly preserves
 *    original palette colors (0 new color artifacts) and preserves single-pixel line continuity.
 */ __turbopack_context__.s([
    "colorDistance32",
    ()=>colorDistance32,
    "downscale8xMajorityVote",
    ()=>downscale8xMajorityVote,
    "rotSprite",
    ()=>rotSprite,
    "rotateNearest",
    ()=>rotateNearest,
    "scale2x",
    ()=>scale2x,
    "scale8x",
    ()=>scale8x
]);
function colorDistance32(c1, c2) {
    if (c1 === c2) return 0;
    const a1 = c1 >>> 24 & 0xff;
    const a2 = c2 >>> 24 & 0xff;
    if (a1 < 16 && a2 < 16) return 0;
    if (Math.abs(a1 - a2) > 64) return 10000;
    const r1 = c1 & 0xff, g1 = c1 >>> 8 & 0xff, b1 = c1 >>> 16 & 0xff;
    const r2 = c2 & 0xff, g2 = c2 >>> 8 & 0xff, b2 = c2 >>> 16 & 0xff;
    return Math.abs(r1 - r2) + Math.abs(g1 - g2) + Math.abs(b1 - b2);
}
function scale2x(src, similarityThreshold = 0) {
    const { width: curW, height: curH, data: srcBytes } = src;
    const outW = curW * 2;
    const outH = curH * 2;
    const outBytes = new Uint8ClampedArray(outW * outH * 4);
    const src32 = new Uint32Array(srcBytes.buffer, srcBytes.byteOffset, curW * curH);
    const out32 = new Uint32Array(outBytes.buffer, outBytes.byteOffset, outW * outH);
    const getPx = (x, y)=>{
        if (x < 0 || x >= curW || y < 0 || y >= curH) {
            return src32[Math.min(curH - 1, Math.max(0, y)) * curW + Math.min(curW - 1, Math.max(0, x))];
        }
        return src32[y * curW + x];
    };
    const dist = colorDistance32;
    for(let y = 0; y < curH; y++){
        for(let x = 0; x < curW; x++){
            const P = src32[y * curW + x];
            const B = getPx(x, y - 1);
            const D = getPx(x - 1, y);
            const F = getPx(x + 1, y);
            const H = getPx(x, y + 1);
            let e0 = P;
            let e1 = P;
            let e2 = P;
            let e3 = P;
            // Scale2x rule: if opposite neighbors differ and adjacent neighbors match
            if (dist(B, H) > similarityThreshold && dist(D, F) > similarityThreshold) {
                if (dist(D, B) <= similarityThreshold) {
                    e0 = dist(D, P) <= dist(B, P) ? D : B;
                }
                if (dist(B, F) <= similarityThreshold) {
                    e1 = dist(B, P) <= dist(F, P) ? B : F;
                }
                if (dist(D, H) <= similarityThreshold) {
                    e2 = dist(D, P) <= dist(H, P) ? D : H;
                }
                if (dist(H, F) <= similarityThreshold) {
                    e3 = dist(H, P) <= dist(F, P) ? H : F;
                }
            }
            const outBase = y * 2 * outW + x * 2;
            out32[outBase] = e0;
            out32[outBase + 1] = e1;
            out32[outBase + outW] = e2;
            out32[outBase + outW + 1] = e3;
        }
    }
    return {
        width: outW,
        height: outH,
        data: outBytes
    };
}
function scale8x(src, similarityThreshold = 0) {
    const p1 = scale2x(src, similarityThreshold);
    const p2 = scale2x(p1, similarityThreshold);
    return scale2x(p2, similarityThreshold);
}
function rotateNearest(src, angleRad, pivotX, pivotY) {
    const { width: w, height: h, data } = src;
    const outBytes = new Uint8ClampedArray(w * h * 4);
    const src32 = new Uint32Array(data.buffer, data.byteOffset, w * h);
    const out32 = new Uint32Array(outBytes.buffer, outBytes.byteOffset, w * h);
    const cx = pivotX ?? w / 2;
    const cy = pivotY ?? h / 2;
    const cos = Math.cos(-angleRad);
    const sin = Math.sin(-angleRad);
    for(let y = 0; y < h; y++){
        for(let x = 0; x < w; x++){
            const dx = x + 0.5 - cx;
            const dy = y + 0.5 - cy;
            const sx = Math.floor(cos * dx - sin * dy + cx);
            const sy = Math.floor(sin * dx + cos * dy + cy);
            if (sx >= 0 && sx < w && sy >= 0 && sy < h) {
                out32[y * w + x] = src32[sy * w + sx];
            } else {
                out32[y * w + x] = 0;
            }
        }
    }
    return {
        width: w,
        height: h,
        data: outBytes
    };
}
function downscale8xMajorityVote(src8x, targetW, targetH, angleRad, srcPivotX, srcPivotY, outPivotX = srcPivotX, outPivotY = srcPivotY) {
    const outBytes = new Uint8ClampedArray(targetW * targetH * 4);
    const out32 = new Uint32Array(outBytes.buffer, outBytes.byteOffset, targetW * targetH);
    const s8Bytes = src8x.data;
    const s8_32 = new Uint32Array(s8Bytes.buffer, s8Bytes.byteOffset, src8x.width * src8x.height);
    const w8 = src8x.width;
    const h8 = src8x.height;
    const cos = Math.cos(-angleRad);
    const sin = Math.sin(-angleRad);
    // 8 subpixel offset coordinates within each 1x pixel cell
    const SUB_OFFSETS = [
        -3.5,
        -2.5,
        -1.5,
        -0.5,
        0.5,
        1.5,
        2.5,
        3.5
    ];
    for(let y = 0; y < targetH; y++){
        for(let x = 0; x < targetW; x++){
            const px = x + 0.5;
            const py = y + 0.5;
            const votes = new Map();
            let nonTransparentWeight = 0;
            let totalWeight = 0;
            let centerCoreWeight = 0;
            for(let vi = 0; vi < 8; vi++){
                const v = SUB_OFFSETS[vi];
                for(let ui = 0; ui < 8; ui++){
                    const u = SUB_OFFSETS[ui];
                    // Continuous inverse rotation from output canvas to 1x source coordinates
                    const dx = px + u / 8 - outPivotX;
                    const dy = py + v / 8 - outPivotY;
                    const sx = cos * dx - sin * dy + srcPivotX;
                    const sy = sin * dx + cos * dy + srcPivotY;
                    // Map to 8x scale raster with epsilon
                    const sx8 = Math.floor(sx * 8 + 1e-9);
                    const sy8 = Math.floor(sy * 8 + 1e-9);
                    // Radially symmetric parabolic center-weighted falloff
                    const distSq = u * u + v * v;
                    const weight = 1.0 + 0.01 * (25 - distSq);
                    totalWeight += weight;
                    let color = 0;
                    if (sx8 >= 0 && sx8 < w8 && sy8 >= 0 && sy8 < h8) {
                        color = s8_32[sy8 * w8 + sx8];
                    }
                    if (color >>> 24 !== 0) {
                        votes.set(color, (votes.get(color) || 0) + weight);
                        nonTransparentWeight += weight;
                        if ((ui === 3 || ui === 4) && (vi === 3 || vi === 4)) {
                            centerCoreWeight += weight;
                        }
                    }
                }
            }
            // Feature conservation threshold:
            // Preserves 1px thin lines if center core touches solid pixels,
            // otherwise requires solid majority to prevent border dilation.
            const dynamicThreshold = centerCoreWeight > 0 ? 0.20 : 0.38;
            if (nonTransparentWeight >= totalWeight * dynamicThreshold && votes.size > 0) {
                let bestColor = 0;
                let maxVote = -1;
                votes.forEach((vote, color)=>{
                    if (vote > maxVote) {
                        maxVote = vote;
                        bestColor = color;
                    }
                });
                out32[y * targetW + x] = bestColor;
            } else {
                out32[y * targetW + x] = 0;
            }
        }
    }
    return {
        width: targetW,
        height: targetH,
        data: outBytes
    };
}
/** Keep source-only border colors on the rotated silhouette boundary. */ function restoreRotatedContourColors(source, output, angleRad, sourcePivotX, sourcePivotY, outputPivotX, outputPivotY) {
    const { width: sw, height: sh } = source;
    const { width: ow, height: oh } = output;
    const src32 = new Uint32Array(source.data.buffer, source.data.byteOffset, sw * sh);
    const out32 = new Uint32Array(output.data.buffer, output.data.byteOffset, ow * oh);
    const sourceClass = new Uint8Array(sw * sh);
    const colorClasses = new Map();
    const maxClassifiedColors = 4096;
    const solid = (x, y)=>x >= 0 && y >= 0 && x < sw && y < sh && src32[y * sw + x] >>> 24 !== 0;
    for(let y = 0; y < sh; y++)for(let x = 0; x < sw; x++){
        const index = y * sw + x;
        const color = src32[index];
        if (color >>> 24 === 0) continue;
        const kind = solid(x - 1, y) && solid(x + 1, y) && solid(x, y - 1) && solid(x, y + 1) ? 2 : 1;
        sourceClass[index] = kind;
        colorClasses.set(color, (colorClasses.get(color) ?? 0) | kind);
        if (colorClasses.size > maxClassifiedColors) return output;
    }
    let hasBorderOnly = false;
    let hasInteriorOnly = false;
    for (const kind of colorClasses.values()){
        if (kind === 1) hasBorderOnly = true;
        if (kind === 2) hasInteriorOnly = true;
    }
    if (!hasBorderOnly || !hasInteriorOnly) return output;
    const cos = Math.cos(-angleRad);
    const sin = Math.sin(-angleRad);
    const outputSolid = (x, y)=>x >= 0 && y >= 0 && x < ow && y < oh && out32[y * ow + x] >>> 24 !== 0;
    for(let y = 0; y < oh; y++)for(let x = 0; x < ow; x++){
        const index = y * ow + x;
        const color = out32[index];
        if (color >>> 24 === 0) continue;
        const kind = outputSolid(x - 1, y) && outputSolid(x + 1, y) && outputSolid(x, y - 1) && outputSolid(x, y + 1) ? 2 : 1;
        if (colorClasses.get(color) !== (kind === 1 ? 2 : 1)) continue;
        const dx = x + 0.5 - outputPivotX;
        const dy = y + 0.5 - outputPivotY;
        const sx = cos * dx - sin * dy + sourcePivotX;
        const sy = sin * dx + cos * dy + sourcePivotY;
        let nearest = -1;
        let distance = Infinity;
        for(let yy = Math.floor(sy) - 2; yy <= Math.floor(sy) + 2; yy++){
            for(let xx = Math.floor(sx) - 2; xx <= Math.floor(sx) + 2; xx++){
                if (xx < 0 || yy < 0 || xx >= sw || yy >= sh) continue;
                const candidate = yy * sw + xx;
                if (sourceClass[candidate] !== kind || colorClasses.get(src32[candidate]) !== kind) continue;
                const d = (xx + 0.5 - sx) ** 2 + (yy + 0.5 - sy) ** 2;
                if (d < distance) {
                    distance = d;
                    nearest = candidate;
                }
            }
        }
        if (nearest >= 0) {
            out32[index] = src32[nearest] & 0x00ffffff | color & 0xff000000;
        }
    }
    return output;
}
function rotSprite(src, angleRad, pivotX, pivotY, targetW, targetH, outPivotX, outPivotY) {
    const { width: w, height: h, data } = src;
    const EPSILON = 1e-5;
    const TWO_PI = Math.PI * 2;
    const normAngle = (angleRad % TWO_PI + TWO_PI) % TWO_PI;
    const isNear = (target)=>Math.abs(normAngle - target) < EPSILON;
    const isQuarterTurn = isNear(Math.PI / 2) || isNear(3 * Math.PI / 2);
    const outW = targetW ?? (isQuarterTurn ? h : w);
    const outH = targetH ?? (isQuarterTurn ? w : h);
    if (w <= 0 || h <= 0 || data.length === 0) {
        const safeW = Math.max(1, outW);
        const safeH = Math.max(1, outH);
        return {
            width: safeW,
            height: safeH,
            data: new Uint8ClampedArray(safeW * safeH * 4)
        };
    }
    const cx = pivotX ?? w / 2;
    const cy = pivotY ?? h / 2;
    const ocx = outPivotX ?? cx;
    const ocy = outPivotY ?? cy;
    // Explicit destination geometry (selection/layer transforms) can still use
    // exact integer quarter turns, even when the crop and pivot are off-center.
    if (targetW !== undefined && targetH !== undefined && outPivotX !== undefined && outPivotY !== undefined && (isNear(0) || isNear(Math.PI / 2) || isNear(Math.PI) || isNear(3 * Math.PI / 2))) {
        const quarter = isNear(Math.PI / 2) ? 1 : isNear(Math.PI) ? 2 : isNear(3 * Math.PI / 2) ? 3 : 0;
        const outBytes = new Uint8ClampedArray(outW * outH * 4);
        for(let y = 0; y < h; y++){
            for(let x = 0; x < w; x++){
                const dx = x + 0.5 - cx;
                const dy = y + 0.5 - cy;
                const rx = quarter === 0 ? dx : quarter === 1 ? -dy : quarter === 2 ? -dx : dy;
                const ry = quarter === 0 ? dy : quarter === 1 ? dx : quarter === 2 ? -dy : -dx;
                const ox = Math.floor(rx + ocx);
                const oy = Math.floor(ry + ocy);
                if (ox >= 0 && ox < outW && oy >= 0 && oy < outH) {
                    const sourceOffset = (y * w + x) * 4;
                    outBytes.set(data.subarray(sourceOffset, sourceOffset + 4), (oy * outW + ox) * 4);
                }
            }
        }
        return {
            width: outW,
            height: outH,
            data: outBytes
        };
    }
    // 1. Lossless fast-paths for exact orthogonal 90-degree multiples when output dimensions match
    if ((isNear(0) || isNear(TWO_PI)) && outW === w && outH === h) {
        const copy = new Uint8ClampedArray(data.length);
        copy.set(data);
        return {
            width: w,
            height: h,
            data: copy
        };
    }
    if (isNear(Math.PI) && outW === w && outH === h && Math.abs(cx - w / 2) < EPSILON && Math.abs(cy - h / 2) < EPSILON) {
        const outBytes = new Uint8ClampedArray(w * h * 4);
        const src32 = new Uint32Array(data.buffer, data.byteOffset, w * h);
        const out32 = new Uint32Array(outBytes.buffer, outBytes.byteOffset, w * h);
        for(let y = 0; y < h; y++){
            for(let x = 0; x < w; x++){
                out32[(h - 1 - y) * w + (w - 1 - x)] = src32[y * w + x];
            }
        }
        return {
            width: w,
            height: h,
            data: outBytes
        };
    }
    if (isNear(Math.PI / 2) && outW === h && outH === w && Math.abs(cx - w / 2) < EPSILON && Math.abs(cy - h / 2) < EPSILON) {
        const outBytes = new Uint8ClampedArray(w * h * 4);
        const src32 = new Uint32Array(data.buffer, data.byteOffset, w * h);
        const out32 = new Uint32Array(outBytes.buffer, outBytes.byteOffset, w * h);
        for(let y = 0; y < h; y++){
            for(let x = 0; x < w; x++){
                out32[x * h + (h - 1 - y)] = src32[y * w + x];
            }
        }
        return {
            width: h,
            height: w,
            data: outBytes
        };
    }
    if (isNear(3 * Math.PI / 2) && outW === h && outH === w && Math.abs(cx - w / 2) < EPSILON && Math.abs(cy - h / 2) < EPSILON) {
        const outBytes = new Uint8ClampedArray(w * h * 4);
        const src32 = new Uint32Array(data.buffer, data.byteOffset, w * h);
        const out32 = new Uint32Array(outBytes.buffer, outBytes.byteOffset, w * h);
        for(let y = 0; y < h; y++){
            for(let x = 0; x < w; x++){
                out32[(w - 1 - x) * h + y] = src32[y * w + x];
            }
        }
        return {
            width: h,
            height: w,
            data: outBytes
        };
    }
    if (isNear(Math.PI / 2) && outW === w && outH === h && Math.abs(cx - w / 2) < EPSILON && Math.abs(cy - h / 2) < EPSILON) {
        const outBytes = new Uint8ClampedArray(w * h * 4);
        const src32 = new Uint32Array(data.buffer, data.byteOffset, w * h);
        const out32 = new Uint32Array(outBytes.buffer, outBytes.byteOffset, w * h);
        for(let y = 0; y < h; y++){
            for(let x = 0; x < w; x++){
                const sx = Math.floor(cx + (y - ocy));
                const sy = Math.floor(cy - (x - ocx));
                if (sx >= 0 && sx < w && sy >= 0 && sy < h) {
                    out32[y * w + x] = src32[sy * w + sx];
                }
            }
        }
        return {
            width: w,
            height: h,
            data: outBytes
        };
    }
    if (isNear(3 * Math.PI / 2) && outW === w && outH === h && Math.abs(cx - w / 2) < EPSILON && Math.abs(cy - h / 2) < EPSILON) {
        const outBytes = new Uint8ClampedArray(w * h * 4);
        const src32 = new Uint32Array(data.buffer, data.byteOffset, w * h);
        const out32 = new Uint32Array(outBytes.buffer, outBytes.byteOffset, w * h);
        for(let y = 0; y < h; y++){
            for(let x = 0; x < w; x++){
                const sx = Math.floor(cx - (y - ocy));
                const sy = Math.floor(cy + (x - ocx));
                if (sx >= 0 && sx < w && sy >= 0 && sy < h) {
                    out32[y * w + x] = src32[sy * w + sx];
                }
            }
        }
        return {
            width: w,
            height: h,
            data: outBytes
        };
    }
    // 2. Perform 3-pass Scale2x cascade to 8x
    const src8x = scale8x(src);
    // 3. Downscale using subpixel inverse rotation and center-weighted Gaussian majority voting
    const rotated = downscale8xMajorityVote(src8x, outW, outH, angleRad, cx, cy, ocx, ocy);
    return restoreRotatedContourColors(src, rotated, angleRad, cx, cy, ocx, ocy);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/rotSpriteLayer.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAX_ROTSPRITE_SOURCE_PIXELS",
    ()=>MAX_ROTSPRITE_SOURCE_PIXELS,
    "planLayerRotation",
    ()=>planLayerRotation
]);
const MAX_ROTSPRITE_SOURCE_PIXELS = 512 * 512;
function planLayerRotation(fullLayer, angleRad) {
    const { width, height, data } = fullLayer;
    if (!Number.isFinite(angleRad) || data.length !== width * height * 4) {
        return {
            error: 'The layer cannot be rotated because its pixels or angle are invalid.'
        };
    }
    let minX = width, minY = height, maxX = -1, maxY = -1;
    for(let y = 0; y < height; y++){
        for(let x = 0; x < width; x++){
            if (data[(y * width + x) * 4 + 3] === 0) continue;
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
        }
    }
    if (maxX < minX) return {};
    const sourceWidth = maxX - minX + 1;
    const sourceHeight = maxY - minY + 1;
    if (sourceWidth * sourceHeight > MAX_ROTSPRITE_SOURCE_PIXELS) {
        return {
            error: 'This artwork is too large for clean rotation. Select a smaller area first.'
        };
    }
    const pivotX = width / 2;
    const pivotY = height / 2;
    const cos = Math.cos(angleRad);
    const sin = Math.sin(angleRad);
    const corners = [
        [
            minX,
            minY
        ],
        [
            maxX + 1,
            minY
        ],
        [
            minX,
            maxY + 1
        ],
        [
            maxX + 1,
            maxY + 1
        ]
    ].map(([x, y])=>({
            x: pivotX + cos * (x - pivotX) - sin * (y - pivotY),
            y: pivotY + sin * (x - pivotX) + cos * (y - pivotY)
        }));
    const destX = Math.floor(Math.min(...corners.map((point)=>point.x)));
    const destY = Math.floor(Math.min(...corners.map((point)=>point.y)));
    const endX = Math.ceil(Math.max(...corners.map((point)=>point.x)));
    const endY = Math.ceil(Math.max(...corners.map((point)=>point.y)));
    if (destX < 0 || destY < 0 || endX > width || endY > height) {
        return {
            error: 'Rotation would clip artwork. Enlarge the canvas or rotate a smaller selection first.'
        };
    }
    const cropped = new Uint8ClampedArray(sourceWidth * sourceHeight * 4);
    for(let y = 0; y < sourceHeight; y++){
        const start = ((minY + y) * width + minX) * 4;
        cropped.set(data.subarray(start, start + sourceWidth * 4), y * sourceWidth * 4);
    }
    return {
        plan: {
            source: {
                width: sourceWidth,
                height: sourceHeight,
                data: cropped
            },
            sourcePivotX: pivotX - minX,
            sourcePivotY: pivotY - minY,
            targetWidth: endX - destX,
            targetHeight: endY - destY,
            outputPivotX: pivotX - destX,
            outputPivotY: pivotY - destY,
            destX,
            destY
        }
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/selectionUtils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Pure selection mask operations (Union, Subtract, Replace, Box Mask extraction).
 */ __turbopack_context__.s([
    "boundarySegmentsToSvgPath",
    ()=>boundarySegmentsToSvgPath,
    "createBoxMask",
    ()=>createBoxMask,
    "extractSelectionBoundarySegments",
    ()=>extractSelectionBoundarySegments,
    "mergeSelectionMask",
    ()=>mergeSelectionMask
]);
function mergeSelectionMask(baseMask, incomingMask, mode, canvasWidth, canvasHeight) {
    const total = canvasWidth * canvasHeight;
    const resultMask = new Uint8Array(total);
    const effectiveBase = mode !== 'replace' && baseMask ? baseMask : null;
    let minX = canvasWidth;
    let minY = canvasHeight;
    let maxX = -1;
    let maxY = -1;
    let count = 0;
    for(let i = 0; i < total; i++){
        const baseVal = effectiveBase ? effectiveBase[i] : 0;
        const incVal = incomingMask[i];
        let finalVal = 0;
        if (mode === 'union') {
            finalVal = baseVal === 1 || incVal === 1 ? 1 : 0;
        } else if (mode === 'subtract') {
            finalVal = baseVal === 1 && incVal === 0 ? 1 : 0;
        } else {
            finalVal = incVal;
        }
        resultMask[i] = finalVal;
        if (finalVal === 1) {
            count++;
            const px = i % canvasWidth;
            const py = Math.floor(i / canvasWidth);
            if (px < minX) minX = px;
            if (px > maxX) maxX = px;
            if (py < minY) minY = py;
            if (py > maxY) maxY = py;
        }
    }
    if (count > 0 && maxX >= minX && maxY >= minY) {
        return {
            box: {
                x: minX,
                y: minY,
                w: maxX - minX + 1,
                h: maxY - minY + 1
            },
            mask: resultMask
        };
    }
    return {
        box: null,
        mask: null
    };
}
function createBoxMask(box, width, height) {
    const mask = new Uint8Array(width * height);
    const endX = Math.min(width, box.x + box.w);
    const endY = Math.min(height, box.y + box.h);
    for(let y = Math.max(0, box.y); y < endY; y++){
        for(let x = Math.max(0, box.x); x < endX; x++){
            mask[y * width + x] = 1;
        }
    }
    return mask;
}
function extractSelectionBoundarySegments(mask, width, height) {
    const segments = [];
    const isSelected = (x, y)=>{
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return mask[y * width + x] === 1;
    };
    // 1. Horizontal Edges (Top & Bottom of selected pixels)
    // For each horizontal line y from 0 to height:
    for(let y = 0; y <= height; y++){
        let startX = null;
        let inEdge = false;
        for(let x = 0; x < width; x++){
            const above = isSelected(x, y - 1);
            const below = isSelected(x, y);
            const hasEdge = above !== below;
            if (hasEdge) {
                if (!inEdge) {
                    inEdge = true;
                    startX = x;
                }
            } else {
                if (inEdge && startX !== null) {
                    segments.push({
                        x1: startX,
                        y1: y,
                        x2: x,
                        y2: y
                    });
                    inEdge = false;
                    startX = null;
                }
            }
        }
        if (inEdge && startX !== null) {
            segments.push({
                x1: startX,
                y1: y,
                x2: width,
                y2: y
            });
        }
    }
    // 2. Vertical Edges (Left & Right of selected pixels)
    // For each vertical line x from 0 to width:
    for(let x = 0; x <= width; x++){
        let startY = null;
        let inEdge = false;
        for(let y = 0; y < height; y++){
            const left = isSelected(x - 1, y);
            const right = isSelected(x, y);
            const hasEdge = left !== right;
            if (hasEdge) {
                if (!inEdge) {
                    inEdge = true;
                    startY = y;
                }
            } else {
                if (inEdge && startY !== null) {
                    segments.push({
                        x1: x,
                        y1: startY,
                        x2: x,
                        y2: y
                    });
                    inEdge = false;
                    startY = null;
                }
            }
        }
        if (inEdge && startY !== null) {
            segments.push({
                x1: x,
                y1: startY,
                x2: x,
                y2: height
            });
        }
    }
    return segments;
}
function boundarySegmentsToSvgPath(segments, scale = 1) {
    if (segments.length === 0) return '';
    return segments.map((s)=>`M ${(s.x1 * scale).toFixed(2)} ${(s.y1 * scale).toFixed(2)} L ${(s.x2 * scale).toFixed(2)} ${(s.y2 * scale).toFixed(2)}`).join(' ');
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/wallpaperSymmetry.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * 17 Wallpaper Groups & Crystallographic Plane Symmetry Brush Engine.
 *
 * Academic Citation:
 * Doris Schattschneider, "The Plane Symmetry Groups: Their Recognition and Notation,"
 * The American Mathematical Monthly, Vol. 85, No. 6, pp. 439-450, 1978.
 *
 * Mathematical Foundations:
 * The 17 planar crystallographic groups describe the discrete isometries of 2D Euclidean space.
 * For finite local sprite and tilework operations, the fundamental point symmetry subgroups
 * of the wallpaper groups generate orbit sets under cyclic (Cn) and dihedral (Dn) actions:
 * - p2 (C2): 180° rotation around canvas centroid (2-fold rotocenter).
 * - pm (D1): Bilateral mirror reflection across the vertical axis.
 * - p4 (C4): 4-fold cyclic rotation (90°, 180°, 270° rotocenters).
 * - p4m (D4): 4-fold rotation with 4 reflection lines intersecting at 45° (8-way kaleidoscope).
 * - p6m (D6): 6-fold rotation with 6 reflection lines intersecting at 30° (12-way snowflake kaleidoscope).
 */ __turbopack_context__.s([
    "applyWallpaperSymmetry",
    ()=>applyWallpaperSymmetry,
    "replicatePointWallpaper",
    ()=>replicatePointWallpaper
]);
function replicatePointWallpaper(x, y, width, height, group) {
    if (group === 'none') {
        return [
            {
                x,
                y
            }
        ];
    }
    const cx = (width - 1) / 2;
    const cy = (height - 1) / 2;
    const u = x - cx;
    const v = y - cy;
    const points = [];
    const visited = new Set();
    const addPoint = (px, py)=>{
        const rx = Math.round(px);
        const ry = Math.round(py);
        if (rx >= 0 && rx < width && ry >= 0 && ry < height) {
            const key = ry * width + rx;
            if (!visited.has(key)) {
                visited.add(key);
                points.push({
                    x: rx,
                    y: ry
                });
            }
        }
    };
    // 1. Identity point
    addPoint(x, y);
    if (group === 'p2') {
        // 180° rotation around center
        addPoint(cx - u, cy - v);
    } else if (group === 'pm') {
        // Bilateral mirror across vertical centroid axis
        addPoint(cx - u, cy + v);
    } else if (group === 'p4') {
        // 90°, 180°, and 270° rotations
        addPoint(cx - v, cy + u); // 90°
        addPoint(cx - u, cy - v); // 180°
        addPoint(cx + v, cy - u); // 270°
    } else if (group === 'p4m') {
        // 4 Rotations (0°, 90°, 180°, 270°)
        addPoint(cx - v, cy + u);
        addPoint(cx - u, cy - v);
        addPoint(cx + v, cy - u);
        // 4 Reflections (vertical, horizontal, diagonal, anti-diagonal)
        addPoint(cx - u, cy + v);
        addPoint(cx + u, cy - v);
        addPoint(cx + v, cy + u);
        addPoint(cx - v, cy - v);
    } else if (group === 'p6m') {
        // 6 Rotations (multiples of 60°)
        for(let k = 1; k < 6; k++){
            const theta = k * Math.PI / 3;
            const cosT = Math.cos(theta);
            const sinT = Math.sin(theta);
            addPoint(cx + (u * cosT - v * sinT), cy + (u * sinT + v * cosT));
        }
        // 6 Reflections across axes spaced by 30°
        const nu = -u;
        for(let k = 0; k < 6; k++){
            const theta = k * Math.PI / 3;
            const cosT = Math.cos(theta);
            const sinT = Math.sin(theta);
            addPoint(cx + (nu * cosT - v * sinT), cy + (nu * sinT + v * cosT));
        }
    }
    return points;
}
function applyWallpaperSymmetry(points, width, height, group) {
    if (group === 'none') {
        return points;
    }
    const pointSet = new Set();
    const result = [];
    for (const pt of points){
        const orbit = replicatePointWallpaper(pt.x, pt.y, width, height, group);
        for (const op of orbit){
            const key = op.y * width + op.x;
            if (!pointSet.has(key)) {
                pointSet.add(key);
                result.push(op);
            }
        }
    }
    return result;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/collab/crdtPixelBuffer.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Last-Write-Wins Conflict-Free Replicated Data Type (LWW-CRDT) Pixel Buffer
 * with Hybrid Logical Clock (HLC) & Bounded Clock Drift Skew Protection.
 *
 * Algorithm References:
 * - Marc Shapiro, Nuno Preguiça, Carlos Baquero, Marek Zawirski,
 *   "Conflict-Free Replicated Data Types," Symposium on Self-Stabilizing
 *   Systems (SSS 2011), LNCS Vol. 6976, pp. 386-400.
 *   (Defines the LWW-Register CRDT used for per-pixel conflict resolution.)
 * - Sandeep S. Kulkarni, Murat Demirbas, Deepak Madappa, Bharadwaj Avva,
 *   Marcelo Leone, "Logical Physical Clocks," 18th International Conference
 *   on Principles of Distributed Systems (OPODIS 2014), LNCS Vol. 8878,
 *   pp. 17-32, Springer, 2014.
 *   (Defines the Hybrid Logical Clock mechanism used for causal ordering.)
 *
 * Design Philosophy:
 * - Martin Kleppmann, Adam Wiggins, Peter van Hardenberg, Mark McGranaghan,
 *   "Local-First Software: You Own Your Data, in spite of the Cloud,"
 *   ACM Onward! Essays, pp. 154-178, 2019.
 *   (Architectural motivation for the serverless, accountless, user-owned design.)
 *
 * Implements an accountless, serverless peer-to-peer co-drawing engine where every pixel
 * cell is modeled as an independent LWW-Register governed by a monotonic Hybrid Logical Clock
 * tuple (l, c) and deterministic peerId tie-breaking.
 *
 * Guarantees Strong Eventual Consistency (SEC) and causality tracking while remaining bounded
 * to physical wall-clock time within MAX_CLOCK_DRIFT_MS (60,000ms), actively rejecting rogue
 * or drifted remote updates from poisoning the logical physical clock.
 */ __turbopack_context__.s([
    "CrdtPixelBuffer",
    ()=>CrdtPixelBuffer,
    "MAX_CLOCK_DRIFT_MS",
    ()=>MAX_CLOCK_DRIFT_MS,
    "MAX_OP_LOG_SIZE",
    ()=>MAX_OP_LOG_SIZE
]);
const MAX_OP_LOG_SIZE = 10000;
const MAX_CLOCK_DRIFT_MS = 60000; // 60s bounded physical clock drift tolerance
class CrdtPixelBuffer {
    width;
    height;
    peerId;
    maxClockDriftMs;
    cells;
    hlc = [
        0,
        0
    ];
    opLog = [];
    /** Conservative estimate for JS cells, HLC tuples, peer strings and retained ops. */ get estimatedBytes() {
        return (this.cells.length + this.opLog.length) * 192;
    }
    constructor(width, height, peerId, maxClockDriftMs = MAX_CLOCK_DRIFT_MS){
        this.width = Math.max(1, width);
        this.height = Math.max(1, height);
        this.peerId = peerId;
        this.maxClockDriftMs = Math.max(0, maxClockDriftMs);
        const totalPixels = this.width * this.height;
        this.cells = new Array(totalPixels);
        for(let i = 0; i < totalPixels; i++){
            this.cells[i] = {
                r: 0,
                g: 0,
                b: 0,
                a: 0,
                timestamp: 0,
                hlc: [
                    0,
                    0
                ],
                peerId: ''
            };
        }
    }
    /**
   * Returns a copy of the current Hybrid Logical Clock tuple [l, c].
   */ getHlc() {
        return [
            this.hlc[0],
            this.hlc[1]
        ];
    }
    /**
   * Appends an op to the local log with a bounded sliding window to prevent unbounded memory growth.
   */ appendOpToLog(op) {
        this.opLog.push(op);
        if (this.opLog.length > MAX_OP_LOG_SIZE) {
            this.opLog.splice(0, this.opLog.length - MAX_OP_LOG_SIZE);
        }
    }
    /**
   * Generates a snapshot of all active pixel operations across the canvas,
   * enabling full canvas synchronization to newly joined peers.
   */ getStateSnapshotOps() {
        const snapshot = [];
        for(let y = 0; y < this.height; y++){
            for(let x = 0; x < this.width; x++){
                const cell = this.cells[y * this.width + x];
                if (cell.timestamp > 0 || cell.hlc[0] > 0 || cell.peerId !== '') {
                    snapshot.push({
                        x,
                        y,
                        r: cell.r,
                        g: cell.g,
                        b: cell.b,
                        a: cell.a,
                        timestamp: cell.timestamp,
                        hlc: [
                            cell.hlc[0],
                            cell.hlc[1]
                        ],
                        peerId: cell.peerId
                    });
                }
            }
        }
        return snapshot;
    }
    /**
   * Advances the local Hybrid Logical Clock for a send/local event (Kulkarni et al., 2014):
   * l' = max(l_old, pt)
   * if (l' == l_old) c' = c_old + 1 else c' = 0
   */ nextHlc() {
        const pt = Date.now();
        const lOld = this.hlc[0];
        const lNext = Math.max(lOld, pt);
        const cNext = lNext === lOld ? this.hlc[1] + 1 : 0;
        this.hlc = [
            lNext,
            cNext
        ];
        return this.hlc;
    }
    /**
   * Applies a local pixel write operation, advances the Hybrid Logical Clock,
   * updates the cell, logs the op, and returns the PixelOp to be broadcast.
   */ setPixel(x, y, color) {
        if (x < 0 || x >= this.width || y < 0 || y >= this.height) {
            return null;
        }
        const idx = y * this.width + x;
        const [l, c] = this.nextHlc();
        const op = {
            x,
            y,
            r: color[0],
            g: color[1],
            b: color[2],
            a: color[3],
            timestamp: l,
            hlc: [
                l,
                c
            ],
            peerId: this.peerId
        };
        this.cells[idx] = {
            r: op.r,
            g: op.g,
            b: op.b,
            a: op.a,
            timestamp: l,
            hlc: [
                l,
                c
            ],
            peerId: op.peerId
        };
        this.appendOpToLog(op);
        return op;
    }
    /**
   * Applies a remote pixel operation according to the LWW-CRDT rule:
   * 1. Check bounded clock drift skew (|remote.l - local.pt| <= MAX_CLOCK_DRIFT_MS).
   * 2. Synchronize local HLC according to Kulkarni/Demirbas receive rule.
   * 3. Higher (l, c) tuple wins; tie-break deterministically via lexicographical peerId.
   *
   * Returns true if the cell was updated, false if the incoming op was stale or rejected due to clock skew.
   */ applyRemoteOp(op) {
        if (!op || typeof op !== 'object' || typeof op.x !== 'number' || typeof op.y !== 'number' || op.x < 0 || op.x >= this.width || op.y < 0 || op.y >= this.height || typeof op.peerId !== 'string' || op.peerId.length === 0) {
            return false;
        }
        const remoteL = op.hlc ? op.hlc[0] : op.timestamp;
        const remoteC = op.hlc ? op.hlc[1] : 0;
        // Reject non-finite, NaN, or non-positive physical timestamps or invalid counters
        if (typeof remoteL !== 'number' || !Number.isFinite(remoteL) || remoteL <= 0 || typeof remoteC !== 'number' || !Number.isFinite(remoteC) || remoteC < 0) {
            return false;
        }
        const pt = Date.now();
        // Bounded clock drift tolerance: reject operations from peers whose physical clock
        // is skewed into the future beyond MAX_CLOCK_DRIFT_MS (e.g. 60,000ms).
        if (remoteL - pt > this.maxClockDriftMs) {
            return false;
        }
        // Synchronize local HLC according to Kulkarni et al. receive rule:
        // l' = max(l_old, pt, remote.l)
        // if (l' == l_old == remote.l) c' = max(c_old, remote.c) + 1
        // else if (l' == l_old) c' = c_old + 1
        // else if (l' == remote.l) c' = remote.c + 1
        // else c' = 0
        const lOld = this.hlc[0];
        const lNext = Math.max(lOld, pt, remoteL);
        let cNext = 0;
        if (lNext === lOld && lNext === remoteL) {
            cNext = Math.max(this.hlc[1], remoteC) + 1;
        } else if (lNext === lOld) {
            cNext = this.hlc[1] + 1;
        } else if (lNext === remoteL) {
            cNext = remoteC + 1;
        } else {
            cNext = 0;
        }
        this.hlc = [
            lNext,
            cNext
        ];
        const idx = op.y * this.width + op.x;
        const current = this.cells[idx];
        const curL = current.hlc ? current.hlc[0] : current.timestamp;
        const curC = current.hlc ? current.hlc[1] : 0;
        let wins = false;
        if (remoteL > curL) {
            wins = true;
        } else if (remoteL === curL) {
            if (remoteC > curC) {
                wins = true;
            } else if (remoteC === curC) {
                wins = op.peerId > current.peerId;
            }
        }
        if (wins) {
            this.cells[idx] = {
                r: op.r,
                g: op.g,
                b: op.b,
                a: op.a,
                timestamp: remoteL,
                hlc: [
                    remoteL,
                    remoteC
                ],
                peerId: op.peerId
            };
            this.appendOpToLog({
                ...op,
                timestamp: remoteL,
                hlc: [
                    remoteL,
                    remoteC
                ]
            });
            return true;
        }
        return false;
    }
    /**
   * Applies an array of remote operations.
   * Returns the count of mutated cells.
   */ applyRemoteOps(ops) {
        let mutated = 0;
        for (const op of ops){
            if (this.applyRemoteOp(op)) {
                mutated++;
            }
        }
        return mutated;
    }
    /**
   * Reads a pixel color from the CRDT buffer.
   */ getPixel(x, y) {
        if (x < 0 || x >= this.width || y < 0 || y >= this.height) {
            return [
                0,
                0,
                0,
                0
            ];
        }
        const cell = this.cells[y * this.width + x];
        return [
            cell.r,
            cell.g,
            cell.b,
            cell.a
        ];
    }
    /**
   * Reads cell metadata including HLC timestamp tuple and peerId.
   */ getCell(x, y) {
        if (x < 0 || x >= this.width || y < 0 || y >= this.height) {
            return null;
        }
        return this.cells[y * this.width + x];
    }
    /**
   * Exports an RGBA Uint8ClampedArray suitable for 2D canvas putImageData.
   */ toRgbaArray() {
        const data = new Uint8ClampedArray(this.width * this.height * 4);
        for(let i = 0; i < this.cells.length; i++){
            const cell = this.cells[i];
            const offset = i * 4;
            data[offset] = cell.r;
            data[offset + 1] = cell.g;
            data[offset + 2] = cell.b;
            data[offset + 3] = cell.a;
        }
        return data;
    }
    /**
   * Returns all recorded operations since a given physical timestamp or HLC tuple.
   */ getOpsSince(since) {
        if (Array.isArray(since)) {
            const [sinceL, sinceC] = since;
            return this.opLog.filter((op)=>{
                const l = op.hlc ? op.hlc[0] : op.timestamp;
                const c = op.hlc ? op.hlc[1] : 0;
                return l > sinceL || l === sinceL && c > sinceC;
            });
        }
        return this.opLog.filter((op)=>{
            const l = op.hlc ? op.hlc[0] : op.timestamp;
            return l > since;
        });
    }
    /**
   * Returns the entire operation log.
   */ getAllOps() {
        return [
            ...this.opLog
        ];
    }
    /**
   * Deterministically merges another CRDT buffer into this one.
   * Both buffers must have identical dimensions.
   * Directly joins cell states without inflating the logical counter,
   * then advances the local HLC once to cover both buffers and physical time.
   */ merge(other) {
        if (other.width !== this.width || other.height !== this.height) {
            throw new Error('Cannot merge CRDT buffers with differing dimensions.');
        }
        let mutated = 0;
        for(let y = 0; y < this.height; y++){
            for(let x = 0; x < this.width; x++){
                const otherCell = other.getCell(x, y);
                if (otherCell && (otherCell.timestamp > 0 || otherCell.hlc[0] > 0 || otherCell.peerId !== '')) {
                    const idx = y * this.width + x;
                    const current = this.cells[idx];
                    const otherL = otherCell.hlc ? otherCell.hlc[0] : otherCell.timestamp;
                    const otherC = otherCell.hlc ? otherCell.hlc[1] : 0;
                    const curL = current.hlc ? current.hlc[0] : current.timestamp;
                    const curC = current.hlc ? current.hlc[1] : 0;
                    let wins = false;
                    if (otherL > curL) {
                        wins = true;
                    } else if (otherL === curL) {
                        if (otherC > curC) {
                            wins = true;
                        } else if (otherC === curC) {
                            wins = otherCell.peerId > current.peerId;
                        }
                    }
                    if (wins) {
                        this.cells[idx] = {
                            r: otherCell.r,
                            g: otherCell.g,
                            b: otherCell.b,
                            a: otherCell.a,
                            timestamp: otherL,
                            hlc: [
                                otherL,
                                otherC
                            ],
                            peerId: otherCell.peerId
                        };
                        this.appendOpToLog({
                            x,
                            y,
                            r: otherCell.r,
                            g: otherCell.g,
                            b: otherCell.b,
                            a: otherCell.a,
                            timestamp: otherL,
                            hlc: [
                                otherL,
                                otherC
                            ],
                            peerId: otherCell.peerId
                        });
                        mutated++;
                    }
                }
            }
        }
        // Advance local HLC once to subsume the causal frontier of both histories
        const otherHlc = other.getHlc();
        const pt = Date.now();
        const lOld = this.hlc[0];
        const remoteL = otherHlc[0];
        const remoteC = otherHlc[1];
        const lNext = Math.max(lOld, pt, remoteL);
        let cNext = 0;
        if (lNext === lOld && lNext === remoteL) {
            cNext = Math.max(this.hlc[1], remoteC) + 1;
        } else if (lNext === lOld) {
            cNext = this.hlc[1] + 1;
        } else if (lNext === remoteL) {
            cNext = remoteC + 1;
        } else {
            cNext = 0;
        }
        this.hlc = [
            lNext,
            cNext
        ];
        return mutated;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/color/compactPalette.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "extractCompactPalette",
    ()=>extractCompactPalette
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/colorSpace.ts [app-client] (ecmascript)");
;
function extractCompactPalette(data, count = 6) {
    const limit = Math.max(1, Math.min(32, Number.isFinite(count) ? Math.round(count) : 6));
    const bins = new Map();
    const exact = new Map();
    let exactOverflow = false;
    for(let i = 0; i < data.length; i += 4){
        const alpha = data[i + 3];
        if (alpha <= 30) continue;
        const r = data[i], g = data[i + 1], b = data[i + 2], sample = r << 16 | g << 8 | b;
        if (!exactOverflow) {
            exact.set(sample, (exact.get(sample) ?? 0) + alpha);
            if (exact.size > limit) {
                exactOverflow = true;
                exact.clear();
            }
        }
        const key = r >> 3 << 10 | g >> 3 << 5 | b >> 3;
        const bin = bins.get(key);
        if (bin) {
            bin.r += r * alpha;
            bin.g += g * alpha;
            bin.b += b * alpha;
            bin.weight += alpha;
        } else bins.set(key, {
            r: r * alpha,
            g: g * alpha,
            b: b * alpha,
            weight: alpha,
            sample
        });
    }
    const hex = (rgb)=>`#${rgb.toString(16).padStart(6, '0').toUpperCase()}`;
    if (!exactOverflow) return [
        ...exact
    ].sort((a, b)=>b[1] - a[1] || a[0] - b[0]).map(([rgb])=>hex(rgb));
    // Select each bin's source sample nearest its mean in a second bounded pass.
    const distances = new Map();
    for(let i = 0; i < data.length; i += 4){
        if (data[i + 3] <= 30) continue;
        const r = data[i], g = data[i + 1], b = data[i + 2], key = r >> 3 << 10 | g >> 3 << 5 | b >> 3;
        const bin = bins.get(key);
        const distance = (r - bin.r / bin.weight) ** 2 + (g - bin.g / bin.weight) ** 2 + (b - bin.b / bin.weight) ** 2;
        if (distance < (distances.get(key) ?? Infinity)) {
            distances.set(key, distance);
            bin.sample = r << 16 | g << 8 | b;
        }
    }
    const points = [
        ...bins.values()
    ].map((bin)=>({
            ...bin,
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOKLab"])(bin.r / bin.weight, bin.g / bin.weight, bin.b / bin.weight)
        })).sort((a, b)=>b.weight - a.weight || a.sample - b.sample);
    if (!points.length) return [];
    const distance = (a, b)=>(a.L - b.L) ** 2 + (a.a - b.a) ** 2 + (a.b - b.b) ** 2;
    let centers = [
        {
            L: points[0].L,
            a: points[0].a,
            b: points[0].b
        }
    ];
    while(centers.length < Math.min(limit, points.length)){
        let best = points[0], score = -1;
        for (const p of points){
            const candidate = Math.min(...centers.map((c)=>distance(p, c))) * Math.sqrt(p.weight);
            if (candidate > score) {
                best = p;
                score = candidate;
            }
        }
        if (score <= 1e-12) break;
        centers.push({
            L: best.L,
            a: best.a,
            b: best.b
        });
    }
    const assignments = new Uint8Array(points.length);
    for(let iteration = 0; iteration < 8; iteration++){
        const sums = centers.map(()=>({
                L: 0,
                a: 0,
                b: 0,
                weight: 0
            }));
        points.forEach((p, i)=>{
            let nearest = 0, d = Infinity;
            centers.forEach((c, j)=>{
                const next = distance(p, c);
                if (next < d) {
                    nearest = j;
                    d = next;
                }
            });
            assignments[i] = nearest;
            const sum = sums[nearest];
            sum.L += p.L * p.weight;
            sum.a += p.a * p.weight;
            sum.b += p.b * p.weight;
            sum.weight += p.weight;
        });
        centers = sums.map((sum, i)=>sum.weight ? {
                L: sum.L / sum.weight,
                a: sum.a / sum.weight,
                b: sum.b / sum.weight
            } : centers[i]);
    }
    const candidates = centers.map((c, index)=>{
        const group = points.filter((_, i)=>assignments[i] === index);
        // Favor a common source swatch near the center over a rare edge sample.
        group.sort((a, b)=>(distance(a, c) + 0.0001) / Math.sqrt(a.weight) - (distance(b, c) + 0.0001) / Math.sqrt(b.weight) || a.sample - b.sample);
        return group.length ? {
            ...group[0],
            clusterWeight: group.reduce((sum, p)=>sum + p.weight, 0)
        } : null;
    }).filter((p)=>p !== null).sort((a, b)=>b.clusterWeight - a.clusterWeight || a.sample - b.sample);
    const distinct = [];
    for (const candidate of candidates){
        // The color limit is a ceiling, not a quota: don't fill unused slots with
        // two almost identical edge/ink shades from the same color family.
        if (!distinct.some((p)=>distance(p, candidate) < 0.03 ** 2)) distinct.push(candidate);
    }
    return distinct.sort((a, b)=>a.L - b.L || a.sample - b.sample).map((p)=>hex(p.sample));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/color/cvdLens.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Perceptual Accessibility Lenses (DESIGN.md Section 12 & 13).
 *
 * CVD (Color Vision Deficiency) simulation via the Machado, Oliveira &
 * Fernandes (2009, IEEE TVCG) severity 1.0 matrices, plus the Silhouette /
 * Squint mode value-contrast transform.
 *
 * CRITICAL INVARIANT: both lenses are display-only. They transform pixel data
 * in pure functions (for tests / future canvas overlays) and are applied to
 * the viewport via CSS `filter: url(#...)` SVG feColorMatrix filters. Project
 * data, the bufferRegistry, and every export path remain 100% untouched.
 */ __turbopack_context__.s([
    "CVD_FILTER_IDS",
    ()=>CVD_FILTER_IDS,
    "CVD_LENS_MATRICES",
    ()=>CVD_LENS_MATRICES,
    "CVD_LENS_MODES",
    ()=>CVD_LENS_MODES,
    "SQUINT_BACKGROUND_RGB",
    ()=>SQUINT_BACKGROUND_RGB,
    "SQUINT_FILTER_ID",
    ()=>SQUINT_FILTER_ID,
    "SQUINT_SILHOUETTE_RGB",
    ()=>SQUINT_SILHOUETTE_RGB,
    "applyCvdLensToImageData",
    ()=>applyCvdLensToImageData,
    "applyCvdLensToPixel",
    ()=>applyCvdLensToPixel,
    "applyCvdMatrixToRgb",
    ()=>applyCvdMatrixToRgb,
    "applySquintToImageData",
    ()=>applySquintToImageData,
    "applySquintToPixel",
    ()=>applySquintToPixel,
    "cycleCvdLens",
    ()=>cycleCvdLens,
    "feColorMatrixValues",
    ()=>feColorMatrixValues,
    "getViewportFilterCss",
    ()=>getViewportFilterCss
]);
const CVD_LENS_MODES = [
    'none',
    'protanopia',
    'deuteranopia',
    'tritanopia',
    'monochromacy'
];
const CVD_LENS_MATRICES = {
    protanopia: [
        0.152286,
        1.052583,
        -0.204868,
        0.114503,
        0.786281,
        0.099216,
        -0.003882,
        -0.048116,
        1.051998
    ],
    deuteranopia: [
        0.367322,
        0.860646,
        -0.227968,
        0.280085,
        0.672501,
        0.047413,
        -0.01182,
        0.04294,
        0.968881
    ],
    tritanopia: [
        1.255528,
        -0.076749,
        -0.178779,
        -0.078411,
        0.930809,
        0.147602,
        0.004733,
        0.691367,
        0.3039
    ],
    // Achromatopsia / monochromacy: pure Rec.709 luminance contrast validation
    // (DESIGN.md Section 12 item 4).
    monochromacy: [
        0.2126,
        0.7152,
        0.0722,
        0.2126,
        0.7152,
        0.0722,
        0.2126,
        0.7152,
        0.0722
    ]
};
const SQUINT_SILHOUETTE_RGB = [
    0x14,
    0x0c,
    0x1e
];
const SQUINT_BACKGROUND_RGB = [
    0xff,
    0xff,
    0xff
];
const CVD_FILTER_IDS = {
    protanopia: 'pixibun-cvd-protanopia',
    deuteranopia: 'pixibun-cvd-deuteranopia',
    tritanopia: 'pixibun-cvd-tritanopia',
    monochromacy: 'pixibun-cvd-monochromacy'
};
const SQUINT_FILTER_ID = 'pixibun-squint';
const clampByte = (v)=>v <= 0 ? 0 : v >= 255 ? 255 : v;
const decodeSrgb = (byte)=>{
    const c = clampByte(byte) / 255;
    return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
};
const encodeSrgb = (linear)=>{
    const c = Math.max(0, Math.min(1, linear));
    return 255 * (c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055);
};
function applyCvdMatrixToRgb(r, g, b, matrix) {
    const lr = decodeSrgb(r), lg = decodeSrgb(g), lb = decodeSrgb(b);
    return [
        encodeSrgb(matrix[0] * lr + matrix[1] * lg + matrix[2] * lb),
        encodeSrgb(matrix[3] * lr + matrix[4] * lg + matrix[5] * lb),
        encodeSrgb(matrix[6] * lr + matrix[7] * lg + matrix[8] * lb)
    ];
}
function applyCvdLensToPixel(r, g, b, mode) {
    if (mode === 'none') return [
        r,
        g,
        b
    ];
    return applyCvdMatrixToRgb(r, g, b, CVD_LENS_MATRICES[mode]);
}
function applyCvdLensToImageData(data, mode) {
    const out = new Uint8ClampedArray(data.length);
    for(let i = 0; i < data.length; i += 4){
        const [r, g, b] = applyCvdLensToPixel(data[i], data[i + 1], data[i + 2], mode);
        out[i] = r;
        out[i + 1] = g;
        out[i + 2] = b;
        out[i + 3] = data[i + 3];
    }
    return out;
}
function applySquintToPixel(r, g, b, a) {
    if (a === 0) return [
        r,
        g,
        b,
        a
    ];
    return [
        SQUINT_SILHOUETTE_RGB[0],
        SQUINT_SILHOUETTE_RGB[1],
        SQUINT_SILHOUETTE_RGB[2],
        a
    ];
}
function applySquintToImageData(data) {
    const out = new Uint8ClampedArray(data.length);
    for(let i = 0; i < data.length; i += 4){
        const [r, g, b, a] = applySquintToPixel(data[i], data[i + 1], data[i + 2], data[i + 3]);
        out[i] = r;
        out[i + 1] = g;
        out[i + 2] = b;
        out[i + 3] = a;
    }
    return out;
}
function feColorMatrixValues(matrix) {
    return [
        `${matrix[0]} ${matrix[1]} ${matrix[2]} 0 0`,
        `${matrix[3]} ${matrix[4]} ${matrix[5]} 0 0`,
        `${matrix[6]} ${matrix[7]} ${matrix[8]} 0 0`,
        '0 0 0 1 0'
    ].join(' ');
}
function cycleCvdLens(current) {
    const index = CVD_LENS_MODES.indexOf(current);
    return CVD_LENS_MODES[(index + 1) % CVD_LENS_MODES.length];
}
function getViewportFilterCss(mode, squintMode) {
    if (squintMode) return `url(#${SQUINT_FILTER_ID})`;
    if (mode !== 'none') return `url(#${CVD_FILTER_IDS[mode]})`;
    return undefined;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/color/rampGenerator.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateOklchRamp",
    ()=>generateOklchRamp
]);
/**
 * Perceptually Uniform OKLCH Color Ramp Generator for Pixel Art
 * Implements standard Pixel Art Color Theory:
 * - Highlights shift toward Warm Sunlight (OKLCH Hue 105°)
 * - Shadows shift toward Cool Sky / Indigo Ambience (OKLCH Hue 285°)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/colorSpace.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/floodFill.ts [app-client] (ecmascript)");
;
;
// Convert Hex to RGB [0-255]
function hexToRgb(hex) {
    if (!hex || typeof hex !== 'string') {
        return [
            0,
            0,
            0
        ];
    }
    let clean = hex.replace('#', '').trim();
    if (clean.length === 3 || clean.length === 4) {
        clean = clean.slice(0, 3).split('').map((c)=>c + c).join('');
    } else if (clean.length > 6) {
        clean = clean.slice(0, 6);
    }
    const num = parseInt(clean, 16);
    if (Number.isNaN(num)) {
        return [
            0,
            0,
            0
        ];
    }
    return [
        num >> 16 & 255,
        num >> 8 & 255,
        num & 255
    ];
}
// Convert RGB [0-255] to uppercase Hex
const rgbToHex = (r, g, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbaToHex"])(r, g, b).toUpperCase();
const WARM_SUN_HUE = 105; // Yellow sunlight
const COOL_SHADOW_HUE = 285; // Deep indigo ambient sky
function generateOklchRamp(baseHex) {
    const [r, g, b] = hexToRgb(baseHex);
    const [L, C, H] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToOklch"])(r, g, b);
    // 1. Highlight: Lighter, slightly desaturated, shifted toward warm sunlight
    const highlightHue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, WARM_SUN_HUE, 15);
    const [hr, hg, hb] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(Math.min(0.96, L + 0.16), Math.max(0.04, C * 0.85), highlightHue);
    // 2. Base Tone
    const baseRgb = [
        r,
        g,
        b
    ];
    // 3. Mid Shadow: Rich, saturated, shifted toward cool shadow hue
    const shadowHue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, COOL_SHADOW_HUE, 12);
    const [sr, sg, sb] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(Math.max(0.18, L - 0.16), Math.min(0.32, C * 1.12), shadowHue);
    // 4. Deep Shadow: Rich deep contrast
    const deepHue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, COOL_SHADOW_HUE, 22);
    const [dr, dg, db] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(Math.max(0.1, L - 0.32), Math.max(0.04, C * 1.05), deepHue);
    // 5. Obsidian Outline: Deep contrast
    const outlineHue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shiftHueToward"])(H, COOL_SHADOW_HUE, 30);
    const [or, og, ob] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$colorSpace$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToRgb"])(Math.max(0.05, L - 0.50), Math.max(0.02, C * 0.5), outlineHue);
    return [
        rgbToHex(hr, hg, hb),
        rgbToHex(baseRgb[0], baseRgb[1], baseRgb[2]),
        rgbToHex(sr, sg, sb),
        rgbToHex(dr, dg, db),
        rgbToHex(or, og, ob)
    ];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/engine/bufferPool.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAX_RETAINED_POOL_BYTES",
    ()=>MAX_RETAINED_POOL_BYTES,
    "acquireFloat32Buffer",
    ()=>acquireFloat32Buffer,
    "acquireInt32Buffer",
    ()=>acquireInt32Buffer,
    "clearBufferPool",
    ()=>clearBufferPool,
    "getBufferPoolUsage",
    ()=>getBufferPoolUsage,
    "releaseFloat32Buffer",
    ()=>releaseFloat32Buffer,
    "releaseInt32Buffer",
    ()=>releaseInt32Buffer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
;
const MAX_RETAINED_POOL_BYTES = 32 * 1024 * 1024;
const MAX_BUCKET_SIZE = 16;
const float32Pool = new Map();
const int32Pool = new Map();
// Insertion order is release order. Evict the oldest idle buffer first.
const idle = new Map();
let retainedBytes = 0;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerMemoryUsage"])('scratchPool', ()=>retainedBytes);
function acquire(pool, size, allocate) {
    const bucket = pool.get(size);
    const buffer = bucket?.pop();
    if (!buffer) return allocate(size);
    if (bucket.length === 0) pool.delete(size);
    idle.delete(buffer);
    retainedBytes -= buffer.byteLength;
    buffer.fill(0);
    return buffer;
}
function evictOldest() {
    const oldest = idle.entries().next().value;
    if (!oldest) return;
    const [buffer, pool] = oldest;
    const bucket = pool.get(buffer.length);
    bucket.splice(bucket.indexOf(buffer), 1);
    if (bucket.length === 0) pool.delete(buffer.length);
    idle.delete(buffer);
    retainedBytes -= buffer.byteLength;
}
function release(pool, buffer) {
    // Subarrays can retain a much larger backing allocation and alias live data.
    if (idle.has(buffer) || buffer.byteLength === 0 || buffer.byteOffset !== 0 || buffer.byteLength !== buffer.buffer.byteLength || buffer.byteLength > MAX_RETAINED_POOL_BYTES) return;
    if ((pool.get(buffer.length)?.length ?? 0) >= MAX_BUCKET_SIZE) return;
    while(idle.size > 0 && (retainedBytes + buffer.byteLength > MAX_RETAINED_POOL_BYTES || (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMemoryBudgetUsage"])().totalBytes + buffer.byteLength > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMBINED_MEMORY_LIMIT_BYTES"]))evictOldest();
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMemoryBudgetUsage"])().totalBytes + buffer.byteLength > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMBINED_MEMORY_LIMIT_BYTES"]) return;
    const bucket = pool.get(buffer.length) ?? [];
    bucket.push(buffer);
    pool.set(buffer.length, bucket);
    idle.set(buffer, pool);
    retainedBytes += buffer.byteLength;
}
function acquireFloat32Buffer(size) {
    return acquire(float32Pool, size, (length)=>new Float32Array(length));
}
function releaseFloat32Buffer(buffer) {
    release(float32Pool, buffer);
}
function acquireInt32Buffer(size) {
    return acquire(int32Pool, size, (length)=>new Int32Array(length));
}
function releaseInt32Buffer(buffer) {
    release(int32Pool, buffer);
}
function clearBufferPool() {
    float32Pool.clear();
    int32Pool.clear();
    idle.clear();
    retainedBytes = 0;
}
function getBufferPoolUsage() {
    return {
        retainedBytes,
        buffers: idle.size,
        buckets: float32Pool.size + int32Pool.size,
        limitBytes: MAX_RETAINED_POOL_BYTES
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/engine/historyEngine.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_HISTORY_MAX_BYTES",
    ()=>DEFAULT_HISTORY_MAX_BYTES,
    "DEFAULT_HISTORY_MAX_DEPTH",
    ()=>DEFAULT_HISTORY_MAX_DEPTH,
    "calculateStepBytes",
    ()=>calculateStepBytes,
    "createHistoryEngine",
    ()=>createHistoryEngine,
    "forgetViewportHistory",
    ()=>forgetViewportHistory,
    "getGlobalBaselineCheckpoint",
    ()=>getGlobalBaselineCheckpoint,
    "getGlobalHistory",
    ()=>getGlobalHistory,
    "getGlobalHistoryEngine",
    ()=>getGlobalHistoryEngine,
    "isGlobalHistoryTruncated",
    ()=>isGlobalHistoryTruncated,
    "readViewportHistory",
    ()=>readViewportHistory,
    "rememberViewportHistory",
    ()=>rememberViewportHistory,
    "setGlobalHistoryEngine",
    ()=>setGlobalHistoryEngine
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/animation/reviewMetadata.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteSemantics.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$research$2f$recipes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/research/recipes.ts [app-client] (ecmascript)");
;
;
;
;
;
const DEFAULT_HISTORY_MAX_DEPTH = 50;
const DEFAULT_HISTORY_MAX_BYTES = 64 * 1024 * 1024; // 64 MiB
function calculateStepBytes(step) {
    if (step.type === 'structural') {
        let bytes = 1024; // Base object overhead
        bytes += step.clips?.reduce((total, clip)=>total + (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["estimateClipBytes"])(clip), 0) ?? 0;
        bytes += step.palettes?.reduce((total, palette)=>total + (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["estimatePaletteBytes"])(palette), 0) ?? 0;
        bytes += step.frames.reduce((total, frame)=>total + frame.layers.reduce((sum, layer)=>sum + (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$research$2f$recipes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["researchBytes"])(layer.research), 0), 0);
        if (step.layerBuffers) {
            for (const b of step.layerBuffers){
                if (b.imageData?.data) {
                    bytes += b.imageData.data.byteLength;
                } else if (b.imageData) {
                    bytes += (b.imageData.width || 0) * (b.imageData.height || 0) * 4;
                }
            }
        }
        if (step.frames) {
            for (const f of step.frames){
                bytes += 256 + (f.layers?.length ?? 0) * 256;
            }
        }
        return bytes;
    } else {
        // Pixel step
        const dataLen = step.imageData?.data?.byteLength ?? (step.imageData ? (step.imageData.width || 0) * (step.imageData.height || 0) * 4 : 0);
        return dataLen + 512;
    }
}
function createHistoryEngine(optionsOrMaxDepth = DEFAULT_HISTORY_MAX_DEPTH) {
    const options = typeof optionsOrMaxDepth === 'number' ? {
        maxDepth: optionsOrMaxDepth,
        maxBytes: DEFAULT_HISTORY_MAX_BYTES
    } : optionsOrMaxDepth;
    const limitDepth = Math.max(1, options.maxDepth ?? DEFAULT_HISTORY_MAX_DEPTH);
    const limitBytes = Math.max(1024, options.maxBytes ?? DEFAULT_HISTORY_MAX_BYTES);
    let undoStack = [];
    let redoStack = [];
    let undoBytes = 0;
    let redoBytes = 0;
    let isTruncated = false;
    let evictionCount = 0;
    let baselineCheckpoint = null;
    function cloneImageData(src) {
        const copy = new Uint8ClampedArray(src.data);
        return {
            width: src.width,
            height: src.height,
            data: copy,
            colorSpace: src.colorSpace ?? 'srgb'
        };
    }
    function createBlankImageData(w, h) {
        return {
            width: w,
            height: h,
            data: new Uint8ClampedArray(w * h * 4),
            colorSpace: 'srgb'
        };
    }
    function updateBaselineFromEvicted(evicted) {
        if (evicted.type === 'pixel' && evicted.imageData) {
            const fIdx = evicted.frameIndex ?? 0;
            const w = evicted.imageData.width;
            const h = evicted.imageData.height;
            if (!baselineCheckpoint) {
                baselineCheckpoint = {
                    width: w,
                    height: h,
                    frames: [
                        {
                            frameIndex: fIdx,
                            layers: [
                                {
                                    layerId: evicted.layerId,
                                    frameIndex: fIdx,
                                    imageData: cloneImageData(evicted.imageData),
                                    name: evicted.layerName,
                                    opacity: 1,
                                    blendMode: evicted.layerBlendMode ?? 'source-over',
                                    visible: true,
                                    order: 0
                                }
                            ]
                        }
                    ],
                    activeFrameIndex: fIdx,
                    totalBytes: evicted.imageData.data.byteLength + 1024 + 512 + 512
                };
            } else {
                let frame = baselineCheckpoint.frames.find((f)=>f.frameIndex === fIdx);
                if (!frame) {
                    frame = {
                        frameIndex: fIdx,
                        layers: []
                    };
                    baselineCheckpoint.frames.push(frame);
                }
                const existingLayer = frame.layers.find((l)=>l.layerId === evicted.layerId);
                if (existingLayer) {
                    existingLayer.imageData = cloneImageData(evicted.imageData);
                    if (evicted.layerName) existingLayer.name = evicted.layerName;
                    if (evicted.layerBlendMode) existingLayer.blendMode = evicted.layerBlendMode;
                } else {
                    frame.layers.push({
                        layerId: evicted.layerId,
                        frameIndex: fIdx,
                        imageData: cloneImageData(evicted.imageData),
                        name: evicted.layerName,
                        opacity: 1,
                        blendMode: evicted.layerBlendMode ?? 'source-over',
                        visible: true,
                        order: frame.layers.length
                    });
                }
                // Recalculate bounded totalBytes from active baseline buffers
                let total = 1024;
                for (const f of baselineCheckpoint.frames){
                    total += 512;
                    for (const l of f.layers){
                        total += l.imageData.data.byteLength + 512;
                    }
                }
                baselineCheckpoint.totalBytes = total;
            }
        } else if (evicted.type === 'structural') {
            if (!baselineCheckpoint && evicted.canvasWidth && evicted.canvasHeight) {
                baselineCheckpoint = {
                    width: evicted.canvasWidth,
                    height: evicted.canvasHeight,
                    frames: [],
                    activeFrameIndex: evicted.activeFrameIndex ?? 0,
                    totalBytes: 1024
                };
            }
            if (baselineCheckpoint) {
                if (evicted.canvasWidth && evicted.canvasHeight) {
                    baselineCheckpoint.width = evicted.canvasWidth;
                    baselineCheckpoint.height = evicted.canvasHeight;
                }
                const width = baselineCheckpoint.width;
                const height = baselineCheckpoint.height;
                // Collect new/updated buffers from layerBuffers
                const bufMap = new Map();
                if (evicted.layerBuffers && evicted.layerBuffers.length > 0) {
                    for (const buf of evicted.layerBuffers){
                        if (buf.imageData) {
                            bufMap.set(buf.layerId, cloneImageData(buf.imageData));
                        }
                    }
                }
                if (evicted.frames && evicted.frames.length > 0) {
                    // Synchronize frames list: remove frames that no longer exist
                    baselineCheckpoint.frames = baselineCheckpoint.frames.filter((f)=>f.frameIndex < evicted.frames.length);
                    for(let fIdx = 0; fIdx < evicted.frames.length; fIdx++){
                        const af = evicted.frames[fIdx];
                        let frame = baselineCheckpoint.frames.find((f)=>f.frameIndex === fIdx);
                        if (!frame) {
                            frame = {
                                frameIndex: fIdx,
                                layers: []
                            };
                            baselineCheckpoint.frames.push(frame);
                        }
                        const existingLayersMap = new Map(frame.layers.map((l)=>[
                                l.layerId,
                                l
                            ]));
                        // Rebuild frame.layers to match af.layers structure and order
                        const nextLayers = [];
                        for(let lIdx = 0; lIdx < af.layers.length; lIdx++){
                            const al = af.layers[lIdx];
                            const existing = existingLayersMap.get(al.id);
                            let imgData;
                            if (bufMap.has(al.id)) {
                                imgData = bufMap.get(al.id);
                            } else if (existing?.imageData) {
                                imgData = existing.imageData;
                            } else {
                                imgData = createBlankImageData(width, height);
                            }
                            nextLayers.push({
                                layerId: al.id,
                                frameIndex: fIdx,
                                name: al.name,
                                imageData: imgData,
                                opacity: al.opacity ?? 1,
                                blendMode: al.blendMode ?? 'source-over',
                                visible: al.visible ?? true,
                                order: af.layers.length - 1 - lIdx
                            });
                        }
                        frame.layers = nextLayers;
                    }
                } else if (evicted.layerBuffers && evicted.layerBuffers.length > 0) {
                    const fIdx = evicted.frameIndex ?? 0;
                    let frame = baselineCheckpoint.frames.find((f)=>f.frameIndex === fIdx);
                    if (!frame) {
                        frame = {
                            frameIndex: fIdx,
                            layers: []
                        };
                        baselineCheckpoint.frames.push(frame);
                    }
                    for (const [layerId, imgData] of bufMap.entries()){
                        const existingLayer = frame.layers.find((l)=>l.layerId === layerId);
                        if (existingLayer) {
                            existingLayer.imageData = imgData;
                        } else {
                            frame.layers.push({
                                layerId,
                                frameIndex: fIdx,
                                imageData: imgData,
                                opacity: 1,
                                blendMode: 'source-over',
                                visible: true,
                                order: frame.layers.length
                            });
                        }
                    }
                }
                // Recalculate bounded totalBytes from active baseline buffers
                let total = 1024;
                for (const f of baselineCheckpoint.frames){
                    total += 512;
                    for (const l of f.layers){
                        total += l.imageData.data.byteLength + 512;
                    }
                }
                baselineCheckpoint.totalBytes = total;
            }
        }
    }
    function evictUntilWithinBudget(incomingBytes) {
        while(undoStack.length > 0 && (undoBytes + redoBytes + incomingBytes > limitBytes || undoStack.length >= limitDepth)){
            const evicted = undoStack.shift();
            undoBytes = Math.max(0, undoBytes - calculateStepBytes(evicted));
            isTruncated = true;
            evictionCount++;
            updateBaselineFromEvicted(evicted);
        }
    }
    return {
        push (step) {
            const stepBytes = calculateStepBytes(step);
            // Oversized entry safety:
            // This snapshot is the state before an edit that has already happened.
            // Without it, older undo steps and the redo branch no longer form a
            // continuous path through the current canvas state.
            if (stepBytes > limitBytes) {
                undoStack = [];
                redoStack = [];
                undoBytes = 0;
                redoBytes = 0;
                baselineCheckpoint = null;
                isTruncated = true;
                try {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                        message: `This edit exceeds the undo memory limit (${(stepBytes / (1024 * 1024)).toFixed(1)} MiB > ${(limitBytes / (1024 * 1024)).toFixed(0)} MiB). Earlier Undo and Redo history was cleared to keep restoration safe.`,
                        type: 'error'
                    });
                } catch  {
                // In headless tests or non-DOM environments, ignore event dispatch error
                }
                return 0;
            }
            // In push, a new edit invalidates redo!
            // Clearing redo resets redo retained bytes to exactly 0.
            redoStack = [];
            redoBytes = 0;
            // Evict oldest entries until within both depth and byte budget
            evictUntilWithinBudget(stepBytes);
            undoStack.push(step);
            undoBytes += stepBytes;
            return undoStack.length;
        },
        undo (currentState) {
            if (undoStack.length === 0) return null;
            const step = undoStack.pop();
            undoBytes = Math.max(0, undoBytes - calculateStepBytes(step));
            let retainedCurrentState = false;
            if (currentState) {
                const currentBytes = calculateStepBytes(currentState);
                if (currentBytes <= limitBytes) {
                    while(redoStack.length > 0 && (undoBytes + redoBytes + currentBytes > limitBytes || redoStack.length >= limitDepth)){
                        const evicted = redoStack.shift();
                        redoBytes = Math.max(0, redoBytes - calculateStepBytes(evicted));
                    }
                    if (undoBytes + redoBytes + currentBytes <= limitBytes && redoStack.length < limitDepth) {
                        redoStack.push(currentState);
                        redoBytes += currentBytes;
                        retainedCurrentState = true;
                    }
                }
            }
            if (!retainedCurrentState) {
                // A missing intermediate state makes every older redo entry unreachable.
                redoStack = [];
                redoBytes = 0;
                if (currentState) isTruncated = true;
            }
            return step;
        },
        redo (currentState) {
            if (redoStack.length === 0) return null;
            const step = redoStack.pop();
            redoBytes = Math.max(0, redoBytes - calculateStepBytes(step));
            if (currentState) {
                const currentBytes = calculateStepBytes(currentState);
                if (currentBytes > limitBytes) {
                    // The redo target can be restored, but without this intermediate
                    // snapshot no older undo or later redo step is safely reachable.
                    undoStack = [];
                    redoStack = [];
                    undoBytes = 0;
                    redoBytes = 0;
                    baselineCheckpoint = null;
                    isTruncated = true;
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                        message: 'Redo restored the edit, but its prior state exceeds the undo memory limit. Undo and Redo history was cleared to avoid skipping artwork states.',
                        type: 'error'
                    });
                } else {
                    evictUntilWithinBudget(currentBytes);
                    while(redoStack.length > 0 && undoBytes + redoBytes + currentBytes > limitBytes){
                        const evicted = redoStack.shift();
                        redoBytes = Math.max(0, redoBytes - calculateStepBytes(evicted));
                    }
                    if (undoBytes + redoBytes + currentBytes <= limitBytes && undoStack.length < limitDepth) {
                        undoStack.push(currentState);
                        undoBytes += currentBytes;
                    } else {
                        undoStack = [];
                        redoStack = [];
                        undoBytes = 0;
                        redoBytes = 0;
                        baselineCheckpoint = null;
                        isTruncated = true;
                    }
                }
            }
            return step;
        },
        peekUndo () {
            return undoStack.length > 0 ? undoStack[undoStack.length - 1] : null;
        },
        peekRedo () {
            return redoStack.length > 0 ? redoStack[redoStack.length - 1] : null;
        },
        clear () {
            undoStack = [];
            redoStack = [];
            undoBytes = 0;
            redoBytes = 0;
            isTruncated = false;
            evictionCount = 0;
            baselineCheckpoint = null;
        },
        getHistory () {
            return [
                ...undoStack
            ];
        },
        getBaseline () {
            return baselineCheckpoint;
        },
        setBaseline (checkpoint) {
            baselineCheckpoint = checkpoint;
        },
        get canUndo () {
            return undoStack.length > 0;
        },
        get canRedo () {
            return redoStack.length > 0;
        },
        get depth () {
            return undoStack.length;
        },
        get redoDepth () {
            return redoStack.length;
        },
        get undoBytes () {
            return Math.max(0, undoBytes);
        },
        get redoBytes () {
            return Math.max(0, redoBytes);
        },
        get totalBytes () {
            return Math.max(0, undoBytes + redoBytes);
        },
        get isTruncated () {
            return isTruncated;
        },
        get evictionCount () {
            return evictionCount;
        },
        get maxBytes () {
            return limitBytes;
        },
        get maxDepth () {
            return limitDepth;
        }
    };
}
let activeGlobalHistoryEngine = null;
let retainedViewportHistory = null;
function rememberViewportHistory(projectId, engine) {
    retainedViewportHistory = {
        projectId,
        engine
    };
}
function readViewportHistory(projectId) {
    return retainedViewportHistory?.projectId === projectId ? retainedViewportHistory.engine : createHistoryEngine(50);
}
function forgetViewportHistory() {
    retainedViewportHistory = null;
}
(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerMemoryUsage"])('history', ()=>{
    const bytes = (engine)=>(engine?.totalBytes ?? 0) + (engine?.getBaseline()?.totalBytes ?? 0);
    const retained = retainedViewportHistory?.engine ?? null;
    return bytes(activeGlobalHistoryEngine) + (retained !== activeGlobalHistoryEngine ? bytes(retained) : 0);
});
function setGlobalHistoryEngine(engine) {
    activeGlobalHistoryEngine = engine;
}
function getGlobalHistoryEngine() {
    return activeGlobalHistoryEngine;
}
function getGlobalHistory() {
    return activeGlobalHistoryEngine ? activeGlobalHistoryEngine.getHistory() : [];
}
function getGlobalBaselineCheckpoint() {
    return activeGlobalHistoryEngine ? activeGlobalHistoryEngine.getBaseline() : null;
}
function isGlobalHistoryTruncated() {
    return activeGlobalHistoryEngine ? activeGlobalHistoryEngine.isTruncated : false;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/engine/structuralHistory.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "captureLayerBuffers",
    ()=>captureLayerBuffers,
    "estimateRestorationAllocation",
    ()=>estimateRestorationAllocation,
    "pushStructuralHistoryStep",
    ()=>pushStructuralHistoryStep,
    "restoreStructuralWorkspace",
    ()=>restoreStructuralWorkspace
]);
/**
 * structuralHistory.ts
 *
 * Implements the structural snapshot recorder for the Hybrid Command Pattern history engine.
 * Records layer/frame tree metadata and only affected raster pixel buffers before destructive
 * structural mutations (layer deletions, merges, duplications, reordering, frame changes).
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/historyEngine.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/animation/reviewMetadata.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteSemantics.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$research$2f$recipes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/research/recipes.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
function captureLayerBuffers(layerIds) {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || typeof document === 'undefined' || !layerIds || layerIds.length === 0) {
        return [];
    }
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    const buffers = [];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertMemoryAvailable"])(new Set(layerIds.filter(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasBuffer"])).size * state.canvasWidth * state.canvasHeight * 4, 'History snapshot');
    const seen = new Set();
    for (const layerId of layerIds){
        if (!seen.has(layerId) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasBuffer"])(layerId)) {
            seen.add(layerId);
            const entry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layerId, state.canvasWidth, state.canvasHeight);
            const data = entry.ctx.getImageData(0, 0, state.canvasWidth, state.canvasHeight);
            buffers.push({
                layerId,
                imageData: data
            });
        }
    }
    return buffers;
}
function pushStructuralHistoryStep(description, options) {
    const engine = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalHistoryEngine"])();
    if (!engine) return true;
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    const affectedIds = options?.affectedLayerIds ?? [];
    const uniqueAffectedIds = [
        ...new Set(affectedIds)
    ].filter(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasBuffer"]);
    const width = options?.canvasWidth ?? state.canvasWidth;
    const height = options?.canvasHeight ?? state.canvasHeight;
    const metadataBytes = state.frames.reduce((bytes, frame)=>bytes + 256 + frame.layers.length * 256, 1024) + state.frames.reduce((bytes, frame)=>bytes + frame.layers.reduce((sum, layer)=>sum + (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$research$2f$recipes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["researchBytes"])(layer.research), 0), 0) + state.clips.reduce((bytes, clip)=>bytes + (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["estimateClipBytes"])(clip), 0) + (options?.includePalettes ? state.palettes.reduce((bytes, palette)=>bytes + (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["estimatePaletteBytes"])(palette), 0) : 0);
    const rasterBytes = width * height * 4;
    const undoBytes = metadataBytes + uniqueAffectedIds.length * rasterBytes;
    const redoBytes = metadataBytes + (options?.addedMetadataBytes ?? 0) + (options?.addedLayerCount ?? 0) * 256 + (options?.addedFrameCount ?? 0) * 256 + (options?.redoBufferCount ?? uniqueAffectedIds.length) * rasterBytes;
    const estimatedBytes = Math.max(undoBytes, redoBytes);
    if (estimatedBytes > engine.maxBytes) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
            type: 'error',
            message: `This edit needs ${(estimatedBytes / (1024 * 1024)).toFixed(1)} MiB of Undo memory, above the ${(engine.maxBytes / (1024 * 1024)).toFixed(0)} MiB limit. The edit was not applied.`
        });
        return false;
    }
    try {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertMemoryAvailable"])(estimatedBytes + (options?.addedLayerCount ?? 0) * rasterBytes, 'Structural edit snapshot and staging');
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
            type: 'error',
            message: error.message
        });
        return false;
    }
    const step = {
        type: 'structural',
        opKind: options?.opKind ?? 'generic-structural',
        description,
        frameIndex: state.activeFrameIndex,
        frames: structuredClone(state.frames),
        activeFrameIndex: state.activeFrameIndex,
        activeLayerId: state.activeLayerId,
        clips: structuredClone(state.clips),
        activeClipId: state.activeClipId,
        ...options?.includePalettes ? {
            palettes: structuredClone(state.palettes),
            currentPaletteId: state.currentPaletteId
        } : {},
        canvasWidth: width,
        canvasHeight: height,
        layerBuffers: captureLayerBuffers(uniqueAffectedIds),
        affectedLayerIds: affectedIds
    };
    const depth = engine.push(step);
    state.setCanUndo(engine.canUndo);
    state.setCanRedo(engine.canRedo);
    return depth > 0;
}
function estimateRestorationAllocation(target) {
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    const sizeChanged = target.canvasWidth !== state.canvasWidth || target.canvasHeight !== state.canvasHeight;
    const previous = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["snapshotBuffers"])();
    const backups = new Set(target.layerBuffers?.map((buffer)=>buffer.layerId));
    return target.frames.reduce((total, frame)=>total + frame.layers.filter((layer)=>backups.has(layer.id) || previous.has(layer.id) && sizeChanged).length, 0) * target.canvasWidth * target.canvasHeight * 4;
}
function restoreStructuralWorkspace(target) {
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    const sizeChanged = target.canvasWidth !== state.canvasWidth || target.canvasHeight !== state.canvasHeight;
    const previous = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["snapshotBuffers"])();
    const staged = new Map();
    const backups = new Map(target.layerBuffers?.map((buf)=>[
            buf.layerId,
            buf.imageData
        ]));
    const release = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reserveMemory"])(estimateRestorationAllocation(target), 'History restoration staging');
    try {
        for (const frame of target.frames){
            for (const layer of frame.layers){
                const existing = previous.get(layer.id);
                const backup = backups.get(layer.id);
                if (!existing && !backup) continue; // Unpainted layers remain lazy.
                if (!sizeChanged && !backup && existing) {
                    staged.set(layer.id, existing);
                    continue;
                }
                const entry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEntry"])(target.canvasWidth, target.canvasHeight, 1, true);
                if (backup) entry.ctx.putImageData(backup, 0, 0);
                else if (existing) entry.ctx.drawImage(existing.canvas, Math.floor((target.canvasWidth - existing.canvas.width) / 2), Math.floor((target.canvasHeight - existing.canvas.height) / 2));
                staged.set(layer.id, entry);
            }
        }
        // Publish pixels before metadata subscribers (autosave/co-draw) see the target tree.
        // History owns redo pixel copies, so removed live canvases need not stay resident.
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceAllBuffers"])(staged);
        try {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                canvasWidth: target.canvasWidth,
                canvasHeight: target.canvasHeight,
                frames: target.frames,
                ...target.clips !== undefined ? {
                    clips: structuredClone(target.clips)
                } : {},
                ...target.activeClipId !== undefined ? {
                    activeClipId: target.activeClipId
                } : {},
                ...target.palettes !== undefined ? {
                    palettes: structuredClone(target.palettes),
                    currentPaletteId: target.currentPaletteId
                } : {},
                activeFrameIndex: Math.min(target.activeFrameIndex, Math.max(0, target.frames.length - 1)),
                activeLayerId: target.activeLayerId
            });
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceAllBuffers"])(previous);
            throw error;
        }
    } finally{
        release();
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/engine/workerDispatcher.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_WORKER_TIMEOUT_MS",
    ()=>DEFAULT_WORKER_TIMEOUT_MS,
    "MAX_PENDING_WORKER_REQUESTS",
    ()=>MAX_PENDING_WORKER_REQUESTS,
    "MAX_SYNC_FALLBACK_WORK_UNITS",
    ()=>MAX_SYNC_FALLBACK_WORK_UNITS,
    "_getPendingCallbacksCountForTesting",
    ()=>_getPendingCallbacksCountForTesting,
    "_resetSharedWorkerForTesting",
    ()=>_resetSharedWorkerForTesting,
    "_setSharedWorkerForTesting",
    ()=>_setSharedWorkerForTesting,
    "_setWorkerFactoryForTesting",
    ()=>_setWorkerFactoryForTesting,
    "runEdtNormalMapInWorker",
    ()=>runEdtNormalMapInWorker,
    "runMorphInWorker",
    ()=>runMorphInWorker,
    "runRotSpriteInWorker",
    ()=>runRotSpriteInWorker,
    "runWfcInWorker",
    ()=>runWfcInWorker
]);
/**
 * workerDispatcher.ts
 * Typesafe Web Worker dispatcher for compute-heavy routines:
 * - RotSprite 8x upscale & majority-voting
 * - WaveFunctionCollapse constraint-satisfaction texture synthesis
 * - Optical Flow & SDF In-Between frame morphing
 * - Euclidean Distance Transform & normal map baking
 *
 * Automatically falls back to synchronous main-thread execution when running
 * in environments without Web Worker support (Node.js, Vitest, SSR, or restrictive CSP).
 *
 * Includes per-request execution timeout (default 10s), AbortSignal cancellation,
 * and deterministic crash recovery that invalidates and terminates corrupt worker instances.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rotSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/rotSprite.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$procedural$2f$waveFunctionCollapse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/procedural/waveFunctionCollapse.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/pixelAiEngine.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/edtNormalMap.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$minecraftSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/minecraftSkin.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
var __TURBOPACK__import$2e$meta__ = {
    get url () {
        return __turbopack_context__.F("src/lib/engine/workerDispatcher.ts");
    },
    env: {
        DEV: true,
        PROD: false,
        MODE: "development",
        BASE_URL: "/",
        SSR: false
    },
    get turbopackHot () {
        return __turbopack_context__.m.hot;
    }
};
;
;
;
;
;
;
const DEFAULT_WORKER_TIMEOUT_MS = 10_000;
const MAX_PENDING_WORKER_REQUESTS = 4;
const MAX_SYNC_FALLBACK_WORK_UNITS = 1_048_576;
function checkAbort(signal) {
    if (signal?.aborted) throw new DOMException('This operation was aborted', 'AbortError');
}
function runBoundedFallback(workUnits, signal, compute) {
    checkAbort(signal);
    if (!Number.isFinite(workUnits) || workUnits < 0 || workUnits > MAX_SYNC_FALLBACK_WORK_UNITS) {
        throw new RangeError('This operation requires a compute worker. Reduce its size or enable Web Workers.');
    }
    const result = compute();
    checkAbort(signal);
    return result;
}
function checkAdmission(signal) {
    checkAbort(signal);
    if (pendingCallbacks.size >= MAX_PENDING_WORKER_REQUESTS) {
        throw new Error('Compute worker is busy. Wait for an operation to finish before trying again.');
    }
}
function interruptedWorkerError() {
    const error = new Error('Worker terminated because another operation was cancelled or timed out. Please retry.');
    error.name = 'WorkerInterruptedError';
    return error;
}
let sharedWorker = null;
let workerFactory = null;
let pendingCallbacks = new Map();
let workerFallbackReported = false;
function reportWorkerFallback(reason) {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || workerFallbackReported) return;
    workerFallbackReported = true;
    const detail = reason instanceof Error ? reason.message : String(reason);
    console.warn('Heavy compute worker unavailable; using main-thread fallback:', detail);
    void __turbopack_context__.A("[project]/src/lib/diagnostics/capture.ts [app-client] (ecmascript, async loader)").then(({ captureDiagnostic })=>captureDiagnostic({
            kind: 'error',
            message: 'Heavy compute worker unavailable; using main-thread fallback.',
            detail
        })).catch(()=>{});
}
/**
 * Terminates the current worker, rejects all active in-flight requests,
 * and resets internal dispatcher state so subsequent requests can re-instantiate cleanly.
 */ function terminateWorkerAndRejectAll(error) {
    if (sharedWorker) {
        try {
            sharedWorker.terminate();
        } catch  {
        // Ignore termination failure
        }
        sharedWorker = null;
    }
    const callbacksToReject = pendingCallbacks;
    pendingCallbacks = new Map();
    callbacksToReject.forEach(({ reject, timerId, cleanupAbortListener })=>{
        if (timerId !== null) clearTimeout(timerId);
        if (cleanupAbortListener) cleanupAbortListener();
        reject(error);
    });
}
function attachWorkerListeners(worker) {
    worker.onmessage = (e)=>{
        const data = e.data;
        if (!data || !data.id) return;
        const cb = pendingCallbacks.get(data.id);
        if (!cb) return;
        if (cb.timerId !== null) clearTimeout(cb.timerId);
        if (cb.cleanupAbortListener) cb.cleanupAbortListener();
        pendingCallbacks.delete(data.id);
        if (data.type === 'error') {
            cb.reject(new Error(data.message));
        } else {
            cb.resolve(data.result);
        }
    };
    worker.onerror = (err)=>{
        const message = 'message' in err && err.message ? err.message : 'Worker encountered fatal error';
        terminateWorkerAndRejectAll(new Error(`Worker fatal error: ${message}`));
    };
}
function getOrCreateWorker() {
    if (sharedWorker) {
        return sharedWorker;
    }
    if (workerFactory) {
        try {
            sharedWorker = workerFactory();
            attachWorkerListeners(sharedWorker);
            return sharedWorker;
        } catch (err) {
            sharedWorker = null;
            reportWorkerFallback(err);
            return null;
        }
    }
    const WorkerCtor = typeof Worker !== 'undefined' ? Worker : typeof globalThis !== 'undefined' ? globalThis.Worker : undefined;
    if (!WorkerCtor) {
        reportWorkerFallback(new Error('Web Worker API is unavailable.'));
        return null;
    }
    try {
        // Keep the constructor literal so Turbopack recognizes and bundles the
        // worker entrypoint instead of copying the TypeScript source as an asset.
        sharedWorker = __turbopack_context__.r("[project]/src/workers/heavyCompute.worker.ts [app-client] (ecmascript, worker loader)")(Worker, {
            type: 'module'
        });
        attachWorkerListeners(sharedWorker);
    } catch (err) {
        sharedWorker = null;
        reportWorkerFallback(err);
    }
    return sharedWorker;
}
let nextReqId = 1;
function getNextId() {
    return `req_${Date.now()}_${nextReqId++}`;
}
/**
 * Dispatches a typed request to the active shared worker with timeout and abort guarantees.
 */ function dispatchToWorker(req, transferables, options) {
    const worker = getOrCreateWorker();
    if (!worker) {
        throw new Error('No worker available');
    }
    const timeoutMs = options?.timeoutMs ?? DEFAULT_WORKER_TIMEOUT_MS;
    const signal = options?.signal;
    if (signal?.aborted) {
        const abortErr = new Error('This operation was aborted');
        abortErr.name = 'AbortError';
        return Promise.reject(abortErr);
    }
    return new Promise((resolve, reject)=>{
        let timerId = null;
        let cleanupAbortListener;
        if (timeoutMs > 0 && Number.isFinite(timeoutMs)) {
            timerId = setTimeout(()=>{
                const pending = pendingCallbacks.get(req.id);
                if (!pending) return;
                pendingCallbacks.delete(req.id);
                pending.cleanupAbortListener?.();
                const timeoutError = new Error(`Worker request ${req.id} timed out after ${timeoutMs}ms`);
                timeoutError.name = 'WorkerTimeoutError';
                pending.reject(timeoutError);
                // Requests share one execution thread. A timed-out job could block every
                // queued job; interrupt peers explicitly and let the next dispatch recover.
                terminateWorkerAndRejectAll(interruptedWorkerError());
            }, timeoutMs);
        }
        if (signal) {
            const onAbort = ()=>{
                const pending = pendingCallbacks.get(req.id);
                if (pending) {
                    if (pending.timerId !== null) clearTimeout(pending.timerId);
                    pendingCallbacks.delete(req.id);
                    pending.cleanupAbortListener?.();
                    const abortErr = new Error('This operation was aborted');
                    abortErr.name = 'AbortError';
                    pending.reject(abortErr);
                    terminateWorkerAndRejectAll(interruptedWorkerError());
                }
            };
            signal.addEventListener('abort', onAbort, {
                once: true
            });
            cleanupAbortListener = ()=>signal.removeEventListener('abort', onAbort);
        }
        pendingCallbacks.set(req.id, {
            resolve: (val)=>resolve(val),
            reject,
            timerId,
            cleanupAbortListener
        });
        try {
            worker.postMessage(req, transferables);
        } catch (postErr) {
            if (timerId !== null) clearTimeout(timerId);
            if (cleanupAbortListener) cleanupAbortListener();
            pendingCallbacks.delete(req.id);
            reject(postErr instanceof Error ? postErr : new Error(String(postErr)));
        }
    });
}
async function runRotSpriteInWorker(...args) {
    const options = typeof args[6] === 'object' ? args[6] : undefined;
    checkAdmission(options?.signal);
    const release = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reserveMemory"])(args[0].width * args[0].height * 4 * 66 + (args[4] ?? args[0].width) * (args[5] ?? args[0].height) * 8, 'RotSprite compute');
    try {
        return await computeRotSprite(...args);
    } finally{
        release();
    }
}
async function computeRotSprite(src, angleRad, pivotX, pivotY, targetW, targetH, outPivotXOrOptions, outPivotY) {
    let outPivotX;
    let options;
    if (typeof outPivotXOrOptions === 'object' && outPivotXOrOptions !== null) {
        options = outPivotXOrOptions;
        outPivotX = options.outPivotX;
        outPivotY = options.outPivotY;
    } else {
        outPivotX = outPivotXOrOptions;
    }
    checkAdmission(options?.signal);
    const runSync = ()=>runBoundedFallback(src.width * src.height * 64 + (targetW ?? src.width) * (targetH ?? src.height), options?.signal, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rotSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotSprite"])(src, angleRad, pivotX, pivotY, targetW, targetH, outPivotX, outPivotY));
    const worker = getOrCreateWorker();
    if (!worker) {
        return runSync();
    }
    const id = getNextId();
    const dataCopy = new Uint8ClampedArray(src.data);
    const req = {
        id,
        type: 'rotSprite',
        data: dataCopy,
        width: src.width,
        height: src.height,
        angleRad,
        pivotX,
        pivotY,
        targetW,
        targetH,
        outPivotX,
        outPivotY
    };
    try {
        return await dispatchToWorker(req, [
            dataCopy.buffer
        ], options);
    } catch (err) {
        if (err instanceof Error && (err.name === 'AbortError' || err.name === 'WorkerTimeoutError' || err.message.includes('Worker terminated') || err.message.includes('Worker fatal error'))) {
            throw err;
        }
        return runSync();
    }
}
async function runWfcInWorker(...args) {
    checkAdmission(args[1]?.signal);
    const release = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reserveMemory"])((args[1]?.maxWorkingSetBytes ?? 64 * 1024 * 1024) + args[0].sampleData.byteLength * 2, 'WFC compute');
    try {
        return await computeWfc(...args);
    } finally{
        release();
    }
}
async function computeWfc(input, options) {
    checkAdmission(options?.signal);
    const runSync = ()=>runBoundedFallback(input.sampleWidth * input.sampleHeight * input.outputWidth * input.outputHeight * (options?.symmetries ?? 8) * (options?.N ?? 2) ** 2 * (options?.maxRetries ?? 10), options?.signal, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$procedural$2f$waveFunctionCollapse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["synthesizeWfc"])(input, options));
    const worker = getOrCreateWorker();
    if (!worker) {
        return runSync();
    }
    const id = getNextId();
    const sampleCopy = new Uint8ClampedArray(input.sampleData);
    const req = {
        id,
        type: 'wfc',
        input: {
            ...input,
            sampleData: sampleCopy
        },
        options
    };
    try {
        return await dispatchToWorker(req, [
            sampleCopy.buffer
        ], options);
    } catch (err) {
        if (err instanceof Error && (err.name === 'AbortError' || err.name === 'WorkerTimeoutError' || err.message.includes('Worker terminated') || err.message.includes('Worker fatal error'))) {
            throw err;
        }
        return runSync();
    }
}
async function runMorphInWorker(...args) {
    checkAdmission(args[4]?.signal);
    const release = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reserveMemory"])(args[0].width * args[0].height * (128 + 8 * (args[3] !== undefined ? 1 : Math.max(1, args[2] ?? 1))), 'Frame morph compute');
    try {
        return await computeMorph(...args);
    } finally{
        release();
    }
}
async function computeMorph(frameA, frameB, steps = 1, fraction, options) {
    checkAdmission(options?.signal);
    const runSync = ()=>runBoundedFallback(frameA.width * frameA.height * 256 * (fraction !== undefined ? 1 : Math.max(1, steps)), options?.signal, ()=>fraction !== undefined ? [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["morphInBetweenFrameAtFraction"])(frameA, frameB, fraction)
            ] : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["morphInBetweenFramesSync"])(frameA, frameB, steps));
    const worker = getOrCreateWorker();
    if (!worker) {
        return runSync();
    }
    const id = getNextId();
    const dataACopy = new Uint8ClampedArray(frameA.data);
    const dataBCopy = new Uint8ClampedArray(frameB.data);
    const req = {
        id,
        type: 'morph',
        frameA: {
            width: frameA.width,
            height: frameA.height,
            data: dataACopy
        },
        frameB: {
            width: frameB.width,
            height: frameB.height,
            data: dataBCopy
        },
        steps,
        fraction
    };
    try {
        return await dispatchToWorker(req, [
            dataACopy.buffer,
            dataBCopy.buffer
        ], options);
    } catch (err) {
        if (err instanceof Error && (err.name === 'AbortError' || err.name === 'WorkerTimeoutError' || err.message.includes('Worker terminated') || err.message.includes('Worker fatal error'))) {
            throw err;
        }
        return runSync();
    }
}
async function runEdtNormalMapInWorker(...args) {
    checkAdmission(args[3]?.signal);
    const release = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reserveMemory"])(args[1] * args[2] * 128, 'Normal map compute');
    try {
        return await computeEdt(...args);
    } finally{
        release();
    }
}
async function computeEdt(rgba, width, height, options = {}) {
    checkAdmission(options.signal);
    const worker = getOrCreateWorker();
    const runSync = ()=>runBoundedFallback(width * height * 64, options.signal, ()=>{
            const isOpaque = (x, y)=>{
                if (x < 0 || x >= width || y < 0 || y >= height) return false;
                return rgba[(y * width + x) * 4 + 3] > 10;
            };
            const normalField = options.isMinecraftSkin ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$minecraftSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeMinecraftSkinNormalField"])(width, height) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeTangentNormalField"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyBilateralFilter"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateInflatedHeightmap"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])(isOpaque, width, height), width, height, 0.5), width, height, 1.5, 2.0), width, height, options.depthScale ?? 2.0);
            const data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bakeNormalMapToRgba"])(normalField, width, height, isOpaque);
            return {
                width,
                height,
                data
            };
        });
    if (!worker) {
        return runSync();
    }
    const id = getNextId();
    const bufferCopy = rgba.slice().buffer;
    const req = {
        id,
        type: 'edtNormalMap',
        buffer: bufferCopy,
        width,
        height,
        isMinecraftSkin: options.isMinecraftSkin,
        depthScale: options.depthScale
    };
    try {
        return await dispatchToWorker(req, [
            bufferCopy
        ], options);
    } catch (err) {
        if (err instanceof Error && (err.name === 'AbortError' || err.name === 'WorkerTimeoutError' || err.message.includes('Worker terminated') || err.message.includes('Worker fatal error'))) {
            throw err;
        }
        return runSync();
    }
}
function _resetSharedWorkerForTesting() {
    terminateWorkerAndRejectAll(new Error('Reset for testing'));
    workerFactory = null;
    workerFallbackReported = false;
}
function _setSharedWorkerForTesting(worker) {
    if (sharedWorker && sharedWorker !== worker) {
        try {
            sharedWorker.terminate();
        } catch  {
        // Ignore
        }
    }
    sharedWorker = worker;
    if (worker) {
        attachWorkerListeners(worker);
    }
}
function _setWorkerFactoryForTesting(factory) {
    workerFactory = factory;
}
function _getPendingCallbacksCountForTesting() {
    return pendingCallbacks.size;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Strongly-typed Studio Event Bus for PixiBun Atelier.
 * 
 * Eliminates loose window.dispatchEvent(new CustomEvent(...)) strings and provides
 * type safety, lifecycle cleanup, and predictable event dispatch across studio panels.
 */ __turbopack_context__.s([
    "studioEvents",
    ()=>studioEvents
]);
class StudioEventBus {
    handlers = new Map();
    emittedDomEvents = new WeakSet();
    on(event, handler) {
        let set = this.handlers.get(event);
        if (!set) {
            set = new Set();
            this.handlers.set(event, set);
        }
        set.add(handler);
        const windowListener = (e)=>{
            if (this.emittedDomEvents.has(e)) {
                // Event was already dispatched in-memory by studioEvents.emit()
                return;
            }
            const customEvent = e;
            try {
                handler(customEvent.detail);
            } catch (err) {
                console.error(`Error executing handler for ${String(event)}:`, err);
            }
        };
        if ("TURBOPACK compile-time truthy", 1) {
            window.addEventListener(event, windowListener);
        }
        return ()=>{
            set?.delete(handler);
            if ("TURBOPACK compile-time truthy", 1) {
                window.removeEventListener(event, windowListener);
            }
        };
    }
    emit(event, ...args) {
        const data = args[0];
        // 1. Direct in-memory dispatch to registered handlers
        const handlers = this.handlers.get(event);
        if (handlers) {
            handlers.forEach((h)=>{
                try {
                    h(data);
                } catch (err) {
                    console.error(`Error executing in-memory handler for ${String(event)}:`, err);
                }
            });
        }
        // 2. Dispatch to DOM window for external listeners and test spies
        if (("TURBOPACK compile-time value", "object") !== 'undefined' && typeof window.dispatchEvent === 'function') {
            const customEvent = new CustomEvent(event, {
                detail: data
            });
            this.emittedDomEvents.add(customEvent);
            window.dispatchEvent(customEvent);
        }
    }
}
const studioEvents = new StudioEventBus();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/export/animationModel.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildAnimationModel",
    ()=>buildAnimationModel,
    "godotSpriteFramesResource",
    ()=>godotSpriteFramesResource,
    "playbackOrder",
    ()=>playbackOrder
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/animationTiming.ts [app-client] (ecmascript)");
;
function playbackOrder(first, last, direction = 'forward', loop = 'repeat') {
    const order = Array.from({
        length: Math.max(0, last - first + 1)
    }, (_, i)=>first + i);
    if (direction === 'reverse') order.reverse();
    return direction === 'ping-pong' || loop === 'ping-pong' ? [
        ...order,
        ...order.slice(1, -1).reverse()
    ] : order;
}
function buildAnimationModel(frames, clips, loopMode, sourceIndices = frames.map((_, i)=>i)) {
    if (!frames.length || frames.length > 500 || clips.length > 500 || sourceIndices.length !== frames.length || sourceIndices.some((i)=>!Number.isInteger(i) || i < 0 || i > 499) || new Set(sourceIndices).size !== frames.length || new Set(frames.map((f)=>f.id)).size !== frames.length || ![
        'repeat',
        'once',
        'ping-pong'
    ].includes(loopMode) || frames.some((f)=>typeof f.id !== 'string' || !f.id.length || f.id.length > 256) || frames.some((f)=>!Number.isInteger(f.durationMs) || f.durationMs < __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMinMs || f.durationMs > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMaxMs)) {
        throw new Error('Animation export requires valid frames and hold durations.');
    }
    const positions = new Map(sourceIndices.map((index, i)=>[
            index,
            i
        ]));
    const names = new Set();
    const uniqueName = (input)=>{
        const base = input.trim() || 'Animation';
        let name = base, suffix = 2;
        while(names.has(name))name = `${base} (${suffix++})`;
        names.add(name);
        return name;
    };
    const model = {
        frames: frames.map((f, i)=>({
                id: f.id,
                sourceIndex: sourceIndices[i],
                durationMs: f.durationMs
            })),
        clips: [
            {
                id: '__all__',
                sourceName: 'All frames',
                name: uniqueName('All frames'),
                frames: playbackOrder(0, frames.length - 1, 'forward', loopMode),
                loop: loopMode !== 'once'
            }
        ]
    };
    for (const clip of clips){
        if (typeof clip.name !== 'string' || clip.name.length > 256 || !Number.isInteger(clip.startFrame) || clip.startFrame < 0 || !Number.isInteger(clip.endFrame) || clip.endFrame < clip.startFrame || clip.endFrame - clip.startFrame >= 500 || clip.loopMode && ![
            'forward',
            'reverse',
            'ping-pong'
        ].includes(clip.loopMode)) {
            throw new Error('A clip has invalid export bounds or direction.');
        }
        const sequence = playbackOrder(clip.startFrame, clip.endFrame, clip.loopMode, loopMode);
        // Scoped sheets contain only complete clips, never silently shortened animations.
        if (!sequence.every((index)=>positions.has(index))) continue;
        model.clips.push({
            id: clip.id,
            sourceName: clip.name,
            name: uniqueName(clip.name),
            frames: sequence.map((index)=>positions.get(index)),
            loop: loopMode !== 'once'
        });
    }
    return model;
}
function godotSpriteFramesResource(model, rects, textureFilename) {
    const resources = rects.map((r, i)=>`[sub_resource type="AtlasTexture" id="frame_${i}"]\natlas = ExtResource("atlas")\nregion = Rect2(${r.x}, ${r.y}, ${r.w}, ${r.h})\nfilter_clip = true`).join('\n\n');
    const animations = model.clips.map((clip)=>`{"name": &${JSON.stringify(clip.name)}, "loop": ${clip.loop ? 1 : 0}, "speed": 1000.0, "frames": [${clip.frames.map((i)=>`{"duration": ${model.frames[i].durationMs}.0, "texture": SubResource("frame_${i}")}`).join(', ')}]}`).join(',\n');
    return `[gd_resource type="SpriteFrames" load_steps=${rects.length + 2} format=3]\n\n[ext_resource type="Texture2D" path="res://${textureFilename}" id="atlas"]\n\n${resources}\n\n[resource]\nanimations = [${animations}]\n`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/export/godotPaletteShader.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "godotPaletteShader",
    ()=>godotPaletteShader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteAdmission.ts [app-client] (ecmascript)");
;
function godotPaletteShader(tracks, paletteLength, legacyNormalized = false) {
    if (!Number.isInteger(paletteLength) || paletteLength < 1 || paletteLength > 256 || tracks.length > 64 || tracks.some((t)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paletteCycleTrackError"])(t, paletteLength))) throw new Error('Invalid palette shader settings.');
    const logic = tracks.filter((t)=>t.enabled && t.rate > 0 && t.high > t.low).map((t)=>{
        const size = t.high - t.low + 1, period = t.direction === 'ping-pong' ? 2 * (size - 1) : size;
        const rate = Number.isInteger(t.rate) ? `${t.rate}.0` : String(t.rate);
        const clock = t.blendShift ? `elapsed_seconds * ${rate}` : `floor(elapsed_seconds * ${rate})`;
        const phase = t.direction === 'ping-pong' ? `${clock} + k` : `k + ${clock} * ${t.direction === 'reverse' ? '1.0' : '-1.0'}`;
        const offsets = t.direction === 'ping-pong' ? `float a = (step_a < ${size}.0) ? step_a : ${period}.0 - step_a;
        float b = (step_b < ${size}.0) ? step_b : ${period}.0 - step_b;` : 'float a = step_a; float b = step_b;';
        return `if (idx >= ${t.low} && idx <= ${t.high}) {
        float k = float(idx - ${t.low});
        float phase = mod(${phase}, ${period}.0);
        float step_a = floor(phase); float step_b = mod(step_a + 1.0, ${period}.0);
        ${offsets}
        vec3 first = palette_rgb(${t.low}.0 + a);
        vec3 second = palette_rgb(${t.low}.0 + b);
        rgb = ${t.blendShift ? 'floor(mix(first, second, fract(phase)) * 255.0 + 0.5) / 255.0' : 'first'};
    }`;
    }).join('\n    ');
    const generated = `shader_type canvas_item;
// Raw index bytes and source alpha are independent opaque data textures.
uniform sampler2D index_texture : filter_nearest, repeat_disable;
uniform sampler2D alpha_texture : filter_nearest, repeat_disable;
uniform sampler2D palette_texture : filter_nearest, repeat_disable;
uniform float elapsed_seconds = 0.0;
vec3 palette_rgb(float idx) { return texture(palette_texture, vec2((idx + 0.5) / ${paletteLength}.0, 0.5)).rgb; }
void fragment() {
    int idx = int(round(texture(index_texture, UV).r * 255.0));
    vec3 rgb = palette_rgb(float(idx));
    ${logic}
    COLOR = vec4(rgb, texture(alpha_texture, UV).r);
}
`;
    if (!legacyNormalized) return generated;
    // Preserve the standalone export's documented normalized-index contract.
    return generated.replace('uniform sampler2D index_texture : filter_nearest, repeat_disable;\n', '').replace('uniform sampler2D alpha_texture : filter_nearest, repeat_disable;\n', '').replace('uniform float elapsed_seconds = 0.0;\n', '// RED = index / max(1, palette_size - 1), ALPHA = source alpha.\n').replaceAll('elapsed_seconds', 'TIME').replace('texture(index_texture, UV).r * 255.0', `texture(TEXTURE, UV).r * ${Math.max(1, paletteLength - 1)}.0`).replace('texture(alpha_texture, UV).r', 'texture(TEXTURE, UV).a');
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/export/shaderExporter.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildCanvasPaletteIndexMap",
    ()=>buildCanvasPaletteIndexMap,
    "generateGodot4Shader",
    ()=>generateGodot4Shader,
    "generateLoopAnimationCanvases",
    ()=>generateLoopAnimationCanvases,
    "generateUnityUrpShader",
    ()=>generateUnityUrpShader
]);
/**
 * shaderExporter.ts
 * Standalone Godot 4 & Unity URP 2D Palette Cycling Shader Exporter & Frame Unroller
 * 
 * Generates hardware shaders with point-filtering, ping-pong oscillation, and sub-step BlendShift,
 * and generates unrolled animation frames using harmonic rational retuning for seamless APNG/GIF loops.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$export$2f$godotPaletteShader$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/export/godotPaletteShader.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteCycling.ts [app-client] (ecmascript)");
;
;
function generateGodot4Shader(tracks, paletteLength = 256) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$export$2f$godotPaletteShader$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["godotPaletteShader"])(tracks, paletteLength, true);
}
function generateUnityUrpShader(tracks, paletteLength = 256) {
    const activeTracks = tracks.filter((t)=>t.enabled && t.rate > 0 && t.high > t.low);
    let trackLogic = '';
    activeTracks.forEach((track, idx)=>{
        const S = track.high - track.low + 1;
        const isPingPong = track.direction === 'ping-pong';
        const M = isPingPong ? 2 * (S - 1) : S;
        const speed = track.rate.toFixed(3);
        const low = track.low;
        const high = track.high;
        if (isPingPong) {
            trackLogic += `
                // Track ${idx}: Ping-Pong [${low}..${high}]
                if (color_idx >= ${low} && color_idx <= ${high}) {
                    float rel_idx = float(color_idx - ${low});
                    float p = fmod(_Time.y * ${speed} + rel_idx, ${M.toFixed(1)});
                    if (p < 0.0) p += ${M.toFixed(1)};
                    float offset = (p < ${S.toFixed(1)}) ? p : (${M.toFixed(1)} - p);
                    final_idx = float(${low}) + offset;
                }`;
        } else {
            const dirSign = track.direction === 'reverse' ? '1.0' : '-1.0';
            trackLogic += `
                // Track ${idx}: ${track.direction === 'reverse' ? 'Reverse' : 'Forward'} [${low}..${high}]
                if (color_idx >= ${low} && color_idx <= ${high}) {
                    float rel_idx = float(color_idx - ${low});
                    float shift = fmod(rel_idx + (${dirSign} * _Time.y * ${speed}), ${S.toFixed(1)});
                    if (shift < 0.0) shift += ${S.toFixed(1)};
                    final_idx = float(${low}) + shift;
                }`;
        }
    });
    return `// RED = index / max(1, palette_size - 1), ALPHA = source alpha.
Shader "PixiBun/PaletteCycling2D"
{
    Properties
    {
        _MainTex ("Indexed Sprite Texture", 2D) = "white" {}
        _PaletteTex ("Palette LUT Texture", 2D) = "white" {}
        _PaletteSize ("Palette Size", Float) = ${paletteLength.toFixed(1)}
    }
    SubShader
    {
        Tags { "RenderType"="Transparent" "Queue"="Transparent" "RenderPipeline"="UniversalPipeline" }
        Blend SrcAlpha OneMinusSrcAlpha
        Cull Off
        ZWrite Off

        Pass
        {
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            struct Attributes
            {
                float4 positionOS   : POSITION;
                float2 uv           : TEXCOORD0;
                float4 color        : COLOR;
            };

            struct Varyings
            {
                float4 positionHCS  : SV_POSITION;
                float2 uv           : TEXCOORD0;
                float4 color        : COLOR;
            };

            TEXTURE2D(_MainTex);
            SAMPLER(sampler_MainTex);

            TEXTURE2D(_PaletteTex);
            SAMPLER(sampler_PaletteTex);

            CBUFFER_START(UnityPerMaterial)
                float _PaletteSize;
            CBUFFER_END

            Varyings vert(Attributes input)
            {
                Varyings output;
                output.positionHCS = TransformObjectToHClip(input.positionOS.xyz);
                output.uv = input.uv;
                output.color = input.color;
                return output;
            }

            half4 frag(Varyings input) : SV_Target
            {
                half4 sprite = SAMPLE_TEXTURE2D(_MainTex, sampler_MainTex, input.uv);
                if (sprite.a == 0.0) return half4(0, 0, 0, 0);

                int color_idx = (int)round(sprite.r * (_PaletteSize - 1.0));
                float final_idx = (float)color_idx;
${trackLogic || '                // No active tracks'}

                float u = (final_idx + 0.5) / _PaletteSize;
                half4 pal = SAMPLE_TEXTURE2D(_PaletteTex, sampler_PaletteTex, float2(u, 0.5));
                return half4(pal.rgb, sprite.a * input.color.a);
            }
            ENDHLSL
        }
    }
}
`;
}
function buildCanvasPaletteIndexMap(ctx, width, height, paletteHex) {
    if (paletteHex.length < 1 || paletteHex.length > 256) {
        throw new RangeError('Palette cycling requires between 1 and 256 colors.');
    }
    const imgData = ctx.getImageData(0, 0, width, height);
    const data = imgData.data;
    const numPixels = width * height;
    const indexMap = new Uint8Array(numPixels);
    const alpha = new Uint8Array(numPixels);
    // Pre-parse palette RGBs
    const paletteRgbs = paletteHex.map((hex)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(hex));
    for(let i = 0; i < numPixels; i++){
        const pIdx = i * 4;
        const a = data[pIdx + 3];
        alpha[i] = a;
        if (a === 0) continue;
        const r = data[pIdx];
        const g = data[pIdx + 1];
        const b = data[pIdx + 2];
        // Nearest color search in palette
        let bestDist = Infinity;
        let bestIdx = 0;
        for(let k = 0; k < paletteRgbs.length; k++){
            const pr = paletteRgbs[k][0];
            const pg = paletteRgbs[k][1];
            const pb = paletteRgbs[k][2];
            const dist = (r - pr) * (r - pr) + (g - pg) * (g - pg) + (b - pb) * (b - pb);
            if (dist < bestDist) {
                bestDist = dist;
                bestIdx = k;
                if (dist === 0) break;
            }
        }
        indexMap[i] = bestIdx;
    }
    return {
        indices: indexMap,
        alpha
    };
}
function generateLoopAnimationCanvases(sourceCanvas, basePaletteHex, tracks, targetDurationSec = 2.0, fps = 30) {
    const width = sourceCanvas.width;
    const height = sourceCanvas.height;
    const ctx = sourceCanvas.getContext('2d');
    if (!ctx) return [];
    const indexMap = buildCanvasPaletteIndexMap(ctx, width, height, basePaletteHex);
    const retunedTracks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["retuneTracksForSeamlessLoop"])(tracks, targetDurationSec);
    const cyclingRegisters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildCycleRegisterMask"])(retunedTracks, basePaletteHex.length);
    const sourceData = ctx.getImageData(0, 0, width, height);
    const source32 = new Uint32Array(sourceData.data.buffer);
    const totalFrames = Math.max(1, Math.round(targetDurationSec * fps));
    const canvases = [];
    const lut32 = new Uint32Array(basePaletteHex.length);
    for(let f = 0; f < totalFrames; f++){
        const elapsedSec = f / fps;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateLivePaletteLUT32"])(basePaletteHex, retunedTracks, elapsedSec, lut32);
        const frameCanvas = document.createElement('canvas');
        frameCanvas.width = width;
        frameCanvas.height = height;
        const fCtx = frameCanvas.getContext('2d');
        if (!fCtx) continue;
        const frameData = fCtx.createImageData(width, height);
        const data32 = new Uint32Array(frameData.data.buffer);
        for(let i = 0; i < width * height; i++){
            const palIdx = indexMap.indices[i];
            if (indexMap.alpha[i] === 0 || !cyclingRegisters[palIdx]) {
                data32[i] = source32[i];
            } else {
                data32[i] = (lut32[palIdx] ?? 0) & 0x00ffffff | indexMap.alpha[i] << 24;
            }
        }
        fCtx.putImageData(frameData, 0, 0);
        canvases.push(frameCanvas);
    }
    return canvases;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/procedural/waveFunctionCollapse.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_WFC_MAX_WORKING_SET_BYTES",
    ()=>DEFAULT_WFC_MAX_WORKING_SET_BYTES,
    "_wfcInternal",
    ()=>_wfcInternal,
    "allocateWfcSolverState",
    ()=>allocateWfcSolverState,
    "buildWfcPropagatorTable",
    ()=>buildWfcPropagatorTable,
    "estimateWfcWorkingSet",
    ()=>estimateWfcWorkingSet,
    "safeAdd",
    ()=>safeAdd,
    "safeMultiply",
    ()=>safeMultiply,
    "synthesizeWfc",
    ()=>synthesizeWfc,
    "validateWfcResourceBudget",
    ()=>validateWfcResourceBudget,
    "verifyWfcAdjacencyConstraints",
    ()=>verifyWfcAdjacencyConstraints
]);
/**
 * WaveFunctionCollapse (WFC) Overlapping Constraint-Satisfaction Texture Synthesis Engine.
 *
 * Academic / Industry References:
 * - Maxim Gumin, "WaveFunctionCollapse," 2016 (constraint-satisfaction procedural texture synthesis).
 * - Paul Merrell, "Example-Based Model Synthesis," I3D 2007 (ACM SIGGRAPH Symposium on
 *   Interactive 3D Graphics and Games). DOI: 10.1145/1230100.1230118.
 *
 * Extracts N x N local overlapping pixel neighborhood patterns, calculates pattern compatibility
 * across orthogonal directions, and collapses a wave of possibilities using minimum Shannon entropy
 * observation and constraint propagation (AC-4 arc consistency with pre-allocated support counters).
 *
 * A WfcResult with success === true and status === 'complete' has zero local
 * neighborhood constraint violations across the generated region.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/canvasLimits.ts [app-client] (ecmascript)");
;
;
const DEFAULT_WFC_MAX_WORKING_SET_BYTES = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_WFC_WORKING_SET_BYTES"];
function safeMultiply(...factors) {
    let result = 1;
    for (const factor of factors){
        if (!Number.isSafeInteger(factor) || factor < 0) {
            return null;
        }
        if (factor === 0) return 0;
        if (result > Math.floor(Number.MAX_SAFE_INTEGER / factor)) {
            return null;
        }
        result *= factor;
    }
    return Number.isSafeInteger(result) ? result : null;
}
function safeAdd(...terms) {
    let sum = 0;
    for (const term of terms){
        if (!Number.isSafeInteger(term) || term < 0) {
            return null;
        }
        if (sum > Number.MAX_SAFE_INTEGER - term) {
            return null;
        }
        sum += term;
    }
    return Number.isSafeInteger(sum) ? sum : null;
}
function estimateWfcWorkingSet(numPatterns, numCells, n = 2, directions = 4) {
    if (!Number.isSafeInteger(numPatterns) || !Number.isSafeInteger(numCells) || !Number.isSafeInteger(n) || !Number.isSafeInteger(directions) || numPatterns < 0 || numCells < 0 || n < 2 || n > 4 || directions !== 4) {
        return null;
    }
    const nArea = safeMultiply(n, n);
    if (nArea === null) return null;
    // patternStorageBytes = P * (n^2 * 4 + 16)
    const bytesPerPattern = safeAdd(safeMultiply(nArea, 4), 16);
    if (bytesPerPattern === null) return null;
    const patternStorageBytes = safeMultiply(numPatterns, bytesPerPattern);
    if (patternStorageBytes === null) return null;
    // Dense neighbors plus offsets, counts, and temporary write positions.
    const pSquared = safeMultiply(numPatterns, numPatterns);
    if (pSquared === null) return null;
    const propagatorBytes = safeAdd(safeMultiply(directions, pSquared, 4) ?? Number.MAX_SAFE_INTEGER, safeMultiply(directions, numPatterns, 12) ?? Number.MAX_SAFE_INTEGER);
    if (propagatorBytes === null) return null;
    // waveBytes = C * P
    const waveBytes = safeMultiply(numCells, numPatterns);
    if (waveBytes === null) return null;
    // compatibilityBytes = C * P * D * 4 = 16 * C * P
    const compatibilityBytes = safeMultiply(numCells, numPatterns, directions, 4);
    if (compatibilityBytes === null) return null;
    // entropyBytes = C * (4 + 8 + 8) = 20 * C
    const entropyBytes = safeMultiply(numCells, 20);
    if (entropyBytes === null) return null;
    const propagationStackBytes = safeMultiply(numCells, numPatterns, 8);
    if (propagationStackBytes === null) return null;
    // outputBytes = C * 4
    const outputBytes = safeMultiply(numCells, 4);
    if (outputBytes === null) return null;
    const totalWorkingSetBytes = safeAdd(patternStorageBytes, propagatorBytes, waveBytes, compatibilityBytes, entropyBytes, propagationStackBytes, outputBytes);
    if (totalWorkingSetBytes === null) return null;
    return {
        patternStorageBytes,
        propagatorBytes,
        waveBytes,
        compatibilityBytes,
        entropyBytes,
        propagationStackBytes,
        outputBytes,
        totalWorkingSetBytes
    };
}
function validateWfcResourceBudget(params) {
    const { numPatterns, numCells, n = 2, directions = 4 } = params;
    const requestedBudget = params.maxWorkingSetBytes ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_WFC_WORKING_SET_BYTES"];
    if (!Number.isSafeInteger(requestedBudget) || requestedBudget <= 0) {
        return {
            admitted: false,
            totalWorkingSetBytes: Infinity,
            maxWorkingSetBytes: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_WFC_WORKING_SET_BYTES"],
            breakdown: null,
            error: 'WaveFunctionCollapse: invalid working set budget ceiling.'
        };
    }
    // Enforce bounded budget contract: callers can inject a smaller budget for boundary testing,
    // but cannot bypass or raise the safety ceiling above MAX_WFC_WORKING_SET_BYTES.
    const maxWorkingSetBytes = Math.min(requestedBudget, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_WFC_WORKING_SET_BYTES"]);
    const retainedSampleBytes = params.retainedSampleBytes ?? 0;
    if (!Number.isSafeInteger(retainedSampleBytes) || retainedSampleBytes < 0) {
        return {
            admitted: false,
            totalWorkingSetBytes: Infinity,
            maxWorkingSetBytes,
            breakdown: null,
            error: 'WaveFunctionCollapse: invalid retained sample byte count.'
        };
    }
    const breakdown = estimateWfcWorkingSet(numPatterns, numCells, n, directions);
    if (!breakdown) {
        return {
            admitted: false,
            totalWorkingSetBytes: Infinity,
            maxWorkingSetBytes,
            breakdown: null,
            error: 'WaveFunctionCollapse: arithmetic overflow calculating working set bounds.'
        };
    }
    const totalWorkingSetBytes = safeAdd(breakdown.totalWorkingSetBytes, retainedSampleBytes);
    if (totalWorkingSetBytes === null || totalWorkingSetBytes > maxWorkingSetBytes) {
        const estimatedMib = ((totalWorkingSetBytes ?? Number.MAX_SAFE_INTEGER) / (1024 * 1024)).toFixed(1);
        const budgetMib = (maxWorkingSetBytes / (1024 * 1024)).toFixed(0);
        return {
            admitted: false,
            totalWorkingSetBytes: totalWorkingSetBytes ?? Infinity,
            maxWorkingSetBytes,
            breakdown,
            error: `WaveFunctionCollapse: projected working set (${estimatedMib} MiB) exceeds safe resource budget (${budgetMib} MiB). Reduce output dimensions, sample size, or symmetries.`
        };
    }
    return {
        admitted: true,
        totalWorkingSetBytes,
        maxWorkingSetBytes,
        breakdown
    };
}
function allocateWfcSolverState(numCells, numPatterns, propagator, sumWeights, initialSumWeightLogWeights) {
    const wave = new Uint8Array(numCells * numPatterns);
    wave.fill(1);
    const possibleCount = new Int32Array(numCells);
    possibleCount.fill(numPatterns);
    const cellSumWeights = new Float64Array(numCells);
    cellSumWeights.fill(sumWeights);
    const cellSumWeightLogWeights = new Float64Array(numCells);
    cellSumWeightLogWeights.fill(initialSumWeightLogWeights);
    const compatible = new Int32Array(numCells * numPatterns * 4);
    for(let c = 0; c < numCells; c++){
        for(let p = 0; p < numPatterns; p++){
            for(let d = 0; d < 4; d++){
                const oppositeDir = OPPOSITE[d];
                const count = propagator.counts[oppositeDir * numPatterns + p];
                compatible[(c * numPatterns + p) * 4 + d] = count;
            }
        }
    }
    return {
        wave,
        possibleCount,
        cellSumWeights,
        cellSumWeightLogWeights,
        compatible
    };
}
const _wfcInternal = {
    allocateSolverState: allocateWfcSolverState,
    buildPropagatorTable: buildWfcPropagatorTable
};
// 4 Orthogonal Directions: [dx, dy]
// 0: Up (0, -1), 1: Right (1, 0), 2: Down (0, 1), 3: Left (-1, 0)
const DX = [
    0,
    1,
    0,
    -1
];
const DY = [
    -1,
    0,
    1,
    0
];
const OPPOSITE = [
    2,
    3,
    0,
    1
];
/**
 * Deterministic 32-bit Mulberry32 PRNG.
 */ function createPrng(seed) {
    let a = (seed ^ 0x6d2b79f5) >>> 0;
    return function next() {
        a = a + 0x6d2b79f5 >>> 0;
        let t = Math.imul(a ^ a >>> 15, 1 | a);
        t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}
/**
 * Packs 4 RGBA bytes into a 32-bit unsigned integer.
 */ function packRgba(r, g, b, a) {
    return (r << 24 | g << 16 | b << 8 | a) >>> 0;
}
/**
 * Unpacks 32-bit unsigned integer into 4 RGBA bytes.
 */ function unpackRgba(color, out, offset) {
    out[offset] = color >>> 24 & 0xff;
    out[offset + 1] = color >>> 16 & 0xff;
    out[offset + 2] = color >>> 8 & 0xff;
    out[offset + 3] = color & 0xff;
}
/**
 * Extracts rotated/reflected variants of an N x N pattern.
 */ function getSymmetryVariants(pattern, n, symmetries) {
    const rotate90 = (p)=>{
        const res = new Uint32Array(n * n);
        for(let y = 0; y < n; y++){
            for(let x = 0; x < n; x++){
                res[x * n + (n - 1 - y)] = p[y * n + x];
            }
        }
        return res;
    };
    const reflect = (p)=>{
        const res = new Uint32Array(n * n);
        for(let y = 0; y < n; y++){
            for(let x = 0; x < n; x++){
                res[y * n + (n - 1 - x)] = p[y * n + x];
            }
        }
        return res;
    };
    const variants = [];
    let curr = pattern;
    for(let r = 0; r < (symmetries === 1 ? 1 : 4); r++){
        variants.push(curr);
        if (symmetries === 8) {
            variants.push(reflect(curr));
        }
        if (symmetries > 1) {
            curr = rotate90(curr);
        }
    }
    return variants;
}
/**
 * Serializes an N x N pattern to string key for deduplication.
 */ function patternKey(pattern) {
    return pattern.join(',');
}
/**
 * Checks if pattern p1 placed at (0, 0) is compatible with p2 placed at (dx, dy).
 */ function arePatternsCompatible(p1, p2, n, dir) {
    const dx = DX[dir];
    const dy = DY[dir];
    const xMin = Math.max(0, dx);
    const xMax = Math.min(n, n + dx);
    const yMin = Math.max(0, dy);
    const yMax = Math.min(n, n + dy);
    for(let y = yMin; y < yMax; y++){
        for(let x = xMin; x < xMax; x++){
            const v1 = p1[y * n + x];
            const v2 = p2[(y - dy) * n + (x - dx)];
            if (v1 !== v2) return false;
        }
    }
    return true;
}
function buildWfcPropagatorTable(patterns, n, directions = 4) {
    const numPatterns = patterns.length;
    const slotCount = directions * numPatterns;
    const counts = new Int32Array(slotCount);
    // Pass 1: Count compatible neighbor patterns per (direction, pattern) slot
    let totalPairs = 0;
    for(let dir = 0; dir < directions; dir++){
        const dirOffset = dir * numPatterns;
        for(let p1 = 0; p1 < numPatterns; p1++){
            let c = 0;
            for(let p2 = 0; p2 < numPatterns; p2++){
                if (arePatternsCompatible(patterns[p1], patterns[p2], n, dir)) {
                    c++;
                }
            }
            counts[dirOffset + p1] = c;
            totalPairs += c;
        }
    }
    // Compute prefix-sum offsets
    const offsets = new Int32Array(slotCount);
    let currentOffset = 0;
    for(let i = 0; i < slotCount; i++){
        offsets[i] = currentOffset;
        currentOffset += counts[i];
    }
    // Pass 2: Populate contiguous neighbors typed array
    const neighbors = new Int32Array(totalPairs);
    const writePos = new Int32Array(offsets);
    for(let dir = 0; dir < directions; dir++){
        const dirOffset = dir * numPatterns;
        for(let p1 = 0; p1 < numPatterns; p1++){
            const slot = dirOffset + p1;
            for(let p2 = 0; p2 < numPatterns; p2++){
                if (arePatternsCompatible(patterns[p1], patterns[p2], n, dir)) {
                    neighbors[writePos[slot]++] = p2;
                }
            }
        }
    }
    const exactBytes = slotCount * 4 + slotCount * 4 + totalPairs * 4;
    return {
        directions,
        numPatterns,
        offsets,
        counts,
        neighbors,
        totalCompatiblePairs: totalPairs,
        exactBytes
    };
}
function synthesizeWfc(input, options = {}) {
    const requestedBudget = options.maxWorkingSetBytes ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_WFC_WORKING_SET_BYTES"];
    const maxWorkingSetBytes = Number.isSafeInteger(requestedBudget) && requestedBudget > 0 ? Math.min(requestedBudget, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_WFC_WORKING_SET_BYTES"]) : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_WFC_WORKING_SET_BYTES"];
    const n = Math.max(2, Math.min(4, options.N ?? 2));
    const periodicInput = options.periodicInput ?? true;
    const periodicOutput = options.periodicOutput ?? true;
    const symmetries = options.symmetries ?? 8;
    const baseSeed = options.seed ?? 42;
    const maxRetries = Math.max(1, options.maxRetries ?? 10);
    const { sampleData, sampleWidth, sampleHeight, outputWidth, outputHeight } = input;
    // 0. Input validation
    if (!Number.isSafeInteger(sampleWidth) || !Number.isSafeInteger(sampleHeight) || !Number.isSafeInteger(outputWidth) || !Number.isSafeInteger(outputHeight) || sampleWidth <= 0 || sampleHeight <= 0 || outputWidth <= 0 || outputHeight <= 0 || !sampleData || !(sampleData instanceof Uint8Array || sampleData instanceof Uint8ClampedArray)) {
        return {
            success: false,
            status: 'invalid_input',
            error: 'WaveFunctionCollapse: invalid input dimensions or parameters.',
            data: new Uint8ClampedArray(0),
            width: outputWidth ?? 0,
            height: outputHeight ?? 0,
            iterations: 0,
            patternsCount: 0
        };
    }
    const numCells = safeMultiply(outputWidth, outputHeight);
    const samplePixelsCount = safeMultiply(sampleWidth, sampleHeight);
    if (numCells === null || samplePixelsCount === null) {
        return {
            success: false,
            status: 'invalid_input',
            error: 'WaveFunctionCollapse: canvas pixel count overflows safe integer range.',
            data: new Uint8ClampedArray(0),
            width: outputWidth,
            height: outputHeight,
            iterations: 0,
            patternsCount: 0
        };
    }
    const expectedSampleBytes = safeMultiply(samplePixelsCount, 4);
    if (expectedSampleBytes === null || sampleData.length < expectedSampleBytes) {
        return {
            success: false,
            status: 'invalid_input',
            error: 'WaveFunctionCollapse: sample data buffer length is insufficient for specified dimensions.',
            data: new Uint8ClampedArray(0),
            width: outputWidth,
            height: outputHeight,
            iterations: 0,
            patternsCount: 0
        };
    }
    const xLimit = periodicInput ? sampleWidth : sampleWidth - n + 1;
    const yLimit = periodicInput ? sampleHeight : sampleHeight - n + 1;
    if (xLimit <= 0 || yLimit <= 0) {
        return {
            success: false,
            status: 'invalid_input',
            error: 'WaveFunctionCollapse: sample dimensions are too small for pattern size N.',
            data: new Uint8ClampedArray(0),
            width: outputWidth,
            height: outputHeight,
            iterations: 0,
            patternsCount: 0
        };
    }
    // Pre-extraction lower-bound & structural policy gate:
    // Rejects source configurations whose deterministic cumulative raw candidate-payload
    // allowance (S * K * 4n^2 bytes), sample pixel storage, or minimal output solver demand
    // already exceeds PixiBun's configured WFC subsystem admission-policy ceiling
    // (MAX_WFC_WORKING_SET_BYTES) before running candidate extraction and deduplication.
    //
    // Structural work terms:
    // - S = source candidate positions (xLimit * yLimit)
    //   where xLimit = periodicInput ? sampleWidth : sampleWidth - n + 1
    //         yLimit = periodicInput ? sampleHeight : sampleHeight - n + 1
    // - K = symmetry variants (1, 4, or 8)
    // - A = pattern pixel area (n^2)
    // - candidateTransforms = S * K
    // - candidatePixelWork = S * K * A
    // - cumulativeCandidateBytes = S * K * (4 * A) (deterministic cumulative raw candidate-payload allowance, not peak heap)
    // - samplePixelsBytes = samplePixelsCount * 4 (known exact raw pixel input bytes)
    // - minSolverBytes = 49 * numCells + 4*n^2 + 80 (minimal solver structures with P=1)
    const sourcePositions = safeMultiply(xLimit, yLimit);
    const patternPixelArea = safeMultiply(n, n);
    const patternFootprint = patternPixelArea !== null ? safeMultiply(patternPixelArea, 4) : null;
    const candidateTransforms = sourcePositions !== null ? safeMultiply(sourcePositions, symmetries) : null;
    const cumulativeCandidateBytes = candidateTransforms !== null && patternFootprint !== null ? safeMultiply(candidateTransforms, patternFootprint) : null;
    const samplePixelsBytes = safeMultiply(samplePixelsCount, 4);
    const minSolverBytes = safeAdd(safeMultiply(numCells, 49) ?? Number.MAX_SAFE_INTEGER, safeAdd(patternFootprint ?? 16, 80) ?? 96);
    // The input view and packed RGBA copy coexist with the solver and output.
    const retainedSampleBytes = samplePixelsBytes !== null ? safeAdd(sampleData.byteLength, samplePixelsBytes) : null;
    const coexistingCoreBytes = retainedSampleBytes !== null && minSolverBytes !== null ? safeAdd(retainedSampleBytes, minSolverBytes) : null;
    const earlyLowerBoundBytes = cumulativeCandidateBytes === null || coexistingCoreBytes === null ? null : Math.max(coexistingCoreBytes, cumulativeCandidateBytes);
    if (earlyLowerBoundBytes === null || earlyLowerBoundBytes > maxWorkingSetBytes) {
        const estMib = ((earlyLowerBoundBytes ?? Number.MAX_SAFE_INTEGER) / (1024 * 1024)).toFixed(1);
        const budgetMib = (maxWorkingSetBytes / (1024 * 1024)).toFixed(0);
        return {
            success: false,
            status: 'resource_limit_exceeded',
            error: `WaveFunctionCollapse: pre-extraction structural demand (${estMib} MiB) exceeds safe resource budget (${budgetMib} MiB). Reduce output dimensions, sample size, or symmetries.`,
            data: new Uint8ClampedArray(0),
            width: outputWidth,
            height: outputHeight,
            iterations: 0,
            patternsCount: 0,
            resourceUsage: {
                estimatedWorkingSetBytes: earlyLowerBoundBytes ?? Number.MAX_SAFE_INTEGER,
                maxWorkingSetBytes
            }
        };
    }
    // Convert sample image data to Uint32Array of packed RGBA
    const samplePixels = new Uint32Array(samplePixelsCount);
    for(let i = 0; i < samplePixelsCount; i++){
        const idx = i * 4;
        samplePixels[i] = packRgba(sampleData[idx], sampleData[idx + 1], sampleData[idx + 2], sampleData[idx + 3]);
    }
    // 1. Extract unique N x N patterns and calculate frequency weights
    const patternWeightsMap = new Map();
    for(let y = 0; y < yLimit; y++){
        for(let x = 0; x < xLimit; x++){
            const basePattern = new Uint32Array(n * n);
            for(let dy = 0; dy < n; dy++){
                for(let dx = 0; dx < n; dx++){
                    const sx = (x + dx) % sampleWidth;
                    const sy = (y + dy) % sampleHeight;
                    basePattern[dy * n + dx] = samplePixels[sy * sampleWidth + sx];
                }
            }
            const variants = getSymmetryVariants(basePattern, n, symmetries);
            for (const variant of variants){
                const key = patternKey(variant);
                const existing = patternWeightsMap.get(key);
                if (existing) {
                    existing.weight += 1;
                } else {
                    // Incremental unique-pattern admission:
                    // Check if admitting another unique pattern (nextP) would exceed the configured resource envelope
                    // for the actual output cells C, pattern size n, and effective budget.
                    const nextP = patternWeightsMap.size + 1;
                    const incrementalCheck = validateWfcResourceBudget({
                        numPatterns: nextP,
                        numCells,
                        n,
                        directions: 4,
                        maxWorkingSetBytes,
                        retainedSampleBytes: retainedSampleBytes ?? Number.MAX_SAFE_INTEGER
                    });
                    if (!incrementalCheck.admitted) {
                        return {
                            success: false,
                            status: 'resource_limit_exceeded',
                            error: incrementalCheck.error ?? 'WaveFunctionCollapse: resource limit exceeded during pattern extraction.',
                            data: new Uint8ClampedArray(0),
                            width: outputWidth,
                            height: outputHeight,
                            iterations: 0,
                            patternsCount: patternWeightsMap.size,
                            resourceUsage: {
                                estimatedWorkingSetBytes: incrementalCheck.totalWorkingSetBytes,
                                maxWorkingSetBytes,
                                breakdown: incrementalCheck.breakdown ?? undefined
                            }
                        };
                    }
                    patternWeightsMap.set(key, {
                        pattern: variant,
                        weight: 1
                    });
                }
            }
        }
    }
    const uniqueEntries = Array.from(patternWeightsMap.values());
    const numPatterns = uniqueEntries.length;
    if (numPatterns === 0) {
        return {
            success: false,
            status: 'invalid_input',
            error: 'WaveFunctionCollapse: no patterns extracted from sample.',
            data: new Uint8ClampedArray(0),
            width: outputWidth,
            height: outputHeight,
            iterations: 0,
            patternsCount: 0
        };
    }
    // 2. Resource Admission Gate: Validate exact working-set demands before building propagator or allocating solver state
    const admission = validateWfcResourceBudget({
        numPatterns,
        numCells,
        n,
        directions: 4,
        maxWorkingSetBytes,
        retainedSampleBytes: retainedSampleBytes ?? Number.MAX_SAFE_INTEGER
    });
    if (!admission.admitted) {
        return {
            success: false,
            status: 'resource_limit_exceeded',
            error: admission.error ?? 'WaveFunctionCollapse: resource limit exceeded.',
            data: new Uint8ClampedArray(0),
            width: outputWidth,
            height: outputHeight,
            iterations: 0,
            patternsCount: numPatterns,
            resourceUsage: {
                estimatedWorkingSetBytes: admission.totalWorkingSetBytes,
                maxWorkingSetBytes,
                breakdown: admission.breakdown ?? undefined
            }
        };
    }
    const patterns = uniqueEntries.map((e)=>e.pattern);
    const weights = new Float64Array(numPatterns);
    const weightLogWeights = new Float64Array(numPatterns);
    let sumWeights = 0;
    let initialSumWeightLogWeights = 0;
    for(let i = 0; i < numPatterns; i++){
        const w = uniqueEntries[i].weight;
        const wlw = w * Math.log(w);
        weights[i] = w;
        weightLogWeights[i] = wlw;
        sumWeights += w;
        initialSumWeightLogWeights += wlw;
    }
    // 3. Precompute typed compatibility table (propagator)
    const propagator = _wfcInternal.buildPropagatorTable(patterns, n, 4);
    // 4. Attempt synthesis loop with retries on contradiction
    // Each (cell, pattern) can be banned at most once per attempt; reuse this
    // bounded typed stack rather than allocating JS tuple arrays on propagation.
    const stack = new Int32Array(numCells * numPatterns * 2);
    for(let attempt = 0; attempt < maxRetries; attempt++){
        const prng = createPrng(baseSeed + attempt * 7919);
        // Allocate solver state using decoupled allocator hook (verifiable in tests)
        const { wave, possibleCount, cellSumWeights, cellSumWeightLogWeights, compatible } = _wfcInternal.allocateSolverState(numCells, numPatterns, propagator, sumWeights, initialSumWeightLogWeights);
        let stackTop = 0;
        const ban = (c, p)=>{
            const idx = c * numPatterns + p;
            if (wave[idx] === 0) return true; // Already banned
            wave[idx] = 0;
            possibleCount[c] -= 1;
            if (possibleCount[c] === 0) {
                return false; // Contradiction
            }
            const w = weights[p];
            cellSumWeights[c] -= w;
            cellSumWeightLogWeights[c] -= weightLogWeights[p];
            stack[stackTop++] = c;
            stack[stackTop++] = p;
            return true;
        };
        let totalCollapsed = 0;
        let contradiction = false;
        let iterations = 0;
        while(totalCollapsed < numCells){
            iterations++;
            // 4a. Find cell with minimum Shannon entropy > 0
            let minEntropy = Infinity;
            let minCell = -1;
            for(let c = 0; c < numCells; c++){
                const count = possibleCount[c];
                if (count <= 1) continue;
                const sW = cellSumWeights[c];
                const sWlogW = cellSumWeightLogWeights[c];
                // Shannon entropy: log(sum) - (sum(w log w) / sum)
                const entropy = Math.log(sW) - sWlogW / sW;
                // Add tiny deterministic noise to break ties uniformly
                const noise = prng() * 1e-6;
                const totalEntropy = entropy + noise;
                if (totalEntropy < minEntropy) {
                    minEntropy = totalEntropy;
                    minCell = c;
                }
            }
            if (minCell === -1) {
                break;
            }
            // 4b. Collapse minCell by choosing a pattern weighted by frequency
            const cellOffset = minCell * numPatterns;
            let totalRemainingWeight = 0;
            for(let p = 0; p < numPatterns; p++){
                if (wave[cellOffset + p] === 1) {
                    totalRemainingWeight += weights[p];
                }
            }
            let r = prng() * totalRemainingWeight;
            let chosenPattern = -1;
            for(let p = 0; p < numPatterns; p++){
                if (wave[cellOffset + p] === 1) {
                    r -= weights[p];
                    if (r <= 0) {
                        chosenPattern = p;
                        break;
                    }
                }
            }
            if (chosenPattern === -1) {
                chosenPattern = 0;
            }
            // Ban all patterns at minCell except chosenPattern
            for(let p = 0; p < numPatterns; p++){
                if (p !== chosenPattern && wave[cellOffset + p] === 1) {
                    if (!ban(minCell, p)) {
                        contradiction = true;
                        break;
                    }
                }
            }
            if (contradiction) break;
            // 4c. Propagate constraints (AC-4)
            while(stackTop > 0){
                const removedP = stack[--stackTop];
                const currCell = stack[--stackTop];
                const cx = currCell % outputWidth;
                const cy = Math.floor(currCell / outputWidth);
                for(let d = 0; d < 4; d++){
                    const nx = cx + DX[d];
                    const ny = cy + DY[d];
                    if (!periodicOutput && (nx < 0 || nx >= outputWidth || ny < 0 || ny >= outputHeight)) {
                        continue;
                    }
                    const wrappedX = (nx + outputWidth) % outputWidth;
                    const wrappedY = (ny + outputHeight) % outputHeight;
                    const neighborCell = wrappedY * outputWidth + wrappedX;
                    // For every pattern p2 compatible with removedP in direction d:
                    // Decrement compatible[neighborCell][p2][d]
                    const slot = d * numPatterns + removedP;
                    const startIdx = propagator.offsets[slot];
                    const count = propagator.counts[slot];
                    const endIdx = startIdx + count;
                    for(let i = startIdx; i < endIdx; i++){
                        const p2 = propagator.neighbors[i];
                        const compIdx = (neighborCell * numPatterns + p2) * 4 + d;
                        compatible[compIdx] -= 1;
                        if (compatible[compIdx] === 0) {
                            // No pattern in currCell supports p2 anymore; ban p2 from neighborCell
                            if (!ban(neighborCell, p2)) {
                                contradiction = true;
                                break;
                            }
                        }
                    }
                    if (contradiction) break;
                }
                if (contradiction) break;
            }
            if (contradiction) break;
            totalCollapsed++;
        }
        if (!contradiction) {
            // 5. Successful synthesis! Reconstruct output pixel buffer
            const outData = new Uint8ClampedArray(outputWidth * outputHeight * 4);
            for(let cy = 0; cy < outputHeight; cy++){
                for(let cx = 0; cx < outputWidth; cx++){
                    const cell = cy * outputWidth + cx;
                    const cellOffset = cell * numPatterns;
                    let patternIdx = 0;
                    for(let p = 0; p < numPatterns; p++){
                        if (wave[cellOffset + p] === 1) {
                            patternIdx = p;
                            break;
                        }
                    }
                    const pattern = patterns[patternIdx];
                    // Each pattern's (0, 0) top-left pixel is placed at (cx, cy)
                    const color = pattern[0];
                    const outIdx = (cy * outputWidth + cx) * 4;
                    unpackRgba(color, outData, outIdx);
                }
            }
            return {
                success: true,
                status: 'complete',
                data: outData,
                width: outputWidth,
                height: outputHeight,
                iterations,
                patternsCount: numPatterns,
                resourceUsage: {
                    estimatedWorkingSetBytes: admission.totalWorkingSetBytes,
                    maxWorkingSetBytes,
                    breakdown: admission.breakdown ?? undefined
                }
            };
        }
    }
    // If all attempts failed with contradictions
    return {
        success: false,
        status: 'contradiction',
        error: 'WaveFunctionCollapse: synthesis encountered contradictions after retries. Try a different sample region or N=2.',
        data: new Uint8ClampedArray(0),
        width: outputWidth,
        height: outputHeight,
        iterations: 0,
        patternsCount: numPatterns,
        resourceUsage: {
            estimatedWorkingSetBytes: admission.totalWorkingSetBytes,
            maxWorkingSetBytes,
            breakdown: admission.breakdown ?? undefined
        }
    };
}
function verifyWfcAdjacencyConstraints(outputData, outputWidth, outputHeight, sampleData, sampleWidth, sampleHeight, n = 2, periodicOutput = true, symmetries = 8) {
    // 1. Build valid pattern set from sample
    const samplePixels = new Uint32Array(sampleWidth * sampleHeight);
    for(let i = 0; i < sampleWidth * sampleHeight; i++){
        const idx = i * 4;
        samplePixels[i] = packRgba(sampleData[idx], sampleData[idx + 1], sampleData[idx + 2], sampleData[idx + 3]);
    }
    const validPatterns = new Set();
    for(let y = 0; y < sampleHeight; y++){
        for(let x = 0; x < sampleWidth; x++){
            const basePattern = new Uint32Array(n * n);
            for(let dy = 0; dy < n; dy++){
                for(let dx = 0; dx < n; dx++){
                    const sx = (x + dx) % sampleWidth;
                    const sy = (y + dy) % sampleHeight;
                    basePattern[dy * n + dx] = samplePixels[sy * sampleWidth + sx];
                }
            }
            const variants = getSymmetryVariants(basePattern, n, symmetries);
            for (const variant of variants){
                validPatterns.add(patternKey(variant));
            }
        }
    }
    // 2. Check every N x N patch in output
    const outputPixels = new Uint32Array(outputWidth * outputHeight);
    for(let i = 0; i < outputWidth * outputHeight; i++){
        const idx = i * 4;
        outputPixels[i] = packRgba(outputData[idx], outputData[idx + 1], outputData[idx + 2], outputData[idx + 3]);
    }
    const xLimit = periodicOutput ? outputWidth : outputWidth - n + 1;
    const yLimit = periodicOutput ? outputHeight : outputHeight - n + 1;
    let violations = 0;
    let totalChecked = 0;
    for(let y = 0; y < yLimit; y++){
        for(let x = 0; x < xLimit; x++){
            const patch = new Uint32Array(n * n);
            for(let dy = 0; dy < n; dy++){
                for(let dx = 0; dx < n; dx++){
                    const ox = (x + dx) % outputWidth;
                    const oy = (y + dy) % outputHeight;
                    patch[dy * n + dx] = outputPixels[oy * outputWidth + ox];
                }
            }
            totalChecked++;
            const key = patternKey(patch);
            if (!validPatterns.has(key)) {
                violations++;
            }
        }
    }
    return {
        violations,
        totalChecked
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/importFile.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "readImportFile",
    ()=>readImportFile,
    "reportImportError",
    ()=>reportImportError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/safeJson.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$imageHeaderProbe$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/imageHeaderProbe.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
;
;
;
async function readImportFile(file) {
    if (file.size > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].MAX_PAYLOAD_BYTES) throw new Error('Import exceeds the 50 MB file limit.');
    if (/\.(pixibun|json)$/i.test(file.name)) {
        return {
            type: 'project',
            filename: file.name,
            projectJson: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].parse(await file.text())
        };
    }
    const dimensions = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$imageHeaderProbe$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageHeaderProbe"].probe(file);
    const dataUrl = await new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.onload = ()=>resolve(reader.result);
        reader.onerror = ()=>reject(new Error('The image file could not be read.'));
        reader.readAsDataURL(file);
    });
    await new Promise((resolve, reject)=>{
        const img = new Image();
        img.onload = ()=>resolve();
        img.onerror = ()=>reject(new Error('The image could not be decoded.'));
        img.src = dataUrl;
    });
    return {
        type: 'image',
        filename: file.name,
        dataUrl,
        imgWidth: dimensions.width,
        imgHeight: dimensions.height
    };
}
function reportImportError(error) {
    const message = error instanceof Error ? error.message : 'The file could not be imported.';
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
        message,
        type: 'error'
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/practiceSession.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "beginPractice",
    ()=>beginPractice,
    "discardPractice",
    ()=>discardPractice,
    "getPracticeSession",
    ()=>getPracticeSession,
    "isPracticeActive",
    ()=>isPracticeActive,
    "keepPractice",
    ()=>keepPractice,
    "preparePractice",
    ()=>preparePractice,
    "subscribePracticeSession",
    ()=>subscribePracticeSession
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/stores/onboardingStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/historyEngine.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$desktopFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/storage/desktopFileSystem.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/storage/db.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/project/serialize.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/persistenceRevisions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sync/coDrawBridge.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/studioRouteSession.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
let active = null;
let suspended = null;
let savedPracticeVersion = null;
const listeners = new Set();
const publish = ()=>listeners.forEach((listener)=>listener());
const subscribePracticeSession = (listener)=>{
    listeners.add(listener);
    return ()=>{
        listeners.delete(listener);
    };
};
const getPracticeSession = ()=>active;
const isPracticeActive = ()=>active !== null;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerMemoryUsage"])('suspendedRasters', ()=>{
    let bytes = 0;
    for (const entry of suspended?.buffers.values() ?? [])bytes += entry.canvas.width * entry.canvas.height * 4;
    return bytes;
});
function requireSoloWorkspace() {
    if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].getRole() !== null) {
        throw new Error('Close your co-draw session in Studio before starting practice.');
    }
}
async function preparePractice() {
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    const studio = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStudioRouteSession"])(state.currentProjectId);
    let resume = studio?.resume() ?? null;
    try {
        requireSoloWorkspace();
        if (studio) {
            const checkpoint = studio.checkpoint().catch((error)=>({
                    ...studio.resume(),
                    error: error instanceof Error ? error.message : 'Saving failed.'
                }));
            // Publish before awaiting: Return during encoding must not hydrate old pixels.
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setStudioResume"])({
                ...studio.resume(),
                checkpoint
            });
            resume = await checkpoint;
            if (resume.error) throw new Error(resume.error);
        } else if (state.isDirty || (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["snapshotBuffers"])().size > 0) {
            throw new Error('Return to Studio and finish saving your drawing before starting practice.');
        }
        requireSoloWorkspace();
        if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId !== state.currentProjectId) {
            throw new Error('Your drawing changed while practice was preparing. Return to Studio and try again.');
        }
        const returnProjectId = studio ? state.currentProjectId : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPracticeReturnProject"])() ?? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLatestStoredProjectId"])();
        const current = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
        if (resume) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setStudioResume"])(resume);
        return {
            projectId: current.currentProjectId,
            editRevision: current.editRevision,
            resume,
            returnProjectId
        };
    } catch (error) {
        // A refused checkpoint must not cause rehydration to erase unsaved RAM work.
        if (studio) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setStudioResume"])({
            ...studio.resume(),
            error: error instanceof Error ? error.message : 'Saving failed.'
        });
        throw error;
    }
}
function beginPractice(prepared) {
    if (active) throw new Error('A practice workspace is already open.');
    requireSoloWorkspace();
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    if (state.currentProjectId !== prepared.projectId || state.editRevision !== prepared.editRevision) {
        throw new Error('Your drawing changed before practice could start. Return to Studio and try again.');
    }
    // This pointer protects the original after refresh, including an interrupted
    // Keep write. If session storage cannot hold it, fail before changing artwork.
    if (prepared.returnProjectId) {
        sessionStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PRACTICE_RETURN_KEY"], prepared.returnProjectId);
        if (sessionStorage.getItem(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PRACTICE_RETURN_KEY"]) !== prepared.returnProjectId) {
            throw new Error('Practice could not protect your return-to-drawing checkpoint.');
        }
    }
    suspended = {
        state,
        buffers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["snapshotBuffers"])(),
        file: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$desktopFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DesktopFileSystem"].captureAssociation(),
        resume: prepared.resume
    };
    const session = {
        token: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('practice'),
        projectId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj')
    };
    try {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setGlobalHistoryEngine"])(null);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceAllBuffers"])(new Map());
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getInitialState(), true);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().resetToNewProject(session.projectId);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setProjectName('Practice Drawing');
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"].getState().startPlayground();
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setBrushSize(2);
        savedPracticeVersion = null;
        active = session;
        publish();
        return session;
    } catch (error) {
        restoreSuspended();
        throw error;
    }
}
function restoreSuspended() {
    const original = suspended;
    if (!original) return;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setGlobalHistoryEngine"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceAllBuffers"])(original.buffers);
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState(original.state, true);
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$desktopFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DesktopFileSystem"].restoreAssociation(original.file);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setStudioResume"])(original.resume);
    suspended = null;
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"].setState({
        isPlaygroundActive: false,
        showStencilGuide: false
    });
}
function discardPractice(token) {
    if (active?.token !== token) return;
    const practiceId = active.projectId;
    active = null;
    restoreSuspended();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearPersistedRevisions"])(practiceId);
    publish();
}
async function keepPractice(token) {
    const session = active;
    if (!session || session.token !== token) throw new Error('Practice is no longer open.');
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    if (state.currentProjectId !== session.projectId || state.currentProjectId === suspended?.state.currentProjectId) {
        throw new Error('Practice no longer owns the current drawing.');
    }
    state.setIsPlaying(false);
    const revision = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().editRevision;
    const payload = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildAutosavePayloadAsync"])();
    if (active?.token !== token) throw new Error('Practice was closed before saving finished.');
    if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().editRevision !== revision) throw new Error('Practice changed while encoding. Try Keep again.');
    const outcome = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["autoSaveWorkspaceDetailed"])(session.projectId, payload.project, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateCompositeThumbnail"])(128, 128), payload.layerBlobs, undefined, savedPracticeVersion);
    if (!outcome.ok) throw new Error(outcome.error || 'Practice could not be saved. Your original drawing is still protected.');
    // Even if the UI was cancelled, the write is a separate copy. The return
    // checkpoint stays in place until a stable adoption has finished.
    if (active?.token !== token) throw new Error('Practice was closed before saving finished.');
    if (!outcome.storageVersion) throw new Error('Practice save did not return a confirmed storage version. Try Keep again.');
    savedPracticeVersion = outcome.storageVersion;
    if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().editRevision !== revision) {
        throw new Error('Practice changed while saving. Try Keep again to save the latest pixels.');
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["commitPersistedRevisions"])(session.projectId, payload.capturedRevisions);
    state.markClean();
    state.setSaveStatus('saved');
    const history = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalHistoryEngine"])();
    if (history) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rememberViewportHistory"])(session.projectId, history);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setStudioResume"])({
        projectId: session.projectId,
        storageVersions: new Map(outcome.storageVersion ? [
            [
                session.projectId,
                outcome.storageVersion
            ]
        ] : []),
        lifecycle: {
            phase: 'active',
            projectId: session.projectId
        },
        conflictProjectId: null
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$desktopFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DesktopFileSystem"].reset();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearPracticeReturnProject"])();
    suspended = null;
    active = null;
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"].setState({
        isPlaygroundActive: false,
        showStencilGuide: false
    });
    publish();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/serialize.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildAutosavePayloadAsync",
    ()=>buildAutosavePayloadAsync,
    "buildProjectFile",
    ()=>buildProjectFile,
    "buildProjectFileAsync",
    ()=>buildProjectFileAsync,
    "generateCompositeThumbnail",
    ()=>generateCompositeThumbnail,
    "hydrateProject",
    ()=>hydrateProject,
    "rasterizeLayerBlobAsync",
    ()=>rasterizeLayerBlobAsync,
    "rasterizeLayerPng",
    ()=>rasterizeLayerPng,
    "rasterizeLayerPngAsync",
    ()=>rasterizeLayerPngAsync
]);
// Bridge between live studio state (metadata in Zustand, pixels in the buffer
// registry) and the portable `.pixibun` ProjectFile format. Every byte of
// artwork passes through here for autosave, project export, and restore.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/types/project.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/schema.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$imageHeaderProbe$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/imageHeaderProbe.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/persistenceRevisions.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
function requireBrowser() {
    if (typeof document === 'undefined') {
        throw new Error('Project serialization needs a browser environment.');
    }
}
function rasterizeLayerPng(layerId, width, height) {
    requireBrowser();
    const hasContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layerId, width, height);
    const dataUrl = hasContent.canvas.toDataURL('image/png');
    const base64 = dataUrl.replace(/^data:image\/png;base64,/, '');
    // An all-transparent layer still encodes to PNG; that is fine to keep.
    return base64;
}
async function rasterizeLayerPngAsync(layerId, width, height) {
    requireBrowser();
    const hasContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layerId, width, height);
    if (!hasContent || !hasContent.canvas) return undefined;
    return new Promise((resolve, reject)=>{
        if (typeof hasContent.canvas.toBlob !== 'function') {
            return resolve(rasterizeLayerPng(layerId, width, height));
        }
        hasContent.canvas.toBlob((blob)=>{
            if (!blob) {
                return reject(new Error('Layer encoding failed.'));
            }
            const reader = new FileReader();
            reader.onloadend = ()=>{
                const result = reader.result;
                const base64 = result ? result.replace(/^data:image\/png;base64,/, '') : undefined;
                resolve(base64);
            };
            reader.onerror = ()=>{
                reject(new Error('Encoded layer could not be read.'));
            };
            reader.readAsDataURL(blob);
        }, 'image/png');
    });
}
async function rasterizeLayerBlobAsync(layerId, width, height) {
    requireBrowser();
    const hasContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layerId, width, height);
    if (!hasContent || !hasContent.canvas) return undefined;
    return new Promise((resolve)=>{
        if (typeof hasContent.canvas.toBlob !== 'function') {
            // Fallback: convert data URL to Blob
            try {
                const dataUrl = hasContent.canvas.toDataURL('image/png');
                const binStr = atob(dataUrl.split(',')[1]);
                const len = binStr.length;
                const arr = new Uint8Array(len);
                for(let i = 0; i < len; i++){
                    arr[i] = binStr.charCodeAt(i);
                }
                return resolve(new Blob([
                    arr
                ], {
                    type: 'image/png'
                }));
            } catch  {
                return resolve(undefined);
            }
        }
        hasContent.canvas.toBlob((blob)=>{
            resolve(blob || undefined);
        }, 'image/png');
    });
}
async function buildAutosavePayloadAsync(projectId) {
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    const projId = projectId || state.currentProjectId;
    const now = Date.now();
    const layerBlobs = [];
    const capturedRevisions = new Map();
    let dirtyLayerCount = 0;
    let totalLayerCount = 0;
    const frames = await Promise.all(state.frames.map(async (frame, frameIndex)=>{
        const layers = await Promise.all(frame.layers.map(async (layer)=>{
            totalLayerCount++;
            const currentRev = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBufferRevision"])(layer.id);
            const dirty = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isLayerDirty"])(projId, layer.id, currentRev, frameIndex);
            if (dirty) {
                dirtyLayerCount++;
                // toBlob snapshots synchronously, but its callback may arrive after another edit.
                const entry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layer.id, state.canvasWidth, state.canvasHeight);
                const encodedRevision = entry.contentRevision;
                const encodedGeneration = entry.generation;
                const blob = await rasterizeLayerBlobAsync(layer.id, state.canvasWidth, state.canvasHeight);
                if (!blob) throw new Error('Layer encoding failed; workspace was not saved.');
                layerBlobs.push({
                    layerId: layer.id,
                    frameIndex,
                    blob
                });
                capturedRevisions.set(layer.id, {
                    revision: encodedRevision,
                    generation: encodedGeneration,
                    frameIndex
                });
            } else {
                const persisted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPersistedRevision"])(projId, layer.id);
                if (persisted) {
                    capturedRevisions.set(layer.id, {
                        ...persisted
                    });
                }
            }
            return {
                id: layer.id,
                name: layer.name,
                visible: layer.visible,
                locked: layer.locked,
                opacity: layer.opacity,
                blendMode: layer.blendMode,
                tag: layer.tag,
                effect: layer.effect ? structuredClone(layer.effect) : undefined,
                research: layer.research ? structuredClone(layer.research) : undefined,
                // Omit pngBase64 in metadata payload when storing binary blobs to prevent double-storage
                pngBase64: undefined
            };
        }));
        return {
            id: frame.id,
            durationMs: frame.durationMs,
            layers
        };
    }));
    const project = {
        format: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_ID"],
        version: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_VERSION"],
        name: state.projectName,
        width: state.canvasWidth,
        height: state.canvasHeight,
        fps: state.fps,
        loopMode: state.loopMode,
        onionSkin: {
            ...state.onionSkin
        },
        palettes: structuredClone(state.palettes),
        currentPaletteId: state.currentPaletteId,
        customRamps: state.customRamps.map((r)=>({
                ...r,
                shades: [
                    ...r.shades
                ]
            })),
        clips: state.clips.map((c)=>({
                ...c
            })),
        frames,
        createdAt: now,
        updatedAt: now
    };
    return {
        project,
        layerBlobs,
        dirtyLayerCount,
        totalLayerCount,
        capturedRevisions
    };
}
function buildProjectFile() {
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    const now = Date.now();
    return {
        format: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_ID"],
        version: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_VERSION"],
        name: state.projectName,
        width: state.canvasWidth,
        height: state.canvasHeight,
        fps: state.fps,
        loopMode: state.loopMode,
        onionSkin: {
            ...state.onionSkin
        },
        palettes: structuredClone(state.palettes),
        currentPaletteId: state.currentPaletteId,
        customRamps: state.customRamps.map((r)=>({
                ...r,
                shades: [
                    ...r.shades
                ]
            })),
        clips: state.clips.map((c)=>({
                ...c
            })),
        frames: state.frames.map((frame)=>({
                id: frame.id,
                durationMs: frame.durationMs,
                layers: frame.layers.map((layer)=>({
                        id: layer.id,
                        name: layer.name,
                        visible: layer.visible,
                        locked: layer.locked,
                        opacity: layer.opacity,
                        blendMode: layer.blendMode,
                        tag: layer.tag,
                        effect: layer.effect ? structuredClone(layer.effect) : undefined,
                        research: layer.research ? structuredClone(layer.research) : undefined,
                        pngBase64: rasterizeLayerPng(layer.id, state.canvasWidth, state.canvasHeight)
                    }))
            })),
        createdAt: now,
        updatedAt: now
    };
}
async function buildProjectFileAsync() {
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    const now = Date.now();
    const frames = await Promise.all(state.frames.map(async (frame)=>{
        const layers = await Promise.all(frame.layers.map(async (layer)=>{
            const pngBase64 = await rasterizeLayerPngAsync(layer.id, state.canvasWidth, state.canvasHeight);
            return {
                id: layer.id,
                name: layer.name,
                visible: layer.visible,
                locked: layer.locked,
                opacity: layer.opacity,
                blendMode: layer.blendMode,
                tag: layer.tag,
                effect: layer.effect ? structuredClone(layer.effect) : undefined,
                research: layer.research ? structuredClone(layer.research) : undefined,
                pngBase64
            };
        }));
        return {
            id: frame.id,
            durationMs: frame.durationMs,
            layers
        };
    }));
    return {
        format: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_ID"],
        version: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_VERSION"],
        name: state.projectName,
        width: state.canvasWidth,
        height: state.canvasHeight,
        fps: state.fps,
        loopMode: state.loopMode,
        onionSkin: {
            ...state.onionSkin
        },
        palettes: structuredClone(state.palettes),
        currentPaletteId: state.currentPaletteId,
        customRamps: state.customRamps.map((r)=>({
                ...r,
                shades: [
                    ...r.shades
                ]
            })),
        clips: state.clips.map((c)=>({
                ...c
            })),
        frames,
        createdAt: now,
        updatedAt: now
    };
}
function generateCompositeThumbnail(maxWidth = 128, maxHeight = 128) {
    if (typeof document === 'undefined') return undefined;
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    const currentFrame = state.frames[state.activeFrameIndex] || state.frames[0];
    if (!currentFrame) return undefined;
    const w = state.canvasWidth;
    const h = state.canvasHeight;
    if (w <= 0 || h <= 0) return undefined;
    const scale = Math.min(maxWidth / w, maxHeight / h, 1);
    const targetW = Math.max(1, Math.round(w * scale));
    const targetH = Math.max(1, Math.round(h * scale));
    const canvas = document.createElement('canvas');
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) return undefined;
    ctx.imageSmoothingEnabled = false;
    currentFrame.layers.slice().reverse().forEach((layer)=>{
        if (!layer.visible) return;
        const entry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layer.id, w, h);
        ctx.globalAlpha = layer.opacity;
        ctx.globalCompositeOperation = layer.blendMode;
        ctx.drawImage(entry.canvas, 0, 0, targetW, targetH);
    });
    return canvas.toDataURL('image/png');
}
function base64ToBlob(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for(let i = 0; i < binary.length; i++){
        bytes[i] = binary.charCodeAt(i);
    }
    return new Blob([
        bytes
    ], {
        type: 'image/png'
    });
}
async function hydrateProject(file, projectId, layerBlobs, canPublish = ()=>true) {
    requireBrowser();
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProjectFile"])(file);
    if (!result.ok) throw new Error(result.error);
    file = result.value;
    const staged = new Map();
    const blobMap = new Map((layerBlobs ?? []).map((b)=>[
            b.layerId + ':' + b.frameIndex,
            b.blob
        ]));
    const activeInitialLayerId = file.frames[0]?.layers[0]?.id;
    const rasterCount = file.frames.reduce((count, frame, index)=>count + frame.layers.filter((layer)=>blobMap.has(layer.id + ':' + index) || layer.pngBase64 || layer.id === activeInitialLayerId).length, 0);
    // Include the largest decoded bitmap alongside the staged canvases and old workspace.
    const release = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reserveMemory"])((rasterCount + 1) * file.width * file.height * 4, 'Project hydration staging');
    try {
        for (const [frameIndex, frame] of file.frames.entries()){
            for (const layer of frame.layers){
                const blob = blobMap.get(layer.id + ':' + frameIndex) ?? (layer.pngBase64 ? base64ToBlob(layer.pngBase64) : undefined);
                if (blob) {
                    const entry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEntry"])(file.width, file.height, 1, true);
                    const dimensions = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$imageHeaderProbe$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageHeaderProbe"].probe(blob);
                    if (dimensions.width !== file.width || dimensions.height !== file.height) {
                        throw new Error('Layer dimensions do not match the project canvas.');
                    }
                    const bitmap = await createImageBitmap(blob);
                    try {
                        entry.ctx.drawImage(bitmap, 0, 0);
                    } finally{
                        bitmap.close();
                    }
                    staged.set(layer.id, entry);
                } else if (layer.id === activeInitialLayerId) {
                    // Guarantee active initial layer always has an allocated buffer ready
                    staged.set(layer.id, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEntry"])(file.width, file.height, 1, true));
                }
            }
        }
        if (!canPublish()) throw new Error('The workspace changed while the project was loading.');
        // Hydration is synchronous from here; validation and every decode already succeeded.
        // Publish pixels before notifying store subscribers (including co-draw),
        // Snapshot both buffer registry and store state before publication.
        // If store publication, subscriber notifications, or event emissions throw,
        // we roll back both buffers and store state to ensure the workspace never enters
        // a split-brain state (e.g. Project B store metadata with Project A buffers).
        const previousBuffers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["snapshotBuffers"])();
        const prevState = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
        const previousProjectId = prevState.currentProjectId;
        const previousProjectSnapshot = {
            name: prevState.projectName,
            width: prevState.canvasWidth,
            height: prevState.canvasHeight,
            fps: prevState.fps,
            loopMode: prevState.loopMode,
            onionSkin: {
                ...prevState.onionSkin
            },
            customRamps: prevState.customRamps ? prevState.customRamps.map((r)=>({
                    ...r,
                    shades: [
                        ...r.shades
                    ]
                })) : [],
            frames: prevState.frames ? prevState.frames.map((f)=>({
                    id: f.id,
                    durationMs: f.durationMs,
                    layers: f.layers.map((l)=>({
                            ...l
                        }))
                })) : [],
            palettes: prevState.palettes ? structuredClone(prevState.palettes) : [],
            currentPaletteId: prevState.currentPaletteId,
            clips: prevState.clips ? prevState.clips.map((c)=>({
                    ...c
                })) : []
        };
        const prevActiveFrameIndex = prevState.activeFrameIndex;
        const prevActiveLayerId = prevState.activeLayerId;
        try {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceAllBuffers"])(staged);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().loadProjectState(file, projectId);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().bumpBufferVersion();
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:history-clear');
        } catch (publishErr) {
            // Two-phase consistent rollback: restore both buffer registry and store state
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceAllBuffers"])(previousBuffers);
            try {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().loadProjectState(previousProjectSnapshot, previousProjectId);
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState((s)=>{
                    s.activeFrameIndex = prevActiveFrameIndex;
                    s.activeLayerId = prevActiveLayerId;
                });
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().bumpBufferVersion();
            } catch  {
                // If rolling back to previous project state fails, place workspace in a defined safe reset state
                try {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().resetToNewProject();
                } catch  {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearAllBuffers"])();
                }
            }
            throw publishErr;
        }
        if (projectId) {
            const persisted = new Map();
            for (const [frameIndex, frame] of file.frames.entries()){
                for (const layer of frame.layers){
                    const hasStoredData = blobMap.has(layer.id + ':' + frameIndex) || !!layer.pngBase64;
                    if (hasStoredData) {
                        persisted.set(layer.id, {
                            revision: 1,
                            frameIndex,
                            generation: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBufferGeneration"])(layer.id)
                        });
                    }
                }
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initProjectPersistedRevisions"])(projectId, persisted);
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setSaveStatus(projectId ? 'saved' : 'idle');
    } finally{
        release();
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/studioRouteSession.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PRACTICE_RETURN_KEY",
    ()=>PRACTICE_RETURN_KEY,
    "clearPracticeReturnProject",
    ()=>clearPracticeReturnProject,
    "getPracticeReturnProject",
    ()=>getPracticeReturnProject,
    "getStudioResume",
    ()=>getStudioResume,
    "getStudioRouteSession",
    ()=>getStudioRouteSession,
    "registerStudioRouteSession",
    ()=>registerStudioRouteSession,
    "setStudioResume",
    ()=>setStudioResume
]);
// One route handoff, not a project cache. No pixels or native handles live here.
let lastStudio = null;
let resumeTicket = null;
function registerStudioRouteSession(session) {
    lastStudio = session;
    if (resumeTicket?.projectId === session.projectId) resumeTicket = null;
}
function getStudioRouteSession(projectId) {
    return lastStudio?.projectId === projectId ? lastStudio : null;
}
function setStudioResume(ticket) {
    resumeTicket = ticket;
}
function getStudioResume(projectId) {
    return resumeTicket?.projectId === projectId ? resumeTicket : null;
}
const PRACTICE_RETURN_KEY = 'pixibun:practice-return-project';
function getPracticeReturnProject() {
    try {
        const id = sessionStorage.getItem(PRACTICE_RETURN_KEY);
        return id && id.length <= 1024 && id.trim() === id ? id : null;
    } catch  {
        return null;
    }
}
function clearPracticeReturnProject() {
    try {
        sessionStorage.removeItem(PRACTICE_RETURN_KEY);
    } catch  {}
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/workspaceEnvelopeGuard.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "canAddFramesToProject",
    ()=>canAddFramesToProject,
    "canAddLayersToFrame",
    ()=>canAddLayersToFrame,
    "canReplaceFrames",
    ()=>canReplaceFrames,
    "validateWorkspaceStructure",
    ()=>validateWorkspaceStructure
]);
/**
 * workspaceEnvelopeGuard.ts
 *
 * Centralized prospective capacity enforcement for PixiBun Atelier.
 * Reuses canonical WORKSPACE_ENVELOPE and validateProjectResourceBudget.
 *
 * Ensures all live structural mutations (add layer, duplicate layer,
 * add frame, duplicate frame, generated/tagged layers, imports, structural undo/redo)
 * validate their exact prospective outcome BEFORE:
 * - recording structural history;
 * - allocating or cloning layer buffers;
 * - mutating Zustand state;
 * - marking the workspace dirty.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/canvasLimits.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/resourceBudget.ts [app-client] (ecmascript)");
;
;
function isValidDimension(dim) {
    return Number.isSafeInteger(dim) && dim >= 1 && dim <= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION;
}
function canAddLayersToFrame(frames, frameIndex, canvasWidth, canvasHeight, layerCountToAdd = 1) {
    if (!isValidDimension(canvasWidth) || !isValidDimension(canvasHeight)) {
        return {
            ok: false,
            reason: `Canvas dimensions must be whole numbers between 1 and ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION}.`
        };
    }
    if (!Number.isSafeInteger(layerCountToAdd) || layerCountToAdd < 1) {
        return {
            ok: false,
            reason: 'Layer count to add must be a positive whole number.'
        };
    }
    if (!Array.isArray(frames) || !Number.isSafeInteger(frameIndex) || frameIndex < 0 || frameIndex >= frames.length) {
        return {
            ok: false,
            reason: 'Invalid frame index for layer mutation.'
        };
    }
    const currentFrame = frames[frameIndex];
    const currentCount = Array.isArray(currentFrame?.layers) ? currentFrame.layers.length : 0;
    const prospectiveCount = currentCount + layerCountToAdd;
    if (prospectiveCount > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS) {
        return {
            ok: false,
            reason: `Frame ${frameIndex + 1} exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS} layer ceiling.`
        };
    }
    // Compose prospective frames summary for resource budget evaluation (0 buffer allocations)
    const prospectiveFrames = frames.map((f, idx)=>{
        const count = Array.isArray(f.layers) ? f.layers.length : 0;
        const newCount = idx === frameIndex ? count + layerCountToAdd : count;
        return {
            layers: new Array(newCount)
        };
    });
    const budget = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProjectResourceBudget"])(canvasWidth, canvasHeight, prospectiveFrames);
    if (!budget.ok) {
        return {
            ok: false,
            reason: budget.error
        };
    }
    return {
        ok: true
    };
}
function canAddFramesToProject(existingFrames, canvasWidth, canvasHeight, incomingFrames) {
    if (!isValidDimension(canvasWidth) || !isValidDimension(canvasHeight)) {
        return {
            ok: false,
            reason: `Canvas dimensions must be whole numbers between 1 and ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION}.`
        };
    }
    if (!Array.isArray(existingFrames)) {
        return {
            ok: false,
            reason: 'Existing frames must be an array.'
        };
    }
    if (!Array.isArray(incomingFrames) || incomingFrames.length === 0) {
        return {
            ok: false,
            reason: 'Incoming frames must be a non-empty array.'
        };
    }
    const prospectiveFrameCount = existingFrames.length + incomingFrames.length;
    if (prospectiveFrameCount > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES) {
        return {
            ok: false,
            reason: `The project exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES} animation frame limit.`
        };
    }
    for(let i = 0; i < incomingFrames.length; i++){
        const count = incomingFrames[i]?.layerCount;
        if (!Number.isSafeInteger(count)) {
            return {
                ok: false,
                reason: `Incoming frame ${i + 1} layer count must be a whole number.`
            };
        }
        if (count < 1) {
            return {
                ok: false,
                reason: `Incoming frame ${i + 1} must contain at least 1 layer.`
            };
        }
        if (count > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS) {
            return {
                ok: false,
                reason: `Frame exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS} layer ceiling.`
            };
        }
    }
    const prospectiveFrames = [
        ...existingFrames.map((f)=>({
                layers: new Array(Array.isArray(f.layers) ? f.layers.length : 0)
            })),
        ...incomingFrames.map((f)=>({
                layers: new Array(f.layerCount)
            }))
    ];
    const budget = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProjectResourceBudget"])(canvasWidth, canvasHeight, prospectiveFrames);
    if (!budget.ok) {
        return {
            ok: false,
            reason: budget.error
        };
    }
    return {
        ok: true
    };
}
function canReplaceFrames(canvasWidth, canvasHeight, replacementFrames) {
    if (!isValidDimension(canvasWidth) || !isValidDimension(canvasHeight)) {
        return {
            ok: false,
            reason: `Canvas dimensions must be whole numbers between 1 and ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION}.`
        };
    }
    if (!Array.isArray(replacementFrames) || replacementFrames.length === 0) {
        return {
            ok: false,
            reason: 'This project has no animation frames to open.'
        };
    }
    if (replacementFrames.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES) {
        return {
            ok: false,
            reason: `The project exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES} animation frame limit.`
        };
    }
    for(let i = 0; i < replacementFrames.length; i++){
        const count = replacementFrames[i]?.layerCount;
        if (!Number.isSafeInteger(count)) {
            return {
                ok: false,
                reason: `Replacement frame ${i + 1} layer count must be a whole number.`
            };
        }
        if (count < 1) {
            return {
                ok: false,
                reason: `Replacement frame ${i + 1} must contain at least 1 layer.`
            };
        }
        if (count > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS) {
            return {
                ok: false,
                reason: `Frame exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS} layer ceiling.`
            };
        }
    }
    const prospectiveFrames = replacementFrames.map((f)=>({
            layers: new Array(f.layerCount)
        }));
    const budget = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProjectResourceBudget"])(canvasWidth, canvasHeight, prospectiveFrames);
    if (!budget.ok) {
        return {
            ok: false,
            reason: budget.error
        };
    }
    return {
        ok: true
    };
}
function validateWorkspaceStructure(canvasWidth, canvasHeight, frames) {
    if (!isValidDimension(canvasWidth) || !isValidDimension(canvasHeight)) {
        return {
            ok: false,
            reason: `Canvas dimensions must be whole numbers between 1 and ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION}.`
        };
    }
    if (!Array.isArray(frames) || frames.length === 0) {
        return {
            ok: false,
            reason: 'This project has no animation frames to open.'
        };
    }
    if (frames.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES) {
        return {
            ok: false,
            reason: `The project exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES} animation frame limit.`
        };
    }
    for(let i = 0; i < frames.length; i++){
        const layers = frames[i]?.layers;
        if (!Array.isArray(layers)) {
            return {
                ok: false,
                reason: `Frame ${i + 1} layers must be an array.`
            };
        }
        const count = layers.length;
        if (count < 1) {
            return {
                ok: false,
                reason: `Frame ${i + 1} must contain at least 1 layer.`
            };
        }
        if (count > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS) {
            return {
                ok: false,
                reason: `Frame ${i + 1} exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS} layer ceiling.`
            };
        }
    }
    const budget = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProjectResourceBudget"])(canvasWidth, canvasHeight, frames);
    if (!budget.ok) {
        return {
            ok: false,
            reason: budget.error
        };
    }
    return {
        ok: true
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/render/compositor.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Single source of visual truth for "what a frame looks like": bottom-up
// layer compositing honoring visibility, opacity, and blend modes. Deliberately
// overlay-free - no onion skins, grid, or selection marquee ever
// leak into what the eyedropper samples or what exporters write to disk.
//
// Reads DOM canvases and the raster registry. Fresh output is the default;
// callers retaining frames must not opt into the shared mutable canvas.
__turbopack_context__.s([
    "compositeFrame",
    ()=>compositeFrame
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
;
let sharedOffscreenCanvas = null;
function compositeFrame(frames, frameIndex, width, height, options = {}, targetCanvas) {
    const frame = frames[frameIndex];
    if (!frame || typeof document === 'undefined') return null;
    const out = targetCanvas || (options.freshCanvas ?? true ? document.createElement('canvas') : sharedOffscreenCanvas ?? (sharedOffscreenCanvas = document.createElement('canvas')));
    if (out.width !== width || out.height !== height) {
        out.width = width;
        out.height = height;
    }
    const ctx = out.getContext('2d');
    if (!ctx) return null;
    ctx.clearRect(0, 0, width, height);
    ctx.imageSmoothingEnabled = false;
    for (const layer of frame.layers.slice().reverse()){
        if (!layer.visible && !options.includeInvisible) continue;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasBuffer"])(layer.id)) continue;
        const buffer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layer.id, width, height);
        ctx.globalAlpha = layer.opacity;
        ctx.globalCompositeOperation = layer.blendMode;
        ctx.drawImage(buffer.canvas, 0, 0);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    return out;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/render/onionSkin.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getOnionSkinSpecs",
    ()=>getOnionSkinSpecs
]);
function getOnionSkinSpecs(frameCount, activeFrameIndex, settings, isPlaying = false) {
    if (!settings.enabled || frameCount <= 1 || isPlaying) {
        return [];
    }
    const specs = [];
    const maxDistance = Math.max(settings.prevFrames, settings.nextFrames);
    for(let dist = 1; dist <= maxDistance; dist++){
        const falloff = Math.max(0, 1 - 0.25 * (dist - 1));
        const alpha = Math.min(1, Math.max(0, settings.opacity * falloff));
        // Previous ghost
        if (dist <= settings.prevFrames) {
            const prevIdx = activeFrameIndex - dist;
            if (prevIdx >= 0 && prevIdx < frameCount) {
                specs.push({
                    frameIndex: prevIdx,
                    tint: settings.prevColor,
                    alpha
                });
            }
        }
        // Next ghost
        if (dist <= settings.nextFrames) {
            const nextIdx = activeFrameIndex + dist;
            if (nextIdx >= 0 && nextIdx < frameCount) {
                specs.push({
                    frameIndex: nextIdx,
                    tint: settings.nextColor,
                    alpha
                });
            }
        }
    }
    return specs;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/safety/imageHeaderProbe.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ImageHeaderProbe",
    ()=>ImageHeaderProbe
]);
/**
 * imageHeaderProbe.ts
 *
 * Pre-flight binary image dimension inspector for PixiBun Atelier.
 * Defensively protects against Decompression Bombs ("Pixel Bombs" / CWE-409)
 * before allocating canvas memory or invoking browser decoders.
 *
 * Academic & Security References:
 * 1. Common Weakness Enumeration (CWE): CWE-409
 *    "Improper Handling of Highly Compressed Data (Decompression Bomb)"
 * 2. ISO/IEC 15948:2004 — Information technology: Computer graphics and image processing —
 *    Portable Network Graphics (PNG): Section 11.2.2 "IHDR Image header".
 * 3. ISO/IEC 10918-1:1994 — Digital compression and coding of continuous-tone still images (JPEG):
 *    Section B.2.2 "Frame header syntax (SOF0/SOF2)".
 * 4. CompuServe Incorporated. "Graphics Interchange Format: Version 89a."
 *    Section 18 "Logical Screen Descriptor".
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/canvasLimits.ts [app-client] (ecmascript)");
;
class ImageHeaderProbe {
    /**
   * Maximum allowed single-axis dimension (8192px).
   */ static MAX_ALLOWED_DIMENSION = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROBE_DIMENSION;
    /**
   * Maximum allowed total pixel area (67,108,864 pixels = 8192x8192).
   * Prevents allocating multi-gigabyte uncompressed RGBA pixel buffers.
   */ static MAX_ALLOWED_PIXELS = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROBE_PIXELS;
    /** Maximum bytes to scan during JPEG marker segment traversal (16MB). */ static MAX_PROBE_SEARCH_WINDOW = 16 * 1024 * 1024;
    /**
   * Probes an image header from a Blob, File, or raw ArrayBuffer/Uint8Array.
   * Supports streaming window paging for Blob/File inputs to handle late SOF segments.
   */ static async probe(input) {
        let headerBytes;
        let chunkStart = 0;
        if (input instanceof Blob) {
            const initialSlice = await input.slice(0, 262144).arrayBuffer();
            headerBytes = new Uint8Array(initialSlice);
        } else if (input instanceof ArrayBuffer) {
            headerBytes = new Uint8Array(input);
        } else {
            headerBytes = input;
        }
        if (headerBytes.length < 10) {
            throw new Error('[ImageHeaderProbe] File is truncated or too small to contain a valid image header');
        }
        const view = new DataView(headerBytes.buffer, headerBytes.byteOffset, headerBytes.byteLength);
        if (headerBytes.length >= 20 && view.getUint32(0, false) === 0x52494646 && view.getUint32(8, false) === 0x57454250) {
            const chunk = view.getUint32(12, false);
            const uint24 = (at)=>headerBytes[at] | headerBytes[at + 1] << 8 | headerBytes[at + 2] << 16;
            if (chunk === 0x56503858 && headerBytes.length >= 30) return this.validate(uint24(24) + 1, uint24(27) + 1, 'WebP');
            if (chunk === 0x5650384c && headerBytes.length >= 25 && headerBytes[20] === 0x2f) {
                const bits = view.getUint32(21, true);
                return this.validate((bits & 0x3fff) + 1, (bits >>> 14 & 0x3fff) + 1, 'WebP');
            }
            if (chunk === 0x56503820 && headerBytes.length >= 30 && headerBytes[23] === 0x9d && headerBytes[24] === 0x01 && headerBytes[25] === 0x2a) {
                return this.validate(view.getUint16(26, true) & 0x3fff, view.getUint16(28, true) & 0x3fff, 'WebP');
            }
            throw new Error('[ImageHeaderProbe] Unsupported or malformed WebP header');
        }
        // 1. Check PNG (Magic: 0x89 50 4E 47 0D 0A 1A 0A)
        if (headerBytes[0] === 0x89 && headerBytes[1] === 0x50 && headerBytes[2] === 0x4e && headerBytes[3] === 0x47 && headerBytes[4] === 0x0d && headerBytes[5] === 0x0a && headerBytes[6] === 0x1a && headerBytes[7] === 0x0a) {
            if (headerBytes.length < 24) {
                throw new Error('[ImageHeaderProbe] Truncated PNG header: IHDR missing');
            }
            // IHDR chunk: 4 bytes length, 4 bytes type ('IHDR'), 4 bytes width, 4 bytes height
            const chunkType = String.fromCharCode(headerBytes[12], headerBytes[13], headerBytes[14], headerBytes[15]);
            if (chunkType !== 'IHDR') {
                throw new Error('[ImageHeaderProbe] Malformed PNG: First chunk is not IHDR');
            }
            const width = view.getUint32(16, false); // Big Endian
            const height = view.getUint32(20, false);
            return this.validate(width, height, 'PNG');
        }
        // 2. Check GIF (Magic: 'GIF87a' or 'GIF89a')
        if (headerBytes[0] === 0x47 && headerBytes[1] === 0x49 && headerBytes[2] === 0x46 && headerBytes[3] === 0x38 && (headerBytes[4] === 0x37 || headerBytes[4] === 0x39) && headerBytes[5] === 0x61) {
            if (headerBytes.length < 10) {
                throw new Error('[ImageHeaderProbe] Truncated GIF logical screen descriptor');
            }
            const width = view.getUint16(6, true); // Little Endian
            const height = view.getUint16(8, true);
            return this.validate(width, height, 'GIF');
        }
        // 3. Check BMP (Magic: 'BM')
        if (headerBytes[0] === 0x42 && headerBytes[1] === 0x4d) {
            if (headerBytes.length < 26) {
                throw new Error('[ImageHeaderProbe] Truncated BMP header');
            }
            // DIB header width and height at offset 18
            const width = Math.abs(view.getInt32(18, true)); // Little Endian
            const height = Math.abs(view.getInt32(22, true));
            return this.validate(width, height, 'BMP');
        }
        // 4. Check JPEG (Magic: 0xFF 0xD8)
        if (headerBytes[0] === 0xff && headerBytes[1] === 0xd8) {
            const ensureBytes = async (offset, length)=>{
                if (offset + length <= chunkStart + headerBytes.length) {
                    return true;
                }
                if (input instanceof Blob) {
                    if (offset >= input.size) return false;
                    const nextChunkSize = Math.max(262144, length);
                    chunkStart = offset;
                    const slice = await input.slice(chunkStart, chunkStart + nextChunkSize).arrayBuffer();
                    headerBytes = new Uint8Array(slice);
                    return headerBytes.length >= length;
                }
                return false;
            };
            let fileOffset = 2;
            while(fileOffset < ImageHeaderProbe.MAX_PROBE_SEARCH_WINDOW){
                if (!await ensureBytes(fileOffset, 2)) {
                    throw new Error('[ImageHeaderProbe] SOF_BEYOND_PROBE_WINDOW: Start of frame not found within probe window');
                }
                const markerPrefix = headerBytes[fileOffset - chunkStart];
                fileOffset++;
                if (markerPrefix !== 0xff) continue;
                if (!await ensureBytes(fileOffset, 1)) {
                    throw new Error('[ImageHeaderProbe] SOF_BEYOND_PROBE_WINDOW: Start of frame not found within probe window');
                }
                let marker = headerBytes[fileOffset - chunkStart];
                fileOffset++;
                while(marker === 0xff){
                    if (!await ensureBytes(fileOffset, 1)) {
                        throw new Error('[ImageHeaderProbe] SOF_BEYOND_PROBE_WINDOW: Start of frame not found within probe window');
                    }
                    marker = headerBytes[fileOffset - chunkStart];
                    fileOffset++;
                }
                // Variable-length markers: EOI (0xD9) or SOS (0xDA) reached without finding SOF
                if (marker === 0xd9 || marker === 0xda) {
                    throw new Error('[ImageHeaderProbe] SOF_BEYOND_PROBE_WINDOW: Start of frame not found within probe window');
                }
                // Check for Start Of Frame markers:
                // SOF0 (0xC0 - Baseline), SOF1 (0xC1 - Extended), SOF2 (0xC2 - Progressive)
                if (marker === 0xc0 || marker === 0xc1 || marker === 0xc2) {
                    if (!await ensureBytes(fileOffset, 7)) {
                        throw new Error('[ImageHeaderProbe] SOF_BEYOND_PROBE_WINDOW: Start of frame not found within probe window');
                    }
                    const sofView = new DataView(headerBytes.buffer, headerBytes.byteOffset + (fileOffset - chunkStart), 7);
                    // Segment length (2 bytes) + Sample precision (1 byte)
                    const height = sofView.getUint16(3, false); // Big Endian
                    const width = sofView.getUint16(5, false);
                    return this.validate(width, height, 'JPEG');
                }
                // Standalone markers without payload (RST0..RST7, TEM)
                if (marker >= 0xd0 && marker <= 0xd7 || marker === 0x01) {
                    continue;
                }
                // Skip marker segment
                if (!await ensureBytes(fileOffset, 2)) {
                    throw new Error('[ImageHeaderProbe] SOF_BEYOND_PROBE_WINDOW: Start of frame not found within probe window');
                }
                const segView = new DataView(headerBytes.buffer, headerBytes.byteOffset + (fileOffset - chunkStart), 2);
                const segmentLength = segView.getUint16(0, false);
                if (segmentLength < 2) {
                    throw new Error('[ImageHeaderProbe] SOF_BEYOND_PROBE_WINDOW: Start of frame not found within probe window');
                }
                fileOffset += segmentLength;
            }
            throw new Error('[ImageHeaderProbe] SOF_BEYOND_PROBE_WINDOW: Start of frame not found within probe window');
        }
        throw new Error('[ImageHeaderProbe] Unsupported or unrecognizable image signature');
    }
    static validate(width, height, format) {
        if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width <= 0 || height <= 0) {
            throw new RangeError(`[ImageHeaderProbe] Corrupted ${format} dimensions declared in header: ${width}x${height}`);
        }
        if (width > this.MAX_ALLOWED_DIMENSION || height > this.MAX_ALLOWED_DIMENSION) {
            throw new RangeError(`[ImageHeaderProbe] Image dimensions (${width}x${height}) exceed maximum allowed workstation limit (${this.MAX_ALLOWED_DIMENSION}px)`);
        }
        if (width * height > this.MAX_ALLOWED_PIXELS) {
            throw new RangeError(`[ImageHeaderProbe] Decompression bomb detected (CWE-409): total pixel area (${width * height}) exceeds safety limit`);
        }
        return {
            width,
            height,
            format
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/safety/mathInvariants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * mathInvariants.ts
 *
 * Mathematically rigorous numerical and geometric invariant guards for PixiBun Atelier.
 *
 * Academic & Literature References:
 * 1. Foley, James D., Andries van Dam, Steven K. Feiner, and John F. Hughes.
 *    "Computer Graphics: Principles and Practice." 2nd ed., Addison-Wesley, 1990.
 *    Section 3.12: "Clipping Lines: The Cohen-Sutherland Algorithm", pp. 113–117.
 * 2. Goldberg, David. "What Every Computer Scientist Should Know About Floating-Point Arithmetic."
 *    ACM Computing Surveys (CSUR), Vol. 23, No. 1, 1991, pp. 5–48. DOI: 10.1145/103162.103163.
 * 3. Knuth, Donald E. "The Art of Computer Programming, Volume 2: Seminumerical Algorithms."
 *    3rd ed., Addison-Wesley, 1997. Section 4.2.2: "Accuracy of Floating Point Arithmetic."
 */ __turbopack_context__.s([
    "MathInvariants",
    ()=>MathInvariants
]);
class MathInvariants {
    /**
   * Safe minimum zoom factor (5%).
   * Prevents division-by-zero singularities when transforming client coordinates to canvas space.
   */ static MIN_ZOOM = 0.05;
    /**
   * Safe maximum zoom factor (6400%).
   * Prevents IEEE 754 floating-point denormalization / catastrophic cancellation.
   */ static MAX_ZOOM = 64.0;
    /**
   * Numerical tolerance epsilon for division-by-zero guards (\( \epsilon = 10^{-6} \)).
   */ static EPSILON = 1e-6;
    /**
   * Checks if a value is a strictly finite, non-NaN IEEE 754 floating-point number.
   * Cites Goldberg (1991) on IEEE 754 NaN propagation hazards.
   */ static isSafeFinite(val) {
        return typeof val === 'number' && Number.isFinite(val) && !Number.isNaN(val);
    }
    /**
   * Defensively bounds a zoom factor within [MIN_ZOOM, MAX_ZOOM].
   * Completely eliminates NaN, Infinity, -Infinity, zero, and negative values.
   */ static clampZoom(zoom, fallback = 1.0) {
        if (!this.isSafeFinite(zoom) || zoom <= this.EPSILON) {
            return fallback;
        }
        return Math.min(this.MAX_ZOOM, Math.max(this.MIN_ZOOM, zoom));
    }
    /**
   * Safely divides two real numbers without producing NaN or ±Infinity.
   * If the absolute denominator is <= EPSILON or inputs are non-finite, returns fallback.
   */ static safeDivide(numerator, denominator, fallback = 0) {
        if (!this.isSafeFinite(numerator) || !this.isSafeFinite(denominator) || Math.abs(denominator) <= this.EPSILON) {
            return fallback;
        }
        const quotient = numerator / denominator;
        return this.isSafeFinite(quotient) ? quotient : fallback;
    }
    /**
   * Clamps an integer or float coordinate into an inclusive [min, max] range.
   */ static clampCoordinate(val, min, max) {
        if (!this.isSafeFinite(val)) return min;
        return Math.max(min, Math.min(max, val));
    }
    /**
   * Normalizes an arbitrary rectangle (supporting negative or inverted drag vectors)
   * into a canonical top-left origin coordinate with strictly positive integer width & height.
   */ static normalizeRect(x1, y1, x2, y2) {
        const safeX1 = this.isSafeFinite(x1) ? x1 : 0;
        const safeY1 = this.isSafeFinite(y1) ? y1 : 0;
        const safeX2 = this.isSafeFinite(x2) ? x2 : 0;
        const safeY2 = this.isSafeFinite(y2) ? y2 : 0;
        const x = Math.floor(Math.min(safeX1, safeX2));
        const y = Math.floor(Math.min(safeY1, safeY2));
        const w = Math.floor(Math.abs(safeX2 - safeX1));
        const h = Math.floor(Math.abs(safeY2 - safeY1));
        return {
            x,
            y,
            w,
            h
        };
    }
    /**
   * Cohen-Sutherland 2D Line Clipping Algorithm.
   *
   * Clips an arbitrary 2D line segment (x0, y0) -> (x1, y1) against an axis-aligned
   * canvas bounding box [0, 0, canvasW - 1, canvasH - 1].
   *
   * Bitwise Outcode encoding (Foley et al., Section 3.12):
   *   Bit 0 (1): Left of window   (x < xMin)
   *   Bit 1 (2): Right of window  (x > xMax)
   *   Bit 2 (4): Below window     (y < yMin)
   *   Bit 3 (8): Above window     (y > yMax)
   *
   * Guarantees that line rasterizers (Bresenham / DDA) never execute redundant
   * iterations outside the canvas boundary or write out-of-bounds array indices.
   *
   * Returns clipped integer endpoints { x0, y0, x1, y1 } or null if completely outside.
   */ static clipLineToCanvas(x0, y0, x1, y1, canvasW, canvasH) {
        if (canvasW <= 0 || canvasH <= 0) return null;
        const INSIDE = 0; // 0000
        const LEFT = 1; // 0001
        const RIGHT = 2; // 0010
        const BOTTOM = 4; // 0100
        const TOP = 8; // 1000
        const xMin = 0;
        const yMin = 0;
        const xMax = canvasW - 1;
        const yMax = canvasH - 1;
        function computeOutCode(x, y) {
            let code = INSIDE;
            if (x < xMin) code |= LEFT;
            else if (x > xMax) code |= RIGHT;
            if (y < yMin) code |= BOTTOM;
            else if (y > yMax) code |= TOP;
            return code;
        }
        let pX0 = this.isSafeFinite(x0) ? x0 : 0;
        let pY0 = this.isSafeFinite(y0) ? y0 : 0;
        let pX1 = this.isSafeFinite(x1) ? x1 : 0;
        let pY1 = this.isSafeFinite(y1) ? y1 : 0;
        let code0 = computeOutCode(pX0, pY0);
        let code1 = computeOutCode(pX1, pY1);
        let accept = false;
        // Loop at most 4 times (each step clips against 1 edge)
        for(let iter = 0; iter < 5; iter++){
            if ((code0 | code1) === 0) {
                // Trivial accept: both points are inside the clipping window
                accept = true;
                break;
            } else if ((code0 & code1) !== 0) {
                break;
            } else {
                // Line needs clipping: select an endpoint that is outside
                const outCode = code0 !== 0 ? code0 : code1;
                let x = 0;
                let y = 0;
                // Find intersection point using slope equations:
                //   y = y0 + slope * (x - x0)
                //   x = x0 + (1 / slope) * (y - y0)
                if ((outCode & TOP) !== 0) {
                    x = pX0 + (pX1 - pX0) * (yMax - pY0) / (pY1 - pY0);
                    y = yMax;
                } else if ((outCode & BOTTOM) !== 0) {
                    x = pX0 + (pX1 - pX0) * (yMin - pY0) / (pY1 - pY0);
                    y = yMin;
                } else if ((outCode & RIGHT) !== 0) {
                    y = pY0 + (pY1 - pY0) * (xMax - pX0) / (pX1 - pX0);
                    x = xMax;
                } else if ((outCode & LEFT) !== 0) {
                    y = pY0 + (pY1 - pY0) * (xMin - pX0) / (pX1 - pX0);
                    x = xMin;
                }
                if (outCode === code0) {
                    pX0 = x;
                    pY0 = y;
                    code0 = computeOutCode(pX0, pY0);
                } else {
                    pX1 = x;
                    pY1 = y;
                    code1 = computeOutCode(pX1, pY1);
                }
            }
        }
        if (!accept) return null;
        return {
            x0: Math.round(pX0),
            y0: Math.round(pY0),
            x1: Math.round(pX1),
            y1: Math.round(pY1)
        };
    }
    /**
   * Cohen-Sutherland 2D Line Clipping with Continuous Sub-Pixel Intersections.
   * Returns exact floating-point endpoints to avoid Bresenham initial slope distortion
   * when rasterizing with DDA.
   */ static clipLineToCanvasSubpixel(x0, y0, x1, y1, canvasW, canvasH) {
        if (canvasW <= 0 || canvasH <= 0) return null;
        const INSIDE = 0;
        const LEFT = 1;
        const RIGHT = 2;
        const BOTTOM = 4;
        const TOP = 8;
        const xMin = 0;
        const yMin = 0;
        const xMax = canvasW - 1;
        const yMax = canvasH - 1;
        function computeOutCode(x, y) {
            let code = INSIDE;
            if (x < xMin) code |= LEFT;
            else if (x > xMax) code |= RIGHT;
            if (y < yMin) code |= BOTTOM;
            else if (y > yMax) code |= TOP;
            return code;
        }
        let pX0 = MathInvariants.isSafeFinite(x0) ? x0 : 0;
        let pY0 = MathInvariants.isSafeFinite(y0) ? y0 : 0;
        let pX1 = MathInvariants.isSafeFinite(x1) ? x1 : 0;
        let pY1 = MathInvariants.isSafeFinite(y1) ? y1 : 0;
        let code0 = computeOutCode(pX0, pY0);
        let code1 = computeOutCode(pX1, pY1);
        let accept = false;
        for(let iter = 0; iter < 5; iter++){
            if ((code0 | code1) === 0) {
                accept = true;
                break;
            } else if ((code0 & code1) !== 0) {
                break;
            } else {
                const outCode = code0 !== 0 ? code0 : code1;
                let x = 0;
                let y = 0;
                if ((outCode & TOP) !== 0) {
                    x = pX0 + (pX1 - pX0) * (yMax - pY0) / (pY1 - pY0);
                    y = yMax;
                } else if ((outCode & BOTTOM) !== 0) {
                    x = pX0 + (pX1 - pX0) * (yMin - pY0) / (pY1 - pY0);
                    y = yMin;
                } else if ((outCode & RIGHT) !== 0) {
                    y = pY0 + (pY1 - pY0) * (xMax - pX0) / (pX1 - pX0);
                    x = xMax;
                } else if ((outCode & LEFT) !== 0) {
                    y = pY0 + (pY1 - pY0) * (xMin - pX0) / (pX1 - pX0);
                    x = xMin;
                }
                if (outCode === code0) {
                    pX0 = x;
                    pY0 = y;
                    code0 = computeOutCode(pX0, pY0);
                } else {
                    pX1 = x;
                    pY1 = y;
                    code1 = computeOutCode(pX1, pY1);
                }
            }
        }
        if (!accept) return null;
        return {
            x0: pX0,
            y0: pY0,
            x1: pX1,
            y1: pY1
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/safety/safeCanvas.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CanvasHardwareLimits",
    ()=>CanvasHardwareLimits,
    "SafeCanvas",
    ()=>SafeCanvas
]);
/**
 * safeCanvas.ts
 *
 * Defensive Canvas 2D raster operations for PixiBun Atelier.
 *
 * Web Standard References:
 * 1. W3C / WHATWG HTML Living Standard: Section 4.12.5.1 "The 2D rendering context"
 *    - Clause on createImageData / getImageData: IndexSizeError DOMException thrown if sw or sh is zero.
 * 2. Khronos Group WebGL Specification (WebGL 1.0 & 2.0):
 *    - MAX_TEXTURE_SIZE hardware capability query and area limits.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/mathInvariants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/canvasLimits.ts [app-client] (ecmascript)");
;
;
class CanvasHardwareLimits {
    static cachedMaxDim = null;
    static DEFAULT_SAFE_DIM = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROBE_DIMENSION;
    static MAX_SAFE_PIXEL_AREA = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_HARDWARE_PIXEL_AREA;
    /**
   * Queries the hardware GPU maximum texture size via WebGL probe context.
   * Caches the result to avoid redundant context creations.
   */ static getMaxTextureSize() {
        if (this.cachedMaxDim !== null) return this.cachedMaxDim;
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        try {
            const probeCanvas = document.createElement('canvas');
            const gl = probeCanvas.getContext('webgl') || probeCanvas.getContext('experimental-webgl');
            if (gl) {
                const max = gl.getParameter(gl.MAX_TEXTURE_SIZE);
                if (typeof max === 'number' && max > 0) {
                    this.cachedMaxDim = max;
                    const loseContext = gl.getExtension('WEBGL_lose_context');
                    if (loseContext) loseContext.loseContext();
                    return max;
                }
            }
        } catch  {
        // Ignore probing failure and use safe default
        }
        this.cachedMaxDim = this.DEFAULT_SAFE_DIM;
        return this.cachedMaxDim;
    }
}
class SafeCanvas {
    /**
   * Defensive wrapper for ctx.createImageData().
   * Guarantees:
   * - Positive integers >= 1 (completely prevents IndexSizeError on 0 or negative dimensions).
   * - Clamped against GPU MAX_TEXTURE_SIZE ceiling.
   * - Validates total pixel area against memory exhaustion ceiling.
   */ static createImageData(ctx, width, height) {
        const maxDim = CanvasHardwareLimits.getMaxTextureSize();
        const rawW = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MathInvariants"].isSafeFinite(width) ? width : 1;
        const rawH = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MathInvariants"].isSafeFinite(height) ? height : 1;
        if (rawW > maxDim || rawH > maxDim || rawW * rawH > CanvasHardwareLimits.MAX_SAFE_PIXEL_AREA) {
            throw new RangeError(`[SafeCanvas] Canvas dimensions (${rawW}x${rawH}) exceed maximum hardware capability ceiling (${maxDim}px or ${CanvasHardwareLimits.MAX_SAFE_PIXEL_AREA} total area)`);
        }
        const w = Math.floor(Math.max(1, rawW));
        const h = Math.floor(Math.max(1, rawH));
        if (ctx && typeof ctx.createImageData === 'function') {
            try {
                return ctx.createImageData(w, h);
            } catch  {
            // Fallback if context is in a detached or invalid state
            }
        }
        // Modern browser and Node 20+ support standalone ImageData constructor
        if (typeof ImageData !== 'undefined') {
            return new ImageData(w, h);
        }
        // Headless test environment mock fallback
        return {
            width: w,
            height: h,
            data: new Uint8ClampedArray(w * h * 4),
            colorSpace: 'srgb'
        };
    }
    /**
   * Defensive wrapper for ctx.getImageData().
   * Guarantees:
   * - Handles negative dimensions by normalizing bounding rectangle origin.
   * - Intersects sampling rectangle with valid canvas boundaries [0, 0, canvasWidth, canvasHeight].
   * - Returns a padded blank ImageData without throwing IndexSizeError when sampling 0-width or 0-height boxes.
   */ static getImageData(ctx, sx, sy, sw, sh) {
        const canvasWidth = ctx.canvas.width;
        const canvasHeight = ctx.canvas.height;
        // 1. Normalize negative drag rectangles
        const norm = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MathInvariants"].normalizeRect(sx, sy, sx + sw, sy + sh);
        const normX = norm.x;
        const normY = norm.y;
        const normW = norm.w;
        const normH = norm.h;
        // 2. Prevent IndexSizeError on zero-dimension selections
        if (normW <= 0 || normH <= 0) {
            return this.createImageData(ctx, 1, 1);
        }
        // 3. Intersect sampling rect with actual canvas boundaries
        const x1 = Math.max(0, normX);
        const y1 = Math.max(0, normY);
        const x2 = Math.min(canvasWidth, normX + normW);
        const y2 = Math.min(canvasHeight, normY + normH);
        const interW = x2 - x1;
        const interH = y2 - y1;
        // Completely off-canvas: return blank transparent ImageData
        if (interW <= 0 || interH <= 0) {
            return this.createImageData(ctx, normW, normH);
        }
        // Pure interior crop: direct native read
        if (normX === x1 && normY === y1 && normW === interW && normH === interH) {
            return ctx.getImageData(normX, normY, normW, normH);
        }
        // Partially out-of-bounds: sample intersecting region and blit onto correctly padded buffer
        const result = this.createImageData(ctx, normW, normH);
        const sampleData = ctx.getImageData(x1, y1, interW, interH);
        const dstOffsetX = x1 - normX;
        const dstOffsetY = y1 - normY;
        const srcU32 = new Uint32Array(sampleData.data.buffer, sampleData.data.byteOffset, interW * interH);
        const dstU32 = new Uint32Array(result.data.buffer, result.data.byteOffset, normW * normH);
        for(let row = 0; row < interH; row++){
            const srcIdx = row * interW;
            const dstIdx = (dstOffsetY + row) * normW + dstOffsetX;
            dstU32.set(srcU32.subarray(srcIdx, srcIdx + interW), dstIdx);
        }
        return result;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/server/tokenBucket.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Token-bucket rate limiter for server route handlers.
//
// Classic token bucket (Tanenbaum & Wetherall, "Computer Networks", §5.3;
// a single request bucket, not the two-bucket three-color marker in RFC 2697): the bucket holds up to `capacity` tokens, refilled continuously
// at `refillPerMinute`, and each request consumes one token.
//
// Limitation (documented honestly): state is per-process memory. On a single
// Node instance this is correct; on multi-instance deployments it becomes a
// per-instance limit. For a zero-backend diagnostics relay this is the right
// trade-off — a distributed limiter would reintroduce the shared state this
// serverless app deliberately avoids.
__turbopack_context__.s([
    "createTokenBucketStore",
    ()=>createTokenBucketStore
]);
function createTokenBucketStore(options) {
    const capacity = Math.max(1, Math.floor(options.capacity));
    const refillPerMs = Math.max(0, options.refillPerMinute) / 60_000;
    const buckets = new Map();
    return {
        take (key, now = Date.now()) {
            let bucket = buckets.get(key);
            if (!bucket) {
                bucket = {
                    tokens: capacity,
                    lastRefill: now
                };
                buckets.set(key, bucket);
            }
            // Continuous refill: tokens accumulate proportionally to elapsed time,
            // capped at capacity.
            const elapsed = Math.max(0, now - bucket.lastRefill);
            if (elapsed > 0 && refillPerMs > 0) {
                bucket.tokens = Math.min(capacity, bucket.tokens + elapsed * refillPerMs);
                bucket.lastRefill = now;
            }
            if (bucket.tokens < 1) {
                return false;
            }
            bucket.tokens -= 1;
            return true;
        },
        prune (now = Date.now(), idleMs = 3_600_000) {
            let removed = 0;
            for (const [key, bucket] of buckets){
                if (now - bucket.lastRefill > idleMs) {
                    buckets.delete(key);
                    removed++;
                }
            }
            return removed;
        },
        size () {
            return buckets.size;
        }
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/storage/desktopFileSystem.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DesktopFileSystem",
    ()=>DesktopFileSystem,
    "PIXIBUN_FILE_TYPES",
    ()=>PIXIBUN_FILE_TYPES,
    "verifyHandlePermission",
    ()=>verifyHandlePermission
]);
/**
 * desktopFileSystem.ts
 *
 * Native Desktop Ergonomics & File System Access API for PixiBun Atelier.
 * Provides direct, in-place file editing and saving on Chromium browsers (Chrome, Edge, Opera, Brave)
 * using window.showSaveFilePicker / window.showOpenFilePicker / FileSystemFileHandle,
 * with zero external dependencies and graceful, robust fallbacks for Firefox, Safari, and headless contexts.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/safeJson.ts [app-client] (ecmascript)");
;
const PIXIBUN_FILE_TYPES = [
    {
        description: 'PixiBun Project File (*.pixibun)',
        accept: {
            'application/json': [
                '.pixibun',
                '.json'
            ]
        }
    }
];
async function verifyHandlePermission(handle, mode = 'readwrite') {
    const h = handle;
    if (typeof h.queryPermission !== 'function') return true;
    try {
        const status = await h.queryPermission({
            mode
        });
        if (status === 'granted') return true;
        if (status === 'prompt' && typeof h.requestPermission === 'function') {
            const requested = await h.requestPermission({
                mode
            });
            return requested === 'granted';
        }
    } catch  {
        return false;
    }
    return false;
}
class DesktopFileSystem {
    static activeHandle = null;
    static activeProjectId;
    static activeFilename = null;
    static isSupported() {
        return ("TURBOPACK compile-time value", "object") !== 'undefined' && typeof window.showOpenFilePicker === 'function' && typeof window.showSaveFilePicker === 'function';
    }
    static getActiveHandle() {
        return this.activeHandle;
    }
    static getActiveFilename() {
        return this.activeFilename;
    }
    static setActiveHandle(handle, filename) {
        this.activeHandle = handle;
        this.activeFilename = filename ?? handle?.name ?? null;
    }
    static captureAssociation() {
        return {
            handle: this.activeHandle,
            projectId: this.activeProjectId,
            filename: this.activeFilename
        };
    }
    static restoreAssociation(saved) {
        this.activeHandle = saved.handle;
        this.activeProjectId = saved.projectId;
        this.activeFilename = saved.filename;
    }
    static reset() {
        this.activeProjectId = undefined;
        this.activeHandle = null;
        this.activeFilename = null;
    }
    static verifyHandlePermission = verifyHandlePermission;
    /**
   * Opens an existing project file from disk.
   * Uses native showOpenFilePicker when supported, or a transient hidden file input fallback.
   */ static async openProject() {
        if (this.isSupported()) {
            try {
                const picker = window.showOpenFilePicker;
                if (!picker) throw new Error('File picker is unavailable');
                const [handle] = await picker({
                    multiple: false,
                    types: PIXIBUN_FILE_TYPES
                });
                if (!handle) return null;
                const hasPermission = await verifyHandlePermission(handle, 'read');
                if (!hasPermission) return null;
                const file = await handle.getFile();
                if (file.size > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].MAX_PAYLOAD_BYTES) throw new Error('Project exceeds the 50 MB import limit.');
                const content = await file.text();
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].parse(content);
                this.setActiveHandle(handle, file.name);
                return {
                    filename: file.name,
                    content,
                    handle
                };
            } catch (err) {
                if (err.name === 'AbortError') return null; // User cancelled dialog
                throw err;
            }
        }
        // DOM Fallback: Invisible input[type=file]
        if (typeof document === 'undefined') return null;
        return new Promise((resolve, reject)=>{
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.pixibun,.json';
            input.style.display = 'none';
            input.onchange = async ()=>{
                const file = input.files?.[0];
                if (!file) {
                    resolve(null);
                    return;
                }
                try {
                    if (file.size > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].MAX_PAYLOAD_BYTES) throw new Error('Project exceeds the 50 MB import limit.');
                    const content = await file.text();
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].parse(content);
                    DesktopFileSystem.setActiveHandle(null, file.name);
                    resolve({
                        filename: file.name,
                        content
                    });
                } catch (e) {
                    reject(e);
                } finally{
                    input.remove();
                }
            };
            document.body.appendChild(input);
            input.click();
        });
    }
    /**
   * Saves project data to disk.
   * If an active file handle exists and `forceSaveAs` is false, it overwrites in-place without prompting.
   * Otherwise, opens showSaveFilePicker or initiates an anchor download fallback.
   */ static async saveProject(data, suggestedName = 'project.pixibun', forceSaveAs = false, projectId) {
        if (this.isSupported()) {
            try {
                let handle = this.activeProjectId === projectId ? this.activeHandle : null;
                if (!handle || forceSaveAs) {
                    const savePicker = window.showSaveFilePicker;
                    if (!savePicker) throw new Error('Save picker is unavailable');
                    handle = await savePicker({
                        suggestedName,
                        types: PIXIBUN_FILE_TYPES
                    });
                    this.setActiveHandle(handle, handle.name);
                    this.activeProjectId = projectId;
                }
                const hasPermission = await verifyHandlePermission(handle, 'readwrite');
                if (!hasPermission) {
                    return {
                        success: false,
                        filename: handle.name,
                        fallbackUsed: false,
                        error: 'Permission denied'
                    };
                }
                const writable = await handle.createWritable();
                await writable.write(data);
                await writable.close();
                return {
                    success: true,
                    filename: handle.name,
                    fallbackUsed: false
                };
            } catch (err) {
                if (err.name === 'AbortError') {
                    return {
                        success: false,
                        filename: suggestedName,
                        fallbackUsed: false,
                        error: 'Save cancelled by user'
                    };
                }
                throw err;
            }
        }
        // DOM Fallback: <a download>
        if (typeof document === 'undefined') {
            return {
                success: false,
                filename: suggestedName,
                fallbackUsed: true,
                error: 'Document unavailable'
            };
        }
        const blob = typeof data === 'string' ? new Blob([
            data
        ], {
            type: 'application/json'
        }) : data;
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = suggestedName;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(()=>URL.revokeObjectURL(url), 1000);
        return {
            success: true,
            filename: suggestedName,
            fallbackUsed: true
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/sync/coDrawBridge.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CODRAW_COMPOSITE_EVENT",
    ()=>CODRAW_COMPOSITE_EVENT,
    "CODRAW_CURSORS_EVENT",
    ()=>CODRAW_CURSORS_EVENT,
    "CODRAW_REMOTE_CHANGE_EVENT",
    ()=>CODRAW_REMOTE_CHANGE_EVENT,
    "CODRAW_STATE_EVENT",
    ()=>CODRAW_STATE_EVENT,
    "CURSOR_BROADCAST_MIN_INTERVAL_MS",
    ()=>CURSOR_BROADCAST_MIN_INTERVAL_MS,
    "CURSOR_STALE_MS",
    ()=>CURSOR_STALE_MS,
    "CoDrawBridge",
    ()=>CoDrawBridge,
    "MAX_CODRAW_INITIAL_PAINTED_PIXELS",
    ()=>MAX_CODRAW_INITIAL_PAINTED_PIXELS,
    "MAX_CODRAW_LAYER_PIXELS",
    ()=>MAX_CODRAW_LAYER_PIXELS,
    "coDrawBridge",
    ()=>coDrawBridge
]);
// CoDrawBridge — the integration layer between the live studio and the P2P
// CRDT sync engine.
//
// Design notes:
// - Full-state antientropy join (Shapiro et al., "Conflict-Free Replicated
//   Data Types," SSS 2011, §4): on connect, the HOST seeds one CrdtPixelBuffer
//   per layer from the live canvases and transmits a complete state snapshot
//   per layer, preceded by a STRUCTURE_SYNC so both peers share one layer-ID
//   namespace (a prerequisite for routing per-layer ops).
// - Delta propagation afterwards: local stroke commits are diffed against
//   their pre-stroke history snapshot (strokeDiff.ts); each changed pixel
//   becomes an LWW op via CrdtPixelBuffer.setPixel and is broadcast.
// - Structure ownership: the host owns the layer/frame tree while a session
//   is active. Guest structural edits remain local and are overwritten by the
//   next host structure push. This is a documented MVP constraint that keeps
//   layer identity deterministic without a full op-based layer CRDT.
// - The bridge is a module singleton so sessions survive modal unmount and
//   so drawing code can reach it without prop drilling.
//
// Convergence guarantee: per-pixel LWW with HLC clocks and deterministic
// peerId tie-breaking (crdtPixelBuffer.ts) yields Strong Eventual Consistency
// for pixel state; canvas buffers are views that converge on op application.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$collab$2f$crdtPixelBuffer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/collab/crdtPixelBuffer.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$p2pSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sync/p2pSync.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$strokeDiff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sync/strokeDiff.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
const CURSOR_BROADCAST_MIN_INTERVAL_MS = 33;
const CURSOR_STALE_MS = 4000;
const CONNECT_SEND_RETRY_MS = 250;
const CONNECT_SEND_MAX_RETRIES = 40;
const MAX_CODRAW_LAYER_PIXELS = 262_144;
const MAX_CODRAW_INITIAL_PAINTED_PIXELS = 32_000;
function getStructureCapacityError(width, height, layerCount) {
    if (width * height * layerCount > MAX_CODRAW_LAYER_PIXELS) {
        return `Co-draw supports up to ${MAX_CODRAW_LAYER_PIXELS.toLocaleString()} total layer pixels. Reduce canvas size, frames, or layers to start a session.`;
    }
    return null;
}
const CODRAW_STATE_EVENT = 'pixibun:codraw-state';
const CODRAW_CURSORS_EVENT = 'pixibun:remote-cursors';
const CODRAW_COMPOSITE_EVENT = 'pixibun:request-composite';
const CODRAW_REMOTE_CHANGE_EVENT = 'pixibun:remote-change';
class CoDrawBridge {
    session = null;
    role = null;
    peerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('peer');
    crdtBuffers = new Map();
    cursors = new Map();
    lastCursorBroadcast = 0;
    syncedLayerIds = new Set();
    unsubscribeStructure = null;
    lastSeenFrames = null;
    lastSeenWidth = 0;
    lastSeenHeight = 0;
    sessionGeneration = 0;
    getRole() {
        return this.role;
    }
    getSession() {
        return this.session;
    }
    getConnectionState() {
        return this.session?.getState() ?? 'idle';
    }
    async startHost(options = {}) {
        const capacityError = this.getHostCapacityError();
        if (capacityError) throw new Error(capacityError);
        this.reset();
        this.role = 'host';
        this.peerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('peer');
        this.session = this.createSession(options);
        return this.session.createHostInvite();
    }
    async startGuest(inviteToken, options = {}) {
        this.reset();
        this.role = 'guest';
        this.peerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('peer');
        this.session = this.createSession(options);
        return this.session.acceptHostInvite(inviteToken);
    }
    disconnect() {
        this.reset();
    }
    createSession(options) {
        const generation = this.sessionGeneration;
        const current = ()=>generation === this.sessionGeneration;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$p2pSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["P2PSyncSession"]({
            peerId: this.peerId,
            peerName: this.role === 'host' ? 'Atelier Host' : 'Atelier Guest',
            iceServers: options.lanOnly === true ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$p2pSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LAN_ICE_SERVERS"] : options.lanOnly === false ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$p2pSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PUBLIC_STUN_ICE_SERVERS"] : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$p2pSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_ICE_SERVERS"],
            lanOnly: options.lanOnly,
            onConnectionStateChange: (state)=>{
                if (current()) this.handleConnectionState(state);
            },
            onRemotePixelOps: (ops, layerId)=>{
                if (current()) this.applyRemoteOps(ops, layerId);
            },
            onInitialSync: (ops, layerId)=>{
                if (current() && this.role === 'guest') this.applyRemoteOps(ops, layerId);
            },
            onStructureSync: (payload)=>{
                if (current()) this.adoptStructure(payload);
            },
            onRemoteCursor: (cursor)=>{
                if (current()) this.handleRemoteCursor(cursor);
            },
            onError: (error)=>{
                if (current()) __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:codraw-error', error.message);
            }
        });
    }
    reset() {
        this.sessionGeneration += 1;
        this.session?.disconnect();
        this.session = null;
        this.role = null;
        this.crdtBuffers.clear();
        this.cursors.clear();
        this.syncedLayerIds.clear();
        if (this.unsubscribeStructure) {
            this.unsubscribeStructure();
            this.unsubscribeStructure = null;
        }
        this.lastSeenFrames = null;
        this.lastSeenWidth = 0;
        this.lastSeenHeight = 0;
    }
    handleConnectionState(state) {
        if (state === 'connected') {
            this.syncedLayerIds.clear();
            if (this.role === 'host') {
                // Data channels may not be 'open' yet when the PC reports connected;
                // retry until the structure + snapshots actually go out (RFC 8831:
                // channel readiness is orthogonal to PeerConnection state).
                this.sendInitialStateWithRetry(0);
            }
        } else if (state === 'disconnected' || state === 'failed') {
            this.syncedLayerIds.clear();
            if (this.unsubscribeStructure) {
                this.unsubscribeStructure();
                this.unsubscribeStructure = null;
            }
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:codraw-state', state);
    }
    sendInitialStateWithRetry(attempt) {
        if (!this.session || this.session.getState() !== 'connected') return;
        const capacityError = this.getHostCapacityError();
        if (capacityError) {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:codraw-error', capacityError);
            this.session.disconnect();
            return;
        }
        const ok = this.sendStructureAndSnapshots();
        if (ok) {
            if (!this.unsubscribeStructure) {
                this.subscribeToStructureChanges();
            }
            return;
        }
        if (attempt < CONNECT_SEND_MAX_RETRIES) {
            const generation = this.sessionGeneration;
            setTimeout(()=>{
                if (generation === this.sessionGeneration) this.sendInitialStateWithRetry(attempt + 1);
            }, CONNECT_SEND_RETRY_MS);
        }
    }
    getHostCapacityError() {
        const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
        const layerIds = new Set(state.frames.flatMap((frame)=>frame.layers.map((layer)=>layer.id)));
        const structureError = getStructureCapacityError(state.canvasWidth, state.canvasHeight, layerIds.size);
        if (structureError) return structureError;
        if (new TextEncoder().encode(JSON.stringify(state.frames)).length > 240 * 1024) {
            return 'Co-draw layer and frame metadata is too large to sync. Reduce the number of frames or layers to start a session.';
        }
        let painted = 0;
        for (const layerId of layerIds){
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasBuffer"])(layerId)) continue;
            const data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layerId, state.canvasWidth, state.canvasHeight).ctx.getImageData(0, 0, state.canvasWidth, state.canvasHeight).data;
            for(let i = 3; i < data.length; i += 4){
                if (data[i] === 0) continue;
                painted++;
                if (painted > MAX_CODRAW_INITIAL_PAINTED_PIXELS) {
                    return `Co-draw supports up to ${MAX_CODRAW_INITIAL_PAINTED_PIXELS.toLocaleString()} painted pixels when joining. Reduce painted area to start a session.`;
                }
            }
        }
        return null;
    }
    sendStructureAndSnapshots() {
        if (!this.session) return false;
        const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
        const payload = {
            width: state.canvasWidth,
            height: state.canvasHeight,
            frames: state.frames.map((f)=>({
                    id: f.id,
                    durationMs: f.durationMs,
                    layers: f.layers.map((l)=>({
                            id: l.id,
                            name: l.name,
                            visible: l.visible,
                            locked: l.locked,
                            opacity: l.opacity,
                            blendMode: l.blendMode,
                            ...l.tag !== undefined ? {
                                tag: l.tag
                            } : {},
                            ...l.effect !== undefined ? {
                                effect: structuredClone(l.effect)
                            } : {}
                        }))
                }))
        };
        if (!this.session.broadcastStructure(payload)) return false;
        const activeLayerIds = new Set();
        for (const frame of state.frames){
            for (const layer of frame.layers){
                activeLayerIds.add(layer.id);
                // Structural edits can bake/restore pixels in an existing layer ID.
                // Reconcile the live raster before sending structure and snapshots so
                // merge/undo/redo also update the shared pixel replica, including erasure.
                if (this.syncedLayerIds.has(layer.id)) {
                    const crdt = this.getBuffer(layer.id, state.canvasWidth, state.canvasHeight);
                    const before = {
                        width: crdt.width,
                        height: crdt.height,
                        data: crdt.toRgbaArray()
                    };
                    this.notifyStrokeCommitted(layer.id, before);
                }
                if (!this.syncedLayerIds.has(layer.id)) {
                    const existing = this.crdtBuffers.get(layer.id);
                    const crdt = this.getBuffer(layer.id, state.canvasWidth, state.canvasHeight);
                    const ops = existing === crdt ? crdt.getStateSnapshotOps() : this.seedCrdtFromCanvas(crdt, layer.id, state.canvasWidth, state.canvasHeight);
                    if (!this.session.broadcastInitialSync(ops, layer.id)) return false;
                    this.syncedLayerIds.add(layer.id);
                }
            }
        }
        for (const id of this.syncedLayerIds){
            if (!activeLayerIds.has(id)) {
                this.syncedLayerIds.delete(id);
                this.crdtBuffers.delete(id);
            }
        }
        return true;
    }
    subscribeToStructureChanges() {
        const initialState = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
        this.lastSeenFrames = initialState.frames;
        this.lastSeenWidth = initialState.canvasWidth;
        this.lastSeenHeight = initialState.canvasHeight;
        this.unsubscribeStructure = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].subscribe(()=>{
            if (this.role !== 'host' || !this.session || this.session.getState() !== 'connected') {
                return;
            }
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            const framesChanged = state.frames !== this.lastSeenFrames;
            const dimensionsChanged = state.canvasWidth !== this.lastSeenWidth || state.canvasHeight !== this.lastSeenHeight;
            if (framesChanged || dimensionsChanged) {
                this.lastSeenFrames = state.frames;
                this.lastSeenWidth = state.canvasWidth;
                this.lastSeenHeight = state.canvasHeight;
                if (dimensionsChanged) {
                    this.syncedLayerIds.clear();
                    this.crdtBuffers.clear();
                }
                this.sendInitialStateWithRetry(0);
            }
        });
    }
    /** Seeds a CRDT replica from the live canvas: every painted pixel becomes a local op. */ seedCrdtFromCanvas(crdt, layerId, width, height) {
        const entry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layerId, width, height);
        const imgData = entry.ctx.getImageData(0, 0, width, height);
        const data = imgData.data;
        const ops = [];
        for(let y = 0; y < height; y++){
            const rowOffset = y * width;
            for(let x = 0; x < width; x++){
                const i = (rowOffset + x) * 4;
                if (data[i + 3] > 0) {
                    const op = crdt.setPixel(x, y, [
                        data[i],
                        data[i + 1],
                        data[i + 2],
                        data[i + 3]
                    ]);
                    if (op) ops.push(op);
                }
            }
        }
        return ops;
    }
    getBuffer(layerId, width, height) {
        const existing = this.crdtBuffers.get(layerId);
        if (existing && existing.width === width && existing.height === height) {
            return existing;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertMemoryAvailable"])(width * height * 192 + 10_000 * 192, 'Collaboration replica');
        const fresh = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$collab$2f$crdtPixelBuffer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CrdtPixelBuffer"](width, height, this.peerId);
        this.crdtBuffers.set(layerId, fresh);
        return fresh;
    }
    /**
   * Called by the drawing pipeline after a stroke is committed to history.
   * Diffs the pre-stroke snapshot against the live buffer and broadcasts the
   * changed pixels as LWW ops for the given layer.
   */ notifyStrokeCommitted(layerId, before) {
        if (!this.session || this.session.getState() !== 'connected' || !before) return;
        const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
        const layerExists = state.frames.some((f)=>f.layers.some((l)=>l.id === layerId));
        if (!layerExists) return;
        const entry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layerId, state.canvasWidth, state.canvasHeight);
        const after = entry.ctx.getImageData(0, 0, state.canvasWidth, state.canvasHeight);
        const deltas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$strokeDiff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["diffImageDataToOps"])(before, after);
        if (deltas.length === 0) return;
        const crdt = this.getBuffer(layerId, state.canvasWidth, state.canvasHeight);
        const ops = [];
        for (const d of deltas){
            const op = crdt.setPixel(d.x, d.y, [
                d.r,
                d.g,
                d.b,
                d.a
            ]);
            if (op) ops.push(op);
        }
        if (ops.length > 0) {
            this.session.broadcastPixelOps(ops, layerId);
        }
    }
    /** Applies remote (or initial-sync) ops to the CRDT replica and repaints the layer view. */ applyRemoteOps(ops, layerId) {
        if (!layerId || ops.length === 0) return;
        const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
        const layerExists = state.frames.some((f)=>f.layers.some((l)=>l.id === layerId));
        if (!layerExists) return;
        const crdt = this.getBuffer(layerId, state.canvasWidth, state.canvasHeight);
        const entry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layerId, state.canvasWidth, state.canvasHeight);
        const img = entry.ctx.getImageData(0, 0, state.canvasWidth, state.canvasHeight);
        let mutated = 0;
        for (const op of ops){
            if (crdt.applyRemoteOp(op)) {
                const i = (op.y * state.canvasWidth + op.x) * 4;
                img.data[i] = op.r;
                img.data[i + 1] = op.g;
                img.data[i + 2] = op.b;
                img.data[i + 3] = op.a;
                mutated++;
            }
        }
        if (mutated > 0) {
            entry.ctx.putImageData(img, 0, 0);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(layerId);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().bumpBufferVersion();
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:request-composite');
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:remote-change');
        }
    }
    /**
   * Guest-side adoption of the host's layer/frame structure. Clears all local
   * buffers, installs the shared metadata, then repaints every layer canvas
   * from its CRDT replica so pixels synced before this point survive.
   */ adoptStructure(payload) {
        if (this.role !== 'guest') {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:codraw-error', 'Only the host may replace the shared frame and layer structure.');
            return;
        }
        if (typeof document === 'undefined') return;
        const layerCount = payload.frames.reduce((count, frame)=>count + frame.layers.length, 0);
        const capacityError = getStructureCapacityError(payload.width, payload.height, layerCount);
        if (capacityError) {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:codraw-error', capacityError);
            this.session?.disconnect();
            return;
        }
        const activeLayerIds = new Set();
        for (const frame of payload.frames){
            for (const layer of frame.layers){
                activeLayerIds.add(layer.id);
            }
        }
        // Stage the guest's views before publishing metadata. Allocation failure
        // leaves its current workspace/replicas intact rather than exposing blank views.
        const replicas = new Map(this.crdtBuffers);
        const staged = new Map();
        for (const [layerId, crdt] of replicas){
            if (!activeLayerIds.has(layerId) || crdt.width !== payload.width || crdt.height !== payload.height) {
                replicas.delete(layerId);
            }
        }
        let releaseStaging;
        try {
            releaseStaging = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reserveMemory"])((replicas.size + 2) * payload.width * payload.height * 4, 'Shared artwork staging');
            for (const [layerId, crdt] of replicas){
                const entry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEntry"])(payload.width, payload.height, 1, true);
                const img = entry.ctx.createImageData(payload.width, payload.height);
                img.data.set(crdt.toRgbaArray());
                entry.ctx.putImageData(img, 0, 0);
                staged.set(layerId, entry);
            }
        } catch  {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:codraw-error', 'Could not prepare the shared artwork. Reconnect to retry.');
            this.session?.disconnect();
            return;
        } finally{
            releaseStaging?.();
        }
        this.crdtBuffers = replicas;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceAllBuffers"])(staged);
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState((state)=>{
            state.canvasWidth = payload.width;
            state.canvasHeight = payload.height;
            state.frames = payload.frames.map((f)=>({
                    id: f.id,
                    durationMs: f.durationMs,
                    layers: f.layers.map((l)=>({
                            ...l
                        }))
                }));
            if (state.activeFrameIndex >= payload.frames.length) {
                state.activeFrameIndex = 0;
            }
            const activeFrame = payload.frames[state.activeFrameIndex];
            const layerStillExists = activeFrame?.layers.some((l)=>l.id === state.activeLayerId);
            if (!layerStillExists) {
                state.activeLayerId = activeFrame?.layers[0]?.id ?? '';
            }
            state.bufferVersion += 1;
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:history-clear');
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:request-composite');
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:remote-change');
    }
    /** Throttled cursor broadcast over the unreliable presence channel. */ broadcastCursor(x, y) {
        if (!this.session || this.session.getState() !== 'connected') return;
        const now = Date.now();
        if (now - this.lastCursorBroadcast < CURSOR_BROADCAST_MIN_INTERVAL_MS) return;
        this.lastCursorBroadcast = now;
        this.session.broadcastCursor(x, y);
    }
    handleRemoteCursor(cursor) {
        this.cursors.set(cursor.peerId, {
            ...cursor,
            lastUpdated: Date.now()
        });
        this.emitCursors();
    }
    getActiveCursors(staleMs = CURSOR_STALE_MS) {
        const now = Date.now();
        const active = [];
        for (const [peerId, cursor] of this.cursors){
            if (now - cursor.lastUpdated > staleMs) {
                this.cursors.delete(peerId);
            } else {
                active.push(cursor);
            }
        }
        return active;
    }
    emitCursors() {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:remote-cursors', this.getActiveCursors());
    }
    getEstimatedMemoryBytes() {
        return [
            ...this.crdtBuffers.values()
        ].reduce((sum, buffer)=>sum + buffer.estimatedBytes, 0);
    }
}
const coDrawBridge = new CoDrawBridge();
(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerMemoryUsage"])('collaboration', ()=>coDrawBridge.getEstimatedMemoryBytes());
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/sync/p2pSync.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_ICE_SERVERS",
    ()=>DEFAULT_ICE_SERVERS,
    "HEX_COLOR_REGEX",
    ()=>HEX_COLOR_REGEX,
    "LAN_ICE_SERVERS",
    ()=>LAN_ICE_SERVERS,
    "MAX_DATA_CHANNEL_BUFFERED_AMOUNT",
    ()=>MAX_DATA_CHANNEL_BUFFERED_AMOUNT,
    "MAX_P2P_PAYLOAD_SIZE",
    ()=>MAX_P2P_PAYLOAD_SIZE,
    "MAX_PRESENCE_BUFFERED_AMOUNT",
    ()=>MAX_PRESENCE_BUFFERED_AMOUNT,
    "P2PSyncSession",
    ()=>P2PSyncSession,
    "PUBLIC_STUN_ICE_SERVERS",
    ()=>PUBLIC_STUN_ICE_SERVERS,
    "STRUCTURE_BLEND_MODES",
    ()=>STRUCTURE_BLEND_MODES,
    "decodeSignalingToken",
    ()=>decodeSignalingToken,
    "encodeSignalingToken",
    ()=>encodeSignalingToken,
    "isValidPixelOp",
    ()=>isValidPixelOp,
    "sanitizePeerName",
    ()=>sanitizePeerName,
    "validateCrdtSyncMessage",
    ()=>validateCrdtSyncMessage,
    "validatePresenceMessage",
    ()=>validatePresenceMessage,
    "validateStructurePayload",
    ()=>validateStructurePayload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/compiled/buffer/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/safeJson.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$server$2f$tokenBucket$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/server/tokenBucket.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/canvasLimits.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/schema.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/resourceBudget.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/animationTiming.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const LAN_ICE_SERVERS = [];
const PUBLIC_STUN_ICE_SERVERS = [
    {
        urls: 'stun:stun.l.google.com:19302'
    },
    {
        urls: 'stun:stun1.l.google.com:19302'
    }
];
const DEFAULT_ICE_SERVERS = LAN_ICE_SERVERS;
const MAX_P2P_PAYLOAD_SIZE = 256 * 1024; // 256 KB
const MAX_DATA_CHANNEL_BUFFERED_AMOUNT = 1024 * 1024; // 1 MB backpressure ceiling
const MAX_PRESENCE_BUFFERED_AMOUNT = 64 * 1024; // 64 KB presence buffer ceiling
const HEX_COLOR_REGEX = /^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
const STRUCTURE_BLEND_MODES = [
    'source-over',
    'multiply',
    'screen',
    'overlay',
    'color-dodge',
    'source-atop'
];
function isStructureBlendMode(value) {
    return typeof value === 'string' && STRUCTURE_BLEND_MODES.includes(value);
}
function validateStructurePayload(data) {
    if (typeof data !== 'object' || data === null) return null;
    const p = data;
    if (typeof p.width !== 'number' || !Number.isInteger(p.width) || p.width < 1 || p.width > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION || typeof p.height !== 'number' || !Number.isInteger(p.height) || p.height < 1 || p.height > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION) {
        return null;
    }
    if (!Array.isArray(p.frames) || p.frames.length === 0 || p.frames.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES) return null;
    const frames = [];
    const frameIds = new Set();
    const layerIds = new Set();
    for (const rawFrame of p.frames){
        if (typeof rawFrame !== 'object' || rawFrame === null) return null;
        const f = rawFrame;
        if (typeof f.id !== 'string' || f.id.length === 0 || f.id.length > 128 || frameIds.has(f.id)) return null;
        frameIds.add(f.id);
        if (typeof f.durationMs !== 'number' || !Number.isInteger(f.durationMs) || f.durationMs < __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMinMs || f.durationMs > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMaxMs) {
            return null;
        }
        if (!Array.isArray(f.layers) || f.layers.length === 0 || f.layers.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS) return null;
        const layers = [];
        for (const rawLayer of f.layers){
            if (typeof rawLayer !== 'object' || rawLayer === null) return null;
            const l = rawLayer;
            if (typeof l.id !== 'string' || l.id.length === 0 || l.id.length > 128 || layerIds.has(l.id)) return null;
            layerIds.add(l.id);
            if (typeof l.name !== 'string' || l.name.length > 256) return null;
            if (typeof l.visible !== 'boolean' || typeof l.locked !== 'boolean') return null;
            if (typeof l.opacity !== 'number' || !Number.isFinite(l.opacity) || l.opacity < 0 || l.opacity > 1) return null;
            if (!isStructureBlendMode(l.blendMode)) return null;
            if (l.tag !== undefined && (typeof l.tag !== 'string' || l.tag.length > 64)) return null;
            const effect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateLayerEffect"])(l.effect);
            if (typeof effect === 'string') return null;
            layers.push({
                id: l.id,
                name: l.name,
                visible: l.visible,
                locked: l.locked,
                opacity: l.opacity,
                blendMode: l.blendMode,
                ...l.tag !== undefined ? {
                    tag: l.tag
                } : {},
                ...effect !== undefined ? {
                    effect
                } : {}
            });
        }
        frames.push({
            id: f.id,
            durationMs: f.durationMs,
            layers
        });
    }
    const budget = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProjectResourceBudget"])(p.width, p.height, frames);
    if (!budget.ok) return null;
    return {
        width: p.width,
        height: p.height,
        frames
    };
}
function isValidPixelOp(op) {
    if (typeof op !== 'object' || op === null) return false;
    const o = op;
    if (typeof o.x !== 'number' || !Number.isFinite(o.x) || Math.floor(o.x) !== o.x || o.x < 0 || o.x >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION) {
        return false;
    }
    if (typeof o.y !== 'number' || !Number.isFinite(o.y) || Math.floor(o.y) !== o.y || o.y < 0 || o.y >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION) {
        return false;
    }
    if (typeof o.r !== 'number' || !Number.isFinite(o.r) || Math.floor(o.r) !== o.r || o.r < 0 || o.r > 255) {
        return false;
    }
    if (typeof o.g !== 'number' || !Number.isFinite(o.g) || Math.floor(o.g) !== o.g || o.g < 0 || o.g > 255) {
        return false;
    }
    if (typeof o.b !== 'number' || !Number.isFinite(o.b) || Math.floor(o.b) !== o.b || o.b < 0 || o.b > 255) {
        return false;
    }
    if (typeof o.a !== 'number' || !Number.isFinite(o.a) || Math.floor(o.a) !== o.a || o.a < 0 || o.a > 255) {
        return false;
    }
    if (typeof o.timestamp !== 'number' || !Number.isFinite(o.timestamp) || o.timestamp <= 0) {
        return false;
    }
    if (typeof o.peerId !== 'string' || o.peerId.length === 0 || o.peerId.length > 128) {
        return false;
    }
    if (o.hlc !== undefined) {
        if (!Array.isArray(o.hlc) || o.hlc.length !== 2 || typeof o.hlc[0] !== 'number' || !Number.isFinite(o.hlc[0]) || o.hlc[0] <= 0 || Math.floor(o.hlc[0]) !== o.hlc[0] || typeof o.hlc[1] !== 'number' || !Number.isFinite(o.hlc[1]) || o.hlc[1] < 0 || Math.floor(o.hlc[1]) !== o.hlc[1]) {
            return false;
        }
    }
    return true;
}
function validateCrdtSyncMessage(data) {
    if (typeof data !== 'object' || data === null) return null;
    const msg = data;
    if (msg.type !== 'INITIAL_SYNC' && msg.type !== 'PIXEL_OPS' && msg.type !== 'PING' && msg.type !== 'STRUCTURE_SYNC') {
        return null;
    }
    if (typeof msg.peerId !== 'string' || msg.peerId.length === 0 || msg.peerId.length > 128) {
        return null;
    }
    if (msg.type === 'INITIAL_SYNC' || msg.type === 'PIXEL_OPS') {
        if (!Array.isArray(msg.ops)) return null;
        // layerId is mandatory when ops target a specific layer buffer
        if (typeof msg.layerId !== 'string' || msg.layerId.length === 0 || msg.layerId.length > 128) {
            return null;
        }
        const validOps = [];
        for (const op of msg.ops){
            if (isValidPixelOp(op)) {
                validOps.push(op);
            } else {
                // Discard invalid / out-of-bounds operations
                return null;
            }
        }
        return {
            type: msg.type,
            peerId: msg.peerId,
            ops: validOps,
            layerId: msg.layerId,
            timestamp: typeof msg.timestamp === 'number' && Number.isFinite(msg.timestamp) ? msg.timestamp : undefined
        };
    }
    if (msg.type === 'STRUCTURE_SYNC') {
        const frames = validateStructurePayload(msg.frames);
        if (!frames) return null;
        return {
            type: 'STRUCTURE_SYNC',
            peerId: msg.peerId,
            frames,
            timestamp: typeof msg.timestamp === 'number' && Number.isFinite(msg.timestamp) ? msg.timestamp : undefined
        };
    }
    return {
        type: 'PING',
        peerId: msg.peerId,
        timestamp: typeof msg.timestamp === 'number' && Number.isFinite(msg.timestamp) ? msg.timestamp : undefined
    };
}
function sanitizePeerName(rawName) {
    let result = '';
    const limit = Math.min(rawName.length, 256);
    for(let i = 0; i < limit; i++){
        const code = rawName.charCodeAt(i);
        if (code >= 0 && code <= 31 || code >= 127 && code <= 159 || code >= 0x202a && code <= 0x202e || code >= 0x2066 && code <= 0x2069 || code === 0x200b || code === 0xfeff) {
            continue;
        }
        result += rawName[i];
    }
    return result.trim();
}
function validatePresenceMessage(data) {
    if (typeof data !== 'object' || data === null) return null;
    const msg = data;
    if (msg.type !== 'CURSOR') return null;
    if (typeof msg.peerId !== 'string' || msg.peerId.length === 0 || msg.peerId.length > 128) return null;
    if (typeof msg.name !== 'string' || msg.name.length === 0 || msg.name.length > 128) return null;
    // Sanitize and strip control characters (C0 and C1 sets, bidi overrides) and trim whitespace
    const sanitizedName = sanitizePeerName(msg.name);
    if (sanitizedName.length === 0 || sanitizedName.length > 64) return null;
    // Strictly validate hex color format (#rgb, #rgba, #rrggbb, #rrggbbaa)
    if (typeof msg.color !== 'string' || !HEX_COLOR_REGEX.test(msg.color)) return null;
    if (typeof msg.x !== 'number' || !Number.isFinite(msg.x)) return null;
    if (typeof msg.y !== 'number' || !Number.isFinite(msg.y)) return null;
    return {
        type: 'CURSOR',
        peerId: msg.peerId,
        name: sanitizedName,
        color: msg.color,
        x: msg.x,
        y: msg.y
    };
}
function bytesToBase64(bytes) {
    if (typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"] !== 'undefined') {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(bytes.buffer, bytes.byteOffset, bytes.byteLength).toString('base64');
    }
    let binary = '';
    const len = bytes.byteLength;
    for(let i = 0; i < len; i++){
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}
function base64ToBytes(base64) {
    // Normalize URL-safe Base64 to standard Base64
    let stdBase64 = base64.replace(/-/g, '+').replace(/_/g, '/');
    const pad = stdBase64.length % 4;
    if (pad) {
        stdBase64 += '='.repeat(4 - pad);
    }
    if (typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"] !== 'undefined') {
        const buf = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(stdBase64, 'base64');
        return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
    }
    const binary = atob(stdBase64);
    const bytes = new Uint8Array(binary.length);
    for(let i = 0; i < binary.length; i++){
        bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
}
function encodeSignalingToken(payload) {
    const json = JSON.stringify(payload);
    const bytes = new TextEncoder().encode(json);
    return bytesToBase64(bytes);
}
function decodeSignalingToken(token) {
    try {
        if (typeof token !== 'string' || token.trim().length === 0) {
            throw new Error('Token string cannot be empty.');
        }
        if (token.length > 1024 * 1024) throw new Error('Signaling token exceeds the size limit.');
        const clean = token.trim();
        const bytes = base64ToBytes(clean);
        const json = new TextDecoder('utf-8').decode(bytes);
        const parsed = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].parse(json);
        if (!parsed || parsed.version !== 1 || !parsed.sdp || !Array.isArray(parsed.candidates)) {
            throw new Error('Invalid PixiBun signaling token format.');
        }
        return parsed;
    } catch (err) {
        throw new Error(`Invalid signaling token format: ${err.message}`);
    }
}
class P2PSyncSession {
    peerId;
    peerName;
    peerColor;
    pc = null;
    syncChannel = null;
    presenceChannel = null;
    state = 'idle';
    iceCandidates = [];
    options;
    // Defensive Token Bucket Rate Limiters (Turner 1986 / Tanenbaum §5.3)
    pendingMessages = new Map();
    pendingMessageBytes = 0;
    // The reliable channel is ordered. A high-water mark suppresses retries without
    // retaining one ID for every message in a long co-draw session.
    lastReceivedDeliveryId = 0;
    deliveryId = 0;
    retryTimer = null;
    queueReliable(msg) {
        const id = ++this.deliveryId;
        const json = JSON.stringify({
            ...msg,
            deliveryId: id
        });
        const bytes = new TextEncoder().encode(json).length;
        if (bytes > MAX_P2P_PAYLOAD_SIZE || this.pendingMessageBytes + bytes > 32 * 1024 * 1024) {
            this.options.onError?.(new Error('Co-draw queue is full. Reconnect to resynchronize artwork.'));
            this.setState('failed');
            return false;
        }
        this.pendingMessages.set(id, {
            json,
            sentAt: 0
        });
        this.pendingMessageBytes += bytes;
        if (!this.retryTimer) this.retryTimer = setInterval(()=>this.flushReliable(), 250);
        this.flushReliable();
        return true;
    }
    flushReliable() {
        const channel = this.syncChannel;
        if (!channel || channel.readyState !== 'open') return;
        for (const item of this.pendingMessages.values()){
            if ((channel.bufferedAmount ?? 0) > MAX_DATA_CHANNEL_BUFFERED_AMOUNT) return;
            if (item.sentAt && Date.now() - item.sentAt < 1500) continue;
            try {
                channel.send(item.json);
                item.sentAt = Date.now();
            } catch  {
                return;
            }
        }
        if (!this.pendingMessages.size && this.retryTimer) {
            clearInterval(this.retryTimer);
            this.retryTimer = null;
        }
    }
    presenceRateLimiter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$server$2f$tokenBucket$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTokenBucketStore"])({
        capacity: 150,
        refillPerMinute: 7200
    });
    constructor(options){
        this.peerId = options.peerId;
        this.peerName = options.peerName ?? `Artisan-${options.peerId.slice(0, 4)}`;
        this.peerColor = options.peerColor ?? '#f0be7c';
        this.options = options;
    }
    getState() {
        return this.state;
    }
    setState(newState) {
        if (this.state !== newState) {
            this.state = newState;
            this.options.onConnectionStateChange?.(newState);
        }
    }
    /**
   * Initializes RTCPeerConnection with dual RTCDataChannels.
   */ initPeerConnection() {
        if (typeof RTCPeerConnection === 'undefined') {
            throw new Error('WebRTC RTCPeerConnection is not supported in this environment.');
        }
        const iceServers = this.options.lanOnly ? LAN_ICE_SERVERS : this.options.iceServers ?? DEFAULT_ICE_SERVERS;
        const pc = new RTCPeerConnection({
            iceServers
        });
        pc.onicecandidate = (e)=>{
            if (e.candidate) {
                this.iceCandidates.push(e.candidate.toJSON());
            }
        };
        pc.onconnectionstatechange = ()=>{
            if (pc.connectionState === 'connected') {
                this.setState('connected');
            } else if (pc.connectionState === 'disconnected' || pc.connectionState === 'closed') {
                this.setState('disconnected');
            } else if (pc.connectionState === 'failed') {
                this.setState('failed');
            }
        };
        // Guest listener for channels created by Host
        pc.ondatachannel = (e)=>{
            this.setupChannel(e.channel);
        };
        this.pc = pc;
        return pc;
    }
    /**
   * Hooks data channel event listeners based on channel label.
   */ setupChannel(channel) {
        if (channel.label === 'pixibun-crdt-sync') {
            this.lastReceivedDeliveryId = 0;
            this.syncChannel = channel;
            channel.bufferedAmountLowThreshold = MAX_DATA_CHANNEL_BUFFERED_AMOUNT / 2;
            channel.onbufferedamountlow = ()=>this.flushReliable();
            channel.onopen = ()=>{
                this.flushReliable();
                if (this.pc?.connectionState === 'connected' || channel.readyState === 'open') {
                    this.setState('connected');
                }
            };
            channel.onmessage = (e)=>{
                try {
                    if (typeof e.data === 'string' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUtf8ByteLength"])(e.data) > MAX_P2P_PAYLOAD_SIZE) {
                        console.warn('P2P payload exceeded 256KB limit. Discarding message.');
                        return;
                    }
                    const raw = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].parse(e.data);
                    if (raw?.type === 'ACK' && Number.isSafeInteger(raw.deliveryId)) {
                        const pending = this.pendingMessages.get(raw.deliveryId);
                        if (pending) {
                            this.pendingMessageBytes -= (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUtf8ByteLength"])(pending.json);
                            this.pendingMessages.delete(raw.deliveryId);
                        }
                        this.flushReliable();
                        return;
                    }
                    const deliveryId = Number.isSafeInteger(raw?.deliveryId) && raw.deliveryId > 0 ? raw.deliveryId : undefined;
                    const acknowledge = ()=>{
                        if (deliveryId !== undefined && channel.readyState === 'open') {
                            channel.send(JSON.stringify({
                                type: 'ACK',
                                deliveryId
                            }));
                        }
                    };
                    if (deliveryId !== undefined && deliveryId <= this.lastReceivedDeliveryId) {
                        acknowledge();
                        return;
                    }
                    const msg = validateCrdtSyncMessage(raw);
                    if (!msg) {
                        console.warn('P2P CRDT sync message failed validation.');
                        return;
                    }
                    if (msg.type === 'INITIAL_SYNC' && msg.ops) {
                        this.options.onInitialSync?.(msg.ops, msg.layerId);
                    } else if (msg.type === 'PIXEL_OPS' && msg.ops) {
                        this.options.onRemotePixelOps?.(msg.ops, msg.layerId);
                    } else if (msg.type === 'STRUCTURE_SYNC' && msg.frames) {
                        this.options.onStructureSync?.(msg.frames);
                    }
                    if (deliveryId !== undefined) this.lastReceivedDeliveryId = deliveryId;
                    acknowledge();
                } catch (err) {
                    console.error('Failed to parse CRDT sync message:', err);
                }
            };
        } else if (channel.label === 'pixibun-presence') {
            this.presenceChannel = channel;
            channel.onmessage = (e)=>{
                try {
                    if (!this.presenceRateLimiter.take('presence')) {
                        // Drop excessive presence frame silently
                        return;
                    }
                    if (typeof e.data === 'string' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUtf8ByteLength"])(e.data) > MAX_P2P_PAYLOAD_SIZE) {
                        console.warn('P2P presence payload exceeded 256KB limit. Discarding message.');
                        return;
                    }
                    const raw = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].parse(e.data);
                    const msg = validatePresenceMessage(raw);
                    if (!msg) {
                        console.warn('P2P presence message failed validation.');
                        return;
                    }
                    if (msg.type === 'CURSOR') {
                        this.options.onRemoteCursor?.({
                            peerId: msg.peerId,
                            name: msg.name,
                            color: msg.color,
                            x: msg.x,
                            y: msg.y,
                            lastUpdated: Date.now()
                        });
                    }
                } catch (err) {
                    console.error('Failed to parse presence message:', err);
                }
            };
        }
    }
    /**
   * Helper waiting for ICE candidate gathering completion:
   * - 5000ms hard safety ceiling (ensuring slow cellular/VPN/STUN candidates are gathered).
   * - Resolves immediately when gathering state is 'complete' or null candidate is received.
   * - Resolves on a 600ms idle debounce once candidate gathering settles.
   */ waitForIceGathering(pc) {
        return new Promise((resolve)=>{
            if (pc.iceGatheringState === 'complete') {
                resolve();
                return;
            }
            let done = false;
            let idleTimeoutId = null;
            const finish = ()=>{
                if (done) return;
                done = true;
                clearTimeout(hardTimeoutId);
                if (idleTimeoutId) clearTimeout(idleTimeoutId);
                pc.removeEventListener('icegatheringstatechange', checkState);
                pc.removeEventListener('icecandidate', checkCandidate);
                resolve();
            };
            const hardTimeoutId = setTimeout(finish, 5000);
            const checkState = ()=>{
                if (pc.iceGatheringState === 'complete') {
                    finish();
                }
            };
            const checkCandidate = (e)=>{
                if (e.candidate) {
                    if (idleTimeoutId) clearTimeout(idleTimeoutId);
                    idleTimeoutId = setTimeout(finish, 600);
                } else {
                    // null candidate signals end of candidate gathering
                    finish();
                }
            };
            pc.addEventListener('icegatheringstatechange', checkState);
            pc.addEventListener('icecandidate', checkCandidate);
        });
    }
    /**
   * Host workflow: creates local offer, waits for ICE candidates, and returns the invite code.
   */ async createHostInvite() {
        this.setState('generating-offer');
        this.iceCandidates = [];
        const pc = this.initPeerConnection();
        // Create Reliable Ordered CRDT Sync Channel
        const syncCh = pc.createDataChannel('pixibun-crdt-sync', {
            ordered: true
        });
        this.setupChannel(syncCh);
        // Create Unreliable Unordered Presence Channel (PR-SCTP maxRetransmits: 0)
        const presenceCh = pc.createDataChannel('pixibun-presence', {
            ordered: false,
            maxRetransmits: 0
        });
        this.setupChannel(presenceCh);
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        await this.waitForIceGathering(pc);
        this.setState('waiting-for-answer');
        const payload = {
            version: 1,
            peerId: this.peerId,
            sdp: pc.localDescription.toJSON(),
            candidates: this.iceCandidates
        };
        return encodeSignalingToken(payload);
    }
    /**
   * Guest workflow: accepts host invite token, creates answer, and returns answer token.
   */ async acceptHostInvite(inviteToken) {
        this.setState('connecting');
        this.iceCandidates = [];
        const hostPayload = decodeSignalingToken(inviteToken);
        const pc = this.initPeerConnection();
        await pc.setRemoteDescription(new RTCSessionDescription(hostPayload.sdp));
        // Add host ICE candidates
        for (const c of hostPayload.candidates){
            try {
                await pc.addIceCandidate(new RTCIceCandidate(c));
            } catch (err) {
                console.warn('Could not add host ICE candidate:', err);
            }
        }
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        await this.waitForIceGathering(pc);
        const guestPayload = {
            version: 1,
            peerId: this.peerId,
            sdp: pc.localDescription.toJSON(),
            candidates: this.iceCandidates
        };
        return encodeSignalingToken(guestPayload);
    }
    /**
   * Host workflow (final step): applies guest answer token to complete connection.
   */ async completeHostConnection(answerToken) {
        if (!this.pc) {
            throw new Error('Host connection has not been initialized.');
        }
        this.setState('connecting');
        const guestPayload = decodeSignalingToken(answerToken);
        await this.pc.setRemoteDescription(new RTCSessionDescription(guestPayload.sdp));
        for (const c of guestPayload.candidates){
            try {
                await this.pc.addIceCandidate(new RTCIceCandidate(c));
            } catch (err) {
                console.warn('Could not add guest ICE candidate:', err);
            }
        }
    }
    /**
   * Broadcasts CRDT pixel operations over the reliable ordered channel.
   */ broadcastPixelOps(ops, layerId) {
        if (!this.syncChannel || this.syncChannel.readyState !== 'open' || ops.length === 0) {
            return false;
        }
        const CHUNK_SIZE = 256;
        for(let i = 0; i < ops.length; i += CHUNK_SIZE){
            const chunk = ops.slice(i, i + CHUNK_SIZE);
            const msg = {
                type: 'PIXEL_OPS',
                peerId: this.peerId,
                ops: chunk,
                ...layerId !== undefined ? {
                    layerId
                } : {},
                timestamp: Date.now()
            };
            if (!this.queueReliable(msg)) return false;
        }
        return true;
    }
    /**
   * Broadcasts initial full state over the reliable ordered channel.
   * Chunks large snapshots into batches of 256 ops to stay safely within the 256KB frame limit.
   */ broadcastInitialSync(allOps, layerId) {
        if (!this.syncChannel || this.syncChannel.readyState !== 'open') {
            return false;
        }
        if (allOps.length === 0) {
            const msg = {
                type: 'INITIAL_SYNC',
                peerId: this.peerId,
                ops: [],
                ...layerId !== undefined ? {
                    layerId
                } : {},
                timestamp: Date.now()
            };
            if (!this.queueReliable(msg)) return false;
            return true;
        }
        const CHUNK_SIZE = 256;
        for(let i = 0; i < allOps.length; i += CHUNK_SIZE){
            const chunk = allOps.slice(i, i + CHUNK_SIZE);
            const msg = {
                type: 'INITIAL_SYNC',
                peerId: this.peerId,
                ops: chunk,
                ...layerId !== undefined ? {
                    layerId
                } : {},
                timestamp: Date.now()
            };
            if (!this.queueReliable(msg)) return false;
        }
        return true;
    }
    /**
   * Broadcasts the host's layer/frame structure so both peers share one layer
   * ID namespace (a prerequisite for per-layer CRDT op routing).
   * The payload is metadata-only (no pixels) and validated on receipt by
   * validateStructurePayload.
   */ broadcastStructure(payload) {
        if (!this.syncChannel || this.syncChannel.readyState !== 'open') {
            return false;
        }
        const msg = {
            type: 'STRUCTURE_SYNC',
            peerId: this.peerId,
            frames: payload,
            timestamp: Date.now()
        };
        const json = JSON.stringify(msg);
        if (json.length > MAX_P2P_PAYLOAD_SIZE) {
            console.warn('P2P structure payload exceeded 256KB limit. Discarding message.');
            return false;
        }
        if (!this.queueReliable(msg)) return false;
        return true;
    }
    /**
   * Broadcasts cursor position over the lossy, zero-retransmission presence channel.
   */ broadcastCursor(x, y) {
        if (!this.presenceChannel || this.presenceChannel.readyState !== 'open') {
            return false;
        }
        // Drop lossy cursor frame under backpressure
        if ((this.presenceChannel.bufferedAmount ?? 0) > MAX_PRESENCE_BUFFERED_AMOUNT) {
            return false;
        }
        const msg = {
            type: 'CURSOR',
            peerId: this.peerId,
            name: this.peerName,
            color: this.peerColor,
            x,
            y
        };
        this.presenceChannel.send(JSON.stringify(msg));
        return true;
    }
    /**
   * Closes data channels and peer connection.
   */ disconnect() {
        if (this.retryTimer) clearInterval(this.retryTimer);
        this.retryTimer = null;
        this.pendingMessages.clear();
        this.pendingMessageBytes = 0;
        this.lastReceivedDeliveryId = 0;
        if (this.syncChannel) {
            this.syncChannel.close();
            this.syncChannel = null;
        }
        if (this.presenceChannel) {
            this.presenceChannel.close();
            this.presenceChannel = null;
        }
        if (this.pc) {
            this.pc.close();
            this.pc = null;
        }
        this.setState('disconnected');
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/sync/strokeDiff.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Pure stroke diff for CRDT op extraction.
//
// Given the pre-stroke ImageData captured by the history engine and the
// post-stroke layer buffer, emits one delta per changed pixel. These deltas
// feed CrdtPixelBuffer.setPixel so local artwork modifications become
// LWW-CRDT operations (Shapiro et al., "Conflict-Free Replicated Data Types,"
// SSS 2011 — delta propagation from state-based replicas).
//
// Kept DOM-free and structurally typed so it is unit-testable without a
// canvas implementation.
__turbopack_context__.s([
    "diffImageDataToOps",
    ()=>diffImageDataToOps
]);
function diffImageDataToOps(before, after) {
    if (before.width !== after.width || before.height !== after.height) {
        // Dimensions changed (resize): a pixel diff is meaningless; callers must
        // re-sync via full snapshot instead.
        return [];
    }
    if (before.data.length !== after.data.length) return [];
    const deltas = [];
    const a = before.data;
    const b = after.data;
    for(let y = 0; y < before.height; y++){
        const rowOffset = y * before.width;
        for(let x = 0; x < before.width; x++){
            const i = (rowOffset + x) * 4;
            if (a[i] !== b[i] || a[i + 1] !== b[i + 1] || a[i + 2] !== b[i + 2] || a[i + 3] !== b[i + 3]) {
                deltas.push({
                    x,
                    y,
                    r: b[i],
                    g: b[i + 1],
                    b: b[i + 2],
                    a: b[i + 3]
                });
            }
        }
    }
    return deltas;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_lib_06zat4u._.js.map