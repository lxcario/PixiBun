(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_app_0ic5bsc._.css","static/chunks/src_11ch1gq._.js","static/chunks/node_modules_0xr9ggx._.js","static/chunks/src_1iok10q._.js","static/chunks/src_1-4bn7v._.js","static/chunks/src_lib_1m8e899._.js","static/chunks/src_components_0_diuwu._.js","static/chunks/src_stores_themeStore_ts_1eexm6d._.js","static/chunks/node_modules_1sftmzb._.js"],
    source: "entry"
});
