(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/studio/FloatingPreviewWindow.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FloatingPreviewWindow",
    ()=>FloatingPreviewWindow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/render/compositor.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const FloatingPreviewWindow = ()=>{
    _s();
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[frames]": (s)=>s.frames
    }["FloatingPreviewWindow.useStudioStore[frames]"]);
    const activeFrameIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[activeFrameIndex]": (s)=>s.activeFrameIndex
    }["FloatingPreviewWindow.useStudioStore[activeFrameIndex]"]);
    const canvasWidth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[canvasWidth]": (s)=>s.canvasWidth
    }["FloatingPreviewWindow.useStudioStore[canvasWidth]"]);
    const canvasHeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[canvasHeight]": (s)=>s.canvasHeight
    }["FloatingPreviewWindow.useStudioStore[canvasHeight]"]);
    const isPlaying = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[isPlaying]": (s)=>s.isPlaying
    }["FloatingPreviewWindow.useStudioStore[isPlaying]"]);
    const setIsPlaying = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[setIsPlaying]": (s)=>s.setIsPlaying
    }["FloatingPreviewWindow.useStudioStore[setIsPlaying]"]);
    const fps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[fps]": (s)=>s.fps
    }["FloatingPreviewWindow.useStudioStore[fps]"]);
    const previewScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[previewScale]": (s)=>s.previewScale
    }["FloatingPreviewWindow.useStudioStore[previewScale]"]);
    const setPreviewScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[setPreviewScale]": (s)=>s.setPreviewScale
    }["FloatingPreviewWindow.useStudioStore[setPreviewScale]"]);
    const previewBackdrop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[previewBackdrop]": (s)=>s.previewBackdrop
    }["FloatingPreviewWindow.useStudioStore[previewBackdrop]"]);
    const setPreviewBackdrop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[setPreviewBackdrop]": (s)=>s.setPreviewBackdrop
    }["FloatingPreviewWindow.useStudioStore[setPreviewBackdrop]"]);
    const showFloatingPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[showFloatingPreview]": (s)=>s.showFloatingPreview
    }["FloatingPreviewWindow.useStudioStore[showFloatingPreview]"]);
    const toggleFloatingPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[toggleFloatingPreview]": (s)=>s.toggleFloatingPreview
    }["FloatingPreviewWindow.useStudioStore[toggleFloatingPreview]"]);
    const bufferVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FloatingPreviewWindow.useStudioStore[bufferVersion]": (s)=>s.bufferVersion
    }["FloatingPreviewWindow.useStudioStore[bufferVersion]"]);
    const previewCanvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isMinimized, setIsMinimized] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [position, setPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 16,
        y: 56
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FloatingPreviewWindow.useEffect": ()=>{
            setPosition({
                x: Math.max(16, window.innerWidth - 640),
                y: 16
            });
        }
    }["FloatingPreviewWindow.useEffect"], []);
    const [isDragging, setIsDragging] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const dragOffsetRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        x: 0,
        y: 0
    });
    // Custom resizable viewport size (minimum 140px width)
    const [viewportSize, setViewportSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        width: 180,
        height: 120
    });
    const [isResizing, setIsResizing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const resizeStartRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        startX: 0,
        startY: 0,
        startW: 180,
        startH: 120
    });
    // Render active composite frame to preview canvas whenever frames, activeFrameIndex, or canvas size changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FloatingPreviewWindow.useEffect": ()=>{
            if (!showFloatingPreview || isMinimized) return;
            const canvas = previewCanvasRef.current;
            if (!canvas) return;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compositeFrame"])(frames, activeFrameIndex, canvasWidth, canvasHeight, {}, canvas);
        }
    }["FloatingPreviewWindow.useEffect"], [
        activeFrameIndex,
        bufferVersion,
        canvasHeight,
        canvasWidth,
        frames,
        showFloatingPreview,
        isMinimized
    ]);
    // Robust window-level dragging listener (prevents mouse stickiness bug)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FloatingPreviewWindow.useEffect": ()=>{
            if (!isDragging) return;
            const onGlobalPointerMove = {
                "FloatingPreviewWindow.useEffect.onGlobalPointerMove": (e)=>{
                    // Abort immediately if pointer button is no longer held
                    if (e.buttons === 0) {
                        setIsDragging(false);
                        return;
                    }
                    setPosition({
                        x: Math.max(10, Math.min(window.innerWidth - 150, e.clientX - dragOffsetRef.current.x)),
                        y: Math.max(10, Math.min(window.innerHeight - 80, e.clientY - dragOffsetRef.current.y))
                    });
                }
            }["FloatingPreviewWindow.useEffect.onGlobalPointerMove"];
            const onGlobalPointerUp = {
                "FloatingPreviewWindow.useEffect.onGlobalPointerUp": ()=>{
                    setIsDragging(false);
                }
            }["FloatingPreviewWindow.useEffect.onGlobalPointerUp"];
            window.addEventListener('pointermove', onGlobalPointerMove);
            window.addEventListener('pointerup', onGlobalPointerUp);
            window.addEventListener('pointercancel', onGlobalPointerUp);
            return ({
                "FloatingPreviewWindow.useEffect": ()=>{
                    window.removeEventListener('pointermove', onGlobalPointerMove);
                    window.removeEventListener('pointerup', onGlobalPointerUp);
                    window.removeEventListener('pointercancel', onGlobalPointerUp);
                }
            })["FloatingPreviewWindow.useEffect"];
        }
    }["FloatingPreviewWindow.useEffect"], [
        isDragging
    ]);
    // Robust window-level resizing listener
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FloatingPreviewWindow.useEffect": ()=>{
            if (!isResizing) return;
            const onGlobalResizeMove = {
                "FloatingPreviewWindow.useEffect.onGlobalResizeMove": (e)=>{
                    if (e.buttons === 0) {
                        setIsResizing(false);
                        return;
                    }
                    const deltaX = e.clientX - resizeStartRef.current.startX;
                    const deltaY = e.clientY - resizeStartRef.current.startY;
                    setViewportSize({
                        width: Math.max(140, Math.min(640, resizeStartRef.current.startW + deltaX)),
                        height: Math.max(80, Math.min(640, resizeStartRef.current.startH + deltaY))
                    });
                }
            }["FloatingPreviewWindow.useEffect.onGlobalResizeMove"];
            const onGlobalResizeUp = {
                "FloatingPreviewWindow.useEffect.onGlobalResizeUp": ()=>{
                    setIsResizing(false);
                }
            }["FloatingPreviewWindow.useEffect.onGlobalResizeUp"];
            window.addEventListener('pointermove', onGlobalResizeMove);
            window.addEventListener('pointerup', onGlobalResizeUp);
            window.addEventListener('pointercancel', onGlobalResizeUp);
            return ({
                "FloatingPreviewWindow.useEffect": ()=>{
                    window.removeEventListener('pointermove', onGlobalResizeMove);
                    window.removeEventListener('pointerup', onGlobalResizeUp);
                    window.removeEventListener('pointercancel', onGlobalResizeUp);
                }
            })["FloatingPreviewWindow.useEffect"];
        }
    }["FloatingPreviewWindow.useEffect"], [
        isResizing
    ]);
    if (!showFloatingPreview) return null;
    const handleTitlePointerDown = (e)=>{
        if (e.button !== 0) return;
        dragOffsetRef.current = {
            x: e.clientX - position.x,
            y: e.clientY - position.y
        };
        setIsDragging(true);
    };
    const handleResizePointerDown = (e)=>{
        if (e.button !== 0) return;
        e.stopPropagation();
        resizeStartRef.current = {
            startX: e.clientX,
            startY: e.clientY,
            startW: viewportSize.width,
            startH: viewportSize.height
        };
        setIsResizing(true);
    };
    const scaledWidth = canvasWidth * previewScale;
    const scaledHeight = canvasHeight * previewScale;
    const getBackdropClass = ()=>{
        switch(previewBackdrop){
            case 'obsidian':
                return 'bg-[#2A2130]';
            case 'alabaster':
                return 'bg-[#EDE8F4]';
            case 'amber':
                return 'bg-[#F0BE7C]/30';
            case 'checker':
            default:
                return 'bg-[repeating-conic-gradient(#3a2e4c_0%_25%,#261c33_0%_50%)] bg-[length:12px_12px]';
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "dialog",
        "aria-label": "Live Preview Window",
        "data-testid": "floating-preview-window",
        onPointerDown: (event)=>event.stopPropagation(),
        style: {
            position: 'absolute',
            left: `${position.x}px`,
            top: `${position.y}px`
        },
        className: `z-30 ${isMinimized ? 'w-44' : 'min-w-[140px]'} bg-[var(--desk-surface)] border border-[var(--desk-border)] rounded-[3px] shadow-[0_12px_32px_rgba(0,0,0,0.6)] flex flex-col select-none overflow-hidden ${isDragging || isResizing ? '' : 'transition-opacity duration-150'} opacity-95 hover:opacity-100 relative`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                onPointerDown: handleTitlePointerDown,
                className: "h-6 bg-[var(--desk-surface-raised)] border-b border-[var(--desk-border)] px-2 flex items-center justify-between cursor-move text-[11px] font-sans font-medium text-[var(--accent-gold)]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1.5 pointer-events-none",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "preview",
                                size: 12
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                lineNumber: 182,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "Live Preview",
                                    isMinimized ? '' : ` (${previewScale}x)`
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                lineNumber: 183,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                        lineNumber: 181,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onPointerDown: (e)=>e.stopPropagation(),
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    setIsMinimized(!isMinimized);
                                },
                                className: "text-[var(--text-muted)] hover:text-[var(--accent-gold)] font-mono text-xs px-1 cursor-pointer leading-none",
                                title: isMinimized ? 'Expand Preview Window' : 'Minimize Preview Window',
                                "aria-label": isMinimized ? 'Expand Preview Window' : 'Minimize Preview Window',
                                children: isMinimized ? '+' : '–'
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                lineNumber: 187,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onPointerDown: (e)=>{
                                    e.stopPropagation();
                                },
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    toggleFloatingPreview();
                                },
                                className: "text-[var(--text-body)] hover:text-[#ff99aa] font-bold text-xs p-0.5 cursor-pointer leading-none",
                                title: "Close Preview Window",
                                "aria-label": "Close Preview Window",
                                children: "×"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                lineNumber: 199,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                        lineNumber: 186,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                lineNumber: 177,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            !isMinimized && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-2.5 flex items-center justify-center bg-[var(--desk-bg)]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `relative border border-[var(--desk-border)] rounded-[2px] overflow-hidden flex items-center justify-center ${getBackdropClass()}`,
                            style: {
                                width: `${viewportSize.width}px`,
                                height: `${viewportSize.height}px`
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                                ref: previewCanvasRef,
                                width: canvasWidth,
                                height: canvasHeight,
                                style: {
                                    width: `${scaledWidth}px`,
                                    height: `${scaledHeight}px`,
                                    maxWidth: `${viewportSize.width}px`,
                                    maxHeight: `${viewportSize.height}px`
                                },
                                className: "pixelated pointer-events-none object-contain"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                lineNumber: 227,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                            lineNumber: 220,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                        lineNumber: 219,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-2 py-1 bg-[var(--desk-surface-raised)] border-t border-[var(--desk-border)] flex flex-wrap items-center justify-between gap-1 text-[10px] font-mono pr-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setIsPlaying(!isPlaying),
                                        className: `p-1 rounded-[2px] border transition-colors cursor-pointer ${isPlaying ? 'bg-[var(--accent-gold)] text-[#16141a] border-[#995e1e]' : 'bg-[var(--desk-surface)] text-[var(--text-heading)] border-[var(--desk-border)] hover:text-[var(--accent-gold)]'}`,
                                        title: isPlaying ? 'Pause Animation' : 'Play Animation',
                                        "aria-label": isPlaying ? 'Pause Animation' : 'Play Animation',
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                            name: isPlaying ? 'pause' : 'play',
                                            size: 12
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                            lineNumber: 256,
                                            columnNumber: 13
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                        lineNumber: 246,
                                        columnNumber: 11
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px] text-[var(--accent-gold)] font-bold font-mono",
                                        children: [
                                            "#",
                                            activeFrameIndex + 1,
                                            "/",
                                            frames.length
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                        lineNumber: 258,
                                        columnNumber: 11
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[9px] text-[var(--text-body)] font-mono",
                                        children: [
                                            "(",
                                            fps,
                                            " FPS)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                        lineNumber: 261,
                                        columnNumber: 11
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                lineNumber: 245,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-0.5 bg-[var(--desk-surface)] p-0.5 rounded-[2px] border border-[var(--desk-border)]",
                                children: [
                                    1,
                                    2,
                                    4
                                ].map((sc)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setPreviewScale(sc),
                                        className: `px-1 py-0.5 text-[9px] font-bold rounded-[1px] cursor-pointer transition-colors font-mono ${previewScale === sc ? 'bg-[var(--accent-gold)] text-[#16141a]' : 'text-[var(--text-body)] hover:text-[var(--accent-gold)]'}`,
                                        children: [
                                            sc,
                                            "x"
                                        ]
                                    }, sc, true, {
                                        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                        lineNumber: 267,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                lineNumber: 265,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-0.5",
                                children: [
                                    'checker',
                                    'obsidian',
                                    'alabaster',
                                    'amber'
                                ].map((bg)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setPreviewBackdrop(bg),
                                        className: "w-5 h-5 flex items-center justify-center cursor-pointer bg-transparent border-0 p-0",
                                        title: `Backdrop: ${bg}`,
                                        "aria-label": `Backdrop: ${bg}`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: `w-3 h-3 rounded-[1px] border block ${previewBackdrop === bg ? 'border-[#f0be7c] scale-110' : 'border-[#140d1f]'} ${bg === 'obsidian' ? 'bg-[#2A2130]' : bg === 'alabaster' ? 'bg-[#EDE8F4]' : bg === 'amber' ? 'bg-[#F0BE7C]' : 'bg-[repeating-conic-gradient(#888_0%_25%,#444_0%_50%)] bg-[length:6px_6px]'}`
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                            lineNumber: 292,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, bg, false, {
                                        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                        lineNumber: 284,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                lineNumber: 282,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                        lineNumber: 243,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        onPointerDown: handleResizePointerDown,
                        className: "absolute bottom-0 right-0 w-4 h-4 cursor-se-resize flex items-end justify-end p-0.5 select-none text-[var(--text-body)] hover:text-[#f0be7c]",
                        title: "Drag to resize Live Preview window",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "6",
                            height: "6",
                            viewBox: "0 0 6 6",
                            fill: "currentColor",
                            className: "pointer-events-none",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                    x: "4",
                                    y: "0",
                                    width: "2",
                                    height: "2"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                    lineNumber: 317,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                    x: "2",
                                    y: "2",
                                    width: "2",
                                    height: "2"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                    lineNumber: 318,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                    x: "4",
                                    y: "2",
                                    width: "2",
                                    height: "2"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                    lineNumber: 319,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                    x: "0",
                                    y: "4",
                                    width: "2",
                                    height: "2"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                    lineNumber: 320,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                    x: "2",
                                    y: "4",
                                    width: "2",
                                    height: "2"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                    lineNumber: 321,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                    x: "4",
                                    y: "4",
                                    width: "2",
                                    height: "2"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                                    lineNumber: 322,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                            lineNumber: 316,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                        lineNumber: 311,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
                lineNumber: 217,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/studio/FloatingPreviewWindow.tsx",
        lineNumber: 160,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(FloatingPreviewWindow, "vkrx+zA8l537U3BDaZUk3mZ83qQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c = FloatingPreviewWindow;
var _c;
__turbopack_context__.k.register(_c, "FloatingPreviewWindow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/studio/PixelLightBulbGizmo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PixelLightBulbGizmo",
    ()=>PixelLightBulbGizmo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$lightGizmoMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/lightGizmoMath.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const PixelLightBulbGizmo = ({ canvasWidth, canvasHeight, zoom, mainCanvasRef, onCommit, onCancel, onLightChange })=>{
    _s();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const hudRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const panX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PixelLightBulbGizmo.useStudioStore[panX]": (s)=>s.panX
    }["PixelLightBulbGizmo.useStudioStore[panX]"]);
    const panY = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PixelLightBulbGizmo.useStudioStore[panY]": (s)=>s.panY
    }["PixelLightBulbGizmo.useStudioStore[panY]"]);
    const [hudBounds, setHudBounds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PixelLightBulbGizmo.useStudioStore[tools]": (s)=>s.tools
    }["PixelLightBulbGizmo.useStudioStore[tools]"]);
    const setLightAzimuth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PixelLightBulbGizmo.useStudioStore[setLightAzimuth]": (s)=>s.setLightAzimuth
    }["PixelLightBulbGizmo.useStudioStore[setLightAzimuth]"]);
    const setLightElevation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PixelLightBulbGizmo.useStudioStore[setLightElevation]": (s)=>s.setLightElevation
    }["PixelLightBulbGizmo.useStudioStore[setLightElevation]"]);
    const setLightBrightness = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PixelLightBulbGizmo.useStudioStore[setLightBrightness]": (s)=>s.setLightBrightness
    }["PixelLightBulbGizmo.useStudioStore[setLightBrightness]"]);
    const glintOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PixelLightBulbGizmo.useStudioStore[glintOnly]": (s)=>s.photometricGlintOnly
    }["PixelLightBulbGizmo.useStudioStore[glintOnly]"]);
    const setGlintStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PixelLightBulbGizmo.useStudioStore[setGlintStyle]": (s)=>s.setGlintStyle
    }["PixelLightBulbGizmo.useStudioStore[setGlintStyle]"]);
    const setShadingBands = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PixelLightBulbGizmo.useStudioStore[setShadingBands]": (s)=>s.setShadingBands
    }["PixelLightBulbGizmo.useStudioStore[setShadingBands]"]);
    const [dragTarget, setDragTarget] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('none');
    const [brightness, setBrightness] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "PixelLightBulbGizmo.useState": ()=>tools.lightBrightness ?? 1.15
    }["PixelLightBulbGizmo.useState"]);
    const rafIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const pendingChangeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const scale = zoom / 100;
    const stageWidth = canvasWidth * scale;
    const stageHeight = canvasHeight * scale;
    // Keep every HUD action inside the workspace, even when zoomed or panned.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "PixelLightBulbGizmo.useLayoutEffect": ()=>{
            const container = containerRef.current, hud = hudRef.current;
            const workspace = container?.closest('main');
            if (!container || !hud || !workspace) return;
            const place = {
                "PixelLightBulbGizmo.useLayoutEffect.place": ()=>{
                    const stage = container.getBoundingClientRect(), area = workspace.getBoundingClientRect();
                    if (!area.width) return;
                    const maxWidth = Math.max(1, area.width - 16);
                    const size = hud.getBoundingClientRect();
                    const width = Math.min(size.width, maxWidth);
                    const minLeft = area.left - stage.left + 8;
                    const maxLeft = area.right - stage.left - width - 8;
                    const left = Math.max(minLeft, Math.min(maxLeft, stage.width / 2 - width / 2)) + width / 2;
                    const top = Math.max(area.top - stage.top + 8, Math.min(stage.height + 8, area.bottom - stage.top - size.height - 8));
                    setHudBounds({
                        "PixelLightBulbGizmo.useLayoutEffect.place": (previous)=>previous?.left === left && previous.top === top && previous.maxWidth === maxWidth ? previous : {
                                left,
                                top,
                                maxWidth
                            }
                    }["PixelLightBulbGizmo.useLayoutEffect.place"]);
                }
            }["PixelLightBulbGizmo.useLayoutEffect.place"];
            place();
            const observer = new ResizeObserver(place);
            observer.observe(workspace);
            observer.observe(hud);
            observer.observe(container);
            window.addEventListener('resize', place);
            return ({
                "PixelLightBulbGizmo.useLayoutEffect": ()=>{
                    observer.disconnect();
                    window.removeEventListener('resize', place);
                }
            })["PixelLightBulbGizmo.useLayoutEffect"];
        }
    }["PixelLightBulbGizmo.useLayoutEffect"], [
        canvasWidth,
        canvasHeight,
        zoom,
        panX,
        panY,
        glintOnly
    ]);
    // Middle light point in canvas coordinates (freely draggable focus)
    const [canvasCentroid, setCanvasCentroid] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "PixelLightBulbGizmo.useState": ()=>({
                x: Math.round(canvasWidth / 2),
                y: Math.round(canvasHeight / 2)
            })
    }["PixelLightBulbGizmo.useState"]);
    // Initialize from artwork centroid on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PixelLightBulbGizmo.useEffect": ()=>{
            const mainCanvas = mainCanvasRef.current;
            if (!mainCanvas) return;
            const ctx = mainCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (!ctx) return;
            try {
                const imgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
                const centroid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$lightGizmoMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeArtworkCentroid"])(imgData.data, canvasWidth, canvasHeight);
                setCanvasCentroid(centroid);
            } catch  {
                setCanvasCentroid({
                    x: Math.round(canvasWidth / 2),
                    y: Math.round(canvasHeight / 2)
                });
            }
        }
    }["PixelLightBulbGizmo.useEffect"], [
        canvasWidth,
        canvasHeight,
        mainCanvasRef
    ]);
    // Middle light point in stage coordinates
    const stageCentroid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PixelLightBulbGizmo.useMemo[stageCentroid]": ()=>({
                x: canvasCentroid.x * scale,
                y: canvasCentroid.y * scale
            })
    }["PixelLightBulbGizmo.useMemo[stageCentroid]"], [
        canvasCentroid,
        scale
    ]);
    // Radius representing horizon grazing (0° elevation)
    const maxRadius = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PixelLightBulbGizmo.useMemo[maxRadius]": ()=>{
            return Math.max(40, Math.min(stageWidth, stageHeight) * 0.44);
        }
    }["PixelLightBulbGizmo.useMemo[maxRadius]"], [
        stageWidth,
        stageHeight
    ]);
    // Current bulb coordinates on stage (orbits around middle light point)
    const bulbCoords = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PixelLightBulbGizmo.useMemo[bulbCoords]": ()=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$lightGizmoMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lightAnglesToCoords"])(tools.lightAzimuth, tools.lightElevation, stageCentroid.x, stageCentroid.y, maxRadius);
        }
    }["PixelLightBulbGizmo.useMemo[bulbCoords]"], [
        tools.lightAzimuth,
        tools.lightElevation,
        stageCentroid,
        maxRadius
    ]);
    // Throttled 60 FPS update loop during drag
    const flushLightChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PixelLightBulbGizmo.useCallback[flushLightChange]": ()=>{
            if (pendingChangeRef.current) {
                const { azimuth, elevation, centerX, centerY, brightness: b } = pendingChangeRef.current;
                setLightAzimuth(azimuth);
                setLightElevation(elevation);
                setLightBrightness(b);
                onLightChange?.(azimuth, elevation, centerX, centerY, b);
                pendingChangeRef.current = null;
            }
            rafIdRef.current = null;
        }
    }["PixelLightBulbGizmo.useCallback[flushLightChange]"], [
        setLightAzimuth,
        setLightElevation,
        setLightBrightness,
        onLightChange
    ]);
    const scheduleLightChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PixelLightBulbGizmo.useCallback[scheduleLightChange]": (azimuth, elevation, centerX, centerY, newBrightness)=>{
            pendingChangeRef.current = {
                azimuth,
                elevation,
                centerX,
                centerY,
                brightness: newBrightness
            };
            if (rafIdRef.current === null) {
                rafIdRef.current = requestAnimationFrame(flushLightChange);
            }
        }
    }["PixelLightBulbGizmo.useCallback[scheduleLightChange]"], [
        flushLightChange
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PixelLightBulbGizmo.useEffect": ()=>{
            return ({
                "PixelLightBulbGizmo.useEffect": ()=>{
                    if (rafIdRef.current !== null) {
                        cancelAnimationFrame(rafIdRef.current);
                    }
                }
            })["PixelLightBulbGizmo.useEffect"];
        }
    }["PixelLightBulbGizmo.useEffect"], []);
    const updateStrength = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PixelLightBulbGizmo.useCallback[updateStrength]": (val)=>{
            const clamped = Math.max(0.3, Math.min(2.5, Math.round(val * 100) / 100));
            setBrightness(clamped);
            scheduleLightChange(tools.lightAzimuth, tools.lightElevation, canvasCentroid.x, canvasCentroid.y, clamped);
        }
    }["PixelLightBulbGizmo.useCallback[updateStrength]"], [
        tools.lightAzimuth,
        tools.lightElevation,
        canvasCentroid,
        scheduleLightChange
    ]);
    const adjustStrength = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PixelLightBulbGizmo.useCallback[adjustStrength]": (delta)=>{
            setBrightness({
                "PixelLightBulbGizmo.useCallback[adjustStrength]": (prev)=>{
                    const next = Math.max(0.3, Math.min(2.5, Math.round((prev + delta) * 100) / 100));
                    scheduleLightChange(tools.lightAzimuth, tools.lightElevation, canvasCentroid.x, canvasCentroid.y, next);
                    return next;
                }
            }["PixelLightBulbGizmo.useCallback[adjustStrength]"]);
        }
    }["PixelLightBulbGizmo.useCallback[adjustStrength]"], [
        tools.lightAzimuth,
        tools.lightElevation,
        canvasCentroid,
        scheduleLightChange
    ]);
    const resetFocus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PixelLightBulbGizmo.useCallback[resetFocus]": ()=>{
            const cx = Math.round(canvasWidth / 2);
            const cy = Math.round(canvasHeight / 2);
            setCanvasCentroid({
                x: cx,
                y: cy
            });
            scheduleLightChange(tools.lightAzimuth, tools.lightElevation, cx, cy, brightness);
        }
    }["PixelLightBulbGizmo.useCallback[resetFocus]"], [
        canvasWidth,
        canvasHeight,
        tools.lightAzimuth,
        tools.lightElevation,
        brightness,
        scheduleLightChange
    ]);
    const handleApply = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PixelLightBulbGizmo.useCallback[handleApply]": ()=>{
            if (rafIdRef.current !== null) {
                cancelAnimationFrame(rafIdRef.current);
                rafIdRef.current = null;
            }
            flushLightChange();
            onCommit();
        }
    }["PixelLightBulbGizmo.useCallback[handleApply]"], [
        flushLightChange,
        onCommit
    ]);
    const handleCancel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PixelLightBulbGizmo.useCallback[handleCancel]": ()=>{
            if (rafIdRef.current !== null) {
                cancelAnimationFrame(rafIdRef.current);
                rafIdRef.current = null;
            }
            pendingChangeRef.current = null;
            onCancel();
        }
    }["PixelLightBulbGizmo.useCallback[handleCancel]"], [
        onCancel
    ]);
    // Global keyboard shortcuts: Enter to apply, Escape to cancel, [-]/[+] to adjust strength, Alt+R to reset focus
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PixelLightBulbGizmo.useEffect": ()=>{
            const handleKeyDown = {
                "PixelLightBulbGizmo.useEffect.handleKeyDown": (e)=>{
                    if (e.key === 'Enter' && e.target?.closest?.('button, input, select')) return;
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        e.stopPropagation();
                        handleApply();
                    } else if (e.key === 'Escape') {
                        e.preventDefault();
                        e.stopPropagation();
                        handleCancel();
                    } else if (e.key === '[' || e.key === '-') {
                        e.preventDefault();
                        e.stopPropagation();
                        adjustStrength(-0.15);
                    } else if (e.key === ']' || e.key === '+' || e.key === '=') {
                        e.preventDefault();
                        e.stopPropagation();
                        adjustStrength(+0.15);
                    } else if ((e.key === 'r' || e.key === 'R') && e.altKey) {
                        e.preventDefault();
                        e.stopPropagation();
                        resetFocus();
                    }
                }
            }["PixelLightBulbGizmo.useEffect.handleKeyDown"];
            window.addEventListener('keydown', handleKeyDown, {
                capture: true
            });
            return ({
                "PixelLightBulbGizmo.useEffect": ()=>{
                    window.removeEventListener('keydown', handleKeyDown, {
                        capture: true
                    });
                }
            })["PixelLightBulbGizmo.useEffect"];
        }
    }["PixelLightBulbGizmo.useEffect"], [
        handleApply,
        handleCancel,
        adjustStrength,
        resetFocus
    ]);
    // Listen for wheel events dispatched from viewport background
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PixelLightBulbGizmo.useEffect": ()=>{
            const unsub = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:photometric-strength-delta', {
                "PixelLightBulbGizmo.useEffect.unsub": (delta)=>{
                    adjustStrength(delta);
                }
            }["PixelLightBulbGizmo.useEffect.unsub"]);
            return ({
                "PixelLightBulbGizmo.useEffect": ()=>{
                    unsub();
                }
            })["PixelLightBulbGizmo.useEffect"];
        }
    }["PixelLightBulbGizmo.useEffect"], [
        adjustStrength
    ]);
    // Update angles from client pointer event (drags bulb around center point)
    const updateAnglesFromPointer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PixelLightBulbGizmo.useCallback[updateAnglesFromPointer]": (clientX, clientY)=>{
            const container = containerRef.current;
            if (!container) return;
            const rect = container.getBoundingClientRect();
            const px = Math.max(0, Math.min(stageWidth, clientX - rect.left));
            const py = Math.max(0, Math.min(stageHeight, clientY - rect.top));
            const angles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$lightGizmoMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coordsToLightAngles"])(px, py, stageCentroid.x, stageCentroid.y, maxRadius);
            scheduleLightChange(angles.azimuth, angles.elevation, canvasCentroid.x, canvasCentroid.y, brightness);
        }
    }["PixelLightBulbGizmo.useCallback[updateAnglesFromPointer]"], [
        stageWidth,
        stageHeight,
        stageCentroid,
        maxRadius,
        canvasCentroid,
        brightness,
        scheduleLightChange
    ]);
    // Update center position from client pointer event (drags center point)
    const updateCenterFromPointer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PixelLightBulbGizmo.useCallback[updateCenterFromPointer]": (clientX, clientY)=>{
            const container = containerRef.current;
            if (!container) return;
            const rect = container.getBoundingClientRect();
            const px = clientX - rect.left;
            const py = clientY - rect.top;
            const clampedPx = Math.max(0, Math.min(stageWidth, px));
            const clampedPy = Math.max(0, Math.min(stageHeight, py));
            const newCanvasX = Math.round(clampedPx / scale);
            const newCanvasY = Math.round(clampedPy / scale);
            setCanvasCentroid({
                x: newCanvasX,
                y: newCanvasY
            });
            scheduleLightChange(tools.lightAzimuth, tools.lightElevation, newCanvasX, newCanvasY, brightness);
        }
    }["PixelLightBulbGizmo.useCallback[updateCenterFromPointer]"], [
        stageWidth,
        stageHeight,
        scale,
        tools.lightAzimuth,
        tools.lightElevation,
        brightness,
        scheduleLightChange
    ]);
    const handleBulbPointerDown = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        setDragTarget('bulb');
        updateAnglesFromPointer(e.clientX, e.clientY);
    };
    const handleCenterPointerDown = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        setDragTarget('center');
        updateCenterFromPointer(e.clientX, e.clientY);
    };
    const handleContainerPointerDown = (e)=>{
        // Ignore clicks on HUD buttons or inputs and stop propagation to viewport
        if (e.target.closest('button, input, [role="toolbar"]')) {
            e.stopPropagation();
            return;
        }
        const container = containerRef.current;
        if (!container) return;
        const rect = container.getBoundingClientRect();
        const px = e.clientX - rect.left;
        const py = e.clientY - rect.top;
        // If pointer is near center reticle (< 24px), drag center
        const distCenter = Math.hypot(px - stageCentroid.x, py - stageCentroid.y);
        if (distCenter <= 24) {
            e.preventDefault();
            e.stopPropagation();
            e.currentTarget.setPointerCapture(e.pointerId);
            setDragTarget('center');
            updateCenterFromPointer(e.clientX, e.clientY);
            return;
        }
        // Otherwise, drag/aim light bulb towards pointer position
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        setDragTarget('bulb');
        updateAnglesFromPointer(e.clientX, e.clientY);
    };
    const handlePointerMove = (e)=>{
        if (dragTarget === 'bulb') {
            e.preventDefault();
            e.stopPropagation();
            updateAnglesFromPointer(e.clientX, e.clientY);
        } else if (dragTarget === 'center') {
            e.preventDefault();
            e.stopPropagation();
            updateCenterFromPointer(e.clientX, e.clientY);
        }
    };
    const handlePointerUp = (e)=>{
        if (dragTarget !== 'none') {
            e.preventDefault();
            e.stopPropagation();
            setDragTarget('none');
            try {
                e.currentTarget.releasePointerCapture(e.pointerId);
            } catch  {
            // Pointer capture may already have been released by browser
            }
            if (pendingChangeRef.current) {
                flushLightChange();
            }
        }
    };
    const handleResetCenter = ()=>{
        const mainCanvas = mainCanvasRef.current;
        if (!mainCanvas) return;
        const ctx = mainCanvas.getContext('2d', {
            willReadFrequently: true
        });
        if (!ctx) return;
        try {
            const imgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
            const centroid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$lightGizmoMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeArtworkCentroid"])(imgData.data, canvasWidth, canvasHeight);
            setCanvasCentroid(centroid);
            scheduleLightChange(tools.lightAzimuth, tools.lightElevation, centroid.x, centroid.y, brightness);
        } catch  {
            const def = {
                x: Math.round(canvasWidth / 2),
                y: Math.round(canvasHeight / 2)
            };
            setCanvasCentroid(def);
            scheduleLightChange(tools.lightAzimuth, tools.lightElevation, def.x, def.y, brightness);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PixelLightBulbGizmo.useEffect": ()=>{
            const el = containerRef.current;
            if (!el) return;
            const onNativeWheel = {
                "PixelLightBulbGizmo.useEffect.onNativeWheel": (e)=>{
                    e.preventDefault();
                    e.stopPropagation();
                    const delta = e.deltaY < 0 ? 0.10 : -0.10;
                    adjustStrength(delta);
                }
            }["PixelLightBulbGizmo.useEffect.onNativeWheel"];
            el.addEventListener('wheel', onNativeWheel, {
                passive: false
            });
            return ({
                "PixelLightBulbGizmo.useEffect": ()=>{
                    el.removeEventListener('wheel', onNativeWheel);
                }
            })["PixelLightBulbGizmo.useEffect"];
        }
    }["PixelLightBulbGizmo.useEffect"], [
        adjustStrength
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        "data-testid": "pixel-light-bulb-gizmo",
        className: "absolute inset-0 z-30 pointer-events-auto select-none",
        style: {
            width: `${stageWidth}px`,
            height: `${stageHeight}px`
        },
        onPointerDown: handleContainerPointerDown,
        onPointerMove: handlePointerMove,
        onPointerUp: handlePointerUp,
        onPointerCancel: handlePointerUp,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-full mt-2 left-1/2 -translate-x-1/2 z-50 flex items-center gap-1 xl:gap-1.5 max-w-[calc(100vw-2rem)] overflow-x-auto bg-[#181124]/95 border-2 border-[#f0be7c] px-2 xl:px-3 py-1.5 rounded-[3px] shadow-[0_8px_24px_rgba(0,0,0,0.85)] font-mono text-xs pointer-events-auto whitespace-nowrap",
                ref: hudRef,
                style: hudBounds ? {
                    left: hudBounds.left,
                    top: hudBounds.top,
                    maxWidth: hudBounds.maxWidth,
                    marginTop: 0
                } : undefined,
                role: "toolbar",
                "aria-label": "Live Light Bulb Controls",
                onPointerDown: (e)=>e.stopPropagation(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1.5 text-[#f0be7c] font-bold",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "lamp",
                                size: 14,
                                className: "drop-shadow-[0_0_8px_#f0be7c]"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 427,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "tracking-wide uppercase text-[10px] hidden 2xl:inline",
                                children: glintOnly ? 'Live Glint' : 'Live Light Bulb'
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 428,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 426,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        title: "Light Azimuth & Elevation",
                        className: "hidden xl:flex items-center gap-1 px-1.5 py-0.5 bg-[#261838] rounded-[2px] border border-[#f0be7c]/40 text-[#dcabdf] font-bold text-[11px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    tools.lightAzimuth,
                                    "°"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 436,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "opacity-50",
                                children: "/"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 437,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    tools.lightElevation,
                                    "°"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 438,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 432,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        title: "Current Middle Light Point (Drag center reticle to move focus)",
                        className: "hidden 2xl:flex items-center gap-1.5 px-1.5 py-0.5 bg-[#261838] rounded-[2px] border border-[#f0be7c]/40 text-[#f0be7c] font-bold text-[10px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                viewBox: "0 0 12 12",
                                width: 12,
                                height: 12,
                                fill: "none",
                                shapeRendering: "crispEdges",
                                className: "inline-block shrink-0 opacity-80",
                                "aria-hidden": "true",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                        cx: "6",
                                        cy: "6",
                                        r: "4",
                                        stroke: "currentColor",
                                        strokeWidth: "1.2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 455,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                        cx: "6",
                                        cy: "6",
                                        r: "1.5",
                                        fill: "currentColor"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 456,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                        x1: "6",
                                        y1: "0.5",
                                        x2: "6",
                                        y2: "2",
                                        stroke: "currentColor",
                                        strokeWidth: "1.2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 457,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                        x1: "6",
                                        y1: "10",
                                        x2: "6",
                                        y2: "11.5",
                                        stroke: "currentColor",
                                        strokeWidth: "1.2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 458,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                        x1: "0.5",
                                        y1: "6",
                                        x2: "2",
                                        y2: "6",
                                        stroke: "currentColor",
                                        strokeWidth: "1.2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 459,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                        x1: "10",
                                        y1: "6",
                                        x2: "11.5",
                                        y2: "6",
                                        stroke: "currentColor",
                                        strokeWidth: "1.2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 460,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 446,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "(",
                                    Math.round(canvasCentroid.x),
                                    ", ",
                                    Math.round(canvasCentroid.y),
                                    ")"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 462,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 442,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleResetCenter,
                        "aria-label": "Recenter light",
                        title: "Reset middle light point to artwork centroid",
                        className: "h-6 px-1.5 bg-[#261838] text-[#dcabdf] border border-[#f0be7c]/30 rounded-[2px] hover:bg-[#382352] active:scale-95 transition-transform cursor-pointer flex items-center gap-1 text-[10px]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "aria-hidden": "true",
                            children: [
                                "↺",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "hidden xl:inline",
                                    children: " Recenter"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                    lineNumber: 473,
                                    columnNumber: 37
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                            lineNumber: 473,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 466,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-px h-3.5 bg-[#f0be7c]/30 xl:mx-0.5"
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 476,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        title: "Light Strength / Brightness (Click - / + or use mouse wheel)",
                        className: "flex items-center gap-1 xl:gap-1.5 px-1.5 xl:px-2 py-0.5 bg-[#261838] rounded-[2px] border border-[#f0be7c]/40 text-[#f0be7c] font-bold text-[11px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "sun",
                                size: 12,
                                className: "hidden xl:block text-[#f0be7c]"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 483,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] text-[#dcabdf] uppercase",
                                children: "Strength"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 484,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                "data-testid": "pixel-light-strength-dec",
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    adjustStrength(-0.15);
                                },
                                className: "w-6 h-6 flex items-center justify-center bg-[#181124] text-[#f0be7c] rounded-[2px] hover:bg-[#382352] active:scale-95 cursor-pointer font-bold text-xs border border-[#f0be7c]/30",
                                title: "Decrease light strength (- / [)",
                                "aria-label": "Decrease light strength",
                                children: "-"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 485,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                "data-testid": "pixel-light-strength-val",
                                className: "min-w-[34px] text-center font-mono text-[11px] text-[#ffe082]",
                                children: [
                                    Math.round(brightness * 100),
                                    "%"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 498,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                "data-testid": "pixel-light-strength-inc",
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    adjustStrength(+0.15);
                                },
                                className: "w-6 h-6 flex items-center justify-center bg-[#181124] text-[#f0be7c] rounded-[2px] hover:bg-[#382352] active:scale-95 cursor-pointer font-bold text-xs border border-[#f0be7c]/30",
                                title: "Increase light strength (+ / ])",
                                "aria-label": "Increase light strength",
                                children: "+"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 504,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "range",
                                "aria-label": "Light Strength Slider",
                                min: 0.3,
                                max: 2.5,
                                step: 0.05,
                                value: brightness,
                                onChange: (e)=>updateStrength(parseFloat(e.target.value)),
                                title: `Strength: ${Math.round(brightness * 100)}%`,
                                className: "hidden xl:block w-14 h-1.5 accent-[#f0be7c] bg-[#181124] rounded cursor-pointer ml-0.5"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 517,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 479,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    !glintOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-px h-3.5 bg-[#f0be7c]/30 xl:mx-0.5"
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 530,
                        columnNumber: 24
                    }, ("TURBOPACK compile-time value", void 0)),
                    !glintOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        title: "Shading Color Tones: 1 = Single (1 shadow), 2 = Dual (2 shadows), 3 = Trio (3 shadows)",
                        className: "flex items-center gap-1 xl:gap-1.5 px-1.5 xl:px-2 py-0.5 bg-[#261838] rounded-[2px] border border-[#f0be7c]/40 text-[#f0be7c] font-bold text-[11px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] text-[#dcabdf] uppercase",
                                children: "Shade"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 538,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-0.5",
                                role: "group",
                                "aria-label": "Shading tones",
                                children: [
                                    1,
                                    2,
                                    3
                                ].map((count)=>{
                                    const active = tools.shadingBands === count;
                                    const label = count === 1 ? '1' : count === 2 ? '2' : '3';
                                    const title = count === 1 ? 'Single: 1 shadow tone (classic 2-tone cel-shading)' : count === 2 ? 'Dual: 2 shadow tones (mid + core shadow)' : 'Trio: 3 shadow tones (soft penumbra + mid + deep core)';
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        "data-testid": `pixel-light-shade-${count}`,
                                        "aria-pressed": active,
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            setShadingBands(count);
                                            scheduleLightChange(tools.lightAzimuth, tools.lightElevation, canvasCentroid.x, canvasCentroid.y, brightness);
                                        },
                                        title: title,
                                        className: `min-w-6 h-6 px-1.5 rounded-[1px] text-[10px] font-mono font-bold cursor-pointer transition-colors ${active ? 'bg-[#f0be7c] text-[#181124] shadow-xs' : 'text-[#dcabdf] hover:text-[#ffe082] hover:bg-[#382352]'}`,
                                        children: label
                                    }, count, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 549,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0));
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 539,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 534,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-px h-3.5 bg-[#f0be7c]/30 xl:mx-0.5"
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 575,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1 xl:gap-1.5 px-1.5 xl:px-2 py-0.5 bg-[#261838] rounded-[2px] border border-[#f0be7c]/40",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] text-[#dcabdf] uppercase font-bold",
                                children: "Glint"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 578,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                role: "group",
                                "aria-label": "Glint style",
                                className: "flex items-center gap-0.5",
                                children: [
                                    'off',
                                    'soft',
                                    'crisp'
                                ].map((style)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        "aria-pressed": (tools.glintStyle ?? 'soft') === style,
                                        "data-testid": `pixel-light-glint-${style}`,
                                        title: style === 'off' ? 'No reflected highlight' : style === 'soft' ? 'Gentle, wider highlight' : 'Small, defined highlight',
                                        onClick: ()=>{
                                            setGlintStyle(style);
                                            scheduleLightChange(tools.lightAzimuth, tools.lightElevation, canvasCentroid.x, canvasCentroid.y, brightness);
                                        },
                                        className: `min-w-8 h-6 px-1.5 rounded-[1px] text-[10px] font-mono font-bold cursor-pointer transition-colors ${(tools.glintStyle ?? 'soft') === style ? 'bg-[#f0be7c] text-[#181124]' : 'text-[#dcabdf] hover:text-[#ffe082] hover:bg-[#382352]'}`,
                                        children: style === 'off' ? 'Off' : style === 'soft' ? 'Soft' : 'Crisp'
                                    }, style, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 581,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 579,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 577,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-px h-3.5 bg-[#f0be7c]/30 xl:mx-0.5"
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 598,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleApply,
                        title: "Apply preview to an editable layer (Enter)",
                        "aria-label": "Apply",
                        "data-testid": "pixel-light-apply",
                        className: "h-7 px-2.5 bg-[#f0be7c] text-[#140d1f] font-bold rounded-[2px] hover:bg-[#ffe082] active:scale-95 transition-transform cursor-pointer flex items-center gap-1 text-[11px] shadow-xs",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Apply"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 608,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "hidden xl:inline text-[9px] opacity-75 font-normal",
                                children: "(Enter)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 609,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 600,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleCancel,
                        title: "Discard preview and restore layer (Esc)",
                        "aria-label": "Cancel",
                        "data-testid": "pixel-light-cancel",
                        className: "h-7 px-2 bg-[#261838] text-[#dcabdf] border border-[#f0be7c]/40 font-bold rounded-[2px] hover:bg-[#382352] active:scale-95 transition-transform cursor-pointer flex items-center gap-1 text-[11px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 620,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "hidden xl:inline text-[9px] opacity-75 font-normal",
                                children: "(Esc)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 621,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 612,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                lineNumber: 418,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: "absolute inset-0 w-full h-full pointer-events-none",
                width: stageWidth,
                height: stageHeight,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: stageCentroid.x,
                        cy: stageCentroid.y,
                        r: maxRadius,
                        fill: "none",
                        stroke: "#f0be7c",
                        strokeWidth: "1.5",
                        strokeDasharray: "4 4",
                        opacity: dragTarget ? 0.35 : 0.12
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 632,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: stageCentroid.x,
                        cy: stageCentroid.y,
                        r: maxRadius * 0.33,
                        fill: "none",
                        stroke: "#f0be7c",
                        strokeWidth: "1",
                        strokeDasharray: "2 3",
                        opacity: dragTarget ? 0.2 : 0.08
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 644,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                        x1: stageCentroid.x,
                        y1: stageCentroid.y,
                        x2: bulbCoords.x,
                        y2: bulbCoords.y,
                        stroke: "#f0be7c",
                        strokeWidth: "2",
                        strokeDasharray: "5 3",
                        opacity: dragTarget ? 0.75 : 0.2
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 656,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                lineNumber: 626,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: "slider",
                tabIndex: 0,
                "data-testid": "pixel-light-center-handle",
                "aria-label": "Middle Light Point. Drag to reposition light focus on canvas.",
                "aria-valuenow": Math.round(canvasCentroid.x),
                onPointerDown: handleCenterPointerDown,
                className: `absolute -translate-x-1/2 -translate-y-1/2 cursor-grab active:cursor-grabbing pointer-events-auto touch-none group ${dragTarget === 'center' ? 'scale-125' : 'hover:scale-115'} transition-transform z-35`,
                style: {
                    left: `${stageCentroid.x}px`,
                    top: `${stageCentroid.y}px`
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative flex items-center justify-center w-7 h-7",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `absolute inset-0 rounded-full border-2 border-[#f0be7c] ${dragTarget === 'center' ? 'opacity-90 scale-110 shadow-[0_0_12px_#f0be7c]' : 'opacity-40 animate-pulse'} pointer-events-none transition-all`,
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 687,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-5 h-5 rounded-full bg-[#181124]/90 border-2 border-[#f0be7c] shadow-[0_0_8px_rgba(240,190,124,0.7)] flex items-center justify-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute -top-1 w-0.5 h-1.5 bg-[#f0be7c]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 696,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute -bottom-1 w-0.5 h-1.5 bg-[#f0be7c]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 697,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute -left-1 h-0.5 w-1.5 bg-[#f0be7c]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 698,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute -right-1 h-0.5 w-1.5 bg-[#f0be7c]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 699,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-2 h-2 rounded-full bg-[#f0be7c] flex items-center justify-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-0.5 h-0.5 rounded-full bg-white"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                            lineNumber: 702,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                        lineNumber: 701,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 694,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 685,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-1/2 -top-5 -translate-x-1/2 px-1.5 py-0.5 bg-[#181124] text-[#f0be7c] text-[9px] font-mono font-bold rounded-[2px] border border-[#f0be7c]/60 shadow-xs whitespace-nowrap pointer-events-none opacity-0 group-hover:opacity-100 group-active:opacity-100 transition-opacity",
                        children: [
                            "Light Center (",
                            Math.round(canvasCentroid.x),
                            ", ",
                            Math.round(canvasCentroid.y),
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 708,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                lineNumber: 669,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: "slider",
                tabIndex: 0,
                "data-testid": "pixel-light-bulb-handle",
                "aria-label": "Directional Light Bulb. Drag to rotate light around sprite.",
                "aria-valuenow": tools.lightAzimuth,
                "aria-valuemin": 0,
                "aria-valuemax": 360,
                onPointerDown: handleBulbPointerDown,
                className: `absolute -translate-x-1/2 -translate-y-1/2 cursor-grab active:cursor-grabbing pointer-events-auto touch-none group ${dragTarget === 'bulb' ? 'scale-110' : 'hover:scale-105'} transition-transform z-40`,
                style: {
                    left: `${bulbCoords.x}px`,
                    top: `${bulbCoords.y}px`
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        width: "24",
                        height: "27",
                        viewBox: "0 0 16 18",
                        fill: "none",
                        className: "relative",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "5",
                                y: "1",
                                width: "6",
                                height: "1",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 740,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "3",
                                y: "2",
                                width: "2",
                                height: "1",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 741,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "11",
                                y: "2",
                                width: "2",
                                height: "1",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 742,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "2",
                                y: "3",
                                width: "1",
                                height: "5",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 743,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "13",
                                y: "3",
                                width: "1",
                                height: "5",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 744,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "3",
                                y: "8",
                                width: "1",
                                height: "2",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 745,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "12",
                                y: "8",
                                width: "1",
                                height: "2",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 746,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "4",
                                y: "10",
                                width: "1",
                                height: "2",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 747,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "11",
                                y: "10",
                                width: "1",
                                height: "2",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 748,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "5",
                                y: "2",
                                width: "6",
                                height: "1",
                                fill: "#fff9db"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 751,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "3",
                                y: "3",
                                width: "10",
                                height: "5",
                                fill: "#fef08a"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 752,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "4",
                                y: "8",
                                width: "8",
                                height: "2",
                                fill: "#fde047"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 753,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "5",
                                y: "10",
                                width: "6",
                                height: "2",
                                fill: "#facc15"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 754,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "4",
                                y: "3",
                                width: "2",
                                height: "3",
                                fill: "#ffffff"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 757,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "6",
                                y: "3",
                                width: "2",
                                height: "1",
                                fill: "#ffffff"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 758,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "7",
                                y: "6",
                                width: "2",
                                height: "2",
                                fill: "#f97316"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 761,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "6",
                                y: "8",
                                width: "1",
                                height: "1",
                                fill: "#ea580c"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 762,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "9",
                                y: "8",
                                width: "1",
                                height: "1",
                                fill: "#ea580c"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 763,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "5",
                                y: "12",
                                width: "6",
                                height: "1",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 766,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "5",
                                y: "13",
                                width: "6",
                                height: "1",
                                fill: "#94a3b8"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 767,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "5",
                                y: "14",
                                width: "6",
                                height: "1",
                                fill: "#475569"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 768,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "6",
                                y: "15",
                                width: "4",
                                height: "1",
                                fill: "#94a3b8"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 769,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "6",
                                y: "16",
                                width: "4",
                                height: "1",
                                fill: "#181124"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 770,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "7",
                                y: "16",
                                width: "2",
                                height: "1",
                                fill: "#eab308"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                                lineNumber: 771,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 732,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-1/2 -bottom-5 -translate-x-1/2 px-1.5 py-0.5 bg-[#181124] text-[#f0be7c] text-[9px] font-mono font-bold rounded-[2px] border border-[#f0be7c]/60 shadow-xs whitespace-nowrap pointer-events-none opacity-0 group-hover:opacity-100 group-focus-visible:opacity-100 group-active:opacity-100",
                        children: [
                            tools.lightAzimuth,
                            "°"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                        lineNumber: 775,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
                lineNumber: 714,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/studio/PixelLightBulbGizmo.tsx",
        lineNumber: 407,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(PixelLightBulbGizmo, "gscwj8a5CtrAaYhVbNjPIGVGuhQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c = PixelLightBulbGizmo;
var _c;
__turbopack_context__.k.register(_c, "PixelLightBulbGizmo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/studio/RadialContextMenu.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RadialContextMenu",
    ()=>RadialContextMenu
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const RadialContextMenu = ({ isOpen, position, onClose })=>{
    _s();
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "RadialContextMenu.useStudioStore[tools]": (s)=>s.tools
    }["RadialContextMenu.useStudioStore[tools]"]);
    const setActiveTool = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "RadialContextMenu.useStudioStore[setActiveTool]": (s)=>s.setActiveTool
    }["RadialContextMenu.useStudioStore[setActiveTool]"]);
    const primaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "RadialContextMenu.useStudioStore[primaryColor]": (s)=>s.primaryColor
    }["RadialContextMenu.useStudioStore[primaryColor]"]);
    const secondaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "RadialContextMenu.useStudioStore[secondaryColor]": (s)=>s.secondaryColor
    }["RadialContextMenu.useStudioStore[secondaryColor]"]);
    const swapColors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "RadialContextMenu.useStudioStore[swapColors]": (s)=>s.swapColors
    }["RadialContextMenu.useStudioStore[swapColors]"]);
    const menuRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const openerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "RadialContextMenu.useEffect": ()=>{
            if (isOpen) {
                if (typeof document !== 'undefined' && document.activeElement instanceof HTMLElement) {
                    openerRef.current = document.activeElement;
                }
                const explicitFocus = menuRef.current?.querySelector('[data-autofocus="true"]');
                if (explicitFocus) {
                    explicitFocus.focus();
                } else {
                    menuRef.current?.focus();
                }
            } else {
                if (openerRef.current && typeof openerRef.current.focus === 'function') {
                    openerRef.current.focus();
                }
            }
        }
    }["RadialContextMenu.useEffect"], [
        isOpen
    ]);
    const handleTool = (tool)=>{
        setActiveTool(tool);
        onClose();
    };
    const handleKeyDown = (e)=>{
        if (e.key === 'Escape') {
            onClose();
            return;
        }
        if (e.key === 'Tab' && menuRef.current) {
            const focusable = menuRef.current.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])');
            if (focusable.length === 0) return;
            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (e.shiftKey && document.activeElement === first) {
                e.preventDefault();
                last.focus();
            } else if (!e.shiftKey && document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        }
    };
    const primaryTools = [
        {
            id: 'pen',
            label: 'Pen',
            icon: 'pen'
        },
        {
            id: 'eraser',
            label: 'Eraser',
            icon: 'eraser'
        },
        {
            id: 'bucket',
            label: 'Fill',
            icon: 'bucket'
        },
        {
            id: 'eyedropper',
            label: 'Eyedropper',
            icon: 'eyedropper'
        }
    ];
    if (!isOpen) return null;
    const menuWidth = 240;
    const menuHeight = 56;
    const clampedX = ("TURBOPACK compile-time truthy", 1) ? Math.max(12, Math.min(window.innerWidth - menuWidth - 12, position.x - 48)) : "TURBOPACK unreachable";
    const clampedY = ("TURBOPACK compile-time truthy", 1) ? Math.max(12, Math.min(window.innerHeight - menuHeight - 12, position.y - 48)) : "TURBOPACK unreachable";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: "fixed inset-0 z-40 w-full h-full bg-transparent border-none cursor-default",
                onClick: onClose,
                onContextMenu: (e)=>{
                    e.preventDefault();
                    onClose();
                },
                "aria-label": "Close radial menu",
                tabIndex: -1
            }, void 0, false, {
                fileName: "[project]/src/components/studio/RadialContextMenu.tsx",
                lineNumber: 92,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: menuRef,
                className: "fixed z-50 flex flex-col items-center gap-2 outline-none",
                style: {
                    left: clampedX,
                    top: clampedY
                },
                onKeyDown: handleKeyDown,
                role: "dialog",
                "aria-modal": "true",
                "aria-label": "Radial tools menu",
                tabIndex: 0,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[var(--desk-surface-raised)] border-2 border-[var(--desk-border)] rounded-[4px] p-2 shadow-xl flex gap-2",
                    onContextMenu: (e)=>{
                        e.preventDefault();
                        e.stopPropagation();
                    },
                    children: [
                        primaryTools.map((tool)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleTool(tool.id),
                                onContextMenu: (e)=>{
                                    e.preventDefault();
                                    e.stopPropagation();
                                    handleTool(tool.id);
                                },
                                onPointerUp: (e)=>{
                                    if (e.button === 0 || e.button === 2) {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        handleTool(tool.id);
                                    }
                                },
                                className: `w-9 h-9 flex items-center justify-center rounded-[2px] border-2 cursor-pointer transition-transform ${tools.activeTool === tool.id ? 'bg-[#f0be7c] text-[#140d1f] border-[#8c5120] scale-110' : 'bg-[var(--desk-surface)] border-[var(--desk-border)] text-[var(--text-body)] hover:text-[#f0be7c] hover:bg-[#2e2040] focus:ring-2 focus:ring-[#f0be7c]'}`,
                                title: `${tool.label} (Click or Right-Click to choose)`,
                                "data-autofocus": tools.activeTool === tool.id,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: tool.icon,
                                    size: 16
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/RadialContextMenu.tsx",
                                    lineNumber: 143,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, tool.id, false, {
                                fileName: "[project]/src/components/studio/RadialContextMenu.tsx",
                                lineNumber: 120,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-px bg-[var(--desk-border)] mx-1"
                        }, void 0, false, {
                            fileName: "[project]/src/components/studio/RadialContextMenu.tsx",
                            lineNumber: 146,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative w-9 h-9",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>{
                                        swapColors();
                                        onClose();
                                    },
                                    onContextMenu: (e)=>{
                                        e.preventDefault();
                                        e.stopPropagation();
                                        swapColors();
                                        onClose();
                                    },
                                    onPointerUp: (e)=>{
                                        if (e.button === 0 || e.button === 2) {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            swapColors();
                                            onClose();
                                        }
                                    },
                                    style: {
                                        backgroundColor: secondaryColor
                                    },
                                    className: "absolute bottom-0 right-0 w-6 h-6 rounded-[2px] border-2 border-[var(--desk-border)] shadow-[0_2px_0_var(--btn-shadow)] cursor-pointer hover:scale-110 transition-transform focus:ring-2",
                                    title: "Secondary Color (Click or Right-Click to Swap)"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/RadialContextMenu.tsx",
                                    lineNumber: 148,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    style: {
                                        backgroundColor: primaryColor
                                    },
                                    onClick: onClose,
                                    onContextMenu: (e)=>{
                                        e.preventDefault();
                                        e.stopPropagation();
                                        onClose();
                                    },
                                    onPointerUp: (e)=>{
                                        if (e.button === 0 || e.button === 2) {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            onClose();
                                        }
                                    },
                                    className: "absolute top-0 left-0 w-6 h-6 rounded-[2px] border-2 border-[#f0be7c] shadow-[0_2px_4px_rgba(0,0,0,0.6)] z-10 cursor-pointer",
                                    title: "Primary Color"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/RadialContextMenu.tsx",
                                    lineNumber: 169,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/studio/RadialContextMenu.tsx",
                            lineNumber: 147,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/studio/RadialContextMenu.tsx",
                    lineNumber: 112,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/studio/RadialContextMenu.tsx",
                lineNumber: 101,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/studio/RadialContextMenu.tsx",
        lineNumber: 91,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(RadialContextMenu, "M8JGK0Wjf/+ZBcZpNHionKtjZlA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c = RadialContextMenu;
var _c;
__turbopack_context__.k.register(_c, "RadialContextMenu");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/studio/RemoteCursorsOverlay.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RemoteCursorsOverlay",
    ()=>RemoteCursorsOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sync/coDrawBridge.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const RemoteCursorsOverlay = ({ zoom })=>{
    _s();
    const [cursors, setCursors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RemoteCursorsOverlay.useEffect": ()=>{
            const sync = {
                "RemoteCursorsOverlay.useEffect.sync": ()=>setCursors(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].getActiveCursors(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURSOR_STALE_MS"]))
            }["RemoteCursorsOverlay.useEffect.sync"];
            sync();
            const unsub = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:remote-cursors', sync);
            const pruneTimer = ("TURBOPACK compile-time truthy", 1) ? window.setInterval(sync, 1000) : "TURBOPACK unreachable";
            return ({
                "RemoteCursorsOverlay.useEffect": ()=>{
                    unsub();
                    if (pruneTimer !== null) window.clearInterval(pruneTimer);
                }
            })["RemoteCursorsOverlay.useEffect"];
        }
    }["RemoteCursorsOverlay.useEffect"], []);
    if (cursors.length === 0) return null;
    const scale = zoom / 100;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "absolute inset-0 pointer-events-none z-30",
        "aria-hidden": "true",
        children: cursors.map((cursor)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute will-change-transform",
                style: {
                    left: `${cursor.x * scale}px`,
                    top: `${cursor.y * scale}px`,
                    transition: 'left 60ms linear, top 60ms linear'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        width: "14",
                        height: "14",
                        viewBox: "0 0 24 24",
                        style: {
                            filter: 'drop-shadow(0 1px 1px rgba(0,0,0,0.6))'
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M4 2 L20 12 L12 13 L8 20 Z",
                            fill: cursor.color,
                            stroke: "#140d1f",
                            strokeWidth: "1.5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/studio/RemoteCursorsOverlay.tsx",
                            lineNumber: 51,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/RemoteCursorsOverlay.tsx",
                        lineNumber: 45,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute left-3.5 top-3 px-1 py-0.5 text-[9px] font-mono font-bold rounded-[2px] whitespace-nowrap",
                        style: {
                            backgroundColor: cursor.color,
                            color: '#140d1f'
                        },
                        children: cursor.name
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/RemoteCursorsOverlay.tsx",
                        lineNumber: 58,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, cursor.peerId, true, {
                fileName: "[project]/src/components/studio/RemoteCursorsOverlay.tsx",
                lineNumber: 36,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)))
    }, void 0, false, {
        fileName: "[project]/src/components/studio/RemoteCursorsOverlay.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(RemoteCursorsOverlay, "4thRNdbe+Y1KYM7Nzkt9X2657J4=");
_c = RemoteCursorsOverlay;
var _c;
__turbopack_context__.k.register(_c, "RemoteCursorsOverlay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/studio/SelectionTransformGizmo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SelectionTransformGizmo",
    ()=>SelectionTransformGizmo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$selectionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/selectionUtils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const HANDLE_VISUAL_SIZE = 8;
const HANDLE_HIT_SIZE = 18;
const SelectionTransformGizmo = ({ canvasWidth, canvasHeight, zoom, selectionMask, transform, interactive = true, onHandlePointerDown, onPointerMove, onPointerUp, onCommit, onCancel, onFlipH, onFlipV, onRotate90CW, onRotate90CCW })=>{
    _s();
    const scale = zoom / 100;
    // Screen coordinates relative to #center-canvas-area
    const screenX = transform.x * scale;
    const screenY = transform.y * scale;
    const screenW = Math.max(1, transform.w * scale);
    const screenH = Math.max(1, transform.h * scale);
    const pivotScreenX = transform.pivot.x * scale;
    const pivotScreenY = transform.pivot.y * scale;
    const localPivotX = pivotScreenX - screenX;
    const localPivotY = pivotScreenY - screenY;
    // Degrees readout
    const rotationDeg = (transform.rotation * 180 / Math.PI % 360 + 360) % 360;
    const displayDeg = rotationDeg > 180 ? (rotationDeg - 360).toFixed(1) : rotationDeg.toFixed(1);
    // Irregular per-pixel boundary segments
    const perPixelSvgPath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SelectionTransformGizmo.useMemo[perPixelSvgPath]": ()=>{
            if (!selectionMask || Math.abs(transform.rotation) > 1e-4) return null;
            const segments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$selectionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractSelectionBoundarySegments"])(selectionMask, canvasWidth, canvasHeight);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$selectionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["boundarySegmentsToSvgPath"])(segments, scale);
        }
    }["SelectionTransformGizmo.useMemo[perPixelSvgPath]"], [
        selectionMask,
        canvasWidth,
        canvasHeight,
        scale,
        transform.rotation
    ]);
    const clientToCanvas = (e)=>{
        const area = document.getElementById('center-canvas-area');
        if (!area) return {
            x: 0,
            y: 0
        };
        const rect = area.getBoundingClientRect();
        const px = (e.clientX - rect.left) / scale;
        const py = (e.clientY - rect.top) / scale;
        return {
            x: px,
            y: py
        };
    };
    const startDrag = (handle, e)=>{
        e.stopPropagation();
        e.preventDefault();
        try {
            e.currentTarget.setPointerCapture(e.pointerId);
        } catch  {
        // noop
        }
        const canvasPoint = clientToCanvas(e);
        onHandlePointerDown(handle, {
            x: e.clientX,
            y: e.clientY
        }, canvasPoint);
    };
    // Robust window-level pointer tracking during drag (prevents missed events when cursor flies outside gizmo)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SelectionTransformGizmo.useEffect": ()=>{
            if (!transform.isTransforming) return;
            const onGlobalPointerMove = {
                "SelectionTransformGizmo.useEffect.onGlobalPointerMove": (e)=>{
                    const area = document.getElementById('center-canvas-area');
                    if (!area) return;
                    const rect = area.getBoundingClientRect();
                    const px = (e.clientX - rect.left) / scale;
                    const py = (e.clientY - rect.top) / scale;
                    onPointerMove({
                        x: px,
                        y: py
                    }, {
                        shiftKey: e.shiftKey,
                        altKey: e.altKey
                    });
                }
            }["SelectionTransformGizmo.useEffect.onGlobalPointerMove"];
            const onGlobalPointerUp = {
                "SelectionTransformGizmo.useEffect.onGlobalPointerUp": ()=>{
                    onPointerUp();
                }
            }["SelectionTransformGizmo.useEffect.onGlobalPointerUp"];
            window.addEventListener('pointermove', onGlobalPointerMove);
            window.addEventListener('pointerup', onGlobalPointerUp);
            return ({
                "SelectionTransformGizmo.useEffect": ()=>{
                    window.removeEventListener('pointermove', onGlobalPointerMove);
                    window.removeEventListener('pointerup', onGlobalPointerUp);
                }
            })["SelectionTransformGizmo.useEffect"];
        }
    }["SelectionTransformGizmo.useEffect"], [
        transform.isTransforming,
        scale,
        onPointerMove,
        onPointerUp
    ]);
    const handles = [
        {
            id: 'tl',
            x: 0,
            y: 0,
            cursor: 'nwse-resize'
        },
        {
            id: 'tc',
            x: screenW / 2,
            y: 0,
            cursor: 'ns-resize'
        },
        {
            id: 'tr',
            x: screenW,
            y: 0,
            cursor: 'nesw-resize'
        },
        {
            id: 'mr',
            x: screenW,
            y: screenH / 2,
            cursor: 'ew-resize'
        },
        {
            id: 'br',
            x: screenW,
            y: screenH,
            cursor: 'nwse-resize'
        },
        {
            id: 'bc',
            x: screenW / 2,
            y: screenH,
            cursor: 'ns-resize'
        },
        {
            id: 'bl',
            x: 0,
            y: screenH,
            cursor: 'nesw-resize'
        },
        {
            id: 'ml',
            x: 0,
            y: screenH / 2,
            cursor: 'ew-resize'
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                children: `
        @keyframes marching-ants {
          0% { stroke-dashoffset: 0; }
          100% { stroke-dashoffset: 8; }
        }
        .marching-ants-black {
          stroke: #140d1f;
          stroke-width: 1.5;
          stroke-dasharray: 4 4;
          animation: marching-ants 0.4s linear infinite;
        }
        .marching-ants-white {
          stroke: #ffffff;
          stroke-width: 1.5;
          stroke-dasharray: 4 4;
          stroke-dashoffset: 4;
          animation: marching-ants 0.4s linear infinite;
        }
      `
            }, void 0, false, {
                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                lineNumber: 138,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            perPixelSvgPath && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: "absolute inset-0 pointer-events-none z-20 overflow-visible",
                width: canvasWidth * scale,
                height: canvasHeight * scale,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: perPixelSvgPath,
                        fill: "none",
                        className: "marching-ants-black"
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                        lineNumber: 165,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: perPixelSvgPath,
                        fill: "none",
                        className: "marching-ants-white"
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                        lineNumber: 166,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                lineNumber: 160,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            !interactive && !perPixelSvgPath && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: "absolute top-0 left-0 pointer-events-none z-20 overflow-visible",
                style: {
                    width: `${screenW}px`,
                    height: `${screenH}px`,
                    transform: `translate(${screenX}px, ${screenY}px)`
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        x: 0,
                        y: 0,
                        width: screenW,
                        height: screenH,
                        fill: "none",
                        className: "marching-ants-black"
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                        lineNumber: 180,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        x: 0,
                        y: 0,
                        width: screenW,
                        height: screenH,
                        fill: "none",
                        className: "marching-ants-white"
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                        lineNumber: 181,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                lineNumber: 172,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            interactive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-testid": "selection-transform-gizmo",
                className: "absolute top-0 left-0 pointer-events-auto select-none z-40",
                style: {
                    width: `${screenW}px`,
                    height: `${screenH}px`,
                    transformOrigin: `${localPivotX}px ${localPivotY}px`,
                    transform: `translate(${screenX}px, ${screenY}px) rotate(${transform.rotation}rad)`,
                    touchAction: 'none'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "absolute inset-0 pointer-events-none overflow-visible",
                        width: screenW,
                        height: screenH,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: 0,
                                y: 0,
                                width: screenW,
                                height: screenH,
                                fill: "none",
                                className: "marching-ants-black"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 205,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: 0,
                                y: 0,
                                width: screenW,
                                height: screenH,
                                fill: "none",
                                className: "marching-ants-white"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 214,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                        lineNumber: 199,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-testid": "gizmo-translate-body",
                        className: "absolute inset-0 cursor-move bg-transparent",
                        title: "Drag to move selection (Shift to lock axis)",
                        onPointerDown: (e)=>{
                            // Let the viewport subtract a selection instead of translating it.
                            if (e.altKey || e.button !== 0) return;
                            startDrag('translate', e);
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                        lineNumber: 225,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    [
                        {
                            x: -24,
                            y: -24,
                            corner: 'tl'
                        },
                        {
                            x: screenW,
                            y: -24,
                            corner: 'tr'
                        },
                        {
                            x: screenW,
                            y: screenH,
                            corner: 'br'
                        },
                        {
                            x: -24,
                            y: screenH,
                            corner: 'bl'
                        }
                    ].map((zone)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-testid": `gizmo-rotate-${zone.corner}`,
                            className: "absolute w-6 h-6 rounded-full cursor-crosshair z-50 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-auto",
                            style: {
                                left: `${zone.x}px`,
                                top: `${zone.y}px`
                            },
                            title: "Drag to rotate selection (Shift to snap 15°)",
                            onPointerDown: (e)=>startDrag('rotate', e),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-4 h-4 rounded-full border border-[#f0be7c] bg-[#140d1f]/70 text-[#f0be7c] text-[8px] flex items-center justify-center font-bold pointer-events-none",
                                children: "↻"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 254,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, `rot-zone-${zone.corner}`, false, {
                            fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                            lineNumber: 243,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))),
                    handles.map((h)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-testid": `gizmo-handle-${h.id}`,
                            className: "absolute z-40 flex items-center justify-center pointer-events-auto",
                            style: {
                                left: `${h.x}px`,
                                top: `${h.y}px`,
                                width: `${HANDLE_HIT_SIZE}px`,
                                height: `${HANDLE_HIT_SIZE}px`,
                                transform: 'translate(-50%, -50%)',
                                cursor: h.cursor
                            },
                            onPointerDown: (e)=>startDrag(h.id, e),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "border border-[#140d1f] shadow-xs",
                                style: {
                                    width: `${HANDLE_VISUAL_SIZE}px`,
                                    height: `${HANDLE_VISUAL_SIZE}px`,
                                    backgroundColor: transform.activeHandle === h.id ? '#f0be7c' : '#ffffff',
                                    boxShadow: '0 0 0 1px #f0be7c'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 276,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, h.id, false, {
                            fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                            lineNumber: 262,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-testid": "gizmo-pivot",
                        className: "absolute z-40 w-5 h-5 flex items-center justify-center pointer-events-auto cursor-grab active:cursor-grabbing",
                        style: {
                            left: `${localPivotX}px`,
                            top: `${localPivotY}px`,
                            transform: 'translate(-50%, -50%)'
                        },
                        title: "Center Pivot Anchor (drag to shift rotation center)",
                        onPointerDown: (e)=>startDrag('pivot', e),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative w-4 h-4 flex items-center justify-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0 rounded-full border border-[#f0be7c] bg-[#140d1f]/60"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                    lineNumber: 302,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute w-3.5 h-[1.5px] bg-[#f0be7c]"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                    lineNumber: 304,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute h-3.5 w-[1.5px] bg-[#f0be7c]"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                    lineNumber: 306,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-1 h-1 rounded-full bg-[#ffffff] z-10"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                    lineNumber: 308,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                            lineNumber: 300,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                        lineNumber: 289,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    Math.abs(parseFloat(displayDeg)) > 0.1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-testid": "gizmo-degree-badge",
                        className: "absolute -top-7 left-1/2 -translate-x-1/2 bg-[#140d1f] text-[#f0be7c] border border-[#f0be7c] text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-[2px] shadow-md pointer-events-none whitespace-nowrap z-50",
                        children: [
                            displayDeg,
                            "°"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                        lineNumber: 314,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-testid": "gizmo-hud-bar",
                        className: "absolute -bottom-9 left-1/2 -translate-x-1/2 bg-[#140d1f]/95 border border-[#3a2e4c] rounded-[2px] px-1 py-0.5 flex items-center gap-1 shadow-lg pointer-events-auto z-50 text-[11px] font-mono",
                        onPointerDown: (event)=>event.stopPropagation(),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: onFlipH,
                                title: "Flip Horizontal (H)",
                                className: "w-6 h-5 flex items-center justify-center text-[var(--text-body)] hover:text-[#f0be7c] hover:bg-[#2c1e40] rounded-[2px] cursor-pointer",
                                children: "↔"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 328,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: onFlipV,
                                title: "Flip Vertical (V)",
                                className: "w-6 h-5 flex items-center justify-center text-[var(--text-body)] hover:text-[#f0be7c] hover:bg-[#2c1e40] rounded-[2px] cursor-pointer",
                                children: "↕"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 336,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-px h-3 bg-[#3a2e4c]"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 344,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: onRotate90CCW,
                                title: "Rotate 90° CCW",
                                className: "w-6 h-5 flex items-center justify-center text-[var(--text-body)] hover:text-[#f0be7c] hover:bg-[#2c1e40] rounded-[2px] cursor-pointer",
                                children: "↺"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 345,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: onRotate90CW,
                                title: "Rotate 90° CW",
                                className: "w-6 h-5 flex items-center justify-center text-[var(--text-body)] hover:text-[#f0be7c] hover:bg-[#2c1e40] rounded-[2px] cursor-pointer",
                                children: "↻"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 353,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-px h-3 bg-[#3a2e4c]"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 361,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: onCommit,
                                title: "Commit Transform (Enter)",
                                "data-testid": "gizmo-commit-btn",
                                className: "w-6 h-5 flex items-center justify-center text-[#80e080] hover:bg-[#1a3a1a] rounded-[2px] cursor-pointer font-bold",
                                children: "✓"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 362,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: onCancel,
                                title: "Cancel Transform (Escape)",
                                "data-testid": "gizmo-cancel-btn",
                                className: "w-6 h-5 flex items-center justify-center text-[#ff8080] hover:bg-[#3a1a1a] rounded-[2px] cursor-pointer font-bold",
                                children: "✕"
                            }, void 0, false, {
                                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                                lineNumber: 371,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                        lineNumber: 323,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
                lineNumber: 187,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/studio/SelectionTransformGizmo.tsx",
        lineNumber: 137,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(SelectionTransformGizmo, "98MIupDOy1g9s9P4FpuF0JDvP3Y=");
_c = SelectionTransformGizmo;
var _c;
__turbopack_context__.k.register(_c, "SelectionTransformGizmo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/studio/ViewportLensFilters.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ViewportLensFilters",
    ()=>ViewportLensFilters
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/cvdLens.ts [app-client] (ecmascript)");
'use client';
;
;
const inkChannel = (v)=>(v / 255).toFixed(6);
const ViewportLensFilters = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        "aria-hidden": "true",
        focusable: "false",
        "data-testid": "viewport-lens-filters",
        width: "0",
        height: "0",
        style: {
            position: 'absolute'
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
            children: [
                Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CVD_LENS_MATRICES"]).map((mode)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("filter", {
                        id: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CVD_FILTER_IDS"][mode],
                        colorInterpolationFilters: "linearRGB",
                        x: "0",
                        y: "0",
                        width: "100%",
                        height: "100%",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feColorMatrix", {
                            type: "matrix",
                            values: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["feColorMatrixValues"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CVD_LENS_MATRICES"][mode])
                        }, void 0, false, {
                            fileName: "[project]/src/components/studio/ViewportLensFilters.tsx",
                            lineNumber: 46,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, mode, false, {
                        fileName: "[project]/src/components/studio/ViewportLensFilters.tsx",
                        lineNumber: 37,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("filter", {
                    id: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SQUINT_FILTER_ID"],
                    colorInterpolationFilters: "sRGB",
                    x: "0",
                    y: "0",
                    width: "100%",
                    height: "100%",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feFlood", {
                            floodColor: "#ffffff",
                            result: "background"
                        }, void 0, false, {
                            fileName: "[project]/src/components/studio/ViewportLensFilters.tsx",
                            lineNumber: 59,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feColorMatrix", {
                            in: "SourceGraphic",
                            type: "matrix",
                            values: `0 0 0 0 ${inkChannel(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SQUINT_SILHOUETTE_RGB"][0])}  0 0 0 0 ${inkChannel(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SQUINT_SILHOUETTE_RGB"][1])}  0 0 0 0 ${inkChannel(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SQUINT_SILHOUETTE_RGB"][2])}  0 0 0 1 0`,
                            result: "ink"
                        }, void 0, false, {
                            fileName: "[project]/src/components/studio/ViewportLensFilters.tsx",
                            lineNumber: 60,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feMerge", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feMergeNode", {
                                    in: "background"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/ViewportLensFilters.tsx",
                                    lineNumber: 69,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feMergeNode", {
                                    in: "ink"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/studio/ViewportLensFilters.tsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/studio/ViewportLensFilters.tsx",
                            lineNumber: 68,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/studio/ViewportLensFilters.tsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/studio/ViewportLensFilters.tsx",
            lineNumber: 33,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/studio/ViewportLensFilters.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = ViewportLensFilters;
var _c;
__turbopack_context__.k.register(_c, "ViewportLensFilters");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_studio_09mjnur._.js.map