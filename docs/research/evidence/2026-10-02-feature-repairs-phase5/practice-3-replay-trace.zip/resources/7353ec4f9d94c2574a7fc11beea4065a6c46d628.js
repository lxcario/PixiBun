(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/ui/AppearancePopover.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AppearancePopover",
    ()=>AppearancePopover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$themeStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/stores/themeStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/StudioToggle.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/ToolMotionPreview.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const AppearancePopover = ({ className = '', label, actions })=>{
    _s();
    const dialogId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const { studioTheme, setStudioTheme, colorScheme, setColorScheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$themeStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeStore"])();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const triggerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const popoverRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const atelierRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const cozyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const darkRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lightRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const firstActionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [coords, setCoords] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [toolPreviewsEnabled, setToolPreviewsEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AppearancePopover.useEffect": ()=>{
            setMounted(true);
            const sync = {
                "AppearancePopover.useEffect.sync": ()=>{
                    setToolPreviewsEnabled(!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isToolPreviewsDisabled"])());
                }
            }["AppearancePopover.useEffect.sync"];
            sync();
            window.addEventListener('storage', sync);
            window.addEventListener(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TOOL_PREVIEWS_CHANGED_EVENT"], sync);
            return ({
                "AppearancePopover.useEffect": ()=>{
                    window.removeEventListener('storage', sync);
                    window.removeEventListener(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TOOL_PREVIEWS_CHANGED_EVENT"], sync);
                }
            })["AppearancePopover.useEffect"];
        }
    }["AppearancePopover.useEffect"], []);
    const updateCoords = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AppearancePopover.useCallback[updateCoords]": ()=>{
            if (triggerRef.current) {
                const rect = triggerRef.current.getBoundingClientRect();
                setCoords({
                    top: rect.bottom + 6,
                    right: Math.max(12, window.innerWidth - rect.right)
                });
            }
        }
    }["AppearancePopover.useCallback[updateCoords]"], []);
    // Initial focus on open
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AppearancePopover.useEffect": ()=>{
            if (isOpen && coords && !popoverRef.current?.contains(document.activeElement)) {
                const timer = requestAnimationFrame({
                    "AppearancePopover.useEffect.timer": ()=>{
                        if (popoverRef.current?.contains(document.activeElement)) return;
                        if (firstActionRef.current) {
                            firstActionRef.current.focus();
                        } else if (studioTheme === 'cozy-classic') {
                            cozyRef.current?.focus();
                        } else {
                            atelierRef.current?.focus();
                        }
                    }
                }["AppearancePopover.useEffect.timer"]);
                return ({
                    "AppearancePopover.useEffect": ()=>cancelAnimationFrame(timer)
                })["AppearancePopover.useEffect"];
            }
        }
    }["AppearancePopover.useEffect"], [
        isOpen,
        studioTheme,
        coords
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AppearancePopover.useEffect": ()=>{
            if (!isOpen) return;
            updateCoords();
            const handleClickOutside = {
                "AppearancePopover.useEffect.handleClickOutside": (e)=>{
                    const target = e.target;
                    if (triggerRef.current && !triggerRef.current.contains(target) && popoverRef.current && !popoverRef.current.contains(target)) {
                        setIsOpen(false);
                    }
                }
            }["AppearancePopover.useEffect.handleClickOutside"];
            const handleKeyDown = {
                "AppearancePopover.useEffect.handleKeyDown": (e)=>{
                    if (e.key === 'Escape') {
                        e.preventDefault();
                        setIsOpen(false);
                        triggerRef.current?.focus();
                    }
                }
            }["AppearancePopover.useEffect.handleKeyDown"];
            window.addEventListener('resize', updateCoords);
            document.addEventListener('mousedown', handleClickOutside);
            document.addEventListener('keydown', handleKeyDown);
            return ({
                "AppearancePopover.useEffect": ()=>{
                    window.removeEventListener('resize', updateCoords);
                    document.removeEventListener('mousedown', handleClickOutside);
                    document.removeEventListener('keydown', handleKeyDown);
                }
            })["AppearancePopover.useEffect"];
        }
    }["AppearancePopover.useEffect"], [
        isOpen,
        updateCoords
    ]);
    const handleStyleKeyDown = (e)=>{
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            if (studioTheme === 'atelier') {
                setStudioTheme('cozy-classic');
                cozyRef.current?.focus();
            } else {
                setStudioTheme('atelier');
                atelierRef.current?.focus();
            }
        }
    };
    const handleSchemeKeyDown = (e)=>{
        if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
            e.preventDefault();
            if (colorScheme === 'dark') {
                setColorScheme('light');
                lightRef.current?.focus();
            } else {
                setColorScheme('dark');
                darkRef.current?.focus();
            }
        }
    };
    if (!mounted) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `${label ? 'w-[72px]' : 'w-7'} h-7 rounded-[1px] ${className}`,
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/AppearancePopover.tsx",
            lineNumber: 139,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                ref: triggerRef,
                type: "button",
                onClick: ()=>setIsOpen((prev)=>!prev),
                title: actions ? 'Studio: theme, co-draw and help' : 'Appearance (Theme & Color Scheme)',
                "aria-label": actions ? 'Studio options' : 'Appearance (Theme & Color Scheme)',
                "aria-expanded": isOpen,
                "aria-haspopup": "dialog",
                "aria-controls": isOpen && coords ? dialogId : undefined,
                "data-testid": "appearance-button",
                className: `${label ? 'px-2.5 gap-1.5 text-xs' : 'w-7'} h-7 flex items-center justify-center rounded-[1px] pixel-tactile-btn border border-[var(--desk-border)] text-[var(--text-body)] hover:text-[var(--text-heading)] cursor-pointer select-none focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--accent-wisteria)] ${isOpen ? 'bg-[var(--surface-2)] text-[var(--text-heading)] font-bold' : ''} ${className}`,
                children: [
                    !actions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                        name: "palette",
                        size: 12
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                        lineNumber: 159,
                        columnNumber: 22
                    }, ("TURBOPACK compile-time value", void 0)),
                    label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                        lineNumber: 160,
                        columnNumber: 19
                    }, ("TURBOPACK compile-time value", void 0)),
                    actions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "aria-hidden": "true",
                        className: "text-[8px]",
                        children: "▼"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                        lineNumber: 161,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                lineNumber: 144,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            isOpen && coords && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: popoverRef,
                id: dialogId,
                role: "dialog",
                "aria-modal": "false",
                "aria-label": actions ? 'Studio options' : 'Appearance settings',
                className: "fixed z-[9999] w-64 max-w-[calc(100vw-24px)] overflow-y-auto bg-[var(--desk-surface)] border border-[var(--desk-border)] rounded-[3px] shadow-2xl p-3 text-xs font-sans text-[var(--text-heading)] select-none animate-in fade-in zoom-in-95 duration-100",
                style: {
                    top: `${coords.top}px`,
                    right: `${coords.right}px`,
                    maxHeight: `calc(100dvh - ${coords.top + 12}px)`
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between pb-2 mb-2.5 border-b border-[var(--desk-border)]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-semibold text-[11px] tracking-wide text-[var(--text-heading)]",
                                children: actions ? 'Studio' : 'Appearance'
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                lineNumber: 182,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    setIsOpen(false);
                                    triggerRef.current?.focus();
                                },
                                "aria-label": actions ? 'Close studio options' : 'Close appearance popover',
                                className: "w-6 h-6 rounded-[1px] flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--text-heading)] hover:bg-[var(--surface-1)] cursor-pointer text-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--accent-wisteria)]",
                                children: "✕"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                lineNumber: 185,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                        lineNumber: 181,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    actions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-2 pb-3 mb-3 border-b border-[var(--desk-border)]",
                        children: actions.map((action, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                ref: index === 0 ? firstActionRef : undefined,
                                type: "button",
                                "data-testid": action.testId,
                                "aria-label": action.ariaLabel,
                                onClick: ()=>{
                                    setIsOpen(false);
                                    triggerRef.current?.focus();
                                    action.onSelect?.();
                                },
                                className: "h-9 flex items-center justify-center gap-1.5 pixel-tactile-btn rounded-[2px] border border-[var(--desk-border)] text-[var(--text-body)] focus-visible:outline focus-visible:outline-1 focus-visible:outline-[var(--accent-gold)]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                        name: action.icon,
                                        size: 12
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                        lineNumber: 203,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    action.label
                                ]
                            }, action.label, true, {
                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                lineNumber: 199,
                                columnNumber: 47
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                        lineNumber: 198,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        role: "radiogroup",
                        tabIndex: -1,
                        "aria-label": "Studio style",
                        onKeyDown: handleStyleKeyDown,
                        className: "flex flex-col gap-1.5 mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-medium text-[var(--text-muted)] uppercase tracking-wider",
                                id: "studio-style-label",
                                children: "Studio style"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                lineNumber: 214,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                ref: atelierRef,
                                type: "button",
                                role: "radio",
                                "aria-checked": studioTheme === 'atelier',
                                "data-testid": "theme-option-atelier",
                                onClick: ()=>setStudioTheme('atelier'),
                                className: `flex items-start gap-2.5 p-2 rounded-[2px] border text-left cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--accent-wisteria)] ${studioTheme === 'atelier' ? 'bg-[var(--surface-2)] border-[var(--accent-wisteria)] text-[var(--text-heading)]' : 'bg-[var(--surface-0)] border-[var(--desk-border)] text-[var(--text-body)] hover:bg-[var(--surface-1)] hover:text-[var(--text-heading)]'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "pt-0.5 shrink-0 text-[11px] font-mono text-[var(--accent-gold)]",
                                        "aria-hidden": "true",
                                        children: studioTheme === 'atelier' ? '●' : '○'
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                        lineNumber: 232,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1 min-w-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between gap-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-semibold text-xs text-[var(--text-heading)]",
                                                        children: "Atelier"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 237,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-0.5 shrink-0",
                                                        "aria-hidden": "true",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "w-2.5 h-2.5 rounded-[1px] border border-black/40 bg-[#16141a]",
                                                                title: "Charcoal Base"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                                lineNumber: 240,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "w-2.5 h-2.5 rounded-[1px] border border-black/40 bg-[#201d26]",
                                                                title: "Workbench Surface"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                                lineNumber: 241,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "w-2.5 h-2.5 rounded-[1px] border border-black/40 bg-[#e5a962]",
                                                                title: "Warm Brass"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                                lineNumber: 242,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 239,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                lineNumber: 236,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[10px] text-[var(--text-muted)] mt-0.5 leading-snug",
                                                children: "Quiet, crafted workbench"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                lineNumber: 245,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                        lineNumber: 235,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                lineNumber: 219,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                ref: cozyRef,
                                type: "button",
                                role: "radio",
                                "aria-checked": studioTheme === 'cozy-classic',
                                "data-testid": "theme-option-cozy-classic",
                                onClick: ()=>setStudioTheme('cozy-classic'),
                                className: `flex items-start gap-2.5 p-2 rounded-[2px] border text-left cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--accent-gold)] ${studioTheme === 'cozy-classic' ? 'bg-[var(--surface-2)] border-[var(--accent-gold)] text-[var(--text-heading)]' : 'bg-[var(--surface-0)] border-[var(--desk-border)] text-[var(--text-body)] hover:bg-[var(--surface-1)] hover:text-[var(--text-heading)]'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "pt-0.5 shrink-0 text-[11px] font-mono text-[var(--accent-gold)]",
                                        "aria-hidden": "true",
                                        children: studioTheme === 'cozy-classic' ? '●' : '○'
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                        lineNumber: 265,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1 min-w-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between gap-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-semibold text-xs text-[var(--text-heading)]",
                                                        children: "Cozy Classic"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 270,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-0.5 shrink-0",
                                                        "aria-hidden": "true",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "w-2.5 h-2.5 rounded-[1px] border border-black/40 bg-[#140c1e]",
                                                                title: "Plum Base"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                                lineNumber: 273,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "w-2.5 h-2.5 rounded-[1px] border border-black/40 bg-[#201431]",
                                                                title: "Lavender Surface"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                                lineNumber: 274,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "w-2.5 h-2.5 rounded-[1px] border border-black/40 bg-[#f0be7c]",
                                                                title: "Golden Amber"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                                lineNumber: 275,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 272,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                lineNumber: 269,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[10px] text-[var(--text-muted)] mt-0.5 leading-snug",
                                                children: "Warm original PixiBun"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                lineNumber: 278,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                        lineNumber: 268,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                lineNumber: 252,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                        lineNumber: 208,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1.5 pt-2 border-t border-[var(--desk-border)]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-medium text-[var(--text-muted)] uppercase tracking-wider",
                                id: "color-scheme-label",
                                children: "Color scheme"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                lineNumber: 287,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                role: "radiogroup",
                                tabIndex: -1,
                                "aria-label": "Color scheme",
                                onKeyDown: handleSchemeKeyDown,
                                className: "flex p-0.5 bg-[var(--surface-0)] border border-[var(--desk-border)] rounded-[2px] gap-0.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        ref: darkRef,
                                        type: "button",
                                        role: "radio",
                                        "aria-checked": colorScheme === 'dark',
                                        "data-testid": "scheme-option-dark",
                                        onClick: ()=>setColorScheme('dark'),
                                        className: `flex-1 flex items-center justify-center gap-1.5 py-1 px-2 rounded-[1px] text-xs font-sans transition-colors cursor-pointer select-none border pixel-tactile-btn focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--accent-wisteria)] ${colorScheme === 'dark' ? 'bg-[var(--surface-2)] border-[var(--desk-border-highlight)] text-[var(--text-heading)] font-semibold shadow-[0_1px_2px_rgba(0,0,0,0.3)]' : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-heading)]'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                viewBox: "0 0 16 16",
                                                width: "11",
                                                height: "11",
                                                fill: "currentColor",
                                                shapeRendering: "crispEdges",
                                                className: "pixelated shrink-0",
                                                "aria-hidden": "true",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M12 9.5A5.5 5.5 0 0 1 6.5 4a5.55 5.55 0 0 1 .45-2.2A6 6 0 1 0 14.2 8.9c-.68.4-1.45.6-2.2.6z"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                    lineNumber: 318,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                lineNumber: 309,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Dark"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                lineNumber: 320,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                        lineNumber: 296,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        ref: lightRef,
                                        type: "button",
                                        role: "radio",
                                        "aria-checked": colorScheme === 'light',
                                        "data-testid": "scheme-option-light",
                                        onClick: ()=>setColorScheme('light'),
                                        className: `flex-1 flex items-center justify-center gap-1.5 py-1 px-2 rounded-[1px] text-xs font-sans transition-colors cursor-pointer select-none border pixel-tactile-btn focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--accent-wisteria)] ${colorScheme === 'light' ? 'bg-[var(--surface-2)] border-[var(--desk-border-highlight)] text-[var(--text-heading)] font-semibold shadow-[0_1px_2px_rgba(0,0,0,0.3)]' : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-heading)]'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                viewBox: "0 0 16 16",
                                                width: "11",
                                                height: "11",
                                                fill: "currentColor",
                                                shapeRendering: "crispEdges",
                                                className: "pixelated shrink-0",
                                                "aria-hidden": "true",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                        cx: "8",
                                                        cy: "8",
                                                        r: "3"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 345,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                        x: "7",
                                                        y: "1",
                                                        width: "2",
                                                        height: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 346,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                        x: "7",
                                                        y: "13",
                                                        width: "2",
                                                        height: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 347,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                        x: "1",
                                                        y: "7",
                                                        width: "2",
                                                        height: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 348,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                        x: "13",
                                                        y: "7",
                                                        width: "2",
                                                        height: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 349,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                        x: "3",
                                                        y: "3",
                                                        width: "2",
                                                        height: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 350,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                        x: "11",
                                                        y: "11",
                                                        width: "2",
                                                        height: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 351,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                        x: "11",
                                                        y: "3",
                                                        width: "2",
                                                        height: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 352,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                        x: "3",
                                                        y: "11",
                                                        width: "2",
                                                        height: "2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                        lineNumber: 353,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                lineNumber: 336,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Light"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                                lineNumber: 355,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                        lineNumber: 323,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                                lineNumber: 290,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                        lineNumber: 286,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "pt-2 border-t border-[var(--desk-border)]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: "Tool Previews",
                            checked: toolPreviewsEnabled,
                            onChange: (enabled)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setToolPreviewsDisabled"])(!enabled)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                            lineNumber: 362,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                        lineNumber: 361,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/AppearancePopover.tsx",
                lineNumber: 167,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)), document.body)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/AppearancePopover.tsx",
        lineNumber: 143,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(AppearancePopover, "xUVnDm8uKgXybSpHVhOiNXBxUpQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$themeStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeStore"]
    ];
});
_c = AppearancePopover;
var _c;
__turbopack_context__.k.register(_c, "AppearancePopover");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/BunMascot.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BunMascot",
    ()=>BunMascot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$bunSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/art/bunSprite.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const BunMascot = ({ size = 32, pose = 'idle', animate = false, className })=>{
    _s();
    const [blinking, setBlinking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BunMascot.useEffect": ()=>{
            if (!animate || pose !== 'idle') return;
            if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
            let hideTimer;
            const schedule = window.setInterval({
                "BunMascot.useEffect.schedule": ()=>{
                    setBlinking(true);
                    hideTimer = window.setTimeout({
                        "BunMascot.useEffect.schedule": ()=>setBlinking(false)
                    }["BunMascot.useEffect.schedule"], 160);
                }
            }["BunMascot.useEffect.schedule"], 3400);
            return ({
                "BunMascot.useEffect": ()=>{
                    window.clearInterval(schedule);
                    window.clearTimeout(hideTimer);
                }
            })["BunMascot.useEffect"];
        }
    }["BunMascot.useEffect"], [
        animate,
        pose
    ]);
    const activePose = pose === 'blink' || blinking ? 'blink' : pose;
    const pixels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BunMascot.useMemo[pixels]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$bunSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bunPixels"])(activePose)
    }["BunMascot.useMemo[pixels]"], [
        activePose
    ]);
    const outline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BunMascot.useMemo[outline]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$bunSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bunOutline"])(activePose)
    }["BunMascot.useMemo[outline]"], [
        activePose
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "-1 -1 18 18",
        width: size,
        height: size,
        shapeRendering: "crispEdges",
        className: className,
        role: "img",
        "aria-label": "Bun, the PixiBun bunny",
        children: [
            outline.map(([x, y], i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    x: x,
                    y: y,
                    width: 1,
                    height: 1,
                    fill: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$bunSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BUN_INK"]
                }, `o${i}`, false, {
                    fileName: "[project]/src/components/ui/BunMascot.tsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))),
            pixels.map(([x, y, w, h, fill], i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    x: x,
                    y: y,
                    width: w,
                    height: h,
                    fill: fill
                }, i, false, {
                    fileName: "[project]/src/components/ui/BunMascot.tsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/BunMascot.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(BunMascot, "DUQnfcHZ7pyl95RhjFP/EEAAE1c=");
_c = BunMascot;
var _c;
__turbopack_context__.k.register(_c, "BunMascot");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/IconButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>IconButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
function IconButton({ icon, onClick, label, size = 'md', variant = 'ghost', active = false, disabled = false, className }) {
    const sizeClasses = {
        sm: 'w-[24px] h-[24px]',
        md: 'w-[28px] h-[28px]',
        lg: 'w-[32px] h-[32px]'
    }[size];
    const iconSizes = {
        sm: 14,
        md: 16,
        lg: 20
    }[size];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        onClick: onClick,
        "aria-label": label,
        disabled: disabled,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])('flex items-center justify-center rounded-[var(--radius-sm)] transition-colors duration-100 ease-out', 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent-gold)] focus-visible:ring-offset-1 focus-visible:ring-offset-[var(--desk-surface)]', sizeClasses, !disabled && 'active:translate-y-[1px]', disabled && 'opacity-40 cursor-not-allowed', !disabled && variant === 'ghost' && !active && 'bg-transparent hover:bg-[var(--state-hover)] active:bg-[var(--state-active)] text-[var(--text-body)] hover:text-[var(--text-heading)]', !disabled && variant === 'surface' && !active && 'bg-[var(--surface-2)] hover:bg-[var(--state-hover)] text-[var(--text-body)] hover:text-[var(--text-heading)]', !disabled && variant === 'danger' && !active && 'bg-transparent hover:bg-[var(--state-danger)] text-[var(--text-body)] hover:text-[#ffffff]', active && !disabled && 'bg-[var(--surface-2)] shadow-[inset_2px_0_0_var(--accent-gold)] text-[var(--text-heading)]', !active && 'shadow-[inset_2px_0_0_transparent]', className)),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
            name: icon,
            size: iconSizes
        }, void 0, false, {
            fileName: "[project]/src/components/ui/IconButton.tsx",
            lineNumber: 68,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/IconButton.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
}
_c = IconButton;
var _c;
__turbopack_context__.k.register(_c, "IconButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/ModalWrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ModalWrapper",
    ()=>ModalWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$motion$2f$dist$2f$es$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/motion/dist/es/react.mjs [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const ModalWrapper = ({ isOpen, onClose, title, children, className = '', maxWidth = 'w-[460px]', bodyClassName })=>{
    _s();
    const dialogRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const openerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const rawId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useId();
    const safeId = rawId.replace(/[^a-zA-Z0-9_-]/g, '');
    const titleId = `modal-title-${safeId}`;
    const bodyId = `modal-body-${safeId}`;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ModalWrapper.useEffect": ()=>{
            const dialog = dialogRef.current;
            if (!dialog) return;
            if (isOpen) {
                // Save trigger element for focus restoration (only if outside dialog)
                if (typeof document !== 'undefined' && document.activeElement instanceof HTMLElement && !dialog.contains(document.activeElement)) {
                    openerRef.current = document.activeElement;
                }
                if (!dialog.open) {
                    try {
                        dialog.showModal();
                    } catch  {
                        // fallback if showModal is not supported in environment
                        dialog.setAttribute('open', '');
                    }
                }
                // Auto-focus priority: [data-autofocus] -> first interactive in modal body -> modal title (WCAG 2.4.3)
                const explicitFocus = dialog.querySelector('[data-autofocus]');
                if (explicitFocus) {
                    explicitFocus.focus();
                } else {
                    const bodyFocusable = dialog.querySelector(`#${bodyId} input:not([disabled]), #${bodyId} textarea:not([disabled]), #${bodyId} select:not([disabled]), #${bodyId} button:not([disabled]), #${bodyId} [href], #${bodyId} [tabindex]:not([tabindex="-1"])`);
                    if (bodyFocusable) {
                        bodyFocusable.focus();
                    } else {
                        const titleHeading = dialog.querySelector(`#${titleId}`);
                        if (titleHeading) {
                            titleHeading.focus();
                        } else {
                            const fallback = dialog.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])');
                            if (fallback.length > 0) {
                                fallback[0].focus();
                            }
                        }
                    }
                }
            } else {
                if (dialog.open) {
                    try {
                        dialog.close();
                    } catch  {
                        dialog.removeAttribute('open');
                    }
                }
                // Return focus to previous opener
                if (openerRef.current && typeof openerRef.current.focus === 'function') {
                    const opener = openerRef.current;
                    setTimeout({
                        "ModalWrapper.useEffect": ()=>opener.focus()
                    }["ModalWrapper.useEffect"], 0);
                }
            }
            const handleDialogKeyDown = {
                "ModalWrapper.useEffect.handleDialogKeyDown": (e)=>{
                    if (e.key === 'Escape') {
                        e.preventDefault();
                        onClose();
                        if (openerRef.current && typeof openerRef.current.focus === 'function') {
                            const opener = openerRef.current;
                            setTimeout({
                                "ModalWrapper.useEffect.handleDialogKeyDown": ()=>opener.focus()
                            }["ModalWrapper.useEffect.handleDialogKeyDown"], 0);
                        }
                        return;
                    }
                    // Focus trap cycle (Tab / Shift+Tab)
                    if (e.key === 'Tab') {
                        const focusable = dialog.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])');
                        if (focusable.length === 0) return;
                        const first = focusable[0];
                        const last = focusable[focusable.length - 1];
                        if (e.shiftKey && document.activeElement === first) {
                            e.preventDefault();
                            last.focus();
                        } else if (!e.shiftKey && document.activeElement === last) {
                            e.preventDefault();
                            first.focus();
                        }
                    }
                }
            }["ModalWrapper.useEffect.handleDialogKeyDown"];
            const handleDialogClick = {
                "ModalWrapper.useEffect.handleDialogClick": (e)=>{
                    if (e.target === dialog) {
                        onClose();
                        if (openerRef.current && typeof openerRef.current.focus === 'function') {
                            const opener = openerRef.current;
                            setTimeout({
                                "ModalWrapper.useEffect.handleDialogClick": ()=>opener.focus()
                            }["ModalWrapper.useEffect.handleDialogClick"], 0);
                        }
                    }
                }
            }["ModalWrapper.useEffect.handleDialogClick"];
            dialog.addEventListener('keydown', handleDialogKeyDown);
            dialog.addEventListener('click', handleDialogClick);
            return ({
                "ModalWrapper.useEffect": ()=>{
                    dialog.removeEventListener('keydown', handleDialogKeyDown);
                    dialog.removeEventListener('click', handleDialogClick);
                    if (openerRef.current && typeof openerRef.current.focus === 'function') {
                        const opener = openerRef.current;
                        setTimeout({
                            "ModalWrapper.useEffect": ()=>opener.focus()
                        }["ModalWrapper.useEffect"], 0);
                    }
                }
            })["ModalWrapper.useEffect"];
        }
    }["ModalWrapper.useEffect"], [
        isOpen,
        onClose,
        bodyId,
        titleId
    ]);
    if (!isOpen) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dialog", {
        ref: dialogRef,
        className: "bg-transparent p-0 m-0 w-full h-full max-w-full max-h-full backdrop:bg-black/75 backdrop:backdrop-blur-sm fixed inset-0 flex items-center justify-center z-50",
        onClose: onClose,
        "aria-labelledby": titleId,
        "aria-describedby": bodyId,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$motion$2f$dist$2f$es$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["motion"].div, {
            initial: {
                opacity: 0,
                scale: 0.96,
                y: 8
            },
            animate: {
                opacity: 1,
                scale: 1,
                y: 0
            },
            exit: {
                opacity: 0,
                scale: 0.96,
                y: 8
            },
            transition: {
                duration: 0.15,
                ease: [
                    0.16,
                    1,
                    0.3,
                    1
                ]
            },
            className: `bg-[var(--desk-surface-raised)] border border-[var(--desk-border)] shadow-[0_20px_60px_rgba(0,0,0,0.6)] p-4 rounded-[2px] flex flex-col gap-3 select-none text-[var(--text-heading)] transition-colors duration-150 max-h-[88vh] max-w-[calc(100vw-2rem)] ${maxWidth} ${className}`,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between border-b border-[var(--desk-border)] pb-2 shrink-0",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            id: titleId,
                            tabIndex: -1,
                            className: "font-sans font-semibold text-sm text-[var(--accent-gold)] tracking-normal m-0 outline-none",
                            children: [
                                "✦ ",
                                title
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ui/ModalWrapper.tsx",
                            lineNumber: 169,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>{
                                onClose();
                                if (openerRef.current && typeof openerRef.current.focus === 'function') {
                                    openerRef.current.focus();
                                }
                            },
                            className: "text-[var(--text-muted)] hover:text-[var(--accent-gold)] text-sm font-mono font-bold cursor-pointer transition-colors p-1",
                            "aria-label": "Close dialog",
                            children: "✕"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/ModalWrapper.tsx",
                            lineNumber: 172,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/ModalWrapper.tsx",
                    lineNumber: 168,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    id: bodyId,
                    "data-modal-body": true,
                    className: bodyClassName ?? 'flex flex-col gap-3 flex-1 min-h-0 overflow-y-auto',
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/ModalWrapper.tsx",
                    lineNumber: 187,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/ModalWrapper.tsx",
            lineNumber: 160,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/ModalWrapper.tsx",
        lineNumber: 153,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ModalWrapper, "s9F3cO0jkZ6H0KJtUzTVEN/7+5k=");
_c = ModalWrapper;
var _c;
__turbopack_context__.k.register(_c, "ModalWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/PanelSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PanelSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function PanelSection({ title, ariaLabel, description, icon, children, defaultOpen = true, storageKey, actions, className }) {
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "PanelSection.useState": ()=>{
            if (("TURBOPACK compile-time value", "object") !== 'undefined' && storageKey) {
                try {
                    const stored = localStorage.getItem(storageKey);
                    if (stored === 'open') return true;
                    if (stored === 'closed') return false;
                } catch  {
                // Fall back to defaultOpen if storage inaccessible
                }
            }
            return defaultOpen;
        }
    }["PanelSection.useState"]);
    const contentId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const descriptionId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const toggleOpen = ()=>{
        const newState = !isOpen;
        setIsOpen(newState);
        if (storageKey) {
            try {
                localStorage.setItem(storageKey, newState ? 'open' : 'closed');
            } catch  {
            // Disclosure controls still work when storage is unavailable.
            }
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])('flex flex-col w-full', description && 'border border-[var(--desk-border)] rounded-[2px] overflow-visible', className)),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])('flex items-center justify-between w-full select-none', isOpen ? 'bg-[var(--desk-surface-raised)]/60' : 'bg-[var(--surface-1)]', 'hover:bg-[var(--surface-2)] transition-colors duration-100 border-b border-[var(--desk-border)]', description ? 'px-2.5 py-2' : 'px-3 py-1.5'),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "flex-1 min-w-0 m-0",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: toggleOpen,
                            "aria-expanded": isOpen,
                            "aria-controls": contentId,
                            "aria-label": ariaLabel || title,
                            "aria-describedby": description ? descriptionId : undefined,
                            className: "w-full min-h-6 flex items-center gap-2 text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent-gold)] focus-visible:ring-inset py-0.5 rounded-[2px]",
                            children: [
                                icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    "aria-hidden": "true",
                                    className: "w-7 h-7 shrink-0 flex items-center justify-center rounded-[2px] bg-[var(--surface-3)] text-[var(--accent-gold)]",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                        name: icon,
                                        size: 14
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/PanelSection.tsx",
                                        lineNumber: 78,
                                        columnNumber: 169
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/PanelSection.tsx",
                                    lineNumber: 78,
                                    columnNumber: 20
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "min-w-0 flex-1 flex flex-col gap-0.5 font-sans",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs font-semibold text-[var(--text-heading)] tracking-normal",
                                            children: title
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ui/PanelSection.tsx",
                                            lineNumber: 80,
                                            columnNumber: 13
                                        }, this),
                                        description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            id: descriptionId,
                                            className: "text-[10px] font-normal leading-4 text-[var(--text-muted)]",
                                            children: description
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ui/PanelSection.tsx",
                                            lineNumber: 81,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/ui/PanelSection.tsx",
                                    lineNumber: 79,
                                    columnNumber: 11
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    "aria-hidden": "true",
                                    className: "text-[var(--text-muted)] text-[10px] w-[10px] inline-block shrink-0",
                                    children: isOpen ? '▾' : '▸'
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/PanelSection.tsx",
                                    lineNumber: 83,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ui/PanelSection.tsx",
                            lineNumber: 69,
                            columnNumber: 9
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PanelSection.tsx",
                        lineNumber: 68,
                        columnNumber: 9
                    }, this),
                    actions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center shrink-0 ml-2",
                        children: actions
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PanelSection.tsx",
                        lineNumber: 88,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/PanelSection.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: contentId,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(!isOpen ? 'hidden' : 'p-2.5 animate-in fade-in duration-150'),
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/PanelSection.tsx",
                lineNumber: 94,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/PanelSection.tsx",
        lineNumber: 59,
        columnNumber: 5
    }, this);
}
_s(PanelSection, "4BdY84Hr5BW9/jCX4SDWYnUruVo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = PanelSection;
var _c;
__turbopack_context__.k.register(_c, "PanelSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/PixiBunLogo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PixiBunLogo",
    ()=>PixiBunLogo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$BunMascot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/BunMascot.tsx [app-client] (ecmascript)");
'use client';
;
;
const PixiBunLogo = ({ size = 'md', showSubtitle = true, wordmarkClassName = '', className = '', style })=>{
    const sizeConfig = {
        sm: {
            tile: 'w-7 h-7 p-0.5',
            mascot: 18,
            title: 'text-xs tracking-wider',
            subtitle: 'text-[9px] mt-0.5',
            gap: 'gap-2'
        },
        md: {
            tile: 'w-8 h-8 p-0.5',
            mascot: 22,
            title: 'text-sm tracking-wider',
            subtitle: 'text-[10px] mt-0.5',
            gap: 'gap-2.5'
        },
        lg: {
            tile: 'w-10 h-10 p-1',
            mascot: 28,
            title: 'text-base tracking-widest',
            subtitle: 'text-xs mt-1',
            gap: 'gap-3'
        }
    }[size];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `inline-flex items-center ${sizeConfig.gap} select-none ${className}`,
        style: style,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `${sizeConfig.tile} flex items-center justify-center bg-[var(--desk-surface-raised)] border-2 border-[var(--desk-border)] rounded-[2px] shadow-sm shrink-0`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$BunMascot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BunMascot"], {
                    size: sizeConfig.mascot,
                    animate: true
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `flex flex-col leading-none ${wordmarkClassName}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `font-display font-bold ${sizeConfig.title} text-[var(--text-heading)]`,
                        children: "PIXIBUN"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    showSubtitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `font-mono tracking-tight text-[var(--accent-gold)] ${sizeConfig.subtitle}`,
                        children: "ATELIER"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
                        lineNumber: 65,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = PixiBunLogo;
var _c;
__turbopack_context__.k.register(_c, "PixiBunLogo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/StudioNumberInput.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StudioNumberInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function StudioNumberInput({ label, value, min, max, step = 1, onChange, unit = '', id, disabled, className = '' }) {
    _s();
    const autoId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const inputId = id || `studio-number-${autoId}`;
    const [localValue, setLocalValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value.toString());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudioNumberInput.useEffect": ()=>{
            setLocalValue(value.toString());
        }
    }["StudioNumberInput.useEffect"], [
        value
    ]);
    const commitValue = (valStr)=>{
        if (valStr === '') {
            setLocalValue(value.toString());
            return;
        }
        let parsed = parseFloat(valStr);
        if (isNaN(parsed)) {
            setLocalValue(value.toString());
            return;
        }
        if (min !== undefined && parsed < min) parsed = min;
        if (max !== undefined && parsed > max) parsed = max;
        setLocalValue(parsed.toString());
        onChange(parsed);
    };
    const handleBlur = ()=>{
        commitValue(localValue);
    };
    const handleKeyDown = (e)=>{
        if (e.key === 'Enter') {
            e.preventDefault();
            commitValue(localValue);
        }
    };
    const increment = ()=>{
        let current = parseFloat(localValue);
        if (isNaN(current)) current = value;
        commitValue((current + step).toString());
    };
    const decrement = ()=>{
        let current = parseFloat(localValue);
        if (isNaN(current)) current = value;
        commitValue((current - step).toString());
    };
    const isAtMin = min !== undefined && value <= min;
    const isAtMax = max !== undefined && value >= max;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex items-center justify-between h-[28px] w-full gap-[var(--space-3)] ${disabled ? 'opacity-50 pointer-events-none' : ''} ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: inputId,
                className: "font-sans text-[11px] text-[var(--text-body)] shrink-0",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/StudioNumberInput.tsx",
                lineNumber: 82,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center h-full bg-[var(--surface-2)] border border-[var(--desk-border)] rounded-[var(--radius-sm)] overflow-hidden focus-within:ring-2 focus-within:ring-[var(--accent-gold)] focus-within:border-[var(--accent-gold)]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        tabIndex: -1,
                        disabled: disabled || isAtMin,
                        onClick: decrement,
                        className: "h-full px-2 flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--text-heading)] hover:bg-[var(--surface-3)] disabled:opacity-50 transition-colors cursor-pointer",
                        "aria-label": "Decrease value",
                        children: "-"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/StudioNumberInput.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative h-full flex items-center bg-[var(--surface-1)]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                id: inputId,
                                type: "number",
                                value: localValue,
                                disabled: disabled,
                                onChange: (e)=>setLocalValue(e.target.value),
                                onBlur: handleBlur,
                                onKeyDown: handleKeyDown,
                                min: min,
                                max: max,
                                step: step,
                                className: `w-[40px] h-full bg-transparent border-none text-center font-mono text-[10px] font-bold text-[var(--text-heading)] focus:outline-none focus:ring-0 p-0 m-0 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none [appearance:textfield] ${unit ? 'pr-4' : ''}`
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/StudioNumberInput.tsx",
                                lineNumber: 97,
                                columnNumber: 11
                            }, this),
                            unit && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "absolute right-1 pointer-events-none font-mono text-[10px] font-bold text-[var(--text-muted)]",
                                children: unit
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/StudioNumberInput.tsx",
                                lineNumber: 111,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/StudioNumberInput.tsx",
                        lineNumber: 96,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        tabIndex: -1,
                        disabled: disabled || isAtMax,
                        onClick: increment,
                        className: "h-full px-2 flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--text-heading)] hover:bg-[var(--surface-3)] disabled:opacity-50 transition-colors cursor-pointer",
                        "aria-label": "Increase value",
                        children: "+"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/StudioNumberInput.tsx",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/StudioNumberInput.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/StudioNumberInput.tsx",
        lineNumber: 81,
        columnNumber: 5
    }, this);
}
_s(StudioNumberInput, "Hkgp5twdn+Qgy764LmVkp4hI6W4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = StudioNumberInput;
var _c;
__turbopack_context__.k.register(_c, "StudioNumberInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/StudioSelect.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StudioSelect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function StudioSelect({ label, value, options, onChange, id, disabled, className = '' }) {
    _s();
    const autoId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const selectId = id || `studio-select-${autoId}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex items-center justify-between h-[28px] w-full gap-[var(--space-3)] ${disabled ? 'opacity-50 pointer-events-none' : ''} ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: selectId,
                className: "font-sans text-[11px] text-[var(--text-body)] shrink-0",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/StudioSelect.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                id: selectId,
                value: value,
                disabled: disabled,
                onChange: (e)=>onChange(e.target.value),
                className: "h-full bg-[var(--surface-2)] border border-[var(--desk-border)] text-[var(--text-heading)] font-sans text-[11px] px-2 py-0 rounded-[var(--radius-sm)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent-gold)] focus-visible:border-[var(--accent-gold)]",
                children: options.map((opt)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        value: opt.value,
                        children: opt.label
                    }, opt.value, false, {
                        fileName: "[project]/src/components/ui/StudioSelect.tsx",
                        lineNumber: 45,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/StudioSelect.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/StudioSelect.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_s(StudioSelect, "c30GLqU4NaAI3XCSCLfDXteiTN8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = StudioSelect;
var _c;
__turbopack_context__.k.register(_c, "StudioSelect");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/StudioToggle.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StudioToggle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function StudioToggle({ label, checked, onChange, id, disabled, className = '' }) {
    _s();
    const autoId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const toggleId = id || `studio-toggle-${autoId}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex items-center justify-between h-[28px] w-full gap-[var(--space-3)] ${disabled ? 'opacity-50 pointer-events-none' : ''} ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: toggleId,
                className: "font-sans text-[11px] text-[var(--text-body)] shrink-0 cursor-pointer",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/StudioToggle.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative inline-flex items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "checkbox",
                        id: toggleId,
                        checked: checked,
                        disabled: disabled,
                        onChange: (e)=>onChange(e.target.checked),
                        className: "sr-only peer"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/StudioToggle.tsx",
                        lineNumber: 31,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        tabIndex: -1,
                        "aria-hidden": "true",
                        disabled: disabled,
                        onClick: ()=>onChange(!checked),
                        className: `relative inline-flex h-[16px] w-[28px] shrink-0 cursor-pointer items-center rounded-full transition-colors duration-200 ease-in-out peer-focus-visible:ring-2 peer-focus-visible:ring-[var(--accent-gold)] peer-focus-visible:ring-offset-2 peer-focus-visible:ring-offset-[var(--surface-1)] ${checked ? 'bg-[var(--accent-gold)]' : 'bg-[var(--desk-border)]'}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: `pointer-events-none inline-block h-[12px] w-[12px] transform rounded-full shadow transition duration-200 ease-in-out ${checked ? 'translate-x-[14px] bg-[var(--text-heading)]' : 'translate-x-[2px] bg-[var(--text-muted)]'}`
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/StudioToggle.tsx",
                            lineNumber: 49,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/StudioToggle.tsx",
                        lineNumber: 39,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/StudioToggle.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/StudioToggle.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
_s(StudioToggle, "c30GLqU4NaAI3XCSCLfDXteiTN8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = StudioToggle;
var _c;
__turbopack_context__.k.register(_c, "StudioToggle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/StudioTooltip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StudioTooltip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function StudioTooltip({ content, shortcut, children, position = 'top', delay = 400, disabled = false }) {
    _s();
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const timeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const handleMouseEnter = ()=>{
        if (disabled) return;
        // Hover followed by focus must share one timer; an older timer could
        // otherwise reopen a tooltip after the pointer and focus have left.
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        timeoutRef.current = setTimeout(()=>{
            timeoutRef.current = null;
            setIsVisible(true);
        }, delay);
    };
    const handleMouseLeave = ()=>{
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
            timeoutRef.current = null;
        }
        setIsVisible(false);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudioTooltip.useEffect": ()=>{
            return ({
                "StudioTooltip.useEffect": ()=>{
                    if (timeoutRef.current) clearTimeout(timeoutRef.current);
                }
            })["StudioTooltip.useEffect"];
        }
    }["StudioTooltip.useEffect"], []);
    const positionClasses = {
        top: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
        bottom: 'top-full left-1/2 -translate-x-1/2 mt-2',
        left: 'right-full top-1/2 -translate-y-1/2 mr-2',
        right: 'left-full top-1/2 -translate-y-1/2 ml-2'
    }[position];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative inline-flex",
        onMouseEnter: handleMouseEnter,
        onMouseLeave: handleMouseLeave,
        onFocus: handleMouseEnter,
        onBlur: handleMouseLeave,
        "aria-describedby": isVisible && !disabled ? id : undefined,
        children: [
            children,
            isVisible && !disabled && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: id,
                role: "tooltip",
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])('absolute z-50 pointer-events-none whitespace-nowrap flex items-center gap-2', 'bg-[var(--surface-3)] border border-[var(--desk-border)] rounded-[var(--radius-md)]', 'text-[var(--text-heading)] font-sans text-[11px]', 'px-[var(--space-3)] py-[var(--space-2)]', 'shadow-[0_2px_8px_rgba(0,0,0,0.3)]', 'transition-opacity duration-150 ease-out', 'motion-reduce:transition-none', positionClasses)),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: content
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/StudioTooltip.tsx",
                        lineNumber: 87,
                        columnNumber: 11
                    }, this),
                    shortcut && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("kbd", {
                        className: "bg-[var(--surface-2)] text-[var(--text-muted)] font-mono text-[10px] px-1 rounded-[var(--radius-sm)] border border-[var(--desk-border)]",
                        children: shortcut
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/StudioTooltip.tsx",
                        lineNumber: 89,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/StudioTooltip.tsx",
                lineNumber: 71,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/StudioTooltip.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
_s(StudioTooltip, "AmvGr26wJceCcs7jkmogGhtmx4Q=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = StudioTooltip;
var _c;
__turbopack_context__.k.register(_c, "StudioTooltip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/TactileButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TactileButton",
    ()=>TactileButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$motion$2f$dist$2f$es$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/motion/dist/es/react.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const TactileButton = /*#__PURE__*/ _s(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = _s(({ variant = 'default', size = 'md', active = false, imageSrc, imageAlt, children, className, disabled, ...props }, ref)=>{
    _s();
    const shouldReduceMotion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"])();
    // Resolve active state whether passed via `active` prop or `variant="active"`
    const isSelected = Boolean(active || variant === 'active');
    const isImageButton = Boolean(imageSrc);
    // Pixel-scaled sizing (sleek & compact)
    const sizeClasses = {
        'icon-sm': 'w-7 h-7 p-1 flex items-center justify-center text-xs',
        'icon': 'w-9 h-9 p-1 flex items-center justify-center text-sm',
        'sm': 'px-2.5 py-0.5 text-xs font-medium h-7',
        'md': 'px-3.5 py-1.5 text-sm font-medium h-9',
        'lg': 'px-5 py-2.5 text-base font-semibold h-11'
    }[size];
    // Alabaster, Thistle, Plum, and Wisteria theme styling
    const variantClasses = isImageButton ? isSelected ? 'bg-transparent border-0 p-0 rounded-[2px] ring-2 ring-[var(--accent-gold)] shadow-[0_0_8px_rgba(240,190,124,0.55)]' : 'bg-transparent border-0 p-0 shadow-none' : ({
        default: isSelected ? 'pixel-tactile-btn bg-[var(--surface-3)] text-[var(--accent-gold)] border-[var(--accent-gold)] shadow-[inset_1px_1px_0_rgba(229,169,98,0.2),0_1px_0px_var(--btn-shadow)]' : 'pixel-tactile-btn tactile-motion-btn text-[var(--text-heading)] border-[var(--desk-border)]',
        tactile: isSelected ? 'pixel-tactile-btn bg-[var(--surface-3)] text-[var(--accent-gold)] border-[var(--accent-gold)] shadow-[inset_1px_1px_0_rgba(229,169,98,0.2),0_1px_0px_var(--btn-shadow)]' : 'pixel-tactile-btn tactile-motion-btn text-[var(--btn-text)] border-[var(--btn-border)]',
        primary: isSelected ? 'pixel-primary-btn tactile-motion-btn font-bold shadow-[inset_0_2px_4px_rgba(0,0,0,0.3)]' : 'pixel-primary-btn tactile-motion-btn',
        accent: isSelected ? 'pixel-tactile-btn bg-[var(--surface-3)] text-[var(--accent-gold)] border-[var(--accent-gold)] shadow-[inset_1px_1px_0_rgba(229,169,98,0.2),0_1px_0px_var(--btn-shadow)]' : 'pixel-tactile-btn tactile-motion-btn text-[var(--text-heading)] border-[var(--desk-border)] hover:bg-[var(--surface-2)]',
        danger: 'pixel-tactile-btn tactile-motion-btn bg-[var(--surface-0)] text-[var(--state-danger)] border-[var(--state-danger)]/40 shadow-[0_2px_0_var(--btn-shadow)] hover:bg-[var(--state-danger)] hover:text-[#ffffff] hover:border-[var(--state-danger)] active:shadow-[inset_1px_1px_0px_rgba(0,0,0,0.4)]',
        ghost: 'bg-transparent text-[var(--text-body)] border-transparent shadow-none hover:bg-[var(--state-hover)] hover:text-[var(--text-heading)]',
        toggle: isSelected ? 'pixel-tactile-btn bg-[var(--surface-2)] text-[var(--accent-gold)] border-[var(--accent-gold)] shadow-[inset_1px_1px_0_rgba(229,169,98,0.15),0_1px_0px_var(--btn-shadow)] font-bold' : 'pixel-tactile-btn tactile-motion-btn text-[var(--text-body)] border-[var(--btn-border)]',
        active: 'pixel-tactile-btn bg-[var(--surface-3)] text-[var(--accent-gold)] border-[var(--accent-gold)] shadow-[inset_1px_1px_0_rgba(229,169,98,0.2),0_1px_0px_var(--btn-shadow)]',
        inset: 'bg-[var(--surface-0)] text-[var(--text-body)] border-[var(--desk-border)] shadow-[inset_0_2px_4px_rgba(0,0,0,0.3)]',
        image: isSelected ? 'bg-transparent border-0 p-0 rounded-[2px] ring-2 ring-[var(--accent-gold)] shadow-[0_0_8px_rgba(240,190,124,0.55)]' : 'bg-transparent border-0 p-0 shadow-none'
    })[variant];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$motion$2f$dist$2f$es$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["motion"].button, {
        ref: ref,
        disabled: disabled,
        initial: "rest",
        animate: isSelected ? "active" : "rest",
        whileHover: disabled ? undefined : "hover",
        whileTap: disabled ? undefined : "tap",
        variants: {
            rest: {
                scale: 1,
                y: 0
            },
            active: {
                scale: 1,
                y: 0,
                transition: {
                    duration: 0.08,
                    ease: 'easeOut'
                }
            },
            hover: {
                scale: 1,
                y: shouldReduceMotion ? 0 : -1,
                transition: {
                    duration: 0.1,
                    ease: 'easeOut'
                }
            },
            tap: {
                scale: 1,
                y: shouldReduceMotion ? 0 : 1,
                transition: {
                    duration: 0.05,
                    ease: 'easeOut'
                }
            }
        },
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])('group relative select-none rounded-[2px] font-sans', 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent-gold)] focus-visible:ring-offset-1 focus-visible:ring-offset-[var(--desk-surface)]', !isImageButton && 'border', 'transition-colors duration-100', 'disabled:opacity-40 disabled:cursor-not-allowed', 'overflow-hidden', sizeClasses, variantClasses, className)),
        ...props,
        children: [
            imageSrc ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full h-full flex items-center justify-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: imageSrc,
                        alt: imageAlt ?? (props['aria-label'] || ''),
                        className: "w-full h-full object-contain pixelated pointer-events-none select-none transition-all duration-150",
                        style: {
                            imageRendering: 'pixelated',
                            filter: isSelected ? 'brightness(0.95) contrast(1.05)' : 'none'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/TactileButton.tsx",
                        lineNumber: 113,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    isSelected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-[var(--accent-gold)]/10 rounded-[2px] pointer-events-none"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/TactileButton.tsx",
                        lineNumber: 125,
                        columnNumber: 15
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/TactileButton.tsx",
                lineNumber: 112,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "relative z-0 flex items-center justify-center gap-1.5 leading-none",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/TactileButton.tsx",
                lineNumber: 129,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)),
            !disabled && variant !== 'ghost' && !shouldReduceMotion && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$motion$2f$dist$2f$es$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["motion"].div, {
                variants: {
                    rest: {
                        x: '-160%',
                        opacity: 0,
                        transition: {
                            duration: 0.45,
                            ease: [
                                0.25,
                                1,
                                0.5,
                                1
                            ]
                        }
                    },
                    active: {
                        x: '-160%',
                        opacity: 0
                    },
                    hover: {
                        x: '160%',
                        opacity: 1,
                        transition: {
                            duration: 0.55,
                            ease: [
                                0.25,
                                1,
                                0.5,
                                1
                            ]
                        }
                    },
                    tap: {
                        opacity: 0.25,
                        transition: {
                            duration: 0.1
                        }
                    }
                },
                className: "pointer-events-none absolute inset-0 z-10 h-[200%] w-[80%] -top-[50%]",
                style: {
                    background: 'linear-gradient(115deg, transparent 0%, rgba(220,171,223,0.15) 20%, rgba(255,255,255,0.75) 50%, rgba(220,171,223,0.15) 80%, transparent 100%)',
                    transformOrigin: 'center center'
                }
            }, void 0, false, {
                fileName: "[project]/src/components/ui/TactileButton.tsx",
                lineNumber: 136,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/TactileButton.tsx",
        lineNumber: 70,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
}, "C9xMdslg1Z8O8dPJqeHy1pZYGWc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"]
    ];
})), "C9xMdslg1Z8O8dPJqeHy1pZYGWc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$reduced$2d$motion$2f$use$2d$reduced$2d$motion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducedMotion"]
    ];
});
_c1 = TactileButton;
TactileButton.displayName = 'TactileButton';
var _c, _c1;
__turbopack_context__.k.register(_c, "TactileButton$React.forwardRef");
__turbopack_context__.k.register(_c1, "TactileButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/ToolMotionPreview.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "body": "ToolMotionPreview-module__Y6wixG__body",
  "card": "ToolMotionPreview-module__Y6wixG__card",
  "card-appear": "ToolMotionPreview-module__Y6wixG__card-appear",
  "caret": "ToolMotionPreview-module__Y6wixG__caret",
  "closeBtn": "ToolMotionPreview-module__Y6wixG__closeBtn",
  "content-crossfade": "ToolMotionPreview-module__Y6wixG__content-crossfade",
  "contentWrap": "ToolMotionPreview-module__Y6wixG__contentWrap",
  "description": "ToolMotionPreview-module__Y6wixG__description",
  "dontShowBtn": "ToolMotionPreview-module__Y6wixG__dontShowBtn",
  "footer": "ToolMotionPreview-module__Y6wixG__footer",
  "header": "ToolMotionPreview-module__Y6wixG__header",
  "headerActions": "ToolMotionPreview-module__Y6wixG__headerActions",
  "headerTitleGroup": "ToolMotionPreview-module__Y6wixG__headerTitleGroup",
  "iconWrap": "ToolMotionPreview-module__Y6wixG__iconWrap",
  "position": "ToolMotionPreview-module__Y6wixG__position",
  "preview-loop": "ToolMotionPreview-module__Y6wixG__preview-loop",
  "shortcutKey": "ToolMotionPreview-module__Y6wixG__shortcutKey",
  "stage": "ToolMotionPreview-module__Y6wixG__stage",
  "stageFrame": "ToolMotionPreview-module__Y6wixG__stageFrame",
  "timeline": "ToolMotionPreview-module__Y6wixG__timeline",
  "timelineFill": "ToolMotionPreview-module__Y6wixG__timelineFill",
  "titleText": "ToolMotionPreview-module__Y6wixG__titleText",
});
}),
"[project]/src/components/ui/ToolMotionPreview.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DRAWING_PREVIEWS",
    ()=>DRAWING_PREVIEWS,
    "DrawingPreviewContext",
    ()=>DrawingPreviewContext,
    "DrawingToolPreview",
    ()=>DrawingToolPreview,
    "DrawingToolsPreviewLayer",
    ()=>DrawingToolsPreviewLayer,
    "PIXITOOLS",
    ()=>PIXITOOLS,
    "PixiToolsPreviewLayer",
    ()=>PixiToolsPreviewLayer,
    "TOOL_PREVIEWS_CHANGED_EVENT",
    ()=>TOOL_PREVIEWS_CHANGED_EVENT,
    "TOOL_PREVIEWS_DISABLED_STORAGE_KEY",
    ()=>TOOL_PREVIEWS_DISABLED_STORAGE_KEY,
    "isToolPreviewsDisabled",
    ()=>isToolPreviewsDisabled,
    "pixiToolsPreviewForButton",
    ()=>pixiToolsPreviewForButton,
    "setToolPreviewsDisabled",
    ()=>setToolPreviewsDisabled
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolPreviewCanvas$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/ToolPreviewCanvas.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/ui/ToolMotionPreview.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const DRAWING_PREVIEWS = {
    pen: {
        title: 'Pen',
        group: 'Drawing',
        description: 'Draw crisp, pixel-perfect strokes and contours.',
        proTip: 'Hold Shift to connect endpoints in a straight line.',
        scene: 'stroke',
        shortcut: 'B',
        icon: 'pen'
    },
    curve: {
        title: 'Bézier Curve',
        group: 'Drawing',
        description: 'Shape a smooth curved pixel arc with control handles.',
        proTip: 'Click two endpoints, then drag the middle handle to bend.',
        scene: 'curve',
        shortcut: 'C',
        icon: 'curve'
    },
    eraser: {
        title: 'Eraser',
        group: 'Drawing',
        description: 'Remove pixels to reveal transparency or underlying layers.',
        proTip: 'Use [ and ] to resize, or right-click to quick-erase.',
        scene: 'erase',
        shortcut: 'E',
        icon: 'eraser'
    },
    bucket: {
        title: 'Flood Fill',
        group: 'Drawing',
        description: 'Fill a connected bounded region with solid color.',
        proTip: 'Ensure outlines are closed to prevent color leakage.',
        scene: 'fill',
        shortcut: 'G',
        icon: 'bucket'
    },
    dither: {
        title: 'Dither Brush',
        group: 'Drawing',
        description: 'Blend shades smoothly with retro checkerboard stippling.',
        proTip: 'Eliminates banding between two tones without adding new palette entries.',
        scene: 'dither',
        shortcut: 'D',
        icon: 'dither'
    },
    'color-replace': {
        title: 'Color Replace',
        group: 'Drawing',
        description: 'Swap one palette color across your artwork instantly.',
        proTip: 'Click the source color to swap it with your active color.',
        scene: 'recolor',
        shortcut: 'R',
        icon: 'color-replace'
    },
    'erase-color': {
        title: 'Erase Sampled Color',
        group: 'Drawing',
        description: 'Erase only the sampled sketch color, protecting all lineart.',
        proTip: 'Lifts rough pencil sketches from underneath finished inks with zero damage.',
        scene: 'erase-color',
        shortcut: 'Shift + R',
        icon: 'erase-color'
    },
    'select-box': {
        title: 'Marquee Box',
        group: 'Selection',
        description: 'Drag out a rectangular selection.',
        proTip: 'Shift to add, Alt to subtract, Ctrl+C to copy pixels.',
        scene: 'select-box',
        shortcut: 'M',
        icon: 'select-box'
    },
    'select-lasso': {
        title: 'Lasso Select',
        group: 'Selection',
        description: 'Draw a freeform selection.',
        proTip: 'Trace around irregular shapes and release to close loop.',
        scene: 'select-lasso',
        shortcut: 'Q',
        icon: 'select-lasso'
    },
    'select-wand': {
        title: 'Magic Wand',
        group: 'Selection',
        description: 'Select neighboring pixels of the same color.',
        proTip: 'Click empty canvas to select all background transparency.',
        scene: 'select-wand',
        shortcut: 'W',
        icon: 'select-wand'
    },
    line: {
        title: 'Line',
        group: 'Geometry',
        description: 'Place a crisp, straight pixel line.',
        proTip: 'Hold Shift to snap to horizontal, vertical, or 45° angle.',
        scene: 'line',
        shortcut: 'L',
        icon: 'line'
    },
    'isometric-line': {
        title: '2:1 Iso Line',
        group: 'Geometry',
        description: 'Draw a stepped isometric line.',
        proTip: 'Classic 2:1 pixel ratio for tactics RPGs and dioramas.',
        scene: 'iso',
        shortcut: 'J',
        icon: 'isometric-line'
    },
    rectangle: {
        title: 'Rectangle',
        group: 'Geometry',
        description: 'Draw a pixel-perfect rectangle.',
        proTip: 'Hold Shift while dragging to constrain to a 1:1 square.',
        scene: 'rectangle',
        shortcut: 'U',
        icon: 'rectangle'
    },
    ellipse: {
        title: 'Ellipse',
        group: 'Geometry',
        description: 'Draw a pixel ellipse.',
        proTip: 'Hold Shift while dragging to draw a perfect circle.',
        scene: 'ellipse',
        shortcut: 'O',
        icon: 'ellipse'
    },
    'normal-chisel': {
        title: 'Normal Chisel',
        group: '2.5D Sculpt',
        description: 'Carve sloped 3D bevels onto flat 2D edges so dynamic lighting creates relief.',
        proTip: 'Beveled edges catch specular highlights and cast directional shadows when light moves.',
        scene: 'depth',
        shortcut: 'K',
        icon: 'chisel'
    },
    eyedropper: {
        title: 'Eyedropper',
        group: 'Utility',
        description: 'Pick a color from your artwork.',
        proTip: 'Hold Alt in any drawing tool to sample colors instantly.',
        scene: 'eyedropper',
        shortcut: 'I',
        icon: 'eyedropper'
    }
};
const PIXITOOLS = [
    [
        /bake light|apply lighting/i,
        {
            title: 'Bake Lighting',
            group: 'AI & Shading',
            description: 'Bake directional light and shadow tones permanently onto your artwork.',
            proTip: 'Converts dynamic lighting preview into permanent layer pixels.',
            scene: 'bake-light',
            icon: 'sun'
        }
    ],
    [
        /place light bulb|analyze & light bulb|^light bulb$|preview lighting/i,
        {
            title: 'Lighting',
            group: 'AI & Shading',
            description: 'Move the light across a finished sprite.',
            proTip: 'Drag the light bulb gizmo to cast dynamic highlights & shadows.',
            scene: 'light',
            icon: 'lamp'
        }
    ],
    [
        /view normals|hide normals|3d map:|show surface directions|hide surface directions/i,
        {
            title: 'Normal Map',
            group: 'AI & Shading',
            description: 'See the surface directions used for lighting.',
            proTip: 'Converts 2D pixel silhouettes into illuminated 3D geometric surfaces.',
            scene: 'normal-map',
            icon: 'chisel'
        }
    ],
    [
        /bake normal map|new 3d normal layer/i,
        {
            title: 'Bake Normal Map',
            group: 'AI & Shading',
            description: 'Save 3D surface depth angles into a dedicated normal map layer.',
            proTip: 'Exports standard OpenGL tangent-space normal maps for 3D game engines.',
            scene: 'bake-normal',
            icon: 'export'
        }
    ],
    [
        /specular glint/i,
        {
            title: 'Specular Glint',
            group: 'AI & Shading',
            description: 'Cast sharp 3D specular light reflections matching your scene light.',
            proTip: 'Calculates Blinn-Phong surface reflections to add brilliant metallic and gemstone highlights.',
            scene: 'glow',
            icon: 'sparkles'
        }
    ],
    [
        /sel.out/i,
        {
            title: 'Selective Outline',
            group: 'AI & Shading',
            description: 'Replace harsh black borders with light-aware edge colors.',
            proTip: 'Softens sprite edges to blend harmoniously with backgrounds like professional pixel art.',
            scene: 'sel-out',
            icon: 'sparkles'
        }
    ],
    [
        /chisel bevel|^paint raised edges$/i,
        {
            title: 'Chisel Bevel',
            group: '2.5D Sculpt',
            description: 'Carve sloped 3D bevels onto flat 2D edges so dynamic lighting creates relief.',
            proTip: 'Generates embossed relief bevels that react dynamically to light.',
            scene: 'depth',
            icon: 'chisel'
        }
    ],
    [
        /add floor shadow|cast ground shadow|render cast shadow|analyze & cast shadow/i,
        {
            title: 'Ground Shadow',
            group: 'AI & Shading',
            description: 'Cast the sprite’s silhouette onto the floor.',
            proTip: 'Raymarches realistic contact shadows anchored to character feet.',
            scene: 'shadow',
            icon: 'sun'
        }
    ],
    [
        /repeat preview/i,
        {
            title: 'Repeat Preview',
            group: 'Tileset Engine',
            description: 'Inspect a selected tile repeated in both directions.',
            proTip: 'Edit the selected tile on the canvas to improve visible seams.',
            scene: 'seamless',
            icon: 'grid'
        }
    ],
    [
        /slice into unique tiles/i,
        {
            title: 'Tile Slicer',
            group: 'Tileset Engine',
            description: 'Slice artwork into unique grid tiles and export a 2D tilemap.',
            proTip: 'Deconstructs sprites into reusable non-redundant tile matrices.',
            scene: 'tiles',
            icon: 'grid'
        }
    ],
    [
        /shade 47-blob contours/i,
        {
            title: '47-Blob Contours',
            group: 'Tileset Engine',
            description: 'Shade contour pixels using 47-blob neighbor masks.',
            proTip: 'Creates a separate visible contour layer.',
            scene: 'autotile',
            icon: 'grid-iso'
        }
    ],
    [
        /smooth jaggies|de-jaggy/i,
        {
            title: 'Smooth Jaggies',
            group: 'Polish & Clean',
            description: 'Eliminate unsightly single-pixel L-corner stair-stepping along strokes.',
            proTip: 'Smooths jagged lines into fluid, professional 1-pixel steps.',
            scene: 'jaggies',
            icon: 'pen'
        }
    ],
    [
        /thin to 1px|skeleton thinning/i,
        {
            title: 'Thin to 1px',
            group: 'Polish & Clean',
            description: 'Trim thick pixel strokes down to crisp, razor-sharp 1px lines.',
            proTip: 'Tightens heavy strokes without breaking line continuity.',
            scene: 'thin',
            icon: 'pen'
        }
    ],
    [
        /erase stray pixels|remove stray pixels/i,
        {
            title: 'Erase Stray Pixels',
            group: 'Polish & Clean',
            description: 'Find and erase isolated single-pixel dots with no touching neighbors.',
            proTip: 'Cleans single-pixel orphan noise and accidental clicks.',
            scene: 'strays',
            icon: 'eraser'
        }
    ],
    [
        /scan artwork/i,
        {
            title: 'Scan Artwork',
            group: 'Polish & Clean',
            description: 'Scan the selected layer for faint pixels, detached specks, and thick dark edges.',
            proTip: 'Identifies cleanup candidates and previews changes before applying.',
            scene: 'clean',
            icon: 'sparkles'
        }
    ],
    [
        /apply cleanup|apply analyzed artwork cleanup/i,
        {
            title: 'Apply Cleanup',
            group: 'Polish & Clean',
            description: 'Batch-fix detected noise, harden semi-transparent edges, and crisp lines.',
            proTip: 'Executes analyzed cleanup optimizations across all frames.',
            scene: 'apply-cleanup',
            icon: 'sparkles'
        }
    ],
    [
        /rotate cleanly|rotSprite/i,
        {
            title: 'RotSprite Clean Rotation',
            group: 'Transform',
            description: 'Rotate pixel art at arbitrary angles without blurry bilinear smoothing.',
            proTip: 'RotSprite algorithm rotates without blurry bilinear smoothing.',
            scene: 'rotate',
            icon: 'rotate'
        }
    ],
    [
        /^sunset$/i,
        {
            title: 'Sunset Atmosphere',
            group: 'Palette',
            description: 'Grade sprite colors with warm golden hour tones, amber hues, and coral shadows.',
            proTip: 'Simulates evening sunlight with warm ambient temperature.',
            scene: 'mood-sunset',
            icon: 'palette'
        }
    ],
    [
        /^moonlight$/i,
        {
            title: 'Moonlight Atmosphere',
            group: 'Palette',
            description: 'Grade sprite colors with cool midnight blues, silver highlights, and deep indigo.',
            proTip: 'Transforms artwork into mystical nocturnal lighting.',
            scene: 'mood-moonlight',
            icon: 'palette'
        }
    ],
    [
        /^neon$/i,
        {
            title: 'Cyberpunk Neon',
            group: 'Palette',
            description: 'Grade sprite colors with vibrant synthwave magenta, electric cyan, and neon violet.',
            proTip: 'Creates vibrant retro-futuristic arcade game lighting.',
            scene: 'mood-neon',
            icon: 'palette'
        }
    ],
    [
        /atkinson dither/i,
        {
            title: 'Atkinson Dithering',
            group: 'Shading',
            description: 'Classic retro Macintosh dither pattern with high-contrast stippling.',
            proTip: 'Spreads 3/4 of quantization error to maintain crisp, high-contrast stippling.',
            scene: 'dither-atkinson',
            icon: 'dither'
        }
    ],
    [
        /smooth dither|riemersma/i,
        {
            title: 'Smooth Dithering',
            group: 'Shading',
            description: 'Smooth continuous-tone Hilbert-curve dither without directional banding.',
            proTip: 'Uses a space-filling curve with exponential decay for seamless shading.',
            scene: 'dither-smooth',
            icon: 'dither'
        }
    ],
    [
        /snap to active palette|quantize palette/i,
        {
            title: 'Snap to Palette',
            group: 'Palette',
            description: 'Match all layer colors to their closest swatches in the active palette.',
            proTip: 'Snaps off-palette pixels to the nearest swatch in the active palette.',
            scene: 'palette-snap',
            icon: 'palette'
        }
    ],
    [
        /harmonize accents/i,
        {
            title: 'Harmonize Accents',
            group: 'Palette',
            description: 'Add complementary and accent shades to your active palette in OKLCH.',
            proTip: 'Computes harmonious color chords to expand your current palette.',
            scene: 'palette-harmonize',
            icon: 'palette'
        }
    ],
    [
        /oklch ramp/i,
        {
            title: 'OKLCH Color Ramp',
            group: 'Palette',
            description: 'Generate a 5-step highlight and shadow color ramp in perceptual OKLCH space.',
            proTip: 'Maintains perceptual uniformity from darkest shadow to peak highlight.',
            scene: 'palette-ramp',
            icon: 'palette'
        }
    ],
    [
        /generate in.between frame|in.between frame/i,
        {
            title: 'In-Between Frame',
            group: 'Animation',
            description: 'Generate a smooth in-between breakdown frame between adjacent keyframes.',
            proTip: 'Generates onion-skinned breakdown frames for fluid animation.',
            scene: 'animate',
            icon: 'play'
        }
    ]
];
function pixiToolsPreviewForButton(button) {
    // Section headers and parameter toggles should not show an effect demo.
    if (button.hasAttribute('aria-controls')) return null;
    const label = `${button.getAttribute('aria-label') ?? ''} ${button.textContent ?? ''}`.trim();
    return PIXITOOLS.find(([pattern])=>pattern.test(label))?.[1] ?? null;
}
const TOOL_PREVIEWS_DISABLED_STORAGE_KEY = 'pixibun:tool-previews-disabled';
const TOOL_PREVIEWS_CHANGED_EVENT = 'pixibun:tool-previews-changed';
function isToolPreviewsDisabled() {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !window.localStorage) return false;
    try {
        return window.localStorage.getItem(TOOL_PREVIEWS_DISABLED_STORAGE_KEY) === 'true';
    } catch  {
        return false;
    }
}
function setToolPreviewsDisabled(disabled) {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !window.localStorage) return;
    try {
        if (disabled) {
            window.localStorage.setItem(TOOL_PREVIEWS_DISABLED_STORAGE_KEY, 'true');
        } else {
            window.localStorage.removeItem(TOOL_PREVIEWS_DISABLED_STORAGE_KEY);
        }
        window.dispatchEvent(new Event(TOOL_PREVIEWS_CHANGED_EVENT));
    } catch  {
    // Ignore storage quota errors
    }
}
// Global warmth tracker for instant cross-tool transitions
let globalLastDismissTime = 0;
let globalActiveSource = null;
const PREVIEW_WIDTH = 304;
const PREVIEW_HEIGHT = 290;
function PreviewCard({ definition, id, side, caretTop, isClosing, onClose, onDisable }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: id,
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card,
        role: "group",
        "aria-label": `${definition.title} preview`,
        "data-side": side,
        "data-closing": isClosing ? 'true' : undefined,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].caret,
                style: {
                    top: `${Math.max(10, Math.min(PREVIEW_HEIGHT - 16, caretTop))}px`
                },
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                lineNumber: 488,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contentWrap,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headerTitleGroup,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconWrap,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                            name: definition.icon || 'pen',
                                            size: 12
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                            lineNumber: 499,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                        lineNumber: 498,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].titleText,
                                        children: definition.title
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                        lineNumber: 501,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                lineNumber: 497,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headerActions,
                                children: [
                                    definition.shortcut && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("kbd", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].shortcutKey,
                                        children: definition.shortcut
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                        lineNumber: 506,
                                        columnNumber: 15
                                    }, this),
                                    definition.secondaryShortcut && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("kbd", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].shortcutKey,
                                        children: definition.secondaryShortcut
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                        lineNumber: 509,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].closeBtn,
                                        "aria-label": "Close tool preview",
                                        onClick: onClose,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            "aria-hidden": "true",
                                            children: "✕"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                            lineNumber: 517,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                        lineNumber: 511,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                lineNumber: 504,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                        lineNumber: 496,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].stageFrame,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].stage,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolPreviewCanvas$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToolPreviewCanvas"], {
                                    scene: definition.scene
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                    lineNumber: 525,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                lineNumber: 524,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].timeline,
                                "aria-hidden": "true",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].timelineFill
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                    lineNumber: 529,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                lineNumber: 528,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                        lineNumber: 523,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].body,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].description,
                                children: definition.description
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                lineNumber: 535,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footer,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dontShowBtn,
                                    onClick: onDisable,
                                    children: "Don't show again"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                    lineNumber: 537,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                                lineNumber: 536,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                        lineNumber: 534,
                        columnNumber: 9
                    }, this)
                ]
            }, definition.title, true, {
                fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
                lineNumber: 494,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
        lineNumber: 479,
        columnNumber: 5
    }, this);
}
_c = PreviewCard;
function usePreviewController(side) {
    _s();
    const [active, setActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const pending = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const hideTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const originalTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const originalDescription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const version = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const cancelHide = ()=>{
        if (hideTimer.current) {
            clearTimeout(hideTimer.current);
            hideTimer.current = null;
        }
    };
    const cancelPending = ()=>{
        if (pending.current) {
            clearTimeout(pending.current.timer);
            pending.current = null;
        }
    };
    const restoreAttributes = ()=>{
        if (originalTitle.current) {
            originalTitle.current.source.setAttribute('title', originalTitle.current.value);
            originalTitle.current = null;
        }
        if (originalDescription.current) {
            const { source, value } = originalDescription.current;
            if (value === null) source.removeAttribute('aria-describedby');
            else source.setAttribute('aria-describedby', value);
            originalDescription.current = null;
        }
    };
    const hide = ()=>{
        cancelPending();
        cancelHide();
        restoreAttributes();
        if (globalActiveSource === active?.source) {
            globalActiveSource = null;
            globalLastDismissTime = Date.now();
        }
        setActive((prev)=>prev ? {
                ...prev,
                isClosing: true
            } : null);
        hideTimer.current = setTimeout(()=>{
            setActive(null);
        }, 120);
    };
    const explicitDismiss = ()=>{
        cancelPending();
        cancelHide();
        restoreAttributes();
        globalLastDismissTime = 0; // Reset warmth so it won't pop back immediately
        globalActiveSource = null;
        setActive(null);
    };
    const disablePreviews = ()=>{
        setToolPreviewsDisabled(true);
        hide();
    };
    const scheduleHide = ()=>{
        cancelPending();
        cancelHide();
        // 160ms grace window so user can mouse over into the card
        hideTimer.current = setTimeout(hide, 160);
    };
    const requestShow = (source, definition, isKeyboard = false)=>{
        if (isToolPreviewsDisabled()) return;
        cancelHide();
        if (active?.source === source && !active.isClosing) return;
        // Determine delay:
        // If actively open (gliding between tools): 0ms (immediate glide)!
        // If warm group (last 450ms): 30ms.
        // If keyboard focus: 60ms.
        // If cold hover: 260ms (prompt, comfortable, avoids flicker when brushing cursor).
        const isCurrentlyOpen = active !== null && !active.isClosing;
        const now = Date.now();
        const isWarm = isCurrentlyOpen || globalActiveSource !== null || now - globalLastDismissTime < 450;
        const delay = isKeyboard ? 60 : isCurrentlyOpen ? 0 : isWarm ? 30 : 260;
        // Remove any previous pending previews
        cancelPending();
        restoreAttributes();
        const title = source.getAttribute('title');
        if (title) {
            originalTitle.current = {
                source,
                value: title
            };
            source.removeAttribute('title');
        }
        const timer = setTimeout(()=>{
            if (isToolPreviewsDisabled()) return;
            pending.current = null;
            const box = source.getBoundingClientRect();
            const cardWidth = Math.min(PREVIEW_WIDTH, window.innerWidth - 24);
            const cardHeight = PREVIEW_HEIGHT;
            // Horizontal positioning
            const x = side === 'right' ? Math.min(window.innerWidth - cardWidth - 12, box.right + 8) : Math.max(12, box.left - cardWidth - 8);
            // Vertical positioning: vertically centered relative to the trigger button,
            // strictly clamped between top navigation rail (48px) and bottom workspace area.
            const buttonCenterY = box.top + box.height / 2;
            const idealY = buttonCenterY - cardHeight / 2;
            const minY = 48; // Below top AtelierRail to prevent header clipping
            const maxY = Math.max(minY, window.innerHeight - cardHeight - 20);
            const y = Math.max(minY, Math.min(maxY, idealY));
            const caretTop = buttonCenterY - y;
            const target = source instanceof HTMLButtonElement ? source : source.querySelector('button');
            if (target) {
                const value = target.getAttribute('aria-describedby');
                originalDescription.current = {
                    source: target,
                    value
                };
                target.setAttribute('aria-describedby', [
                    value,
                    id
                ].filter(Boolean).join(' '));
            }
            globalActiveSource = source;
            setActive((prev)=>({
                    definition,
                    x,
                    y,
                    caretTop,
                    source,
                    version: ++version.current,
                    isGliding: prev !== null && !prev.isClosing,
                    isClosing: false
                }));
        }, delay);
        pending.current = {
            source,
            timer
        };
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePreviewController.useEffect": ()=>{
            const onPrefChange = {
                "usePreviewController.useEffect.onPrefChange": ()=>{
                    if (isToolPreviewsDisabled()) hide();
                }
            }["usePreviewController.useEffect.onPrefChange"];
            window.addEventListener('storage', onPrefChange);
            window.addEventListener(TOOL_PREVIEWS_CHANGED_EVENT, onPrefChange);
            return ({
                "usePreviewController.useEffect": ()=>{
                    window.removeEventListener('storage', onPrefChange);
                    window.removeEventListener(TOOL_PREVIEWS_CHANGED_EVENT, onPrefChange);
                }
            })["usePreviewController.useEffect"];
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["usePreviewController.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePreviewController.useEffect": ()=>{
            if (!active) return;
            const onKey = {
                "usePreviewController.useEffect.onKey": (event)=>{
                    if (event.key === 'Escape') explicitDismiss();
                }
            }["usePreviewController.useEffect.onKey"];
            const onScroll = {
                "usePreviewController.useEffect.onScroll": (event)=>{
                    // If the scroll happened within the container of the active trigger button,
                    // re-anchor rather than abruptly destroying the preview
                    if (active?.source && event.target instanceof Node && event.target.contains(active.source)) {
                        const box = active.source.getBoundingClientRect();
                        const cardWidth = Math.min(PREVIEW_WIDTH, window.innerWidth - 24);
                        const cardHeight = PREVIEW_HEIGHT;
                        const x = side === 'right' ? Math.min(window.innerWidth - cardWidth - 12, box.right + 8) : Math.max(12, box.left - cardWidth - 8);
                        const buttonCenterY = box.top + box.height / 2;
                        const idealY = buttonCenterY - cardHeight / 2;
                        const minY = 48;
                        const maxY = Math.max(minY, window.innerHeight - cardHeight - 20);
                        const y = Math.max(minY, Math.min(maxY, idealY));
                        const caretTop = buttonCenterY - y;
                        setActive({
                            "usePreviewController.useEffect.onScroll": (prev)=>prev ? {
                                    ...prev,
                                    x,
                                    y,
                                    caretTop,
                                    isGliding: false
                                } : null
                        }["usePreviewController.useEffect.onScroll"]);
                        return;
                    }
                    hide();
                }
            }["usePreviewController.useEffect.onScroll"];
            window.addEventListener('keydown', onKey);
            window.addEventListener('resize', onScroll);
            window.addEventListener('scroll', onScroll, true);
            return ({
                "usePreviewController.useEffect": ()=>{
                    window.removeEventListener('keydown', onKey);
                    window.removeEventListener('resize', onScroll);
                    window.removeEventListener('scroll', onScroll, true);
                }
            })["usePreviewController.useEffect"];
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["usePreviewController.useEffect"], [
        active?.source,
        active?.x,
        active?.y
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePreviewController.useEffect": ()=>({
                "usePreviewController.useEffect": ()=>{
                    if (pending.current) clearTimeout(pending.current.timer);
                    if (hideTimer.current) clearTimeout(hideTimer.current);
                    if (originalTitle.current) originalTitle.current.source.setAttribute('title', originalTitle.current.value);
                    if (originalDescription.current) {
                        const { source, value } = originalDescription.current;
                        if (value === null) source.removeAttribute('aria-describedby');
                        else source.setAttribute('aria-describedby', value);
                    }
                }
            })["usePreviewController.useEffect"]
    }["usePreviewController.useEffect"], []);
    const popup = active && typeof document !== 'undefined' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].position,
        "data-gliding": active.isGliding ? 'true' : undefined,
        style: {
            left: active.x,
            top: active.y
        },
        onMouseEnter: cancelHide,
        onMouseLeave: scheduleHide,
        onFocus: cancelHide,
        onBlur: scheduleHide,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PreviewCard, {
            definition: active.definition,
            id: id,
            side: side,
            caretTop: active.caretTop,
            isClosing: active.isClosing,
            onClose: explicitDismiss,
            onDisable: disablePreviews
        }, void 0, false, {
            fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
            lineNumber: 780,
            columnNumber: 11
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
        lineNumber: 771,
        columnNumber: 9
    }, this), document.body) : null;
    return {
        requestShow,
        scheduleHide,
        popup
    };
}
_s(usePreviewController, "duiNjsFYHFAMQntjSrDVkbiNm7Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
const DrawingPreviewContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext(null);
function DrawingToolsPreviewLayer({ children }) {
    _s1();
    const controller = usePreviewController('right');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DrawingPreviewContext.Provider, {
        value: controller,
        children: [
            children,
            controller.popup
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
        lineNumber: 802,
        columnNumber: 5
    }, this);
}
_s1(DrawingToolsPreviewLayer, "fnifb5QTV13/fdb4OjbQgVyrW4c=", false, function() {
    return [
        usePreviewController
    ];
});
_c1 = DrawingToolsPreviewLayer;
function DrawingToolPreview({ toolId, children }) {
    _s2();
    const contextController = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(DrawingPreviewContext);
    const definition = DRAWING_PREVIEWS[toolId];
    if (contextController) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex",
            onMouseEnter: (event)=>contextController.requestShow(event.currentTarget, definition, false),
            onMouseLeave: contextController.scheduleHide,
            onFocus: (event)=>contextController.requestShow(event.currentTarget, definition, true),
            onBlur: contextController.scheduleHide,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
            lineNumber: 821,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StandaloneDrawingToolPreview, {
        toolId: toolId,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
        lineNumber: 833,
        columnNumber: 10
    }, this);
}
_s2(DrawingToolPreview, "QlpVawmje3APpoIUB010tHUAXcQ=");
_c2 = DrawingToolPreview;
function StandaloneDrawingToolPreview({ toolId, children }) {
    _s3();
    const controller = usePreviewController('right');
    const definition = DRAWING_PREVIEWS[toolId];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "inline-flex",
        onMouseEnter: (event)=>controller.requestShow(event.currentTarget, definition, false),
        onMouseLeave: controller.scheduleHide,
        onFocus: (event)=>controller.requestShow(event.currentTarget, definition, true),
        onBlur: controller.scheduleHide,
        children: [
            children,
            controller.popup
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
        lineNumber: 847,
        columnNumber: 5
    }, this);
}
_s3(StandaloneDrawingToolPreview, "fnifb5QTV13/fdb4OjbQgVyrW4c=", false, function() {
    return [
        usePreviewController
    ];
});
_c3 = StandaloneDrawingToolPreview;
function PixiToolsPreviewLayer({ children }) {
    _s4();
    const controller = usePreviewController('left');
    const onTarget = (target, isKeyboard = false)=>{
        if (!(target instanceof Element)) return;
        const button = target.closest('button');
        if (!(button instanceof HTMLButtonElement)) return;
        const definition = pixiToolsPreviewForButton(button);
        if (definition) controller.requestShow(button, definition, isKeyboard);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex-1 min-h-0 overflow-y-auto",
        onMouseOver: (event)=>onTarget(event.target, false),
        onMouseOut: (event)=>{
            const from = event.target instanceof Element ? event.target.closest('button') : null;
            const to = event.relatedTarget;
            if (from && (!(to instanceof Node) || !from.contains(to))) controller.scheduleHide();
        },
        onFocus: (event)=>onTarget(event.target, true),
        onBlur: controller.scheduleHide,
        children: [
            children,
            controller.popup
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/ToolMotionPreview.tsx",
        lineNumber: 872,
        columnNumber: 5
    }, this);
}
_s4(PixiToolsPreviewLayer, "fnifb5QTV13/fdb4OjbQgVyrW4c=", false, function() {
    return [
        usePreviewController
    ];
});
_c4 = PixiToolsPreviewLayer;
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "PreviewCard");
__turbopack_context__.k.register(_c1, "DrawingToolsPreviewLayer");
__turbopack_context__.k.register(_c2, "DrawingToolPreview");
__turbopack_context__.k.register(_c3, "StandaloneDrawingToolPreview");
__turbopack_context__.k.register(_c4, "PixiToolsPreviewLayer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/ToolPreviewCanvas.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ToolPreviewCanvas",
    ()=>ToolPreviewCanvas,
    "drawToolPreviewFrame",
    ()=>drawToolPreviewFrame
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
const W = 96;
const H = 54;
const DURATION = 2600;
const GOLD = '#f0be7c';
const RED = '#e85a70';
const BLUE = '#66c6e8';
const INK = '#271b37';
const WHITE = '#f8edf5';
function clamp(value) {
    return Math.max(0, Math.min(1, value));
}
function lerp(a, b, t) {
    return Math.round(a + (b - a) * t);
}
function pixel(ctx, x, y, color, size = 1) {
    ctx.fillStyle = color;
    ctx.fillRect(Math.round(x), Math.round(y), size, size);
}
function box(ctx, x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}
function line(ctx, x0, y0, x1, y1, color, width = 1) {
    let x = Math.round(x0);
    let y = Math.round(y0);
    const endX = Math.round(x1);
    const endY = Math.round(y1);
    const dx = Math.abs(endX - x);
    const dy = Math.abs(endY - y);
    const sx = x < endX ? 1 : -1;
    const sy = y < endY ? 1 : -1;
    let error = dx - dy;
    while(true){
        box(ctx, x, y, width, width, color);
        if (x === endX && y === endY) break;
        const twice = 2 * error;
        if (twice > -dy) {
            error -= dy;
            x += sx;
        }
        if (twice < dx) {
            error += dx;
            y += sy;
        }
    }
}
function pathPoint(points, progress) {
    const at = clamp(progress) * (points.length - 1);
    const index = Math.min(points.length - 2, Math.floor(at));
    return [
        lerp(points[index][0], points[index + 1][0], at - index),
        lerp(points[index][1], points[index + 1][1], at - index)
    ];
}
function path(ctx, points, progress, color, width = 1) {
    const at = clamp(progress) * (points.length - 1);
    for(let i = 0; i < Math.floor(at); i++){
        line(ctx, points[i][0], points[i][1], points[i + 1][0], points[i + 1][1], color, width);
    }
    const index = Math.min(points.length - 2, Math.floor(at));
    const end = pathPoint(points, progress);
    line(ctx, points[index][0], points[index][1], end[0], end[1], color, width);
}
function ants(ctx, points, t) {
    let step = Math.floor(t * 18);
    for(let i = 0; i < points.length - 1; i++){
        let x = points[i][0];
        let y = points[i][1];
        const [ex, ey] = points[i + 1];
        const dx = Math.abs(ex - x);
        const dy = Math.abs(ey - y);
        const sx = x < ex ? 1 : -1;
        const sy = y < ey ? 1 : -1;
        let error = dx - dy;
        while(true){
            pixel(ctx, x, y, step % 6 < 3 ? WHITE : INK);
            step++;
            if (x === ex && y === ey) break;
            const twice = 2 * error;
            if (twice > -dy) {
                error -= dy;
                x += sx;
            }
            if (twice < dx) {
                error += dx;
                y += sy;
            }
        }
    }
}
function cursor(ctx, x, y, pressed = false) {
    x = Math.round(x);
    y = Math.round(y);
    box(ctx, x - 4, y, 3, 1, WHITE);
    box(ctx, x + 2, y, 3, 1, WHITE);
    box(ctx, x, y - 4, 1, 3, WHITE);
    box(ctx, x, y + 2, 1, 3, WHITE);
    pixel(ctx, x, y, pressed ? GOLD : BLUE);
}
function backdrop(ctx) {
    box(ctx, 0, 0, W, H, '#120e1b');
    for(let y = 7; y < 47; y += 4){
        for(let x = 9; x < 89; x += 4){
            box(ctx, x, y, 4, 4, (x + y) / 4 % 2 ? '#21192d' : '#1a1425');
        }
    }
    box(ctx, 8, 6, 81, 1, '#40304f');
    box(ctx, 8, 47, 81, 1, '#40304f');
}
function outlineRect(ctx, x, y, w, h, color) {
    line(ctx, x, y, x + w, y, color);
    line(ctx, x + w, y, x + w, y + h, color);
    line(ctx, x + w, y + h, x, y + h, color);
    line(ctx, x, y + h, x, y, color);
}
function ellipse(ctx, cx, cy, rx, ry, color) {
    if (rx < 2 || ry < 2) return;
    for(let i = 0; i <= 80; i++){
        const angle = i / 80 * Math.PI * 2;
        pixel(ctx, cx + Math.cos(angle) * rx, cy + Math.sin(angle) * ry, color);
    }
}
function sampleSprite(ctx, cx = 48, cy = 27, style = {}) {
    const base = style.base ?? '#dfbfdb';
    const highlight = style.highlight ?? '#fff0ed';
    const shadow = style.shadow ?? '#9b78ab';
    const rows = [
        [
            -15,
            -12,
            -7
        ],
        [
            -14,
            -13,
            -6
        ],
        [
            -13,
            -13,
            -6
        ],
        [
            -12,
            -13,
            -6
        ],
        [
            -11,
            -13,
            -6
        ],
        [
            -10,
            -13,
            -6
        ],
        [
            -9,
            -13,
            -6
        ],
        [
            -8,
            -13,
            -6
        ],
        [
            -7,
            -13,
            -6
        ],
        [
            -6,
            -13,
            -6
        ],
        [
            -5,
            -14,
            14
        ],
        [
            -4,
            -15,
            15
        ],
        [
            -3,
            -16,
            16
        ],
        [
            -2,
            -16,
            16
        ],
        [
            -1,
            -16,
            16
        ],
        [
            0,
            -16,
            16
        ],
        [
            1,
            -16,
            16
        ],
        [
            2,
            -16,
            16
        ],
        [
            3,
            -16,
            16
        ],
        [
            4,
            -16,
            16
        ],
        [
            5,
            -16,
            16
        ],
        [
            6,
            -15,
            15
        ],
        [
            7,
            -14,
            14
        ],
        [
            8,
            -13,
            13
        ],
        [
            9,
            -12,
            12
        ],
        [
            10,
            -11,
            11
        ],
        [
            11,
            -9,
            9
        ],
        [
            12,
            -7,
            7
        ]
    ];
    const spanFor = (y, x)=>{
        if (y <= -6 && x > 0) return [
            6,
            13
        ];
        return rows.find(([row])=>row === y)?.slice(1);
    };
    for(let y = -15; y <= 12; y++){
        const spans = y <= -6 ? [
            [
                -13,
                -6
            ],
            [
                6,
                13
            ]
        ] : [
            spanFor(y, 0)
        ];
        for (const span of spans){
            if (!span) continue;
            const [left, right] = span;
            for(let x = left; x <= right; x++){
                const edge = x === left || x === right || y === -15 || y === 12;
                const litX = style.lightFromRight ? -x : x;
                let color = base;
                if (style.normal) {
                    const r = Math.round((x / 16 + 1) * 110 + 18);
                    const g = Math.round((-y / 15 + 1) * 100 + 25);
                    color = `rgb(${r},${g},220)`;
                } else if (edge) {
                    color = style.selout ? litX < 0 ? highlight : shadow : style.bevel ? litX < 0 ? GOLD : '#392c61' : style.outline ?? INK;
                } else if (!style.flat) {
                    color = litX < -5 && y < 5 ? highlight : litX > 6 || y > 6 ? shadow : base;
                    if (y <= -6 && x > left + 2 && x < right - 2) color = '#ef91b5';
                }
                pixel(ctx, cx + x, cy + y, color);
            }
        }
    }
    if (!style.normal) {
        box(ctx, cx - 8, cy + 1, 3, 4, INK);
        box(ctx, cx + 5, cy + 1, 3, 4, INK);
        pixel(ctx, cx - 7, cy + 1, WHITE);
        pixel(ctx, cx + 6, cy + 1, WHITE);
        box(ctx, cx - 12, cy + 5, 4, 2, style.flat ? base : '#ea93b2');
        box(ctx, cx + 8, cy + 5, 4, 2, style.flat ? base : '#ea93b2');
        box(ctx, cx - 1, cy + 6, 2, 2, '#a65a81');
        box(ctx, cx - 3, cy + 8, 2, 1, INK);
        box(ctx, cx + 1, cy + 8, 2, 1, INK);
    }
    if (style.glint) {
        box(ctx, cx - 10, cy - 12, 2, 7, WHITE);
        box(ctx, cx - 12, cy - 10, 6, 2, WHITE);
    }
}
function specks(ctx, visible = ()=>true) {
    const dots = [
        [
            24,
            19
        ],
        [
            71,
            15
        ],
        [
            74,
            36
        ],
        [
            28,
            38
        ]
    ];
    dots.forEach(([x, y], index)=>{
        if (visible(index)) pixel(ctx, x, y, index % 2 ? BLUE : RED);
    });
}
function wipeSprite(ctx, progress, before, after) {
    sampleSprite(ctx, 48, 27, before);
    if (progress > 0) {
        ctx.save();
        ctx.beginPath();
        ctx.rect(29, 12, Math.round(39 * clamp(progress)), 31);
        ctx.clip();
        sampleSprite(ctx, 48, 27, after);
        ctx.restore();
        if (progress < 1) box(ctx, 29 + Math.round(39 * progress), 12, 1, 31, GOLD);
    }
}
function swatches(ctx, colors, count = colors.length) {
    const left = Math.round((96 - colors.length * 10) / 2);
    colors.forEach((color, index)=>{
        if (index >= count) return;
        box(ctx, left + index * 10, 41, 8, 6, color);
        outlineRect(ctx, left + index * 10, 41, 8, 6, '#554660');
    });
}
function drawToolPreviewFrame(ctx, scene, t) {
    const action = clamp((t - 0.12) / 0.56);
    const done = t >= 0.68;
    let label = done ? 'RESULT' : action > 0 ? 'ACTION' : 'BEFORE';
    backdrop(ctx);
    switch(scene){
        case 'stroke':
            {
                const points = [
                    [
                        24,
                        35
                    ],
                    [
                        31,
                        30
                    ],
                    [
                        38,
                        31
                    ],
                    [
                        44,
                        22
                    ],
                    [
                        52,
                        25
                    ],
                    [
                        59,
                        16
                    ],
                    [
                        70,
                        20
                    ]
                ];
                path(ctx, points, action, GOLD, 2);
                if (!done) {
                    const [x, y] = pathPoint(points, action);
                    cursor(ctx, x, y, action > 0);
                }
                label = done ? 'PIXEL STROKE' : 'DRAG PEN';
                break;
            }
        case 'curve':
            {
                const start = [
                    22,
                    37
                ];
                const end = [
                    73,
                    35
                ];
                const handle = [
                    47,
                    lerp(34, 13, action)
                ];
                line(ctx, start[0], start[1], handle[0], handle[1], '#735a75');
                line(ctx, handle[0], handle[1], end[0], end[1], '#735a75');
                for(let i = 0; i <= 40; i++){
                    const u = i / 40;
                    pixel(ctx, (1 - u) * (1 - u) * start[0] + 2 * (1 - u) * u * handle[0] + u * u * end[0], (1 - u) * (1 - u) * start[1] + 2 * (1 - u) * u * handle[1] + u * u * end[1], GOLD);
                }
                box(ctx, start[0] - 1, start[1] - 1, 3, 3, BLUE);
                box(ctx, end[0] - 1, end[1] - 1, 3, 3, BLUE);
                box(ctx, handle[0] - 1, handle[1] - 1, 3, 3, WHITE);
                if (!done) cursor(ctx, handle[0], handle[1], action > 0);
                label = done ? 'CURVE SET' : 'DRAG HANDLE';
                break;
            }
        case 'erase':
            {
                box(ctx, 27, 19, 42, 16, RED);
                box(ctx, 27, 19, 42, 2, INK);
                const erased = Math.round(action * 32);
                for(let y = 23; y < 31; y++){
                    for(let x = 32; x < 32 + erased; x++){
                        box(ctx, x, y, 1, 1, (x + y) % 2 ? '#21192d' : '#1a1425');
                    }
                }
                if (!done) cursor(ctx, 32 + erased, 27, action > 0);
                label = done ? 'PIXELS REMOVED' : 'DRAG ERASER';
                break;
            }
        case 'fill':
            {
                outlineRect(ctx, 23, 16, 48, 24, WHITE);
                line(ctx, 61, 17, 61, 39, WHITE);
                box(ctx, 62, 17, 9, 23, BLUE);
                box(ctx, 24, 17, Math.round(37 * action), 23, RED);
                if (!done) cursor(ctx, 36, 28, action > 0);
                label = done ? 'CONNECTED AREA' : 'CLICK TO FILL';
                break;
            }
        case 'dither':
            {
                box(ctx, 24, 16, 25, 24, RED);
                box(ctx, 49, 16, 24, 24, '#354d9b');
                const through = Math.round(action * 24);
                for(let y = 17; y < 40; y++){
                    if (y - 16 > through) continue;
                    for(let x = 43; x <= 54; x++){
                        if ((x + y) % 2 === 0) pixel(ctx, x, y, x < 49 ? '#354d9b' : RED);
                    }
                }
                if (!done) cursor(ctx, 49, 16 + through, action > 0);
                label = done ? 'DITHER BLEND' : 'BRUSH BETWEEN';
                break;
            }
        case 'recolor':
            {
                const changed = action > 0.42;
                box(ctx, 27, 18, 16, 12, changed ? BLUE : RED);
                box(ctx, 54, 29, 16, 11, changed ? BLUE : RED);
                box(ctx, 56, 15, 9, 8, GOLD);
                if (!done) cursor(ctx, 35, 24, action > 0);
                label = changed ? 'BOTH COLORS SWAP' : 'CLICK SOURCE RED';
                break;
            }
        case 'erase-color':
            {
                sampleSprite(ctx, 48, 27, {
                    flat: true
                });
                const cyan = [
                    [
                        22,
                        19
                    ],
                    [
                        29,
                        25
                    ],
                    [
                        69,
                        21
                    ],
                    [
                        73,
                        36
                    ],
                    [
                        28,
                        38
                    ]
                ];
                cyan.forEach(([x, y], i)=>{
                    if (action < (i + 1) / cyan.length) box(ctx, x, y, 4, 2, BLUE);
                });
                if (!done) cursor(ctx, 24, 20, action > 0);
                label = done ? 'ONLY CYAN ERASED' : 'CLICK CYAN';
                break;
            }
        case 'select-box':
            {
                sampleSprite(ctx);
                const w = Math.round(action * 40);
                const h = Math.round(action * 31);
                if (done) ants(ctx, [
                    [
                        28,
                        11
                    ],
                    [
                        68,
                        11
                    ],
                    [
                        68,
                        42
                    ],
                    [
                        28,
                        42
                    ],
                    [
                        28,
                        11
                    ]
                ], t);
                else outlineRect(ctx, 28, 11, w, h, WHITE);
                if (!done) cursor(ctx, 28 + w, 11 + h, action > 0);
                label = done ? 'RECTANGLE SELECTED' : 'DRAG MARQUEE';
                break;
            }
        case 'select-lasso':
            {
                sampleSprite(ctx);
                pixel(ctx, 76, 35, RED, 2);
                const loop = [
                    [
                        47,
                        13
                    ],
                    [
                        37,
                        14
                    ],
                    [
                        31,
                        21
                    ],
                    [
                        32,
                        32
                    ],
                    [
                        40,
                        39
                    ],
                    [
                        52,
                        40
                    ],
                    [
                        63,
                        35
                    ],
                    [
                        67,
                        25
                    ],
                    [
                        61,
                        16
                    ],
                    [
                        54,
                        13
                    ],
                    [
                        47,
                        13
                    ]
                ];
                if (done) ants(ctx, loop, t);
                else {
                    path(ctx, loop, action, WHITE);
                    const [x, y] = pathPoint(loop, action);
                    cursor(ctx, x, y, action > 0);
                }
                label = done ? 'FREEFORM SELECTED' : 'TRACE ARTWORK';
                break;
            }
        case 'select-wand':
            {
                box(ctx, 22, 18, 21, 16, RED);
                box(ctx, 29, 14, 9, 4, RED);
                box(ctx, 57, 29, 13, 10, RED);
                box(ctx, 61, 17, 10, 7, BLUE);
                if (action > 0.35) ants(ctx, [
                    [
                        22,
                        18
                    ],
                    [
                        29,
                        18
                    ],
                    [
                        29,
                        14
                    ],
                    [
                        38,
                        14
                    ],
                    [
                        38,
                        18
                    ],
                    [
                        43,
                        18
                    ],
                    [
                        43,
                        34
                    ],
                    [
                        22,
                        34
                    ],
                    [
                        22,
                        18
                    ]
                ], t);
                if (!done) cursor(ctx, 32, 25, action > 0);
                label = done ? 'CONNECTED RED ONLY' : 'CLICK ONE REGION';
                break;
            }
        case 'line':
            {
                line(ctx, 23, 36, lerp(23, 72, action), lerp(36, 17, action), GOLD, 2);
                if (!done) cursor(ctx, lerp(23, 72, action), lerp(36, 17, action), action > 0);
                label = done ? 'STRAIGHT PIXELS' : 'DRAG LINE';
                break;
            }
        case 'iso':
            {
                const steps = Math.round(action * 23);
                for(let i = 0; i < steps; i++)box(ctx, 25 + i * 2, 16 + i, 2, 1, GOLD);
                if (!done) cursor(ctx, 25 + steps * 2, 16 + steps, action > 0);
                label = done ? '2:1 PIXEL STEPS' : 'DRAG ISO LINE';
                break;
            }
        case 'rectangle':
            {
                const w = Math.round(action * 49);
                const h = Math.round(action * 25);
                outlineRect(ctx, 23, 15, w, h, GOLD);
                if (!done) cursor(ctx, 23 + w, 15 + h, action > 0);
                label = done ? 'RECTANGLE' : 'DRAG CORNERS';
                break;
            }
        case 'ellipse':
            {
                const rx = Math.max(2, Math.round(action * 25));
                const ry = Math.max(2, Math.round(action * 14));
                ellipse(ctx, 48, 27, rx, ry, BLUE);
                if (!done) cursor(ctx, 48 + rx, 27 + ry, action > 0);
                label = done ? 'PIXEL ELLIPSE' : 'DRAG ELLIPSE';
                break;
            }
        case 'depth':
            {
                wipeSprite(ctx, action, {
                    flat: true
                }, {
                    bevel: true,
                    glint: true
                });
                if (!done) cursor(ctx, lerp(35, 60, action), 17, action > 0);
                label = done ? 'BEVELED SURFACE' : 'CARVE EDGE';
                break;
            }
        case 'eyedropper':
            {
                box(ctx, 26, 18, 18, 17, RED);
                box(ctx, 44, 18, 22, 17, BLUE);
                box(ctx, 66, 18, 7, 17, GOLD);
                box(ctx, 35, 42, 10, 6, action > 0.42 ? BLUE : RED);
                outlineRect(ctx, 35, 42, 10, 6, WHITE);
                if (!done) cursor(ctx, lerp(34, 54, action), 25, action > 0);
                label = done ? 'FOREGROUND: BLUE' : 'CLICK BLUE PIXEL';
                break;
            }
        case 'light':
            {
                const lightX = lerp(24, 74, action);
                const lightY = lerp(16, 18, action);
                sampleSprite(ctx, 48, 28, {
                    lightFromRight: lightX > 48
                });
                box(ctx, lightX - 2, lightY - 2, 5, 5, GOLD);
                pixel(ctx, lightX, lightY, WHITE);
                line(ctx, lightX, lightY + 3, 48, 24, '#a57d6d');
                if (!done) cursor(ctx, lightX, lightY, action > 0);
                label = done ? 'LIGHT FROM RIGHT' : 'DRAG LIGHT';
                break;
            }
        case 'bake-light':
            {
                wipeSprite(ctx, action, {
                    flat: true
                }, {
                    glint: true
                });
                label = done ? 'SHADING APPLIED' : 'BAKE LIGHT';
                break;
            }
        case 'normal-map':
            {
                wipeSprite(ctx, action, {}, {
                    normal: true
                });
                label = done ? 'NORMAL VIEW ONLY' : 'TOGGLE VIEW';
                break;
            }
        case 'bake-normal':
            {
                sampleSprite(ctx, 34, 27);
                box(ctx, 58, 12, 28, 32, '#29364d');
                outlineRect(ctx, 58, 12, 28, 32, BLUE);
                if (action > 0.2) {
                    const rows = Math.round((action - 0.2) / 0.8 * 17);
                    for(let y = 0; y < rows; y++){
                        for(let x = 0; x < 19; x++){
                            const r = Math.round(75 + x * 5);
                            const g = Math.round(70 + y * 7);
                            pixel(ctx, 62 + x, 18 + y, 'rgb(' + r + ',' + g + ',220)');
                        }
                    }
                }
                label = done ? 'NEW NORMAL LAYER' : 'BAKE NORMALS';
                break;
            }
        case 'glow':
            {
                wipeSprite(ctx, action, {}, {
                    glint: true
                });
                if (action > 0.6) {
                    box(ctx, 39, 20, 5, 1, WHITE);
                    box(ctx, 41, 18, 1, 5, WHITE);
                }
                label = done ? 'SPECULAR GLINT' : 'ADD REFLECTION';
                break;
            }
        case 'sel-out':
            {
                wipeSprite(ctx, action, {
                    outline: '#08070c'
                }, {
                    selout: true
                });
                label = done ? 'COLORED OUTLINE' : 'SOFTEN EDGE';
                break;
            }
        case 'shadow':
            {
                box(ctx, 10, 42, 76, 1, '#62516a');
                if (action > 0) {
                    const reach = Math.round(action * 19);
                    box(ctx, 42, 43, 20 + reach, 3, '#100c19');
                    box(ctx, 46, 41, 14 + reach, 2, '#181121');
                }
                sampleSprite(ctx, 42, 28);
                box(ctx, 23, 15, 4, 4, GOLD);
                label = done ? 'GROUND SHADOW' : 'CAST ON FLOOR';
                break;
            }
        case 'seamless':
            {
                const repeat = Math.max(1, Math.round(1 + action * 11));
                for(let i = 0; i < repeat; i++){
                    const col = i % 4;
                    const row = Math.floor(i / 4);
                    const x = 14 + col * 18;
                    const y = 10 + row * 12;
                    box(ctx, x + 1, y + 1, 16, 10, '#303957');
                    box(ctx, x + 3, y + 3, 3, 3, BLUE);
                    box(ctx, x + 11, y + 5, 3, 3, GOLD);
                    line(ctx, x + 7, y + 9, x + 10, y + 2, '#899bd0');
                }
                if (!done) outlineRect(ctx, 14, 10, 18, 12, GOLD);
                label = done ? 'CHECK TILE SEAMS' : 'REPEAT SELECTED TILE';
                break;
            }
        case 'tiles':
            {
                for(let i = 0; i < 9; i++){
                    const x = 14 + i % 3 * 11;
                    const y = 13 + Math.floor(i / 3) * 11;
                    box(ctx, x, y, 10, 10, i % 2 ? '#3f6974' : '#8c6b54');
                    box(ctx, x + 2, y + 2, 3, 3, i % 2 ? BLUE : GOLD);
                }
                if (action > 0.1) {
                    line(ctx, 53, 27, 60, 27, GOLD);
                    box(ctx, 61, 23, 3, 9, GOLD);
                    const count = Math.round(action * 2);
                    for(let i = 0; i < count; i++){
                        const x = 68 + i * 11;
                        box(ctx, x, 21, 10, 10, i ? '#3f6974' : '#8c6b54');
                        box(ctx, x + 2, 23, 3, 3, i ? BLUE : GOLD);
                    }
                }
                label = done ? '2 UNIQUE TILES' : 'SLICE & DEDUPE';
                break;
            }
        case 'autotile':
            {
                for(let row = 0; row < 3; row++){
                    for(let col = 0; col < 3; col++){
                        const x = 30 + col * 12;
                        const y = 9 + row * 12;
                        const land = col === 1 || row === 1;
                        box(ctx, x, y, 11, 11, land ? '#36836c' : '#60475a');
                        if (action > 0.45 && land) {
                            if (col === 0) box(ctx, x + 9, y, 2, 11, GOLD);
                            if (col === 2) box(ctx, x, y, 2, 11, GOLD);
                            if (row === 0) box(ctx, x, y + 9, 11, 2, GOLD);
                            if (row === 2) box(ctx, x, y, 11, 2, GOLD);
                        }
                    }
                }
                label = done ? 'EDGES CONNECT' : 'BUILD TRANSITIONS';
                break;
            }
        case 'clean':
            {
                sampleSprite(ctx);
                specks(ctx);
                const scanX = lerp(17, 79, action);
                if (action > 0.18) outlineRect(ctx, 22, 17, 4, 4, GOLD);
                if (action > 0.72) outlineRect(ctx, 69, 13, 4, 4, GOLD);
                if (!done) box(ctx, scanX, 12, 1, 32, BLUE);
                label = done ? 'ISSUES MARKED' : 'SCAN ONLY';
                break;
            }
        case 'apply-cleanup':
            {
                sampleSprite(ctx, 48, 27, {
                    flat: true
                });
                box(ctx, 46, 25, 3, 2, action > 0.6 ? RED : '#867b79');
                specks(ctx, (index)=>action < (index + 1) / 4);
                if (!done) box(ctx, lerp(18, 78, action), 12, 1, 32, '#7bd8ab');
                label = done ? 'ARTWORK CLEANED' : 'APPLY CLEANUP';
                break;
            }
        case 'jaggies':
            {
                const rough = [
                    [
                        22,
                        38
                    ],
                    [
                        30,
                        38
                    ],
                    [
                        30,
                        31
                    ],
                    [
                        38,
                        31
                    ],
                    [
                        38,
                        29
                    ],
                    [
                        47,
                        29
                    ],
                    [
                        47,
                        21
                    ],
                    [
                        55,
                        21
                    ],
                    [
                        55,
                        17
                    ],
                    [
                        70,
                        17
                    ]
                ];
                path(ctx, rough, 1, RED, 2);
                if (action > 0) {
                    ctx.save();
                    ctx.beginPath();
                    ctx.rect(18, 13, Math.round(action * 60), 32);
                    ctx.clip();
                    backdrop(ctx);
                    line(ctx, 22, 38, 70, 17, GOLD, 2);
                    ctx.restore();
                }
                label = done ? 'EVEN PIXEL STEPS' : 'SMOOTH CORNERS';
                break;
            }
        case 'thin':
            {
                const width = Math.max(1, 5 - Math.round(action * 4));
                line(ctx, 24, 34, 72, 19, RED, width);
                if (!done) box(ctx, lerp(22, 75, action), 14, 1, 27, BLUE);
                label = done ? '1PX LINE' : 'THIN STROKE';
                break;
            }
        case 'strays':
            {
                box(ctx, 40, 19, 14, 13, RED);
                box(ctx, 54, 26, 8, 6, RED);
                specks(ctx, (index)=>action < (index + 1) / 4);
                box(ctx, 24, 32, 2, 1, BLUE);
                if (!done) cursor(ctx, lerp(24, 73, action), 19, action > 0);
                label = done ? 'LOOSE DOTS GONE' : 'CHECK NEIGHBORS';
                break;
            }
        case 'rotate':
            {
                const angle = action * Math.PI / 4;
                const shape = [];
                for(let x = -8; x <= 8; x++)for(let y = -8; y <= -5; y++)shape.push([
                    x,
                    y
                ]);
                for(let x = -2; x <= 2; x++)for(let y = -4; y <= 9; y++)shape.push([
                    x,
                    y
                ]);
                shape.forEach(([x, y])=>{
                    const rx = Math.round(x * Math.cos(angle) - y * Math.sin(angle));
                    const ry = Math.round(x * Math.sin(angle) + y * Math.cos(angle));
                    pixel(ctx, 48 + rx, 27 + ry, GOLD);
                });
                box(ctx, 73, 37, 18, 9, INK);
                ctx.fillStyle = WHITE;
                ctx.font = '7px monospace';
                ctx.fillText(Math.round(action * 45) + '°', 76, 44);
                label = done ? 'CRISP 45° TURN' : 'ROTATE PIXELS';
                break;
            }
        case 'dither-atkinson':
        case 'dither-smooth':
            {
                const atkinson = scene === 'dither-atkinson';
                for(let y = 16; y < 40; y++){
                    for(let x = 24; x < 73; x++){
                        const shade = (x - 24) / 49;
                        let color = shade < 0.5 ? RED : '#354d9b';
                        if (x - 24 < action * 49) {
                            const threshold = atkinson ? (x * 3 + y * 5) % 8 / 8 : (x * 13 + y * 19 + (x ^ y)) % 17 / 17;
                            color = threshold < shade ? '#354d9b' : RED;
                        }
                        pixel(ctx, x, y, color);
                    }
                }
                if (!done) box(ctx, 24 + Math.round(action * 49), 15, 1, 26, GOLD);
                label = done ? atkinson ? 'ATKINSON DOTS' : 'SMOOTH DOTS' : 'DITHER SHADES';
                break;
            }
        case 'palette':
        case 'palette-snap':
            {
                wipeSprite(ctx, action, {
                    base: '#89736d',
                    highlight: '#b4a79a',
                    shadow: '#61565b'
                }, {});
                swatches(ctx, [
                    INK,
                    '#922a58',
                    RED,
                    '#ffb6ba',
                    WHITE
                ]);
                label = done ? 'ON-PALETTE COLORS' : 'MATCH SWATCHES';
                break;
            }
        case 'palette-harmonize':
            {
                sampleSprite(ctx);
                const colors = [
                    INK,
                    '#922a58',
                    RED,
                    GOLD,
                    '#66c6e8',
                    '#8fd596'
                ];
                swatches(ctx, colors, 3 + Math.round(action * 3));
                label = done ? 'ACCENTS ADDED' : 'EXPAND PALETTE';
                break;
            }
        case 'palette-ramp':
            {
                sampleSprite(ctx);
                const colors = [
                    '#351733',
                    '#7a2855',
                    RED,
                    '#ff9ca9',
                    '#ffe1df'
                ];
                swatches(ctx, colors, Math.max(1, Math.round(1 + action * 4)));
                label = done ? '5 SHADE RAMP' : 'GENERATE SHADES';
                break;
            }
        case 'mood-sunset':
        case 'mood-moonlight':
        case 'mood-neon':
            {
                const after = scene === 'mood-sunset' ? {
                    base: '#f18b53',
                    highlight: '#ffe0a2',
                    shadow: '#93405a'
                } : scene === 'mood-moonlight' ? {
                    base: '#5d88c9',
                    highlight: '#b9d7ee',
                    shadow: '#30385e'
                } : {
                    base: '#ed5ba6',
                    highlight: '#8de5f2',
                    shadow: '#6b328f'
                };
                wipeSprite(ctx, action, {}, after);
                label = done ? 'COLORS REGRADED' : 'APPLY COLOR MOOD';
                break;
            }
        case 'animate':
            {
                for(let i = 0; i < 3; i++){
                    const x = 12 + i * 27;
                    box(ctx, x, 14, 22, 27, '#293042');
                    outlineRect(ctx, x, 14, 22, 27, i === 1 ? GOLD : '#64738a');
                    const showMiddle = i !== 1 || action > 0.45;
                    if (showMiddle) {
                        const centerY = i === 0 ? 29 : i === 1 ? 25 : 21;
                        box(ctx, x + 6, centerY - 4, 9, 8, RED);
                        box(ctx, x + 7, centerY - 5, 7, 2, '#ffb6ba');
                    }
                    ctx.fillStyle = WHITE;
                    ctx.font = '6px monospace';
                    ctx.fillText(String(i + 1), x + 9, 47);
                }
                label = done ? 'MIDDLE FRAME MADE' : 'BETWEEN KEYFRAMES';
                break;
            }
        default:
            break;
    }
    return label;
}
function ToolPreviewCanvas({ scene }) {
    _s();
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ToolPreviewCanvas.useEffect": ()=>{
            const canvas = canvasRef.current;
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            if (!ctx) return;
            const currentCanvas = canvas;
            ctx.imageSmoothingEnabled = false;
            const render = {
                "ToolPreviewCanvas.useEffect.render": (progress)=>{
                    const label = drawToolPreviewFrame(ctx, scene, progress);
                    currentCanvas.parentElement?.setAttribute('data-step-label', label);
                }
            }["ToolPreviewCanvas.useEffect.render"];
            if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
                render(0.85);
                currentCanvas.dataset.previewPhase = 'result';
                return;
            }
            let frame = 0;
            const start = performance.now();
            const animate = {
                "ToolPreviewCanvas.useEffect.animate": (now)=>{
                    const progress = (now - start) % DURATION / DURATION;
                    render(progress);
                    currentCanvas.dataset.previewPhase = progress >= 0.68 ? 'result' : progress >= 0.12 ? 'action' : 'before';
                    frame = requestAnimationFrame(animate);
                }
            }["ToolPreviewCanvas.useEffect.animate"];
            frame = requestAnimationFrame(animate);
            return ({
                "ToolPreviewCanvas.useEffect": ()=>cancelAnimationFrame(frame)
            })["ToolPreviewCanvas.useEffect"];
        }
    }["ToolPreviewCanvas.useEffect"], [
        scene
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
        ref: canvasRef,
        width: W,
        height: H,
        "data-scene": scene,
        role: "img",
        "aria-label": scene.replaceAll('-', ' ') + ' animated tool demonstration',
        style: {
            imageRendering: 'pixelated'
        }
    }, void 0, false, {
        fileName: "[project]/src/components/ui/ToolPreviewCanvas.tsx",
        lineNumber: 664,
        columnNumber: 5
    }, this);
}
_s(ToolPreviewCanvas, "UJgi7ynoup7eqypjnwyX/s32POg=");
_c = ToolPreviewCanvas;
var _c;
__turbopack_context__.k.register(_c, "ToolPreviewCanvas");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_ui_1w6m7jk._.js.map