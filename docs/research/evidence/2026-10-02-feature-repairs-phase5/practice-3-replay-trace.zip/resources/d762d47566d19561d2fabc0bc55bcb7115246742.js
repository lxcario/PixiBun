(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/config/shortcuts.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CANONICAL_SHORTCUTS",
    ()=>CANONICAL_SHORTCUTS,
    "CANONICAL_TOOLS",
    ()=>CANONICAL_TOOLS,
    "TOOL_GROUPS",
    ()=>TOOL_GROUPS,
    "TOOL_METADATA_MAP",
    ()=>TOOL_METADATA_MAP
]);
const CANONICAL_TOOLS = [
    // Drawing
    {
        id: 'pen',
        label: 'Pen',
        shortcut: 'B',
        icon: 'pen',
        group: 'Drawing'
    },
    {
        id: 'curve',
        label: 'Bézier Curve',
        shortcut: 'C',
        icon: 'curve',
        group: 'Drawing'
    },
    {
        id: 'eraser',
        label: 'Eraser',
        shortcut: 'E',
        icon: 'eraser',
        group: 'Drawing'
    },
    {
        id: 'bucket',
        label: 'Flood Fill',
        shortcut: 'G',
        icon: 'bucket',
        group: 'Drawing'
    },
    {
        id: 'dither',
        label: 'Dither Brush',
        shortcut: 'D',
        icon: 'dither',
        group: 'Drawing'
    },
    {
        id: 'color-replace',
        label: 'Color Replace',
        shortcut: 'R',
        icon: 'color-replace',
        group: 'Drawing'
    },
    {
        id: 'erase-color',
        label: 'Erase Sampled Color',
        shortcut: 'Shift + R',
        icon: 'erase-color',
        group: 'Drawing'
    },
    // Selection
    {
        id: 'select-box',
        label: 'Marquee Box',
        shortcut: 'M',
        icon: 'select-box',
        group: 'Selection'
    },
    {
        id: 'select-lasso',
        label: 'Lasso Select',
        shortcut: 'Q',
        icon: 'select-lasso',
        group: 'Selection'
    },
    {
        id: 'select-wand',
        label: 'Magic Wand',
        shortcut: 'W',
        icon: 'select-wand',
        group: 'Selection'
    },
    // Geometry
    {
        id: 'line',
        label: 'Line',
        shortcut: 'L',
        icon: 'line',
        group: 'Geometry'
    },
    {
        id: 'isometric-line',
        label: '2:1 Iso Line',
        shortcut: 'J',
        icon: 'isometric-line',
        group: 'Geometry'
    },
    {
        id: 'rectangle',
        label: 'Rectangle',
        shortcut: 'U',
        icon: 'rectangle',
        group: 'Geometry'
    },
    {
        id: 'ellipse',
        label: 'Ellipse',
        shortcut: 'O',
        icon: 'ellipse',
        group: 'Geometry'
    },
    // 2.5D Sculpt
    {
        id: 'normal-chisel',
        label: 'Normal Chisel',
        shortcut: 'K',
        icon: 'chisel',
        group: '2.5D Sculpt'
    },
    // Utility
    {
        id: 'eyedropper',
        label: 'Eyedropper',
        shortcut: 'I',
        icon: 'eyedropper',
        group: 'Utility'
    }
];
const CANONICAL_SHORTCUTS = [
    // Tools
    {
        key: 'B',
        description: 'Pen Tool',
        category: 'Tools',
        toolId: 'pen'
    },
    {
        key: 'C',
        description: 'Bézier Curve Tool',
        category: 'Tools',
        toolId: 'curve'
    },
    {
        key: 'E',
        description: 'Eraser Tool',
        category: 'Tools',
        toolId: 'eraser'
    },
    {
        key: 'G',
        description: 'Flood Fill / Bucket',
        category: 'Tools',
        toolId: 'bucket'
    },
    {
        key: 'D',
        description: 'Dither Brush',
        category: 'Tools',
        toolId: 'dither'
    },
    {
        key: 'I',
        description: 'Eyedropper',
        category: 'Tools',
        toolId: 'eyedropper'
    },
    {
        key: 'M',
        description: 'Marquee Box Select',
        category: 'Tools',
        toolId: 'select-box'
    },
    {
        key: 'Q',
        description: 'Lasso Select',
        category: 'Tools',
        toolId: 'select-lasso'
    },
    {
        key: 'W',
        description: 'Magic Wand',
        category: 'Tools',
        toolId: 'select-wand'
    },
    {
        key: 'L',
        description: 'Line Tool',
        category: 'Tools',
        toolId: 'line'
    },
    {
        key: 'J',
        description: 'Isometric 2:1 Line',
        category: 'Tools',
        toolId: 'isometric-line'
    },
    {
        key: 'U',
        description: 'Rectangle Tool',
        category: 'Tools',
        toolId: 'rectangle'
    },
    {
        key: 'O',
        description: 'Ellipse Tool',
        category: 'Tools',
        toolId: 'ellipse'
    },
    {
        key: 'R',
        description: 'Color Replace Tool',
        category: 'Tools',
        toolId: 'color-replace'
    },
    {
        key: 'Shift + R',
        description: 'Erase Sampled Color Tool',
        category: 'Tools',
        toolId: 'erase-color'
    },
    {
        key: 'K',
        description: 'Normal Chisel Tool',
        category: 'Tools',
        toolId: 'normal-chisel'
    },
    // Editing
    {
        key: 'Ctrl + S',
        description: 'Save Project Now',
        category: 'Editing'
    },
    {
        key: 'X',
        description: 'Swap Colors',
        category: 'Editing'
    },
    {
        key: '[ / ]',
        description: 'Decrease / Increase Size',
        category: 'Editing'
    },
    {
        key: 'H / V',
        description: 'Flip Selection H / V',
        category: 'Editing'
    },
    {
        key: 'Ctrl + C / X / V',
        description: 'Copy / Cut / Paste',
        category: 'Editing'
    },
    {
        key: 'Ctrl + Z / Y',
        description: 'Undo / Redo Stroke',
        category: 'Editing'
    },
    {
        key: 'Esc',
        description: 'Deselect / Commit Float',
        category: 'Editing'
    },
    {
        key: 'Shift + Select',
        description: 'Add to Selection (Union)',
        category: 'Editing'
    },
    {
        key: 'Alt + Select',
        description: 'Subtract from Selection',
        category: 'Editing'
    },
    // Canvas & Viewport
    {
        key: 'Middle / Alt + Drag',
        description: 'Pan Canvas Viewport',
        category: 'Canvas & Viewport'
    },
    {
        key: 'Arrow Keys',
        description: 'Pan Viewport / Nudge Selection',
        category: 'Canvas & Viewport'
    },
    {
        key: 'Mouse Wheel',
        description: 'Zoom In / Out Canvas',
        category: 'Canvas & Viewport'
    },
    {
        key: 'Ctrl + + / -',
        description: 'Zoom In / Out Step',
        category: 'Canvas & Viewport'
    },
    {
        key: 'Ctrl + 0',
        description: 'Fit Canvas to Screen',
        category: 'Canvas & Viewport'
    },
    {
        key: 'Ctrl + 1',
        description: 'Reset Zoom to 100%',
        category: 'Canvas & Viewport'
    },
    {
        key: 'Shift + H',
        description: 'Toggle Horizontal Symmetry Mirror',
        category: 'Canvas & Viewport'
    },
    {
        key: 'Shift + V',
        description: 'Toggle Vertical Symmetry Mirror',
        category: 'Canvas & Viewport'
    },
    {
        key: 'P',
        description: 'Cycle CVD Colorblindness Lens',
        category: 'Canvas & Viewport'
    },
    {
        key: 'S',
        description: 'Silhouette / Squint Mode',
        category: 'Canvas & Viewport'
    },
    // Animation
    {
        key: 'Space',
        description: 'Play / Pause Animation',
        category: 'Animation'
    },
    {
        key: ',',
        description: 'Step to Previous Frame',
        category: 'Animation'
    },
    {
        key: '.',
        description: 'Step to Next Frame',
        category: 'Animation'
    }
];
const TOOL_GROUPS = [
    'Drawing',
    'Selection',
    'Geometry',
    '2.5D Sculpt',
    'Utility'
].map(_c = (groupName)=>({
        groupName,
        tools: CANONICAL_TOOLS.filter((t)=>t.group === groupName).map((t)=>({
                id: t.id,
                label: t.label,
                shortcut: t.shortcut,
                icon: t.icon
            }))
    }));
_c1 = TOOL_GROUPS;
const TOOL_METADATA_MAP = CANONICAL_TOOLS.reduce(_c2 = (acc, tool)=>{
    acc[tool.id] = {
        label: tool.label,
        shortcut: tool.shortcut,
        icon: tool.icon
    };
    return acc;
}, {});
_c3 = TOOL_METADATA_MAP;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "TOOL_GROUPS$[\n  'Drawing',\n  'Selection',\n  'Geometry',\n  '2.5D Sculpt',\n  'Utility',\n].map");
__turbopack_context__.k.register(_c1, "TOOL_GROUPS");
__turbopack_context__.k.register(_c2, "TOOL_METADATA_MAP$CANONICAL_TOOLS.reduce");
__turbopack_context__.k.register(_c3, "TOOL_METADATA_MAP");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/config/zoom.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Canonical integer zoom ladder and step navigation helpers.
 * Used uniformly across mouse wheel, toolbar buttons, and keyboard shortcuts.
 */ __turbopack_context__.s([
    "DEFAULT_ZOOM",
    ()=>DEFAULT_ZOOM,
    "MAX_ZOOM",
    ()=>MAX_ZOOM,
    "MIN_ZOOM",
    ()=>MIN_ZOOM,
    "ZOOM_LADDER",
    ()=>ZOOM_LADDER,
    "calculateFitZoom",
    ()=>calculateFitZoom,
    "getNextZoomStep",
    ()=>getNextZoomStep,
    "getPrevZoomStep",
    ()=>getPrevZoomStep
]);
const ZOOM_LADDER = [
    10,
    20,
    25,
    50,
    75,
    100,
    200,
    300,
    400,
    500,
    600,
    800,
    1000,
    1200,
    1600,
    2400,
    3200,
    4800,
    6400
];
const MIN_ZOOM = 10;
const MAX_ZOOM = 6400;
const DEFAULT_ZOOM = 1600;
function getNextZoomStep(current) {
    const next = ZOOM_LADDER.find((step)=>step > current);
    return next !== undefined ? next : MAX_ZOOM;
}
function getPrevZoomStep(current) {
    const reversed = [
        ...ZOOM_LADDER
    ].reverse();
    const prev = reversed.find((step)=>step < current);
    return prev !== undefined ? prev : MIN_ZOOM;
}
function calculateFitZoom(canvasWidth, canvasHeight, viewportWidth, viewportHeight) {
    if (canvasWidth <= 0 || canvasHeight <= 0) return DEFAULT_ZOOM;
    const viewport = typeof document !== 'undefined' ? document.getElementById('main-content') : null;
    const availW = Math.max(1, (viewportWidth ?? viewport?.clientWidth ?? 860) - 48);
    const availH = Math.max(1, (viewportHeight ?? viewport?.clientHeight ?? 520) - 48);
    const maxFitW = Math.floor(availW / canvasWidth * 100);
    const maxFitH = Math.floor(availH / canvasHeight * 100);
    const rawFit = Math.min(maxFitW, maxFitH);
    // Reduced views benefit from using the available stage, even between toolbar steps.
    if (rawFit < 100) return Math.max(MIN_ZOOM, Math.min(99, rawFit));
    // Find the highest step from ZOOM_LADDER that fits within rawFit
    const step = [
        ...ZOOM_LADDER
    ].reverse().find((s)=>s <= rawFit);
    if (step !== undefined) {
        return Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, step));
    }
    // Very large canvases use the smallest overview step.
    return MIN_ZOOM;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/stores/onboardingStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateLessonSteps",
    ()=>generateLessonSteps,
    "syncStudioWithLesson",
    ()=>syncStudioWithLesson,
    "useOnboardingStore",
    ()=>useOnboardingStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/art/playgroundLessons.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
'use client';
;
;
;
function syncStudioWithLesson(lesson) {
    const targetSize = lesson.canvasSize || 16;
    const studio = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    // 1. Sync canvas dimensions if different
    if (studio.canvasWidth !== targetSize || studio.canvasHeight !== targetSize) {
        studio.setCanvasSize(targetSize, targetSize);
    }
    // 2. Sync FPS
    studio.setFps(lesson.fps);
    // 3. Sync frames: adjust frame count to match lesson.totalFrames exactly without stale snapshots
    let freshFrames = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames;
    while(freshFrames.length < lesson.totalFrames){
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().addFrame();
        freshFrames = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames;
    }
    while(freshFrames.length > lesson.totalFrames){
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().deleteFrame(freshFrames.length - 1);
        freshFrames = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames;
    }
    // 4. Assign durationMs for each frame from template using fresh store state
    const updatedState = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
    lesson.frames.forEach((frameTemplate, idx)=>{
        if (idx < updatedState.frames.length && frameTemplate.recommendedHoldMs) {
            updatedState.setFrameDuration(idx, frameTemplate.recommendedHoldMs, true);
        }
    });
    updatedState.setActiveFrame(0);
}
function generateLessonSteps(lesson) {
    const steps = [];
    // Steps 1..N: Draw each frame directly without screen-blocking welcome popups
    lesson.frames.forEach((frame, idx)=>{
        const isLastFrame = idx === lesson.frames.length - 1;
        steps.push({
            id: `draw-frame-${idx}`,
            type: 'DRAW_FRAME',
            stepIndex: steps.length,
            totalSteps: 0,
            frameIndex: idx,
            title: `${frame.name}`,
            subtitle: `${frame.subhead}`,
            dialogTitle: `Inking ${frame.name}`,
            mascotPose: idx % 2 === 0 ? 'idle' : 'happy',
            description: 'Use your Pen tool (B) to trace the perimeter outline onto the canvas. Notice the silhouette deformation for this keyframe.',
            artisanTip: frame.artisanRule,
            targetSelector: '#center-canvas-area',
            highlightLabel: 'Canvas Tracing Lightbox',
            nextButtonLabel: isLastFrame ? 'Next: Test Playback' : `Next: Frame ${idx + 2}`,
            template: frame
        });
    });
    // Playback Step
    steps.push({
        id: 'playback',
        type: 'PLAYBACK',
        stepIndex: steps.length,
        totalSteps: 0,
        title: 'Playback & Timing Validation',
        subtitle: `Testing ${lesson.title} Loop at ${lesson.fps} FPS`,
        dialogTitle: 'Validate Motion Loop',
        mascotPose: 'happy',
        description: 'Press "PLAY" (or tap Spacebar) on the timeline. Observe the rhythm. Notice how the deformation keyframes produce fluid, living physics.',
        artisanTip: `Timing Metric: This loop runs at ${lesson.fps} FPS to give natural weight and bounce.`,
        targetSelector: '[data-tutorial="play-button"]',
        highlightLabel: 'Play / Pause Loop',
        nextButtonLabel: 'Complete Lesson'
    });
    // Complete Step
    steps.push({
        id: 'complete',
        type: 'COMPLETE',
        stepIndex: steps.length,
        totalSteps: 0,
        title: 'Lesson Mastered',
        subtitle: 'Ready for Full Production Workspace',
        dialogTitle: 'Artisan Lesson Complete',
        mascotPose: 'happy',
        description: `You have successfully built a full ${lesson.totalFrames}-frame animation cycle. Your artwork is preserved in live browser memory. Transfer into the full Studio to access color ramps, multi-layer shading, normal maps, and GIF exports.`,
        artisanTip: 'Next Steps: In the full studio, try adding secondary shading, specular glints, or character costumes.',
        targetSelector: null,
        nextButtonLabel: 'Enter Full Studio'
    });
    const total = steps.length;
    steps.forEach((s)=>{
        s.totalSteps = total;
    });
    return steps;
}
const initialLesson = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLAYGROUND_LESSONS"][0];
const initialSteps = generateLessonSteps(initialLesson);
const useOnboardingStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        currentStepIndex: 0,
        isPlaygroundActive: true,
        activeLessonId: initialLesson.id,
        steps: initialSteps,
        showStencilGuide: true,
        stencilOpacity: 0.45,
        completedStepIndices: new Set(),
        hasDrawnCurrentFrame: false,
        coverageRatio: 0,
        isFrameDrawingComplete: false,
        latestAnalysis: null,
        setStepIndex: (index)=>{
            const { steps, currentStepIndex, completedStepIndices } = get();
            const validIndex = Math.max(0, Math.min(steps.length - 1, index));
            const nextCompleted = new Set(completedStepIndices);
            nextCompleted.add(currentStepIndex);
            const targetStep = steps[validIndex];
            if (targetStep && targetStep.type === 'DRAW_FRAME' && targetStep.frameIndex !== undefined) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setActiveFrame(targetStep.frameIndex);
            }
            set({
                currentStepIndex: validIndex,
                completedStepIndices: nextCompleted,
                hasDrawnCurrentFrame: false,
                coverageRatio: 0,
                isFrameDrawingComplete: false,
                latestAnalysis: null
            });
        },
        nextStep: ()=>{
            const { currentStepIndex } = get();
            get().setStepIndex(currentStepIndex + 1);
        },
        prevStep: ()=>{
            const { currentStepIndex } = get();
            get().setStepIndex(currentStepIndex - 1);
        },
        selectLesson: (lessonId)=>{
            const lesson = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLAYGROUND_LESSONS"].find((l)=>l.id === lessonId) || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLAYGROUND_LESSONS"][0];
            const newSteps = generateLessonSteps(lesson);
            syncStudioWithLesson(lesson);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setActiveFrame(0);
            set({
                activeLessonId: lesson.id,
                steps: newSteps,
                currentStepIndex: 0,
                completedStepIndices: new Set(),
                hasDrawnCurrentFrame: false,
                coverageRatio: 0,
                isFrameDrawingComplete: false,
                latestAnalysis: null
            });
        },
        toggleStencilGuide: ()=>{
            set((state)=>({
                    showStencilGuide: !state.showStencilGuide
                }));
        },
        setStencilOpacity: (opacity)=>{
            set({
                stencilOpacity: Math.max(0.1, Math.min(1.0, opacity))
            });
        },
        recordAnalysis: (analysis)=>{
            set({
                hasDrawnCurrentFrame: true,
                coverageRatio: analysis.completionScore / 100,
                isFrameDrawingComplete: analysis.isComplete,
                latestAnalysis: analysis
            });
        },
        resetOnboarding: ()=>{
            const lesson = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLAYGROUND_LESSONS"][0];
            syncStudioWithLesson(lesson);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setActiveFrame(0);
            set({
                activeLessonId: lesson.id,
                steps: generateLessonSteps(lesson),
                currentStepIndex: 0,
                completedStepIndices: new Set(),
                hasDrawnCurrentFrame: false,
                coverageRatio: 0,
                isFrameDrawingComplete: false,
                latestAnalysis: null
            });
        },
        startPlayground: ()=>{
            const lesson = get().getCurrentLesson();
            syncStudioWithLesson(lesson);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setActiveFrame(0);
            set({
                isPlaygroundActive: true,
                steps: generateLessonSteps(lesson),
                currentStepIndex: 0,
                completedStepIndices: new Set(),
                hasDrawnCurrentFrame: false,
                coverageRatio: 0,
                isFrameDrawingComplete: false,
                latestAnalysis: null
            });
        },
        completeOnboarding: ()=>{
            const { steps } = get();
            set({
                currentStepIndex: steps.length - 1
            });
        },
        getCurrentLesson: ()=>{
            const { activeLessonId } = get();
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLAYGROUND_LESSONS"].find((l)=>l.id === activeLessonId) || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLAYGROUND_LESSONS"][0];
        },
        getCurrentStep: ()=>{
            const { steps, currentStepIndex } = get();
            return steps[Math.max(0, Math.min(steps.length - 1, currentStepIndex))];
        },
        getCurrentFrameTemplate: ()=>{
            const step = get().getCurrentStep();
            if (!step || step.type !== 'DRAW_FRAME') return null;
            if (step.template) return step.template;
            if (step.frameIndex !== undefined) {
                const lesson = get().getCurrentLesson();
                return lesson.frames[step.frameIndex] || null;
            }
            return null;
        }
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/stores/slices/createAnimationSlice.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createAnimationSlice",
    ()=>createAnimationSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/structuralHistory.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/workspaceEnvelopeGuard.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/metadataAdmission.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/animationTiming.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/animation/reviewMetadata.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
function remapClipAfterFrameDeletion(clip, removedIndex) {
    const startFrame = clip.startFrame - (removedIndex < clip.startFrame ? 1 : 0);
    const endFrame = clip.endFrame - (removedIndex <= clip.endFrame ? 1 : 0);
    if (startFrame > endFrame) return null;
    return {
        ...clip,
        startFrame,
        endFrame,
        fromFrame: startFrame,
        toFrame: endFrame
    };
}
const initialLayerId = 'layer-1';
const initialFrameId = 'frame-1';
function activateFrame(state, index) {
    const frame = state.frames[index];
    if (!Number.isInteger(index) || !frame) return;
    state.activeFrameIndex = index;
    if (!frame.layers.some((layer)=>layer.id === state.activeLayerId)) {
        state.activeLayerId = frame.layers[0]?.id ?? '';
    }
}
const defaultInitialFrame = {
    id: initialFrameId,
    durationMs: 100,
    layers: [
        {
            id: initialLayerId,
            name: 'Base Layer',
            visible: true,
            locked: false,
            opacity: 1,
            blendMode: 'source-over'
        }
    ]
};
const createAnimationSlice = (set, get)=>({
        frames: [
            defaultInitialFrame
        ],
        activeFrameIndex: 0,
        isPlaying: false,
        fps: 8,
        loopMode: 'repeat',
        onionSkin: {
            enabled: false,
            prevFrames: 1,
            nextFrames: 1,
            prevColor: '#C792DF',
            nextColor: '#DCABDF',
            opacity: 0.45
        },
        clips: [
            {
                id: 'tag-1',
                name: 'Default',
                fromFrame: 0,
                toFrame: 0,
                startFrame: 0,
                endFrame: 0,
                color: '#F0BE7C',
                loopMode: 'forward'
            }
        ],
        activeClipId: null,
        addFrame: ()=>{
            const currentStore = get();
            const currentFrame = currentStore.frames[currentStore.activeFrameIndex];
            if (!currentFrame) return;
            const untaggedLayerCount = currentFrame.layers.filter((l)=>!l.tag).length;
            const incomingLayerCount = Math.max(1, untaggedLayerCount);
            const capacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAddFramesToProject"])(currentStore.frames, currentStore.canvasWidth, currentStore.canvasHeight, [
                {
                    layerCount: incomingLayerCount
                }
            ]);
            if (!capacity.ok) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    message: capacity.reason || 'Cannot add frame: workspace capacity ceiling reached.',
                    type: 'error'
                });
                return;
            }
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Add Frame', {
                opKind: 'add-frame',
                affectedLayerIds: [],
                redoBufferCount: incomingLayerCount,
                addedLayerCount: incomingLayerCount,
                addedFrameCount: 1
            })) return;
            set((state)=>{
                const newFrameId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('frame');
                const currentFrame = state.frames[state.activeFrameIndex];
                const clonedLayers = currentFrame.layers.filter((l)=>!l.tag).map((l)=>({
                        ...l,
                        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('layer'),
                        effect: l.effect ? {
                            ...structuredClone((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(l.effect)),
                            id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('effect'),
                            updatedAt: Date.now()
                        } : undefined
                    }));
                if (clonedLayers.length === 0) {
                    clonedLayers.push({
                        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('layer'),
                        name: 'Base Layer',
                        visible: true,
                        locked: false,
                        opacity: 1,
                        blendMode: 'source-over'
                    });
                }
                const newFrame = {
                    id: newFrameId,
                    durationMs: 100,
                    layers: clonedLayers
                };
                state.frames.push(newFrame);
                state.activeFrameIndex = state.frames.length - 1;
                state.activeLayerId = clonedLayers[0].id;
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        duplicateFrame: (frameIndex, rasterizedContent)=>{
            const currentStore = get();
            const srcFrame = currentStore.frames[frameIndex];
            if (!srcFrame || !Number.isInteger(frameIndex)) return null;
            if (rasterizedContent && (rasterizedContent.width !== currentStore.canvasWidth || rasterizedContent.height !== currentStore.canvasHeight || rasterizedContent.data.length !== currentStore.canvasWidth * currentStore.canvasHeight * 4 || !srcFrame.layers.some((layer)=>!layer.tag))) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'error',
                    message: 'Cannot insert invalid rasterized frame content.'
                });
                return null;
            }
            const incomingLayerCount = srcFrame.layers.length;
            const capacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAddFramesToProject"])(currentStore.frames, currentStore.canvasWidth, currentStore.canvasHeight, [
                {
                    layerCount: incomingLayerCount
                }
            ]);
            if (!capacity.ok) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    message: capacity.reason || 'Cannot duplicate frame: workspace capacity ceiling reached.',
                    type: 'error'
                });
                return null;
            }
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Duplicate Frame', {
                opKind: 'duplicate-frame',
                affectedLayerIds: [],
                redoBufferCount: incomingLayerCount,
                addedLayerCount: incomingLayerCount,
                addedFrameCount: 1
            })) return null;
            let result = null;
            set((state)=>{
                const srcFrame = state.frames[frameIndex];
                if (!srcFrame) return;
                const newFrameId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('frame');
                const duplicatedLayers = srcFrame.layers.map((l)=>({
                        ...l,
                        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('layer'),
                        effect: l.effect ? {
                            ...structuredClone((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(l.effect)),
                            id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('effect'),
                            updatedAt: Date.now()
                        } : undefined
                    }));
                const duplicate = {
                    ...srcFrame,
                    id: newFrameId,
                    layers: duplicatedLayers
                };
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneBuffers"])(srcFrame.layers.map((l)=>l.id), duplicatedLayers.map((l)=>l.id), state.canvasWidth, state.canvasHeight);
                // Install generated pixels before publishing the new frame to save/sync subscribers.
                if (rasterizedContent) {
                    const artworkLayers = duplicatedLayers.filter((layer)=>!layer.tag);
                    const base = artworkLayers[artworkLayers.length - 1];
                    for (const layer of artworkLayers){
                        const entry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layer.id, state.canvasWidth, state.canvasHeight);
                        if (layer === base) {
                            const image = entry.ctx.createImageData(state.canvasWidth, state.canvasHeight);
                            image.data.set(rasterizedContent.data);
                            entry.ctx.putImageData(image, 0, 0);
                            layer.visible = true;
                            layer.opacity = 1;
                            layer.blendMode = 'source-over';
                            layer.effect = undefined;
                        } else {
                            entry.ctx.clearRect(0, 0, state.canvasWidth, state.canvasHeight);
                        }
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(layer.id);
                    }
                }
                state.frames.splice(frameIndex + 1, 0, duplicate);
                state.activeFrameIndex = frameIndex + 1;
                state.activeLayerId = duplicatedLayers[0].id;
                result = {
                    frameId: newFrameId,
                    layerIds: duplicatedLayers.map((layer)=>layer.id)
                };
                state.isDirty = true;
                state.editRevision += 1;
            });
            return result;
        },
        deleteFrame: (frameIndex)=>{
            if (get().frames.length <= 1 || frameIndex < 0 || frameIndex >= get().frames.length) return;
            const frameToDelete = get().frames[frameIndex];
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Delete Frame', {
                opKind: 'delete-frame',
                affectedLayerIds: frameToDelete.layers.map((l)=>l.id)
            })) return;
            set((state)=>{
                if (state.frames.length <= 1) return;
                // Bounds guard: an out-of-range index would crash on removedFrame.layers
                if (frameIndex < 0 || frameIndex >= state.frames.length) return;
                const removedFrame = state.frames[frameIndex];
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteBuffers"])(removedFrame.layers.map((l)=>l.id));
                state.frames.splice(frameIndex, 1);
                state.clips = state.clips.map((clip)=>remapClipAfterFrameDeletion(clip, frameIndex)).filter((clip)=>clip !== null);
                if (state.activeClipId && !state.clips.some((clip)=>clip.id === state.activeClipId)) {
                    state.activeClipId = null;
                }
                state.activeFrameIndex = Math.min(state.activeFrameIndex, state.frames.length - 1);
                state.activeLayerId = state.frames[state.activeFrameIndex].layers[0].id;
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        setFrameDuration: (frameIndex, durationMs, skipHistory = false)=>{
            if (!Number.isFinite(durationMs)) return false;
            const frame = get().frames[frameIndex];
            const nextDuration = Math.max(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMinMs, Math.min(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMaxMs, Math.round(durationMs)));
            if (!frame || frame.durationMs === nextDuration) return false;
            if (!skipHistory && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Change Frame Duration')) return false;
            set((state)=>{
                const frame = state.frames[frameIndex];
                if (frame) {
                    frame.durationMs = nextDuration;
                    state.isDirty = true;
                    state.editRevision += 1;
                }
            });
            return true;
        },
        reorderFrames: (startIndex, endIndex)=>{
            const frameCount = get().frames.length;
            if (startIndex < 0 || startIndex >= frameCount || endIndex < 0 || endIndex >= frameCount || startIndex === endIndex) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Reorder Frames', {
                opKind: 'reorder-frames',
                affectedLayerIds: []
            })) return;
            set((state)=>{
                // Bounds guard: out-of-range indices would splice `undefined` into frames
                if (startIndex < 0 || startIndex >= state.frames.length || endIndex < 0 || endIndex >= state.frames.length) {
                    return;
                }
                const [removed] = state.frames.splice(startIndex, 1);
                state.frames.splice(endIndex, 0, removed);
                activateFrame(state, endIndex);
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        setActiveFrame: (index)=>{
            set((state)=>{
                activateFrame(state, index);
            });
        },
        setFps: (fps)=>{
            set((state)=>{
                if (!Number.isFinite(fps)) return;
                state.fps = Math.max(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].fpsMin, Math.min(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].fpsMax, Math.round(fps)));
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        setIsPlaying: (playing)=>{
            set((state)=>{
                state.isPlaying = playing;
            });
        },
        setLoopMode: (mode)=>{
            set((state)=>{
                state.loopMode = mode;
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        setOnionSkin: (settings)=>{
            set((state)=>{
                state.onionSkin = {
                    ...state.onionSkin,
                    ...settings
                };
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        addClip: (name, startFrame, endFrame, color, loopMode = 'forward')=>{
            const current = get();
            const nameError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["metadataNameError"])(name, 'clip');
            const error = nameError ?? (current.clips.length >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PROJECT_CLIPS"] ? `A project can have at most ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PROJECT_CLIPS"]} clips.` : !Number.isInteger(startFrame) || !Number.isInteger(endFrame) ? 'Clip frame positions must be whole numbers.' : null);
            if (error) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'error',
                    message: error
                });
                return;
            }
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Add Clip')) return;
            set((state)=>{
                const minF = Math.max(0, Math.min(state.frames.length - 1, Math.min(startFrame, endFrame)));
                const maxF = Math.max(0, Math.min(state.frames.length - 1, Math.max(startFrame, endFrame)));
                const newClip = {
                    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('tag'),
                    name,
                    fromFrame: minF,
                    toFrame: maxF,
                    startFrame: minF,
                    endFrame: maxF,
                    color: color || '#F0BE7C',
                    loopMode: loopMode || 'forward'
                };
                state.clips.push(newClip);
                state.activeClipId = newClip.id;
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        updateClip: (id, updates)=>{
            const current = get();
            const existing = current.clips.find((clip)=>clip.id === id);
            if (!existing) return;
            const review = updates.review === undefined ? undefined : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAnimationReview"])(updates.review);
            if (review === null) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'error',
                    message: 'Review regions or exceptions exceed their limits or are invalid.'
                });
                return;
            }
            const startFrame = updates.startFrame ?? updates.fromFrame ?? existing.startFrame;
            const endFrame = updates.endFrame ?? updates.toFrame ?? existing.endFrame;
            const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["metadataNameError"])(updates.name ?? existing.name, 'clip') ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clipRangeError"])(startFrame, endFrame, current.frames.length);
            if (error) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'error',
                    message: error
                });
                return;
            }
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Update Clip')) return;
            set((state)=>{
                const clip = state.clips.find((c)=>c.id === id);
                if (clip) {
                    Object.assign(clip, updates, {
                        startFrame,
                        endFrame,
                        fromFrame: startFrame,
                        toFrame: endFrame
                    });
                    if (review) clip.review = review;
                    state.isDirty = true;
                    state.editRevision += 1;
                }
            });
        },
        deleteClip: (id)=>{
            if (!get().clips.some((clip)=>clip.id === id) || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Delete Clip')) return;
            set((state)=>{
                state.clips = state.clips.filter((c)=>c.id !== id);
                if (state.activeClipId === id) {
                    state.activeClipId = null;
                }
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        reorderClips: (sourceIndex, targetIndex)=>{
            const count = get().clips.length;
            if (!Number.isInteger(sourceIndex) || !Number.isInteger(targetIndex) || sourceIndex < 0 || sourceIndex >= count || targetIndex < 0 || targetIndex >= count || sourceIndex === targetIndex) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Reorder Clips')) return;
            set((state)=>{
                if (sourceIndex < 0 || sourceIndex >= state.clips.length || targetIndex < 0 || targetIndex >= state.clips.length) {
                    return;
                }
                const [moved] = state.clips.splice(sourceIndex, 1);
                state.clips.splice(targetIndex, 0, moved);
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        setActiveClipId: (id)=>{
            const clip = id ? get().clips.find((c)=>c.id === id) : undefined;
            if (id && !clip) return;
            set((state)=>{
                state.activeClipId = id;
                if (clip) activateFrame(state, clip.fromFrame ?? clip.startFrame);
            });
        },
        addTag: (name, fromFrame, toFrame, color, loopMode = 'forward')=>{
            get().addClip(name, fromFrame, toFrame, color, loopMode);
        },
        updateTag: (id, updates)=>{
            get().updateClip(id, updates);
        },
        deleteTag: (id)=>{
            get().deleteClip(id);
        },
        reorderTags: (sourceIndex, targetIndex)=>{
            get().reorderClips(sourceIndex, targetIndex);
        },
        setActiveTagId: (id)=>{
            get().setActiveClipId(id);
        }
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/stores/slices/createHistorySlice.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createHistorySlice",
    ()=>createHistorySlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$desktopFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/storage/desktopFileSystem.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/canvasLimits.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/animation/reviewMetadata.ts [app-client] (ecmascript)");
;
;
;
;
;
const createHistorySlice = (set, get)=>({
        canUndo: false,
        canRedo: false,
        setCanUndo: (can)=>{
            set((state)=>{
                state.canUndo = can;
            });
        },
        setCanRedo: (can)=>{
            set((state)=>{
                state.canRedo = can;
            });
        },
        bufferVersion: 0,
        bumpBufferVersion: ()=>{
            set((state)=>{
                state.bufferVersion += 1;
            });
        },
        saveStatus: 'idle',
        setSaveStatus: (status)=>{
            set((state)=>{
                state.saveStatus = status;
            });
        },
        isDirty: false,
        editRevision: 0,
        setDirty: (dirty)=>{
            set((state)=>{
                state.isDirty = dirty;
                if (dirty) state.editRevision += 1;
            });
        },
        markClean: ()=>{
            set((state)=>{
                state.isDirty = false;
            });
        },
        selection: null,
        selectionMask: null,
        setSelection: (sel, mask = null)=>{
            set((state)=>{
                state.selection = sel;
                state.selectionMask = mask;
            });
        },
        aiMessages: [
            {
                id: 'welcome-msg',
                sender: 'assistant',
                text: "Hey there! I'm PixiBud, your pixel art math studio assistant. Tap any of the panels below to execute deterministic 2.5D photometric lighting, volumetric SSS, or normal baking directly on your artwork layers!",
                timestamp: Date.now(),
                suggestions: [
                    '2.5D Photometric',
                    'Volumetric SSS',
                    'Harmonize palette',
                    'Clean jaggies'
                ]
            }
        ],
        isAiThinking: false,
        activeInspectorTab: 'layers',
        setActiveInspectorTab: (tab)=>{
            set((state)=>{
                state.activeInspectorTab = tab;
            });
        },
        addAiMessage: (message)=>{
            set((state)=>{
                state.aiMessages.push({
                    ...message,
                    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('msg'),
                    timestamp: Date.now()
                });
            });
        },
        setIsAiThinking: (thinking)=>{
            set((state)=>{
                state.isAiThinking = thinking;
            });
        },
        loadProjectState: (projectData, projectId)=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertWorkspaceDimensions"])(projectData.width ?? get().canvasWidth, projectData.height ?? get().canvasHeight);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$desktopFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DesktopFileSystem"].reset();
            set((state)=>{
                // Cross-project boundary: viewport-local state that cannot be carried
                // meaningfully into the restored document must be reset, or a stale
                // selection / clip reference survives into an unrelated project.
                state.selection = null;
                state.selectionMask = null;
                state.activeClipId = null;
                state.isPlaying = false;
                state.currentProjectId = projectId || (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
                state.editRevision += 1;
                if (projectData.name) state.projectName = projectData.name;
                if (projectData.width) state.canvasWidth = projectData.width;
                if (projectData.height) state.canvasHeight = projectData.height;
                if (projectData.fps) state.fps = projectData.fps;
                if (projectData.loopMode) state.loopMode = projectData.loopMode;
                if (projectData.onionSkin) {
                    state.onionSkin = {
                        ...state.onionSkin,
                        ...projectData.onionSkin
                    };
                }
                if (projectData.customRamps) {
                    state.customRamps = projectData.customRamps.map((r)=>({
                            ...r,
                            shades: [
                                ...r.shades
                            ]
                        }));
                }
                if (projectData.frames && projectData.frames.length > 0) {
                    state.frames = projectData.frames;
                    state.activeFrameIndex = 0;
                    if (projectData.frames[0].layers.length > 0) {
                        state.activeLayerId = projectData.frames[0].layers[0].id;
                    }
                }
                if (projectData.palettes && projectData.palettes.length > 0) {
                    state.palettes = projectData.palettes;
                    state.currentPaletteId = projectData.currentPaletteId || projectData.palettes[0].id;
                }
                if (projectData.clips) {
                    state.clips = projectData.clips.map((c, idx)=>{
                        const from = c.fromFrame !== undefined ? c.fromFrame : c.startFrame ?? 0;
                        const to = c.toFrame !== undefined ? c.toFrame : c.endFrame ?? from;
                        const review = c.review === undefined ? null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAnimationReview"])(c.review);
                        return {
                            id: c.id || `tag-${idx + 1}`,
                            name: c.name || `Tag ${idx + 1}`,
                            fromFrame: from,
                            toFrame: to,
                            startFrame: from,
                            endFrame: to,
                            color: c.color || '#F0BE7C',
                            loopMode: c.loopMode || 'forward',
                            ...review ? {
                                review
                            } : {}
                        };
                    });
                }
                state.isDirty = false;
            });
        },
        resetToNewProject: (newId)=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$desktopFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DesktopFileSystem"].reset();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearAllBuffers"])();
            const initialLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('layer');
            const initialFrameId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('frame');
            set((state)=>{
                state.currentProjectId = newId || (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
                state.projectName = 'Untitled Sprite';
                state.canvasWidth = 32;
                state.canvasHeight = 32;
                state.zoom = 1600;
                state.panX = 0;
                state.panY = 0;
                state.isDirty = false;
                state.saveStatus = 'idle';
                state.canUndo = false;
                state.canRedo = false;
                state.frames = [
                    {
                        id: initialFrameId,
                        durationMs: 125,
                        layers: [
                            {
                                id: initialLayerId,
                                name: 'Base Layer',
                                visible: true,
                                locked: false,
                                opacity: 1,
                                blendMode: 'source-over'
                            }
                        ]
                    }
                ];
                state.activeFrameIndex = 0;
                state.activeLayerId = initialLayerId;
                state.clips = [
                    {
                        id: 'tag-1',
                        name: 'Default',
                        fromFrame: 0,
                        toFrame: 0,
                        startFrame: 0,
                        endFrame: 0,
                        color: '#F0BE7C',
                        loopMode: 'forward'
                    }
                ];
                state.activeClipId = null;
                state.bufferVersion += 1;
            });
        }
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/stores/slices/createLayerSlice.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createLayerSlice",
    ()=>createLayerSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/structuralHistory.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/workspaceEnvelopeGuard.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/metadataAdmission.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
const createLayerSlice = (set, get)=>({
        activeLayerId: 'layer-1',
        setActiveLayer: (layerId)=>{
            if (!get().frames[get().activeFrameIndex]?.layers.some((layer)=>layer.id === layerId)) return;
            set((state)=>{
                state.activeLayerId = layerId;
            });
        },
        addLayer: (name, tag, idOverride, skipHistory)=>{
            const currentStore = get();
            const frame = currentStore.frames[currentStore.activeFrameIndex];
            if (!frame) return;
            const nameError = name === undefined ? null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["metadataNameError"])(name, 'layer');
            if (nameError) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'error',
                    message: nameError
                });
                return;
            }
            const capacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAddLayersToFrame"])(currentStore.frames, currentStore.activeFrameIndex, currentStore.canvasWidth, currentStore.canvasHeight, 1);
            if (!capacity.ok) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    message: capacity.reason || 'Cannot add layer: workspace capacity ceiling reached.',
                    type: 'error'
                });
                return;
            }
            if (!skipHistory) {
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Add Layer', {
                    opKind: 'add-layer',
                    affectedLayerIds: [],
                    redoBufferCount: 1,
                    addedLayerCount: 1
                })) return;
            }
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame) return;
                const layerCount = currentFrame.layers.length + 1;
                const newLayerId = idOverride || (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('layer');
                const newLayer = {
                    id: newLayerId,
                    name: name || `Layer ${layerCount}`,
                    visible: true,
                    locked: false,
                    opacity: 1,
                    blendMode: 'source-over',
                    ...tag ? {
                        tag
                    } : {}
                };
                currentFrame.layers.unshift(newLayer);
                state.activeLayerId = newLayerId;
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        deleteLayer: (layerId, skipHistory)=>{
            const frame = get().frames[get().activeFrameIndex];
            if (!frame || frame.layers.length <= 1 || !frame.layers.some((layer)=>layer.id === layerId)) return;
            if (!skipHistory) {
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Delete Layer', {
                    opKind: 'delete-layer',
                    affectedLayerIds: [
                        layerId
                    ]
                })) return;
            }
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame || currentFrame.layers.length <= 1) return;
                currentFrame.layers = currentFrame.layers.filter((l)=>l.id !== layerId);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteBuffers"])([
                    layerId
                ]);
                if (state.activeLayerId === layerId) {
                    state.activeLayerId = currentFrame.layers[0].id;
                }
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        duplicateLayer: (layerId)=>{
            const currentStore = get();
            const frame = currentStore.frames[currentStore.activeFrameIndex];
            if (!frame?.layers.some((layer)=>layer.id === layerId)) return;
            const capacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAddLayersToFrame"])(currentStore.frames, currentStore.activeFrameIndex, currentStore.canvasWidth, currentStore.canvasHeight, 1);
            if (!capacity.ok) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    message: capacity.reason || 'Cannot duplicate layer: workspace capacity ceiling reached.',
                    type: 'error'
                });
                return;
            }
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Duplicate Layer', {
                opKind: 'duplicate-layer',
                affectedLayerIds: [],
                redoBufferCount: 1,
                addedLayerCount: 1
            })) return;
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame) return;
                const idx = currentFrame.layers.findIndex((l)=>l.id === layerId);
                if (idx === -1) return;
                const src = currentFrame.layers[idx];
                const newLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('layer');
                const duplicate = {
                    ...src,
                    id: newLayerId,
                    name: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeLayerCopyName"])(src.name),
                    effect: src.effect ? {
                        ...structuredClone((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(src.effect)),
                        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('effect'),
                        updatedAt: Date.now()
                    } : undefined
                };
                currentFrame.layers.splice(idx, 0, duplicate);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneBuffers"])([
                    layerId
                ], [
                    newLayerId
                ], state.canvasWidth, state.canvasHeight);
                state.activeLayerId = newLayerId;
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        reorderLayers: (startIndex, endIndex)=>{
            const frame = get().frames[get().activeFrameIndex];
            if (!frame || startIndex < 0 || startIndex >= frame.layers.length || endIndex < 0 || endIndex >= frame.layers.length || startIndex === endIndex) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Reorder Layers', {
                opKind: 'reorder-layers',
                affectedLayerIds: []
            })) return;
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame) return;
                const [removed] = currentFrame.layers.splice(startIndex, 1);
                currentFrame.layers.splice(endIndex, 0, removed);
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        toggleLayerVisibility: (layerId)=>{
            if (!get().frames[get().activeFrameIndex]?.layers.some((layer)=>layer.id === layerId)) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Toggle Layer Visibility')) return;
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame) return;
                const layer = currentFrame.layers.find((l)=>l.id === layerId);
                if (layer) {
                    layer.visible = !layer.visible;
                    state.isDirty = true;
                    state.editRevision += 1;
                }
            });
        },
        toggleLayerLock: (layerId)=>{
            if (!get().frames[get().activeFrameIndex]?.layers.some((layer)=>layer.id === layerId)) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Toggle Layer Lock')) return;
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame) return;
                const layer = currentFrame.layers.find((l)=>l.id === layerId);
                if (layer) {
                    layer.locked = !layer.locked;
                    state.isDirty = true;
                    state.editRevision += 1;
                }
            });
        },
        setLayerOpacity: (layerId, opacity, skipHistory = false)=>{
            if (!Number.isFinite(opacity)) return false;
            const layer = get().frames[get().activeFrameIndex]?.layers.find((candidate)=>candidate.id === layerId);
            const nextOpacity = Math.max(0, Math.min(1, opacity));
            if (!layer || layer.opacity === nextOpacity) return false;
            if (!skipHistory && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Change Layer Opacity')) return false;
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame) return;
                const layer = currentFrame.layers.find((l)=>l.id === layerId);
                if (layer) {
                    layer.opacity = nextOpacity;
                    state.isDirty = true;
                    state.editRevision += 1;
                }
            });
            return true;
        },
        setLayerBlendMode: (layerId, blendMode)=>{
            const layer = get().frames[get().activeFrameIndex]?.layers.find((candidate)=>candidate.id === layerId);
            if (!layer || layer.blendMode === blendMode) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Change Layer Blend Mode')) return;
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame) return;
                const layer = currentFrame.layers.find((l)=>l.id === layerId);
                if (layer) {
                    layer.blendMode = blendMode;
                    state.isDirty = true;
                    state.editRevision += 1;
                }
            });
        },
        renameLayer: (layerId, name)=>{
            const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["metadataNameError"])(name, 'layer');
            if (error) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'error',
                    message: error
                });
                return;
            }
            const layer = get().frames[get().activeFrameIndex]?.layers.find((candidate)=>candidate.id === layerId);
            if (!layer || layer.name === name) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Rename Layer')) return;
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame) return;
                const layer = currentFrame.layers.find((l)=>l.id === layerId);
                if (layer) {
                    layer.name = name;
                    state.isDirty = true;
                    state.editRevision += 1;
                }
            });
        },
        // Immutably assign/update a layer's tag. Must go through the Immer producer
        // because store state is frozen (autoFreeze) — direct mutation of a layer
        // object retrieved via getState() throws "object is not extensible".
        setLayerTag: (layerId, tag)=>{
            const layer = get().frames[get().activeFrameIndex]?.layers.find((candidate)=>candidate.id === layerId);
            if (!layer || layer.tag === tag) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Change Layer Tag')) return;
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame) return;
                const layer = currentFrame.layers.find((l)=>l.id === layerId);
                if (layer) {
                    layer.tag = tag;
                    state.isDirty = true;
                    state.editRevision += 1;
                }
            });
        },
        setLayerEffect: (layerId, effect)=>{
            if (!get().frames[get().activeFrameIndex]?.layers.some((layer)=>layer.id === layerId)) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Change Layer Effect')) return;
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame) return;
                const layer = currentFrame.layers.find((l)=>l.id === layerId);
                if (layer) {
                    layer.effect = effect ? structuredClone(effect) : undefined;
                    state.isDirty = true;
                    state.editRevision += 1;
                }
            });
        },
        mergeLayerDown: (layerId)=>{
            const frame = get().frames[get().activeFrameIndex];
            const layerIndex = frame?.layers.findIndex((layer)=>layer.id === layerId) ?? -1;
            if (!frame || frame.layers.length <= 1 || layerIndex < 0 || layerIndex >= frame.layers.length - 1) return;
            const upper = frame.layers[layerIndex];
            const lower = frame.layers[layerIndex + 1];
            if (upper.locked || lower.locked) return;
            const nonNormal = [
                upper,
                lower
            ].find((layer)=>layer.visible && layer.opacity > 0 && layer.blendMode !== 'source-over');
            if (nonNormal) {
                const modeLabel = nonNormal.blendMode.charAt(0).toUpperCase() + nonNormal.blendMode.slice(1);
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'error',
                    message: `Cannot merge: "${nonNormal.name}" uses ${modeLabel} blending. Merge down requires Normal blending on both visible layers to preserve their appearance.`
                });
                return;
            }
            const { canvasWidth: width, canvasHeight: height } = get();
            const merged = document.createElement('canvas');
            merged.width = width;
            merged.height = height;
            const mergeCtx = merged.getContext('2d', {
                willReadFrequently: true
            });
            if (!mergeCtx) return;
            mergeCtx.imageSmoothingEnabled = false;
            mergeCtx.globalCompositeOperation = 'source-over';
            for (const layer of [
                lower,
                upper
            ]){
                if (!layer.visible) continue;
                mergeCtx.globalAlpha = layer.opacity;
                mergeCtx.drawImage((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layer.id, width, height).canvas, 0, 0);
            }
            const mergedPixels = mergeCtx.getImageData(0, 0, width, height);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Merge Down Layer', {
                opKind: 'merge-layer',
                affectedLayerIds: [
                    upper.id,
                    lower.id
                ]
            })) return;
            set((state)=>{
                const currentFrame = state.frames[state.activeFrameIndex];
                if (!currentFrame || currentFrame.layers.length <= 1) return;
                const upperIndex = currentFrame.layers.findIndex((l)=>l.id === layerId);
                if (upperIndex === -1 || upperIndex >= currentFrame.layers.length - 1) {
                    return;
                }
                const upper = currentFrame.layers[upperIndex];
                const lower = currentFrame.layers[upperIndex + 1];
                const lowerBuffer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(lower.id, state.canvasWidth, state.canvasHeight);
                lowerBuffer.ctx.putImageData(mergedPixels, 0, 0);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(lower.id);
                lower.visible = upper.visible || lower.visible;
                lower.opacity = 1;
                lower.blendMode = 'source-over';
                // A merged raster is baked artwork, no longer the output of a single recipe.
                lower.tag = undefined;
                lower.effect = undefined;
                lower.research = undefined;
                currentFrame.layers.splice(upperIndex, 1);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteBuffers"])([
                    upper.id
                ]);
                state.activeLayerId = lower.id;
                state.bufferVersion += 1;
                state.isDirty = true;
                state.editRevision += 1;
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                type: 'success',
                message: `Merged "${upper.name}" into "${lower.name}"`,
                action: {
                    label: 'Undo',
                    onClick: ()=>{
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:undo');
                    }
                }
            });
        }
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/stores/slices/createToolSlice.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PRESET_PALETTES",
    ()=>PRESET_PALETTES,
    "createToolSlice",
    ()=>createToolSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$rampGenerator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/rampGenerator.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteAdmission.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteSemantics.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/structuralHistory.ts [app-client] (ecmascript)");
;
;
;
;
;
;
function rejectPaletteEdit(message) {
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
        type: 'error',
        message
    });
}
const PRESET_PALETTES = [
    {
        id: 'alabaster-wisteria-8',
        name: 'Alabaster & Wisteria (Active Theme)',
        colors: [
            '#DDDFDF',
            '#DDDDDF',
            '#D0C4DF',
            '#DCABDF',
            '#C792DF',
            '#A86EC6',
            '#6A5880',
            '#3A2E4C'
        ],
        cycleTracks: [
            {
                id: 'wisteria-pulse',
                name: 'Wisteria Shimmer',
                low: 2,
                high: 6,
                rate: 4,
                direction: 'ping-pong',
                blendShift: true,
                enabled: true
            }
        ]
    },
    {
        id: 'cozy-hearth-16',
        name: 'Cozy Hearth 16',
        colors: [
            '#161210',
            '#2c241e',
            '#3e332a',
            '#57473a',
            '#782216',
            '#ab3324',
            '#de4b39',
            '#f27463',
            '#9c6307',
            '#c98314',
            '#f5a623',
            '#f8be66',
            '#3b672c',
            '#6eb257',
            '#8cd075',
            '#f7efe6'
        ],
        cycleTracks: [
            {
                id: 'hearth-fire',
                name: 'Ember Cascade',
                low: 4,
                high: 7,
                rate: 8,
                direction: 'forward',
                blendShift: true,
                enabled: true
            },
            {
                id: 'gold-glow',
                name: 'Gold Glow',
                low: 8,
                high: 11,
                rate: 5,
                direction: 'ping-pong',
                blendShift: true,
                enabled: false
            }
        ]
    },
    {
        id: 'pico-8',
        name: 'Pico-8',
        colors: [
            '#000000',
            '#1D2B53',
            '#7E2553',
            '#008751',
            '#AB5236',
            '#5F574F',
            '#C2C3C7',
            '#FFF1E8',
            '#FF004D',
            '#FFA300',
            '#FFEC27',
            '#00E436',
            '#29ADFF',
            '#83769C',
            '#FF77A8',
            '#FFCCAA'
        ]
    },
    {
        id: 'endesga-32',
        name: 'Endesga 32 (EDG32)',
        colors: [
            '#be4a2f',
            '#d77643',
            '#ead4aa',
            '#e4a672',
            '#b86f56',
            '#733e39',
            '#3e2731',
            '#261726',
            '#a22633',
            '#e43b44',
            '#f77622',
            '#feae34',
            '#fee761',
            '#63c74d',
            '#3e8948',
            '#265c42',
            '#193c3e',
            '#124e89',
            '#0099db',
            '#2ce8f5',
            '#ffffff',
            '#c0cbdc',
            '#8b9bb4',
            '#5a6988',
            '#3a4466',
            '#262b44',
            '#181425',
            '#ff0044',
            '#68386c',
            '#b55088',
            '#f6757a',
            '#e8b796'
        ]
    }
];
const createToolSlice = (set, get)=>({
        tools: {
            activeTool: 'pen',
            brushSize: 1,
            pixelPerfect: true,
            ditherMatrix: '2x2',
            ditherDensity: 0.5,
            bucketContiguous: true,
            bucketTolerance: 0,
            fillTolerance: 24,
            fillEnclosedSpecks: false,
            eraseColorTolerance: 24,
            eraseColorContiguous: false,
            eraseColorFamily: true,
            eraseColorAllFrames: false,
            shapeFilled: false,
            symmetryHorizontal: false,
            symmetryVertical: false,
            symmetryGroup: 'none',
            lightAzimuth: 315,
            lightElevation: 45,
            lightRadius: 64,
            lightBrightness: 1.15,
            glintStyle: 'soft',
            sourceShadingRemoval: 0,
            materialPreset: 'matte',
            formType: 'auto',
            minecraftSkinMode: 'auto',
            shadingBands: 2,
            cavityStrength: 1.0,
            ditherModulation: 0.0,
            curveTightness: 0.5,
            isoAngleSnap: true,
            chiselAzimuth: 315,
            chiselIncline: 45,
            chiselWidth: 4,
            chiselRidgeMode: false,
            normalBlendMode: 'rnm'
        },
        primaryColor: '#3A2E4C',
        secondaryColor: '#C792DF',
        palettes: PRESET_PALETTES,
        currentPaletteId: 'alabaster-wisteria-8',
        customRamps: [],
        isPaletteCycling: false,
        paletteCycleSpeedMultiplier: 1.0,
        recentColors: [],
        setActiveTool: (tool)=>{
            set((state)=>{
                state.tools.activeTool = tool;
            });
        },
        setBrushSize: (size)=>{
            set((state)=>{
                state.tools.brushSize = Math.max(1, Math.min(32, size));
            });
        },
        setPixelPerfect: (enabled)=>{
            set((state)=>{
                state.tools.pixelPerfect = enabled;
            });
        },
        setDitherMatrix: (matrix)=>{
            set((state)=>{
                state.tools.ditherMatrix = matrix;
            });
        },
        setDitherDensity: (density)=>{
            set((state)=>{
                state.tools.ditherDensity = Math.max(0.05, Math.min(0.95, density));
            });
        },
        setBucketContiguous: (enabled)=>{
            set((state)=>{
                state.tools.bucketContiguous = enabled;
            });
        },
        setBucketTolerance: (tolerance)=>{
            set((state)=>{
                state.tools.bucketTolerance = Math.max(0, Math.min(255, tolerance));
            });
        },
        setFillTolerance: (tolerance)=>{
            set((state)=>{
                state.tools.fillTolerance = Math.max(0, Math.min(255, tolerance));
            });
        },
        setFillEnclosedSpecks: (enabled)=>{
            set((state)=>{
                state.tools.fillEnclosedSpecks = enabled;
            });
        },
        setEraseColorTolerance: (tolerance)=>{
            set((state)=>{
                state.tools.eraseColorTolerance = Math.max(0, Math.min(255, tolerance));
            });
        },
        setEraseColorContiguous: (enabled)=>{
            set((state)=>{
                state.tools.eraseColorContiguous = enabled;
                if (enabled) state.tools.eraseColorAllFrames = false;
            });
        },
        setEraseColorFamily: (enabled)=>{
            set((state)=>{
                state.tools.eraseColorFamily = enabled;
                if (enabled) state.tools.eraseColorContiguous = false;
            });
        },
        setEraseColorAllFrames: (enabled)=>{
            set((state)=>{
                state.tools.eraseColorAllFrames = enabled;
                if (enabled) state.tools.eraseColorContiguous = false;
            });
        },
        setShapeFilled: (filled)=>{
            set((state)=>{
                state.tools.shapeFilled = filled;
            });
        },
        toggleSymmetryH: ()=>{
            set((state)=>{
                state.tools.symmetryHorizontal = !state.tools.symmetryHorizontal;
            });
        },
        toggleSymmetryV: ()=>{
            set((state)=>{
                state.tools.symmetryVertical = !state.tools.symmetryVertical;
            });
        },
        setSymmetryGroup: (group)=>{
            set((state)=>{
                state.tools.symmetryGroup = group;
            });
        },
        setLightAzimuth: (azimuth)=>{
            set((state)=>{
                state.tools.lightAzimuth = (azimuth % 360 + 360) % 360;
            });
        },
        setLightElevation: (elevation)=>{
            set((state)=>{
                state.tools.lightElevation = Math.max(0, Math.min(90, elevation));
            });
        },
        setLightRadius: (radius)=>{
            set((state)=>{
                state.tools.lightRadius = Math.max(16, Math.min(256, radius));
            });
        },
        setLightBrightness: (brightness)=>{
            set((state)=>{
                state.tools.lightBrightness = Math.max(0.3, Math.min(2.5, brightness));
            });
        },
        setSourceShadingRemoval: (amount)=>{
            set((state)=>{
                state.tools.sourceShadingRemoval = Math.max(0, Math.min(1, amount));
            });
        },
        setMaterialPreset: (preset)=>{
            set((state)=>{
                state.tools.materialPreset = preset;
            });
        },
        setFormType: (formType)=>{
            set((state)=>{
                state.tools.formType = formType;
            });
        },
        setMinecraftSkinMode: (mode)=>{
            set((state)=>{
                state.tools.minecraftSkinMode = mode;
            });
        },
        setGlintStyle: (style)=>{
            set((state)=>{
                state.tools.glintStyle = style;
            });
        },
        setShadingBands: (bands)=>{
            set((state)=>{
                state.tools.shadingBands = bands;
            });
        },
        setCavityStrength: (strength)=>{
            set((state)=>{
                state.tools.cavityStrength = Math.max(0, Math.min(2, strength));
            });
        },
        setDitherModulation: (mod)=>{
            set((state)=>{
                state.tools.ditherModulation = Math.max(0, Math.min(1, mod));
            });
        },
        setCurveTightness: (tightness)=>{
            set((state)=>{
                state.tools.curveTightness = Math.max(0, Math.min(1, tightness));
            });
        },
        setIsoAngleSnap: (snap)=>{
            set((state)=>{
                state.tools.isoAngleSnap = snap;
            });
        },
        setChiselAzimuth: (azimuth)=>{
            set((state)=>{
                state.tools.chiselAzimuth = (azimuth % 360 + 360) % 360;
            });
        },
        setChiselIncline: (incline)=>{
            set((state)=>{
                state.tools.chiselIncline = Math.max(15, Math.min(75, incline));
            });
        },
        setChiselWidth: (width)=>{
            set((state)=>{
                state.tools.chiselWidth = Math.max(1, Math.min(32, width));
            });
        },
        setChiselRidgeMode: (ridge)=>{
            set((state)=>{
                state.tools.chiselRidgeMode = ridge;
            });
        },
        setNormalBlendMode: (mode)=>{
            set((state)=>{
                state.tools.normalBlendMode = mode;
            });
        },
        togglePaletteCycling: ()=>{
            set((state)=>{
                state.isPaletteCycling = !state.isPaletteCycling;
            });
        },
        setPaletteCycling: (cycling)=>{
            set((state)=>{
                state.isPaletteCycling = cycling;
            });
        },
        setPaletteCycleSpeedMultiplier: (mult)=>{
            set((state)=>{
                state.paletteCycleSpeedMultiplier = Math.max(0.1, Math.min(10, mult));
            });
        },
        addPaletteCycleTrack: (paletteId, track)=>{
            const palette = get().palettes.find((p)=>p.id === paletteId);
            if (!palette) return;
            const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paletteCycleTrackError"])(track, palette.colors.length);
            if (error || (palette.cycleTracks?.length ?? 0) >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_CYCLE_TRACKS"] || palette.cycleTracks?.some((existing)=>existing.id === track.id)) {
                rejectPaletteEdit(error ?? `A palette can have at most ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_CYCLE_TRACKS"]} unique cycle tracks.`);
                return;
            }
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Add palette cycle track', {
                includePalettes: true
            })) return;
            set((state)=>{
                const pal = state.palettes.find((p)=>p.id === paletteId);
                if (pal) {
                    if (!pal.cycleTracks) pal.cycleTracks = [];
                    pal.cycleTracks.push(track);
                }
            });
            get().setDirty(true);
        },
        updatePaletteCycleTrack: (paletteId, trackId, updates)=>{
            const palette = get().palettes.find((p)=>p.id === paletteId);
            const current = palette?.cycleTracks?.find((track)=>track.id === trackId);
            if (!palette || !current) return;
            const candidate = {
                ...current,
                ...updates
            };
            const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paletteCycleTrackError"])(candidate, palette.colors.length);
            if (error || palette.cycleTracks?.some((track)=>track !== current && track.id === candidate.id)) {
                rejectPaletteEdit(error ?? 'Cycle track identifiers must be unique.');
                return;
            }
            if (Object.entries(updates).every(([key, value])=>current[key] === value)) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Edit palette cycle track', {
                includePalettes: true
            })) return;
            set((state)=>{
                const pal = state.palettes.find((p)=>p.id === paletteId);
                if (pal?.cycleTracks) {
                    const trk = pal.cycleTracks.find((t)=>t.id === trackId);
                    if (trk) {
                        Object.assign(trk, updates);
                    }
                }
            });
            get().setDirty(true);
        },
        deletePaletteCycleTrack: (paletteId, trackId)=>{
            if (!get().palettes.find((p)=>p.id === paletteId)?.cycleTracks?.some((track)=>track.id === trackId)) return;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Remove palette cycle track', {
                includePalettes: true
            })) return;
            set((state)=>{
                const pal = state.palettes.find((p)=>p.id === paletteId);
                if (pal?.cycleTracks) {
                    pal.cycleTracks = pal.cycleTracks.filter((t)=>t.id !== trackId);
                }
            });
            get().setDirty(true);
        },
        setPaletteSemantics: (paletteId, input)=>{
            const palette = get().palettes.find((p)=>p.id === paletteId);
            if (!palette) return;
            const semantics = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parsePaletteSemantics"])(input, palette.colors.length);
            if (!semantics) {
                rejectPaletteEdit('Palette roles or bindings are invalid or exceed their limits.');
                return;
            }
            if (JSON.stringify(semantics) === JSON.stringify(palette.semantics)) return;
            const growth = Math.max(0, JSON.stringify(semantics).length * 2 - JSON.stringify(palette.semantics ?? {}).length * 2);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Edit palette roles and index bindings', {
                includePalettes: true,
                addedMetadataBytes: growth
            })) return;
            set((state)=>{
                state.palettes.find((p)=>p.id === paletteId).semantics = semantics;
            });
            get().setDirty(true);
        },
        setPrimaryColor: (color)=>{
            set((state)=>{
                state.primaryColor = color;
            });
            get().addRecentColor(color);
        },
        setSecondaryColor: (color)=>{
            set((state)=>{
                state.secondaryColor = color;
            });
            get().addRecentColor(color);
        },
        addRecentColor: (color)=>{
            set((state)=>{
                const hex = color.toUpperCase();
                state.recentColors = state.recentColors.filter((c)=>c !== hex);
                state.recentColors.unshift(hex);
                if (state.recentColors.length > 8) {
                    state.recentColors.pop();
                }
                if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.localStorage) {
                    window.localStorage.setItem('pixibun_recent_colors', JSON.stringify(state.recentColors));
                }
            });
        },
        loadRecentColors: ()=>{
            if (("TURBOPACK compile-time value", "object") === 'undefined' || !window.localStorage) return;
            try {
                const parsed = JSON.parse(window.localStorage.getItem('pixibun_recent_colors') || '[]');
                if (!Array.isArray(parsed)) return;
                const valid = parsed.filter((c)=>typeof c === 'string');
                set((state)=>{
                    state.recentColors = valid;
                });
            } catch  {
            // ignore corrupted storage
            }
        },
        swapColors: ()=>{
            set((state)=>{
                const temp = state.primaryColor;
                state.primaryColor = state.secondaryColor;
                state.secondaryColor = temp;
            });
        },
        selectPalette: (id)=>{
            if (id === get().currentPaletteId) return;
            if (!get().palettes.some((palette)=>palette.id === id)) {
                rejectPaletteEdit('That palette is unavailable.');
                return;
            }
            set((state)=>{
                state.currentPaletteId = id;
            });
            get().setDirty(true);
        },
        addCustomColorToPalette: (paletteId, color)=>{
            const palette = get().palettes.find((p)=>p.id === paletteId);
            if (!palette || palette.colors.includes(color)) return;
            const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paletteEntryError"])(palette.name, [
                ...palette.colors,
                color
            ]);
            if (error) {
                rejectPaletteEdit(error);
                return;
            }
            set((state)=>{
                const pal = state.palettes.find((p)=>p.id === paletteId);
                if (pal && !pal.colors.includes(color)) {
                    pal.colors.push(color);
                }
            });
            get().setDirty(true);
        },
        setCustomRamps: (ramps)=>{
            const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["customRampsError"])(ramps);
            if (error) {
                rejectPaletteEdit(error);
                return;
            }
            set((state)=>{
                state.customRamps = ramps.map((ramp)=>({
                        baseColor: ramp.baseColor,
                        shades: [
                            ...ramp.shades
                        ]
                    }));
            });
            get().setDirty(true);
        },
        removePaletteColor: (paletteId, index)=>{
            const palette = get().palettes.find((p)=>p.id === paletteId);
            if (!palette || !Number.isInteger(index) || index < 0 || index >= palette.colors.length) return false;
            if (palette.colors.length <= 1) {
                rejectPaletteEdit('Keep at least one color in your palette.');
                return false;
            }
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Remove palette color', {
                includePalettes: true
            })) return false;
            set((state)=>{
                const target = state.palettes.find((p)=>p.id === paletteId);
                target.colors.splice(index, 1);
                if (target.semantics) {
                    const removed = target.semantics.entries.splice(index, 1)[0]?.id;
                    target.semantics.bindings = target.semantics.bindings.filter((b)=>b.entryId !== removed);
                }
                target.cycleTracks = target.cycleTracks?.flatMap((track)=>{
                    if (index > track.high) return [
                        track
                    ];
                    if (index < track.low) return [
                        {
                            ...track,
                            low: track.low - 1,
                            high: track.high - 1
                        }
                    ];
                    return track.high > track.low ? [
                        {
                            ...track,
                            high: track.high - 1
                        }
                    ] : [];
                });
            });
            get().setDirty(true);
            return true;
        },
        addExtractedPalette: (name, colors)=>{
            if (get().palettes.length >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PROJECT_PALETTES"]) {
                rejectPaletteEdit(`A project can have at most ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PROJECT_PALETTES"]} palettes.`);
                return false;
            }
            const nextColors = colors.length > 0 ? colors : [
                '#3A2E4C',
                '#C792DF',
                '#DCABDF',
                '#DDDFDF'
            ];
            const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paletteEntryError"])(name, nextColors);
            if (error) {
                rejectPaletteEdit(error);
                return false;
            }
            const newPalette = {
                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('palette'),
                name,
                colors: [
                    ...nextColors
                ]
            };
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Add palette', {
                includePalettes: true,
                addedMetadataBytes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["estimatePaletteBytes"])(newPalette)
            })) return false;
            set((state)=>{
                state.palettes.push(newPalette);
                state.currentPaletteId = newPalette.id;
            });
            get().setDirty(true);
            return true;
        },
        generateAndAddRamp: (baseColor)=>{
            const palette = get().palettes.find((p)=>p.id === get().currentPaletteId);
            if (!palette) return;
            const rampColors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$rampGenerator$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateOklchRamp"])(baseColor);
            const newColors = rampColors.filter((color)=>!palette.colors.includes(color));
            if (newColors.length === 0) return;
            if (palette.colors.length + newColors.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_COLORS"]) {
                rejectPaletteEdit(`A palette can have at most ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_COLORS"]} colors.`);
                return;
            }
            if (palette.semantics && palette.colors.length + newColors.length > 256) {
                rejectPaletteEdit('A palette with index bindings can have at most 256 registers.');
                return;
            }
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Add palette ramp', {
                includePalettes: true
            })) return;
            set((state)=>{
                const activePal = state.palettes.find((p)=>p.id === state.currentPaletteId);
                if (activePal) {
                    for (const color of rampColors){
                        if (!activePal.colors.includes(color)) {
                            activePal.colors.push(color);
                            activePal.semantics?.entries.push({
                                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('register'),
                                role: ''
                            });
                        }
                    }
                }
            });
            get().setDirty(true);
        }
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/stores/slices/createViewportSlice.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createViewportSlice",
    ()=>createViewportSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/canvasLimits.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/workspaceEnvelopeGuard.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/metadataAdmission.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const createViewportSlice = (set, get)=>({
        currentProjectId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj'),
        canvasWidth: 32,
        canvasHeight: 32,
        projectName: 'Untitled Sprite',
        zoom: 1600,
        panX: 0,
        panY: 0,
        showGrid: true,
        showTilePreview: false,
        showIsoGuides: false,
        showFloatingPreview: false,
        showNormalMapPreview: false,
        previewScale: 2,
        previewBackdrop: 'checker',
        cvdLens: 'none',
        squintMode: false,
        photometricGizmoActive: false,
        referenceOverlay: 'none',
        setReferenceOverlay: (mode)=>{
            set((state)=>{
                state.referenceOverlay = mode;
            });
        },
        cycleReferenceOverlay: ()=>{
            set((state)=>{
                const modes = [
                    'none',
                    'thirds',
                    'golden',
                    'center'
                ];
                const nextIdx = (modes.indexOf(state.referenceOverlay) + 1) % modes.length;
                state.referenceOverlay = modes[nextIdx];
            });
        },
        setPhotometricGizmoActive: (active)=>{
            set((state)=>{
                state.photometricGizmoActive = active;
            });
        },
        setCurrentProjectId: (id)=>{
            set((state)=>{
                state.currentProjectId = id;
            });
        },
        setCanvasSize: (width, height, anchor = 'center', resample = true)=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertWorkspaceDimensions"])(width, height);
            const previousWidth = get().canvasWidth;
            const previousHeight = get().canvasHeight;
            if (previousWidth === width && previousHeight === height) return;
            const validity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateWorkspaceStructure"])(width, height, get().frames);
            if (!validity.ok) {
                throw new RangeError(validity.reason);
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resizeAllBuffers"])(width, height, anchor, resample);
            set((state)=>{
                state.canvasWidth = width;
                state.canvasHeight = height;
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        setProjectName: (name)=>{
            const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["projectNameError"])(name);
            if (error) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'error',
                    message: error
                });
                return;
            }
            if (name === get().projectName) return;
            set((state)=>{
                state.projectName = name;
                state.isDirty = true;
                state.editRevision += 1;
            });
        },
        setZoom: (zoom)=>{
            set((state)=>{
                state.zoom = Math.max(10, Math.min(6400, Math.round(zoom)));
            });
        },
        setPan: (x, y)=>{
            set((state)=>{
                state.panX = Math.round(x);
                state.panY = Math.round(y);
            });
        },
        setZoomAndPan: (zoom, x, y)=>{
            set((state)=>{
                state.zoom = Math.max(10, Math.min(6400, Math.round(zoom)));
                state.panX = Math.round(x);
                state.panY = Math.round(y);
            });
        },
        toggleGrid: ()=>{
            set((state)=>{
                state.showGrid = !state.showGrid;
            });
        },
        toggleTilePreview: ()=>{
            set((state)=>{
                state.showTilePreview = !state.showTilePreview;
            });
        },
        toggleIsoGuides: ()=>{
            set((state)=>{
                state.showIsoGuides = !state.showIsoGuides;
            });
        },
        toggleFloatingPreview: ()=>{
            set((state)=>{
                state.showFloatingPreview = !state.showFloatingPreview;
            });
        },
        toggleNormalMapPreview: ()=>{
            set((state)=>{
                state.showNormalMapPreview = !state.showNormalMapPreview;
            });
        },
        setPreviewScale: (scale)=>{
            set((state)=>{
                state.previewScale = scale;
            });
        },
        setPreviewBackdrop: (bg)=>{
            set((state)=>{
                state.previewBackdrop = bg;
            });
        },
        setCvdLens: (mode)=>{
            set((state)=>{
                state.cvdLens = mode;
            });
        },
        toggleSquintMode: ()=>{
            set((state)=>{
                state.squintMode = !state.squintMode;
            });
        }
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStudioStore",
    ()=>useStudioStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware/immer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$slices$2f$createViewportSlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/stores/slices/createViewportSlice.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$slices$2f$createToolSlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/stores/slices/createToolSlice.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$slices$2f$createLayerSlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/stores/slices/createLayerSlice.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$slices$2f$createAnimationSlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/stores/slices/createAnimationSlice.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$slices$2f$createHistorySlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/stores/slices/createHistorySlice.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const useStudioStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["immer"])((...a)=>({
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$slices$2f$createViewportSlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createViewportSlice"])(...a),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$slices$2f$createToolSlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createToolSlice"])(...a),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$slices$2f$createLayerSlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createLayerSlice"])(...a),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$slices$2f$createAnimationSlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAnimationSlice"])(...a),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$slices$2f$createHistorySlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createHistorySlice"])(...a)
    })));
if ("TURBOPACK compile-time truthy", 1) {
    if ("TURBOPACK compile-time truthy", 1) {
        window.__studioStore = useStudioStore;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/stores/themeStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyThemeToDOM",
    ()=>applyThemeToDOM,
    "getInitialColorScheme",
    ()=>getInitialColorScheme,
    "getInitialStudioTheme",
    ()=>getInitialStudioTheme,
    "useThemeStore",
    ()=>useThemeStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
'use client';
;
function applyThemeToDOM(studioTheme, colorScheme) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const root = document.documentElement;
    // 1. Inject temporary zero-transition override
    const css = document.createElement('style');
    css.id = 'pixibun-theme-transition-killer';
    css.appendChild(document.createTextNode(`*, *::before, *::after {
        -webkit-transition: none !important;
        -moz-transition: none !important;
        -o-transition: none !important;
        -ms-transition: none !important;
        transition: none !important;
      }`));
    document.head.appendChild(css);
    // 2. Mutate theme attributes
    const validTheme = studioTheme === 'cozy-classic' ? 'cozy-classic' : 'atelier';
    const validScheme = colorScheme === 'light' ? 'light' : 'dark';
    root.setAttribute('data-studio-theme', validTheme);
    root.setAttribute('data-color-scheme', validScheme);
    root.setAttribute('data-theme', validScheme); // backward compatibility
    if (validScheme === 'light') {
        root.classList.add('light');
        root.classList.remove('dark');
        root.style.colorScheme = 'light';
    } else {
        root.classList.add('dark');
        root.classList.remove('light');
        root.style.colorScheme = 'dark';
    }
    // 3. Force synchronous style recalculation while transitions are disabled
    void window.getComputedStyle(css).opacity;
    // 4. Cleanly remove the temporary stylesheet on the next frame
    requestAnimationFrame(()=>{
        if (css.parentNode) {
            document.head.removeChild(css);
        }
    });
}
function getInitialStudioTheme() {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !window.localStorage) return 'atelier';
    try {
        const saved = window.localStorage.getItem('pixibun-studio-theme');
        if (saved === 'cozy-classic') return 'cozy-classic';
        if (saved === 'atelier') return 'atelier';
    } catch  {
    // ignore storage errors
    }
    return 'atelier';
}
function getInitialColorScheme() {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !window.localStorage) return 'dark';
    try {
        const savedScheme = window.localStorage.getItem('pixibun-color-scheme') || window.localStorage.getItem('pixibun-theme');
        if (savedScheme === 'light') return 'light';
        if (savedScheme === 'dark') return 'dark';
    } catch  {
    // ignore storage errors
    }
    return 'dark';
}
const initialStudioTheme = getInitialStudioTheme();
const initialColorScheme = getInitialColorScheme();
const useThemeStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        studioTheme: initialStudioTheme,
        colorScheme: initialColorScheme,
        theme: initialColorScheme,
        setStudioTheme: (studioTheme)=>{
            const validTheme = studioTheme === 'cozy-classic' ? 'cozy-classic' : 'atelier';
            set({
                studioTheme: validTheme
            });
            if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.localStorage) {
                try {
                    window.localStorage.setItem('pixibun-studio-theme', validTheme);
                } catch  {
                // ignore storage errors
                }
                applyThemeToDOM(validTheme, get().colorScheme);
            }
        },
        setColorScheme: (colorScheme)=>{
            const validScheme = colorScheme === 'light' ? 'light' : 'dark';
            set({
                colorScheme: validScheme,
                theme: validScheme
            });
            if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.localStorage) {
                try {
                    window.localStorage.setItem('pixibun-color-scheme', validScheme);
                    window.localStorage.setItem('pixibun-theme', validScheme);
                } catch  {
                // ignore storage errors
                }
                applyThemeToDOM(get().studioTheme, validScheme);
            }
        },
        toggleColorScheme: ()=>{
            const next = get().colorScheme === 'dark' ? 'light' : 'dark';
            get().setColorScheme(next);
        },
        setTheme: (theme)=>{
            get().setColorScheme(theme);
        },
        toggleTheme: ()=>{
            get().toggleColorScheme();
        }
    }));
if ("TURBOPACK compile-time truthy", 1) {
    applyThemeToDOM(initialStudioTheme, initialColorScheme);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/workers/heavyCompute.worker.ts (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/heavyCompute.worker.0p65f84rwe3b9.ts");}),
"[project]/src/workers/heavyCompute.worker.ts [app-client] (ecmascript, worker loader)", ((__turbopack_context__) => {

__turbopack_context__.v(__turbopack_context__.r("[turbopack-ecmascript]/worker/browser/createWorker.ts [app-client] (ecmascript)")["default"]("static/chunks/turbopack-worker-[client-fs]__next_static_chunks_1_hyozq._.js", ["static/chunks/src_1u27gfa._.js","static/chunks/src_workers_heavyCompute_worker_ts_1gdnjqz._.js","static/chunks/turbopack-src_workers_heavyCompute_worker_ts_07st5kw._.js"]));
}),
]);

//# sourceMappingURL=src_208x4lb._.js.map