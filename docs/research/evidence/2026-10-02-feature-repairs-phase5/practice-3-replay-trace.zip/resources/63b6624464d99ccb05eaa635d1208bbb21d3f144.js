(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/error.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ErrorBoundary
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixiBunLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixiBunLogo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/diagnostics/capture.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function ErrorBoundary({ error, reset }) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ErrorBoundary.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureDiagnostic"])({
                kind: 'error',
                message: error.message || 'Unhandled route error',
                detail: error.stack || (error.digest ? `Digest: ${error.digest}` : undefined)
            });
        }
    }["ErrorBoundary.useEffect"], [
        error
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen flex items-center justify-center bg-[var(--desk-bg)] text-[var(--text-heading)] p-6 font-mono",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-md w-full bg-[var(--desk-surface)] border-2 border-[var(--desk-border)] rounded-[4px] p-6 shadow-[0_4px_0_var(--desk-bg)] flex flex-col gap-4 text-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-center mb-1",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixiBunLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixiBunLogo"], {
                        size: "lg",
                        className: "drop-shadow-sm"
                    }, void 0, false, {
                        fileName: "[project]/src/app/error.tsx",
                        lineNumber: 26,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/error.tsx",
                    lineNumber: 25,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-lg font-bold text-[var(--accent-gold)] font-display",
                    children: "A Hitch in the Atelier"
                }, void 0, false, {
                    fileName: "[project]/src/app/error.tsx",
                    lineNumber: 28,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-xs text-[var(--text-body)] leading-relaxed",
                    children: "An unexpected interruption occurred. Your artwork and preferences remain safely stored in your browser."
                }, void 0, false, {
                    fileName: "[project]/src/app/error.tsx",
                    lineNumber: 31,
                    columnNumber: 9
                }, this),
                error.message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[var(--desk-bg)] border border-[var(--desk-border)] p-2.5 rounded text-[11px] text-[#fca5a5] text-left break-words max-h-24 overflow-y-auto font-mono",
                    children: error.message
                }, void 0, false, {
                    fileName: "[project]/src/app/error.tsx",
                    lineNumber: 35,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col sm:flex-row gap-2 justify-center mt-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>reset(),
                            className: "px-4 py-2 bg-[var(--accent-gold)] text-[var(--desk-bg)] font-bold text-xs rounded border-2 border-[var(--desk-border)] hover:opacity-90 transition-opacity",
                            children: "Try Again"
                        }, void 0, false, {
                            fileName: "[project]/src/app/error.tsx",
                            lineNumber: 40,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>window.location.reload(),
                            className: "px-4 py-2 bg-[var(--desk-surface-raised)] text-[var(--text-heading)] font-medium text-xs rounded border border-[var(--desk-border)] hover:bg-[var(--desk-surface)] transition-colors",
                            children: "Reload Atelier"
                        }, void 0, false, {
                            fileName: "[project]/src/app/error.tsx",
                            lineNumber: 47,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exportDiagnosticsFile"])(),
                            className: "px-3 py-2 bg-transparent text-[var(--text-body)] hover:text-[var(--accent-gold)] text-xs underline underline-offset-2 transition-colors",
                            children: "Export Logs"
                        }, void 0, false, {
                            fileName: "[project]/src/app/error.tsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/error.tsx",
                    lineNumber: 39,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/error.tsx",
            lineNumber: 24,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/error.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
}
_s(ErrorBoundary, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ErrorBoundary;
var _c;
__turbopack_context__.k.register(_c, "ErrorBoundary");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/BunMascot.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BunMascot",
    ()=>BunMascot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$bunSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/art/bunSprite.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const BunMascot = ({ size = 32, pose = 'idle', animate = false, className })=>{
    _s();
    const [blinking, setBlinking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BunMascot.useEffect": ()=>{
            if (!animate || pose !== 'idle') return;
            if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
            let hideTimer;
            const schedule = window.setInterval({
                "BunMascot.useEffect.schedule": ()=>{
                    setBlinking(true);
                    hideTimer = window.setTimeout({
                        "BunMascot.useEffect.schedule": ()=>setBlinking(false)
                    }["BunMascot.useEffect.schedule"], 160);
                }
            }["BunMascot.useEffect.schedule"], 3400);
            return ({
                "BunMascot.useEffect": ()=>{
                    window.clearInterval(schedule);
                    window.clearTimeout(hideTimer);
                }
            })["BunMascot.useEffect"];
        }
    }["BunMascot.useEffect"], [
        animate,
        pose
    ]);
    const activePose = pose === 'blink' || blinking ? 'blink' : pose;
    const pixels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BunMascot.useMemo[pixels]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$bunSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bunPixels"])(activePose)
    }["BunMascot.useMemo[pixels]"], [
        activePose
    ]);
    const outline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BunMascot.useMemo[outline]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$bunSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bunOutline"])(activePose)
    }["BunMascot.useMemo[outline]"], [
        activePose
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "-1 -1 18 18",
        width: size,
        height: size,
        shapeRendering: "crispEdges",
        className: className,
        role: "img",
        "aria-label": "Bun, the PixiBun bunny",
        children: [
            outline.map(([x, y], i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    x: x,
                    y: y,
                    width: 1,
                    height: 1,
                    fill: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$bunSprite$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BUN_INK"]
                }, `o${i}`, false, {
                    fileName: "[project]/src/components/ui/BunMascot.tsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))),
            pixels.map(([x, y, w, h, fill], i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    x: x,
                    y: y,
                    width: w,
                    height: h,
                    fill: fill
                }, i, false, {
                    fileName: "[project]/src/components/ui/BunMascot.tsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/BunMascot.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(BunMascot, "DUQnfcHZ7pyl95RhjFP/EEAAE1c=");
_c = BunMascot;
var _c;
__turbopack_context__.k.register(_c, "BunMascot");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/PixiBunLogo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PixiBunLogo",
    ()=>PixiBunLogo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$BunMascot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/BunMascot.tsx [app-client] (ecmascript)");
'use client';
;
;
const PixiBunLogo = ({ size = 'md', showSubtitle = true, wordmarkClassName = '', className = '', style })=>{
    const sizeConfig = {
        sm: {
            tile: 'w-7 h-7 p-0.5',
            mascot: 18,
            title: 'text-xs tracking-wider',
            subtitle: 'text-[9px] mt-0.5',
            gap: 'gap-2'
        },
        md: {
            tile: 'w-8 h-8 p-0.5',
            mascot: 22,
            title: 'text-sm tracking-wider',
            subtitle: 'text-[10px] mt-0.5',
            gap: 'gap-2.5'
        },
        lg: {
            tile: 'w-10 h-10 p-1',
            mascot: 28,
            title: 'text-base tracking-widest',
            subtitle: 'text-xs mt-1',
            gap: 'gap-3'
        }
    }[size];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `inline-flex items-center ${sizeConfig.gap} select-none ${className}`,
        style: style,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `${sizeConfig.tile} flex items-center justify-center bg-[var(--desk-surface-raised)] border-2 border-[var(--desk-border)] rounded-[2px] shadow-sm shrink-0`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$BunMascot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BunMascot"], {
                    size: sizeConfig.mascot,
                    animate: true
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `flex flex-col leading-none ${wordmarkClassName}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `font-display font-bold ${sizeConfig.title} text-[var(--text-heading)]`,
                        children: "PIXIBUN"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    showSubtitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `font-mono tracking-tight text-[var(--accent-gold)] ${sizeConfig.subtitle}`,
                        children: "ATELIER"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
                        lineNumber: 65,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/PixiBunLogo.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = PixiBunLogo;
var _c;
__turbopack_context__.k.register(_c, "PixiBunLogo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/art/bunSprite.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BUN_BODY",
    ()=>BUN_BODY,
    "BUN_INK",
    ()=>BUN_INK,
    "BUN_POSES",
    ()=>BUN_POSES,
    "bunOutline",
    ()=>bunOutline,
    "bunPixels",
    ()=>bunPixels,
    "drawBun",
    ()=>drawBun
]);
const BUN_INK = '#3a2e4c';
const FUR = '#f2ecf7';
const SHADE = '#d9cde8';
const INNER = '#f0b7cf';
const BLUSH = '#f2b8c6';
const BELLY = '#faf6fc';
const BUN_BODY = [
    // Left ear
    [
        4,
        0,
        1,
        1,
        FUR
    ],
    [
        3,
        1,
        3,
        1,
        FUR
    ],
    [
        3,
        2,
        3,
        3,
        FUR
    ],
    [
        4,
        2,
        1,
        3,
        INNER
    ],
    // Right ear
    [
        11,
        0,
        1,
        1,
        FUR
    ],
    [
        10,
        1,
        3,
        1,
        FUR
    ],
    [
        10,
        2,
        3,
        3,
        FUR
    ],
    [
        11,
        2,
        1,
        3,
        INNER
    ],
    // Head, rounded corners
    [
        4,
        5,
        8,
        1,
        FUR
    ],
    [
        3,
        6,
        10,
        1,
        FUR
    ],
    [
        2,
        7,
        12,
        4,
        FUR
    ],
    [
        3,
        11,
        10,
        1,
        SHADE
    ],
    // Body
    [
        3,
        12,
        10,
        3,
        FUR
    ],
    [
        3,
        12,
        1,
        3,
        SHADE
    ],
    [
        12,
        12,
        1,
        3,
        SHADE
    ],
    [
        6,
        13,
        4,
        2,
        BELLY
    ],
    [
        3,
        15,
        10,
        1,
        SHADE
    ]
];
const BUN_POSES = {
    idle: [
        [
            5,
            8,
            1,
            2,
            BUN_INK
        ],
        [
            10,
            8,
            1,
            2,
            BUN_INK
        ]
    ],
    blink: [
        [
            5,
            9,
            1,
            1,
            BUN_INK
        ],
        [
            10,
            9,
            1,
            1,
            BUN_INK
        ]
    ],
    happy: [
        [
            5,
            7,
            1,
            1,
            BUN_INK
        ],
        [
            4,
            8,
            1,
            1,
            BUN_INK
        ],
        [
            6,
            8,
            1,
            1,
            BUN_INK
        ],
        [
            10,
            7,
            1,
            1,
            BUN_INK
        ],
        [
            9,
            8,
            1,
            1,
            BUN_INK
        ],
        [
            11,
            8,
            1,
            1,
            BUN_INK
        ]
    ]
};
// Rosy cheeks survive every pose.
const BUN_BLUSH = [
    [
        3,
        9,
        2,
        1,
        BLUSH
    ],
    [
        11,
        9,
        2,
        1,
        BLUSH
    ]
];
function bunPixels(pose) {
    return [
        ...BUN_BODY,
        ...BUN_BLUSH,
        ...BUN_POSES[pose]
    ];
}
function bunOutline(pose) {
    const covered = new Set();
    const ring = [];
    for (const [x, y, w, h] of bunPixels(pose)){
        for(let dx = -1; dx <= w; dx++){
            for(let dy = -1; dy <= h; dy++){
                const px = x + dx;
                const py = y + dy;
                const key = `${px},${py}`;
                if (covered.has(key)) continue;
                covered.add(key);
                const inside = dx >= 0 && dx < w && dy >= 0 && dy < h;
                if (!inside) ring.push([
                    px,
                    py
                ]);
            }
        }
    }
    return ring;
}
function drawBun(ctx, ox, oy, pose, outline = true) {
    if (outline) {
        ctx.fillStyle = BUN_INK;
        for (const [x, y] of bunOutline(pose)){
            ctx.fillRect(ox + x, oy + y, 1, 1);
        }
    }
    for (const [x, y, w, h, fill] of bunPixels(pose)){
        ctx.fillStyle = fill;
        ctx.fillRect(ox + x, oy + y, w, h);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_1iok10q._.js.map