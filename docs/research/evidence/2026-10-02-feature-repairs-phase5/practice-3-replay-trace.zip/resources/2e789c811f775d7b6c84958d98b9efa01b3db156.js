(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/modals/CreatePaletteModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CreatePaletteModal",
    ()=>CreatePaletteModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ModalWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/ModalWrapper.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/TactileButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteAdmission.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/render/compositor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$compactPalette$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/compactPalette.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
function normalizeColor(value) {
    const hex = value.trim().replace(/^#/, '');
    if (/^[\da-f]{3}$/i.test(hex)) return `#${hex.split('').map((c)=>c + c).join('').toUpperCase()}`;
    return /^(?:[\da-f]{6}|[\da-f]{8})$/i.test(hex) ? `#${hex.toUpperCase()}` : null;
}
function CreatePaletteModal({ onClose }) {
    _s();
    const palettes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CreatePaletteModal.useStudioStore[palettes]": (s)=>s.palettes
    }["CreatePaletteModal.useStudioStore[palettes]"]);
    const currentId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CreatePaletteModal.useStudioStore[currentId]": (s)=>s.currentPaletteId
    }["CreatePaletteModal.useStudioStore[currentId]"]);
    const primaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CreatePaletteModal.useStudioStore[primaryColor]": (s)=>s.primaryColor
    }["CreatePaletteModal.useStudioStore[primaryColor]"]);
    const addPalette = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CreatePaletteModal.useStudioStore[addPalette]": (s)=>s.addExtractedPalette
    }["CreatePaletteModal.useStudioStore[addPalette]"]);
    const [name, setName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('My palette');
    const [colors, setColors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        normalizeColor(primaryColor) ?? '#C792DF'
    ]);
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hex, setHex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(colors[0]);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [notice, setNotice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const normalized = normalizeColor(hex);
    const full = palettes.length >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PROJECT_PALETTES"];
    const valid = name.trim().length > 0 && colors.length > 0 && normalized !== null && !full;
    const fieldClass = 'h-9 w-full min-w-0 bg-[var(--surface-0)] border border-[var(--desk-border)] rounded-[2px] px-2 text-xs text-[var(--text-heading)]';
    const loadColors = (next, message = '')=>{
        const normalizedColors = next.map(normalizeColor).filter((color)=>color !== null);
        setColors(normalizedColors);
        setSelected(0);
        setHex(normalizedColors[0] ?? normalizeColor(primaryColor) ?? '#C792DF');
        setError('');
        setNotice(message);
    };
    const fromArtwork = ()=>{
        try {
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            const canvas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compositeFrame"])(state.frames, state.activeFrameIndex, state.canvasWidth, state.canvasHeight);
            const context = canvas?.getContext('2d');
            const extracted = context ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$compactPalette$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractCompactPalette"])(context.getImageData(0, 0, state.canvasWidth, state.canvasHeight).data, 6) : [];
            if (!extracted.length) {
                setError('Draw or import some artwork first.');
                return;
            }
            loadColors(extracted, 'Up to 6 main colors from this frame.');
        } catch  {
            setError('Could not read this frame. Your draft is still here.');
        }
    };
    const editHex = (value)=>{
        setHex(value);
        setError('');
        const color = normalizeColor(value);
        if (color && colors.length) setColors(colors.map((existing, i)=>i === selected ? color : existing));
    };
    const addColor = ()=>{
        if (colors.length >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_COLORS"] || !normalized) return;
        setColors([
            ...colors,
            normalized
        ]);
        setSelected(colors.length);
        setHex(normalized);
        setError('');
    };
    const moveColor = (direction)=>{
        const target = selected + direction;
        if (target < 0 || target >= colors.length) return;
        const next = [
            ...colors
        ];
        [next[selected], next[target]] = [
            next[target],
            next[selected]
        ];
        setColors(next);
        setSelected(target);
    };
    const removeColor = ()=>{
        const next = colors.filter((_, i)=>i !== selected);
        const index = Math.max(0, Math.min(selected, next.length - 1));
        setColors(next);
        setSelected(index);
        setHex(next[index] ?? normalizeColor(primaryColor) ?? '#C792DF');
        setError('');
    };
    const save = ()=>{
        if (!valid) return;
        if (addPalette(name.trim(), colors)) onClose();
        else setError('Could not create the palette. Your draft is still here.');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ModalWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModalWrapper"], {
        isOpen: true,
        onClose: onClose,
        title: "Create palette",
        maxWidth: "w-[440px]",
        bodyClassName: "flex flex-col gap-3 min-h-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-3 min-h-0 overflow-y-auto p-0.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "flex flex-col gap-1 text-xs",
                        children: [
                            "Palette name",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                "data-autofocus": true,
                                value: name,
                                maxLength: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_NAME_LENGTH"],
                                onChange: (e)=>{
                                    setName(e.target.value);
                                    setError('');
                                },
                                className: fieldClass
                            }, void 0, false, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 80,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-3 gap-2",
                        role: "group",
                        "aria-label": "Start palette from",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                onClick: ()=>loadColors([
                                        primaryColor
                                    ]),
                                children: "Pick colors"
                            }, void 0, false, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 84,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                onClick: ()=>loadColors(palettes.find((p)=>p.id === currentId)?.colors ?? []),
                                children: "Copy palette"
                            }, void 0, false, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 85,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                onClick: fromArtwork,
                                children: "From artwork"
                            }, void 0, false, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 86,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 83,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between items-center text-xs",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Choose a swatch to edit."
                            }, void 0, false, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 89,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[var(--text-muted)]",
                                "aria-live": "polite",
                                children: [
                                    colors.length,
                                    " ",
                                    colors.length === 1 ? 'color' : 'colors'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 90,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 88,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-8 gap-2 p-2 min-h-16 max-h-48 overflow-y-auto bg-[var(--surface-0)] border border-[var(--desk-border)] rounded-[2px]",
                        role: "group",
                        "aria-label": "Palette draft colors",
                        children: colors.map((color, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                "aria-label": `Edit color ${index + 1}: ${color}`,
                                "aria-pressed": selected === index,
                                title: color,
                                style: {
                                    backgroundColor: color
                                },
                                onClick: ()=>{
                                    setSelected(index);
                                    setHex(color);
                                    setError('');
                                },
                                className: `aspect-square w-full border rounded-[2px] cursor-pointer ${selected === index ? 'border-[var(--accent-gold)] ring-2 ring-[var(--accent-gold)]' : 'border-[var(--desk-border)]'}`
                            }, index, false, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 94,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-[44px_1fr] gap-2 items-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "color",
                                "aria-label": "Pick swatch color",
                                value: normalized?.slice(0, 7) ?? '#C792DF',
                                onChange: (e)=>editHex(e.target.value + (normalized?.length === 9 ? normalized.slice(7) : '')),
                                className: "w-11 h-9 p-0.5 bg-[var(--surface-0)] border border-[var(--desk-border)] rounded-[2px] cursor-pointer"
                            }, void 0, false, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 101,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex flex-col gap-1 text-xs",
                                children: [
                                    "Hex color",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        value: hex,
                                        onChange: (e)=>editHex(e.target.value),
                                        spellCheck: false,
                                        "aria-invalid": !normalized,
                                        maxLength: 9,
                                        className: `${fieldClass} font-mono`
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                        lineNumber: 105,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 104,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 100,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                        size: "sm",
                        onClick: addColor,
                        disabled: !normalized || colors.length >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_COLORS"],
                        className: "w-full",
                        children: "+ Add color"
                    }, void 0, false, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 109,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-3 gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                onClick: ()=>moveColor(-1),
                                disabled: selected === 0 || !colors.length,
                                children: "Move left"
                            }, void 0, false, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 111,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                onClick: ()=>moveColor(1),
                                disabled: selected >= colors.length - 1,
                                children: "Move right"
                            }, void 0, false, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 112,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                onClick: removeColor,
                                disabled: !colors.length,
                                children: "Remove"
                            }, void 0, false, {
                                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                                lineNumber: 113,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this),
                    (!normalized || full || error) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        role: "alert",
                        className: "text-xs text-[var(--text-heading)] m-0",
                        children: error || (full ? `This project already has ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PROJECT_PALETTES"]} palettes.` : 'Use a hex color such as #FFAA33.')
                    }, void 0, false, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 115,
                        columnNumber: 44
                    }, this),
                    notice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        role: "status",
                        className: "text-xs text-[var(--text-muted)] m-0",
                        children: notice
                    }, void 0, false, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 118,
                        columnNumber: 20
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-2 gap-2 pt-3 border-t border-[var(--desk-border)] shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                        onClick: onClose,
                        children: "Cancel"
                    }, void 0, false, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 121,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                        variant: "primary",
                        onClick: save,
                        disabled: !valid,
                        children: "Create palette"
                    }, void 0, false, {
                        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                        lineNumber: 122,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
                lineNumber: 120,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/modals/CreatePaletteModal.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, this);
}
_s(CreatePaletteModal, "Da9iGG8saLVT2GEvnOaMJ6wTMAU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c = CreatePaletteModal;
var _c;
__turbopack_context__.k.register(_c, "CreatePaletteModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/modals/TagManagerModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TAG_PALETTE_COLORS",
    ()=>TAG_PALETTE_COLORS,
    "TagManagerModal",
    ()=>TagManagerModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ModalWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/ModalWrapper.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/TactileButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const TAG_PALETTE_COLORS = [
    '#F0BE7C',
    '#4ECCD3',
    '#FF5E7E',
    '#C792DF',
    '#80E080',
    '#FF9F68',
    '#64B5F6',
    '#E0B0FF',
    '#FFD54F',
    '#90A4AE'
];
const TagManagerModal = ({ isOpen, onClose })=>{
    _s();
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "TagManagerModal.useStudioStore[frames]": (s)=>s.frames
    }["TagManagerModal.useStudioStore[frames]"]);
    const clips = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "TagManagerModal.useStudioStore[clips]": (s)=>s.clips
    }["TagManagerModal.useStudioStore[clips]"]);
    const activeClipId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "TagManagerModal.useStudioStore[activeClipId]": (s)=>s.activeClipId
    }["TagManagerModal.useStudioStore[activeClipId]"]);
    const addTag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "TagManagerModal.useStudioStore[addTag]": (s)=>s.addTag
    }["TagManagerModal.useStudioStore[addTag]"]);
    const updateTag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "TagManagerModal.useStudioStore[updateTag]": (s)=>s.updateTag
    }["TagManagerModal.useStudioStore[updateTag]"]);
    const deleteTag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "TagManagerModal.useStudioStore[deleteTag]": (s)=>s.deleteTag
    }["TagManagerModal.useStudioStore[deleteTag]"]);
    const reorderTags = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "TagManagerModal.useStudioStore[reorderTags]": (s)=>s.reorderTags
    }["TagManagerModal.useStudioStore[reorderTags]"]);
    const setActiveTagId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "TagManagerModal.useStudioStore[setActiveTagId]": (s)=>s.setActiveTagId
    }["TagManagerModal.useStudioStore[setActiveTagId]"]);
    const [newTagName, setNewTagName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [newFromFrame, setNewFromFrame] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [newToFrame, setNewToFrame] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(Math.max(1, frames.length));
    const [newColor, setNewColor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(TAG_PALETTE_COLORS[0]);
    const [newLoopMode, setNewLoopMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('forward');
    const handleAddNewTag = (e)=>{
        e.preventDefault();
        const name = newTagName.trim() || `Tag ${clips.length + 1}`;
        const minF = Math.max(0, Math.min(frames.length - 1, newFromFrame - 1));
        const maxF = Math.max(minF, Math.min(frames.length - 1, newToFrame - 1));
        addTag(name, minF, maxF, newColor, newLoopMode);
        setNewTagName('');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ModalWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModalWrapper"], {
        isOpen: isOpen,
        onClose: onClose,
        title: "Animation Tags & Clips",
        maxWidth: "max-w-2xl",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-4 text-xs font-mono text-[var(--text-body)]",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-[var(--text-body)]/80 leading-relaxed",
                    children: "Define tagged animation loops (e.g. Idle, Walk, Attack). Tags provide visual bracket ribbons on the timeline, control playback bounds, and export directly into Godot 4, Unity, and Aseprite formats."
                }, void 0, false, {
                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-2 max-h-72 overflow-y-auto pr-1",
                    children: clips.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-4 rounded-[2px] border border-dashed border-[var(--desk-border)] text-center text-[var(--text-body)]/60",
                        children: "No animation tags created yet. Add a tag below to begin bounding animation loops."
                    }, void 0, false, {
                        fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                        lineNumber: 67,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)) : clips.map((clip, index)=>{
                        const isActive = activeClipId === clip.id;
                        const fromVal = (clip.fromFrame ?? clip.startFrame) + 1;
                        const toVal = (clip.toFrame ?? clip.endFrame) + 1;
                        const loop = clip.loopMode || 'forward';
                        const color = clip.color || '#F0BE7C';
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `flex flex-col gap-2 p-2.5 rounded-[2px] border-2 transition-all ${isActive ? 'bg-[#2a1d3b] border-[#f0be7c] shadow-xs' : 'bg-[var(--desk-surface-raised)] border-[var(--desk-border)]'}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "w-3.5 h-3.5 rounded-[2px] border border-[#140d1f] shrink-0",
                                            style: {
                                                backgroundColor: color
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 89,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            "aria-label": "Tag name",
                                            value: clip.name,
                                            onChange: (e)=>updateTag(clip.id, {
                                                    name: e.target.value
                                                }),
                                            className: "bg-[#181124] text-[var(--text-heading)] px-2 py-1 rounded-[2px] border border-[var(--desk-border)] focus:border-[#f0be7c] outline-none flex-1 font-bold text-xs"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 95,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                            size: "sm",
                                            variant: isActive ? 'primary' : 'default',
                                            onClick: ()=>setActiveTagId(isActive ? null : clip.id),
                                            title: isActive ? 'Clear tag playback filter' : 'Filter playback to this tag',
                                            className: "text-[10px] px-2 py-1",
                                            children: isActive ? 'FILTERED' : 'FILTER'
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 104,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-0.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    disabled: index === 0,
                                                    onClick: ()=>reorderTags(index, index - 1),
                                                    "aria-label": "Move tag up",
                                                    title: "Move Tag Up",
                                                    className: "p-1 text-[var(--text-body)]/60 hover:text-[var(--text-heading)] disabled:opacity-20 cursor-pointer disabled:cursor-default",
                                                    children: "▲"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                    lineNumber: 116,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    disabled: index === clips.length - 1,
                                                    onClick: ()=>reorderTags(index, index + 1),
                                                    "aria-label": "Move tag down",
                                                    title: "Move Tag Down",
                                                    className: "p-1 text-[var(--text-body)]/60 hover:text-[var(--text-heading)] disabled:opacity-20 cursor-pointer disabled:cursor-default",
                                                    children: "▼"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                    lineNumber: 126,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 115,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                            size: "icon-sm",
                                            variant: "danger",
                                            onClick: ()=>deleteTag(clip.id),
                                            title: "Delete Tag",
                                            className: "w-7 h-7 bg-[#3d1928] border-[#6b283d] text-[#ff99aa]",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                name: "trash",
                                                size: 12
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                lineNumber: 146,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 139,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                    lineNumber: 87,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between gap-2 pt-1 border-t border-[var(--desk-border)]/50 text-[11px]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-[var(--text-body)]/60",
                                                            children: "Frames:"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                            lineNumber: 155,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "number",
                                                            min: "1",
                                                            max: frames.length,
                                                            value: fromVal,
                                                            onChange: (e)=>{
                                                                const val = parseInt(e.target.value, 10);
                                                                if (!isNaN(val)) {
                                                                    updateTag(clip.id, {
                                                                        fromFrame: Math.max(0, val - 1)
                                                                    });
                                                                }
                                                            },
                                                            "aria-label": `Start frame for tag ${clip.name}`,
                                                            className: "w-14 bg-[#181124] text-[#f0be7c] px-1 py-0.5 rounded-[2px] border border-[var(--desk-border)] text-center text-[11px] [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                            lineNumber: 156,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: "to"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                            lineNumber: 170,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "number",
                                                            min: "1",
                                                            max: frames.length,
                                                            value: toVal,
                                                            onChange: (e)=>{
                                                                const val = parseInt(e.target.value, 10);
                                                                if (!isNaN(val)) {
                                                                    updateTag(clip.id, {
                                                                        toFrame: Math.min(frames.length - 1, val - 1)
                                                                    });
                                                                }
                                                            },
                                                            "aria-label": `End frame for tag ${clip.name}`,
                                                            className: "w-14 bg-[#181124] text-[#f0be7c] px-1 py-0.5 rounded-[2px] border border-[var(--desk-border)] text-center text-[11px] [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                            lineNumber: 171,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                    lineNumber: 154,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-[var(--text-body)]/60",
                                                            children: "Loop:"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                            lineNumber: 189,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                            value: loop,
                                                            onChange: (e)=>updateTag(clip.id, {
                                                                    loopMode: e.target.value
                                                                }),
                                                            "aria-label": `Loop mode for tag ${clip.name}`,
                                                            className: "bg-[#181124] text-[var(--text-heading)] px-1.5 py-0.5 rounded-[2px] border border-[var(--desk-border)] text-[11px] outline-none",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "forward",
                                                                    children: "Forward"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                                    lineNumber: 196,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "reverse",
                                                                    children: "Reverse"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                                    lineNumber: 197,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "ping-pong",
                                                                    children: "Ping-Pong"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                                    lineNumber: 198,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                            lineNumber: 190,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                    lineNumber: 188,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 152,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-1",
                                            children: TAG_PALETTE_COLORS.slice(0, 6).map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: ()=>updateTag(clip.id, {
                                                            color: c
                                                        }),
                                                    className: `w-3.5 h-3.5 rounded-[2px] border transition-transform cursor-pointer ${color === c ? 'border-[#ffffff] scale-110' : 'border-[#140d1f]'}`,
                                                    style: {
                                                        backgroundColor: c
                                                    },
                                                    "aria-label": `Set tag color to ${c}`
                                                }, c, false, {
                                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                                    lineNumber: 206,
                                                    columnNumber: 25
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 204,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                    lineNumber: 151,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, clip.id, true, {
                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                            lineNumber: 79,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0));
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                    lineNumber: 65,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                    onSubmit: handleAddNewTag,
                    className: "p-3 bg-[var(--desk-surface-raised)] rounded-[2px] border-2 border-[var(--desk-border)] flex flex-col gap-2.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-bold text-[var(--text-heading)] text-xs uppercase tracking-wide",
                            children: "Add New Animation Tag"
                        }, void 0, false, {
                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                            lineNumber: 230,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    placeholder: "Tag name (e.g. Idle, Run, Jump)",
                                    value: newTagName,
                                    onChange: (e)=>setNewTagName(e.target.value),
                                    "aria-label": "New tag name",
                                    className: "bg-[#181124] text-[var(--text-heading)] px-2.5 py-1.5 rounded-[2px] border border-[var(--desk-border)] focus:border-[#f0be7c] outline-none flex-1 text-xs"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                    lineNumber: 235,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-1 text-[11px]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "#"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 245,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "number",
                                            min: "1",
                                            max: frames.length,
                                            value: newFromFrame,
                                            onChange: (e)=>setNewFromFrame(parseInt(e.target.value, 10) || 1),
                                            "aria-label": "New tag start frame",
                                            className: "w-14 bg-[#181124] text-[#f0be7c] px-1 py-1 rounded-[2px] border border-[var(--desk-border)] text-center text-xs [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 246,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "-"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 255,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "number",
                                            min: "1",
                                            max: frames.length,
                                            value: newToFrame,
                                            onChange: (e)=>setNewToFrame(parseInt(e.target.value, 10) || 1),
                                            "aria-label": "New tag end frame",
                                            className: "w-14 bg-[#181124] text-[#f0be7c] px-1 py-1 rounded-[2px] border border-[var(--desk-border)] text-center text-xs [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 256,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                    lineNumber: 244,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: newLoopMode,
                                    onChange: (e)=>setNewLoopMode(e.target.value),
                                    "aria-label": "New tag loop mode",
                                    className: "bg-[#181124] text-[var(--text-heading)] px-2 py-1.5 rounded-[2px] border border-[var(--desk-border)] text-xs outline-none",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "forward",
                                            children: "Forward"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 273,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "reverse",
                                            children: "Reverse"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 274,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "ping-pong",
                                            children: "Ping-Pong"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 275,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                    lineNumber: 267,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                    type: "submit",
                                    size: "sm",
                                    variant: "primary",
                                    className: "whitespace-nowrap px-3 py-1.5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                            name: "plus",
                                            size: 13
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 284,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "Add Tag"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                            lineNumber: 285,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                    lineNumber: 278,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                            lineNumber: 234,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1.5 pt-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[11px] text-[var(--text-body)]/60",
                                    children: "Color:"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                    lineNumber: 290,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                TAG_PALETTE_COLORS.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setNewColor(c),
                                        className: `w-4 h-4 rounded-[2px] border transition-transform cursor-pointer ${newColor === c ? 'border-[#ffffff] scale-125 ring-1 ring-[#f0be7c]' : 'border-[#140d1f]'}`,
                                        style: {
                                            backgroundColor: c
                                        },
                                        "aria-label": `Select color ${c}`
                                    }, c, false, {
                                        fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                                        lineNumber: 292,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                            lineNumber: 289,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                    lineNumber: 226,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-end gap-2 pt-2 border-t border-[var(--desk-border)]",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                        size: "sm",
                        variant: "default",
                        onClick: onClose,
                        className: "px-4 py-1.5",
                        children: "Done"
                    }, void 0, false, {
                        fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                        lineNumber: 308,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/modals/TagManagerModal.tsx",
                    lineNumber: 307,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/modals/TagManagerModal.tsx",
            lineNumber: 59,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/modals/TagManagerModal.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(TagManagerModal, "7JrtoMAr+peLB7VJKN1DIrKxfj4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c = TagManagerModal;
var _c;
__turbopack_context__.k.register(_c, "TagManagerModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/system/OfflineIndicator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OfflineIndicator",
    ()=>OfflineIndicator,
    "useOnlineStatus",
    ()=>useOnlineStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
function useOnlineStatus() {
    _s();
    const [isOnline, setIsOnline] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useOnlineStatus.useState": ()=>{
            if (typeof navigator !== 'undefined' && typeof navigator.onLine === 'boolean') {
                return navigator.onLine;
            }
            return true;
        }
    }["useOnlineStatus.useState"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useOnlineStatus.useEffect": ()=>{
            const handleOnline = {
                "useOnlineStatus.useEffect.handleOnline": ()=>setIsOnline(true)
            }["useOnlineStatus.useEffect.handleOnline"];
            const handleOffline = {
                "useOnlineStatus.useEffect.handleOffline": ()=>setIsOnline(false)
            }["useOnlineStatus.useEffect.handleOffline"];
            window.addEventListener('online', handleOnline);
            window.addEventListener('offline', handleOffline);
            return ({
                "useOnlineStatus.useEffect": ()=>{
                    window.removeEventListener('online', handleOnline);
                    window.removeEventListener('offline', handleOffline);
                }
            })["useOnlineStatus.useEffect"];
        }
    }["useOnlineStatus.useEffect"], []);
    return isOnline;
}
_s(useOnlineStatus, "ZHr5e+BKCoQzy7LLPoa5YI4HAbw=");
function OfflineIndicator() {
    _s1();
    const isOnline = useOnlineStatus();
    if (isOnline) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "status",
        "aria-live": "polite",
        className: "inline-flex shrink-0 h-7 items-center gap-1.5 px-1.5 bg-[#281b3d] border border-[#f0be7c] text-[#f0be7c] text-[11px] font-mono font-bold rounded-[2px] shadow-sm select-none",
        title: "You are currently offline. All drawings and changes are saved locally to IndexedDB.",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-2 h-2 rounded-full bg-[#f0be7c]"
            }, void 0, false, {
                fileName: "[project]/src/components/system/OfflineIndicator.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: "Offline"
            }, void 0, false, {
                fileName: "[project]/src/components/system/OfflineIndicator.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/system/OfflineIndicator.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
_s1(OfflineIndicator, "d8TOj6JB44UG9shajNdgfJB5rPM=", false, function() {
    return [
        useOnlineStatus
    ];
});
_c = OfflineIndicator;
var _c;
__turbopack_context__.k.register(_c, "OfflineIndicator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_0lyf2ha._.js.map