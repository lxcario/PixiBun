(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/system/DiagnosticsProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DiagnosticsProvider",
    ()=>DiagnosticsProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/diagnostics/capture.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$vitals$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/diagnostics/vitals.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function DiagnosticsProvider({ children }) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DiagnosticsProvider.useEffect": ()=>{
            // 1. Initialize web vitals reporting
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$vitals$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initWebVitals"])();
            // 2. Global error listener
            const handleError = {
                "DiagnosticsProvider.useEffect.handleError": (event)=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureDiagnostic"])({
                        kind: 'error',
                        message: event.message || 'Window error event',
                        detail: event.error?.stack || `${event.filename}:${event.lineno}:${event.colno}`
                    });
                }
            }["DiagnosticsProvider.useEffect.handleError"];
            // 3. Unhandled promise rejection listener
            const handleRejection = {
                "DiagnosticsProvider.useEffect.handleRejection": (event)=>{
                    const reason = event.reason;
                    const message = typeof reason === 'string' ? reason : reason?.message || 'Unhandled promise rejection';
                    const detail = reason?.stack || JSON.stringify(reason);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureDiagnostic"])({
                        kind: 'unhandled-rejection',
                        message,
                        detail
                    });
                }
            }["DiagnosticsProvider.useEffect.handleRejection"];
            window.addEventListener('error', handleError);
            window.addEventListener('unhandledrejection', handleRejection);
            return ({
                "DiagnosticsProvider.useEffect": ()=>{
                    window.removeEventListener('error', handleError);
                    window.removeEventListener('unhandledrejection', handleRejection);
                }
            })["DiagnosticsProvider.useEffect"];
        }
    }["DiagnosticsProvider.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/system/DiagnosticsProvider.tsx",
        lineNumber: 46,
        columnNumber: 10
    }, this);
}
_s(DiagnosticsProvider, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = DiagnosticsProvider;
var _c;
__turbopack_context__.k.register(_c, "DiagnosticsProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/system/PwaUpdateToast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PwaUpdateToast",
    ()=>PwaUpdateToast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
'use client';
;
;
const PwaUpdateToast = ({ onUpdate, onDismiss, deferred = false })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        "aria-label": "Application update notification",
        className: "fixed bottom-4 right-4 z-50 w-[26rem] max-w-[calc(100vw-2rem)] bg-[#201431] border-2 border-[#f0be7c] p-3 rounded-[3px] shadow-[0_8px_20px_rgba(0,0,0,0.6)] flex items-center gap-3 font-mono text-xs text-[#ede8f4]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex min-w-0 items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                        name: "sun",
                        size: 14
                    }, void 0, false, {
                        fileName: "[project]/src/components/system/PwaUpdateToast.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: deferred ? 'Update ready · Close all PixiBun tabs when done to apply.' : 'Update ready · A fresh atelier build is ready. Close all PixiBun tabs when done to apply.'
                    }, void 0, false, {
                        fileName: "[project]/src/components/system/PwaUpdateToast.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/system/PwaUpdateToast.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-1.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onUpdate,
                        className: "px-2.5 py-1 bg-[#f0be7c] hover:bg-[#fcd699] hover:shadow-[0_2px_0_#8c5120] text-[#140d1f] font-bold rounded-[2px] border border-[#8c5120] cursor-pointer",
                        children: "Update instructions"
                    }, void 0, false, {
                        fileName: "[project]/src/components/system/PwaUpdateToast.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onDismiss,
                        className: "px-1.5 py-1 text-[#d0c4df] hover:text-[#f0be7c] cursor-pointer",
                        "aria-label": "Dismiss update banner",
                        children: "✕"
                    }, void 0, false, {
                        fileName: "[project]/src/components/system/PwaUpdateToast.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/system/PwaUpdateToast.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/system/PwaUpdateToast.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = PwaUpdateToast;
var _c;
__turbopack_context__.k.register(_c, "PwaUpdateToast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/system/ServiceWorkerRegistrar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ServiceWorkerRegistrar",
    ()=>ServiceWorkerRegistrar,
    "registerServiceWorker",
    ()=>registerServiceWorker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$system$2f$PwaUpdateToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/system/PwaUpdateToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/diagnostics/capture.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function registerServiceWorker() {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !('serviceWorker' in navigator) || window.location.protocol === 'file:') {
        return Promise.resolve(null);
    }
    return navigator.serviceWorker.register('/sw.js', {
        scope: '/',
        updateViaCache: 'none'
    }).then((registration)=>{
        return registration;
    }).catch((err)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureDiagnostic"])({
            kind: 'error',
            message: 'ServiceWorker registration failed',
            detail: String(err)
        });
        return null;
    });
}
function ServiceWorkerRegistrar() {
    _s();
    const [waitingWorker, setWaitingWorker] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showToast, setShowToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [updateDeferred, setUpdateDeferred] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ServiceWorkerRegistrar.useEffect": ()=>{
            if (("TURBOPACK compile-time value", "object") === 'undefined' || !('serviceWorker' in navigator)) return;
            const ac = new AbortController();
            const { signal } = ac;
            const warmed = new Set();
            const warmAssets = {
                "ServiceWorkerRegistrar.useEffect.warmAssets": (entries)=>{
                    const controller = navigator.serviceWorker.controller;
                    if (!controller) return;
                    const urls = entries.map({
                        "ServiceWorkerRegistrar.useEffect.warmAssets.urls": (entry)=>entry.name
                    }["ServiceWorkerRegistrar.useEffect.warmAssets.urls"]).filter({
                        "ServiceWorkerRegistrar.useEffect.warmAssets.urls": (value)=>{
                            const url = new URL(value, window.location.origin);
                            return url.origin === window.location.origin && url.pathname.startsWith('/_next/static/') && !warmed.has(value);
                        }
                    }["ServiceWorkerRegistrar.useEffect.warmAssets.urls"]);
                    urls.forEach({
                        "ServiceWorkerRegistrar.useEffect.warmAssets": (url)=>warmed.add(url)
                    }["ServiceWorkerRegistrar.useEffect.warmAssets"]);
                    if (urls.length) controller.postMessage({
                        type: 'CACHE_ASSETS',
                        urls
                    });
                }
            }["ServiceWorkerRegistrar.useEffect.warmAssets"];
            // Initial requests can finish before the first worker claims this page.
            // Buffer completed resources and also track lazy studio chunks as they arrive.
            const observer = typeof PerformanceObserver === 'undefined' ? null : new PerformanceObserver({
                "ServiceWorkerRegistrar.useEffect": (list)=>warmAssets(list.getEntries())
            }["ServiceWorkerRegistrar.useEffect"]);
            observer?.observe({
                type: 'resource',
                buffered: true
            });
            navigator.serviceWorker.addEventListener('controllerchange', {
                "ServiceWorkerRegistrar.useEffect": ()=>warmAssets(performance.getEntriesByType('resource'))
            }["ServiceWorkerRegistrar.useEffect"], {
                signal
            });
            warmAssets(performance.getEntriesByType('resource'));
            registerServiceWorker().then({
                "ServiceWorkerRegistrar.useEffect": (reg)=>{
                    if (!reg || signal.aborted) return;
                    // Check if a worker is already waiting
                    if (reg.waiting && navigator.serviceWorker.controller) {
                        setWaitingWorker(reg.waiting);
                        setShowToast(true);
                    }
                    const trackInstalling = {
                        "ServiceWorkerRegistrar.useEffect.trackInstalling": (worker)=>{
                            worker.addEventListener('statechange', {
                                "ServiceWorkerRegistrar.useEffect.trackInstalling": ()=>{
                                    if (worker.state === 'installed' && navigator.serviceWorker.controller) {
                                        if (!signal.aborted) {
                                            setWaitingWorker(worker);
                                            setShowToast(true);
                                        }
                                    }
                                }
                            }["ServiceWorkerRegistrar.useEffect.trackInstalling"], {
                                signal
                            });
                        }
                    }["ServiceWorkerRegistrar.useEffect.trackInstalling"];
                    if (reg.installing) {
                        trackInstalling(reg.installing);
                    }
                    // Listen for new worker installation
                    reg.addEventListener('updatefound', {
                        "ServiceWorkerRegistrar.useEffect": ()=>{
                            if (reg.installing) {
                                trackInstalling(reg.installing);
                            }
                        }
                    }["ServiceWorkerRegistrar.useEffect"], {
                        signal
                    });
                }
            }["ServiceWorkerRegistrar.useEffect"]);
            // Never reload artwork because a worker changed (including older deployed workers).
            navigator.serviceWorker.addEventListener('message', {
                "ServiceWorkerRegistrar.useEffect": (event)=>{
                    if (event.data?.type === 'UPDATE_DEFERRED') setUpdateDeferred(true);
                }
            }["ServiceWorkerRegistrar.useEffect"], {
                signal
            });
            return ({
                "ServiceWorkerRegistrar.useEffect": ()=>{
                    ac.abort();
                    observer?.disconnect();
                }
            })["ServiceWorkerRegistrar.useEffect"];
        }
    }["ServiceWorkerRegistrar.useEffect"], []);
    const handleUpdate = ()=>{
        if (waitingWorker) {
            setUpdateDeferred(true);
            waitingWorker.postMessage({
                type: 'SKIP_WAITING'
            });
        }
    };
    const handleDismiss = ()=>{
        setShowToast(false);
    };
    if (!showToast) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$system$2f$PwaUpdateToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PwaUpdateToast"], {
        onUpdate: handleUpdate,
        onDismiss: handleDismiss,
        deferred: updateDeferred
    }, void 0, false, {
        fileName: "[project]/src/components/system/ServiceWorkerRegistrar.tsx",
        lineNumber: 128,
        columnNumber: 10
    }, this);
}
_s(ServiceWorkerRegistrar, "MnNxQrKQiqHbf7lPJd9Sm6FmmFs=");
_c = ServiceWorkerRegistrar;
var _c;
__turbopack_context__.k.register(_c, "ServiceWorkerRegistrar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PixelIcon",
    ()=>PixelIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
const PixelIcon = ({ name, className = '', size = 18 })=>{
    const renderSvg = ()=>{
        switch(name){
            // 1. Drawing Tools
            case 'pen':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 83,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m15 5 4 4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 84,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 82,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'eraser':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.6-9.6c1-1 2.5-1 3.4 0l5.6 5.6c1 1 1 2.5 0 3.4L13 21"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 91,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M22 21H7"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 92,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m5 11 9 9"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 93,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 90,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'erase-color':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "1.8",
                    strokeLinecap: "square",
                    strokeLinejoin: "miter",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m14 2 6 6-2 2-6-6zM12 5 5 12l-1 4 4-1 7-7"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 100,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M4 19h4v4H4zM8 16h4v3H8zM12 19h4v4h-4z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 101,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 99,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'bucket':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m19 11-8-8-8.6 8.6a2 2 0 0 0 0 2.8l5.2 5.2c.8.8 2 .8 2.8 0L19 11Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 108,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m5 2 5 5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 109,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M2 13h15"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 110,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M22 20a2 2 0 1 1-4 0c0-1.6 1.7-2.4 2-4 .3 1.6 2 2.4 2 4Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 111,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 107,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'dither':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "currentColor",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "3",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 118,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "11",
                            y: "3",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 119,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "17",
                            y: "3",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 120,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "7",
                            y: "7",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 121,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "15",
                            y: "7",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 122,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "11",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 123,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "11",
                            y: "11",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 124,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "17",
                            y: "11",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 125,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "7",
                            y: "15",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 126,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "15",
                            y: "15",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 127,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "19",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 128,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "11",
                            y: "19",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 129,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "17",
                            y: "19",
                            width: "4",
                            height: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 130,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 117,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'eyedropper':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m14 2 6 6"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 137,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m16 6-9 9-4 1 1-4 9-9"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 138,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m9 13 2 2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 139,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 136,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'select-box':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeDasharray: "3 3",
                    className: className,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        width: "18",
                        height: "18",
                        x: "3",
                        y: "3",
                        rx: "1"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PixelIcon.tsx",
                        lineNumber: 146,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 145,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'select-lasso':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeDasharray: "3 2",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M7 22a5 5 0 0 1-2-4c0-4 4-8 9-8s8 4 8 8-3 6-8 6c-3 0-5-1-6-2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 153,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M3 14c1-4 4-7 8-9",
                            strokeDasharray: "none"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 154,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "6",
                            cy: "18",
                            r: "1.5",
                            fill: "currentColor",
                            stroke: "none"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 155,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 152,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'line':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2.5",
                    strokeLinecap: "round",
                    className: className,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                        x1: "5",
                        y1: "19",
                        x2: "19",
                        y2: "5"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PixelIcon.tsx",
                        lineNumber: 162,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 161,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'rectangle':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    className: className,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        width: "18",
                        height: "14",
                        x: "3",
                        y: "5",
                        rx: "1"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PixelIcon.tsx",
                        lineNumber: 169,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 168,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'ellipse':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    className: className,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: "12",
                        cy: "12",
                        r: "8"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PixelIcon.tsx",
                        lineNumber: 176,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 175,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            // 2. Timeline & Utilities
            case 'undo':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M3 7v6h6"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 184,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 185,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 183,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'redo':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M21 7v6h-6"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 192,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 193,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 191,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'zoom-in':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "11",
                            cy: "11",
                            r: "8"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 200,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "21",
                            y1: "21",
                            x2: "16.65",
                            y2: "16.65"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 201,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "11",
                            y1: "8",
                            x2: "11",
                            y2: "14"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 202,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "8",
                            y1: "11",
                            x2: "14",
                            y2: "11"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 203,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 199,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'zoom-out':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "11",
                            cy: "11",
                            r: "8"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 210,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "21",
                            y1: "21",
                            x2: "16.65",
                            y2: "16.65"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 211,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "8",
                            y1: "11",
                            x2: "14",
                            y2: "11"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 212,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 209,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'grid':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "18",
                            height: "18",
                            x: "3",
                            y: "3",
                            rx: "2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 219,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "3",
                            y1: "9",
                            x2: "21",
                            y2: "9"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 220,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "3",
                            y1: "15",
                            x2: "21",
                            y2: "15"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 221,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "9",
                            y1: "3",
                            x2: "9",
                            y2: "21"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 222,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "15",
                            y1: "3",
                            x2: "15",
                            y2: "21"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 223,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 218,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'play':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "currentColor",
                    className: className,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polygon", {
                        points: "6 3 20 12 6 21 6 3"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PixelIcon.tsx",
                        lineNumber: 230,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 229,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'pause':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "currentColor",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "6",
                            y: "4",
                            width: "4",
                            height: "16"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 237,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "14",
                            y: "4",
                            width: "4",
                            height: "16"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 238,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 236,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'step-forward':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "currentColor",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polygon", {
                            points: "5 4 15 12 5 20 5 4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 245,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "19",
                            y1: "5",
                            x2: "19",
                            y2: "19",
                            stroke: "currentColor",
                            strokeWidth: "2.5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 246,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 244,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'step-backward':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "currentColor",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polygon", {
                            points: "19 20 9 12 19 4 19 20"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 253,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "5",
                            y1: "5",
                            x2: "5",
                            y2: "19",
                            stroke: "currentColor",
                            strokeWidth: "2.5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 254,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 252,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'loop':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m17 2 4 4-4 4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 261,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M3 11v-1a4 4 0 0 1 4-4h14"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 262,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m7 22-4-4 4-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 263,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M21 13v1a4 4 0 0 1-4 4H3"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 264,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 260,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'ping-pong':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M7 16V4m0 0L3 8m4-4l4 4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 271,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M17 8v12m0 0l4-4m-4 4l-4-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 272,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 270,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'onion':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 279,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "12",
                            cy: "9",
                            r: "2.5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 280,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 278,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'layers':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polygon", {
                            points: "12 2 2 7 12 12 22 7 12 2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 287,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                            points: "2 17 12 22 22 17"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 288,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                            points: "2 12 12 17 22 12"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 289,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 286,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'merge-down':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M4 20h16"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 296,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12 4v11"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 297,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m8 11 4 4 4-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 298,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 295,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'palette':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "13.5",
                            cy: "6.5",
                            r: ".5",
                            fill: "currentColor"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 305,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "17.5",
                            cy: "10.5",
                            r: ".5",
                            fill: "currentColor"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 306,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "8.5",
                            cy: "7.5",
                            r: ".5",
                            fill: "currentColor"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 307,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "6.5",
                            cy: "12.5",
                            r: ".5",
                            fill: "currentColor"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 308,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.93 0 1.5-.68 1.5-1.5 0-.38-.15-.74-.39-1.02-.23-.27-.37-.62-.37-1.02 0-.83.67-1.5 1.5-1.5H16c3.31 0 6-2.69 6-6 0-4.97-4.48-9-10-9z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 309,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 304,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'export':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 316,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                            points: "7 10 12 15 17 10"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 317,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "12",
                            y1: "15",
                            x2: "12",
                            y2: "3"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 318,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 315,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'import':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 325,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                            points: "17 8 12 3 7 8"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 326,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "12",
                            y1: "3",
                            x2: "12",
                            y2: "15"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 327,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 324,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'trash':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M3 6h18"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 334,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 335,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 336,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 333,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'plus':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2.5",
                    strokeLinecap: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "12",
                            y1: "5",
                            x2: "12",
                            y2: "19"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 343,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "5",
                            y1: "12",
                            x2: "19",
                            y2: "12"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 344,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 342,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'copy':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "14",
                            height: "14",
                            x: "8",
                            y: "8",
                            rx: "2",
                            ry: "2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 351,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 352,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 350,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'eye':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 359,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "12",
                            cy: "12",
                            r: "3"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 360,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 358,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'eye-off':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M9.88 9.88a3 3 0 1 0 4.24 4.24"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 367,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 368,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 369,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "2",
                            y1: "2",
                            x2: "22",
                            y2: "22"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 370,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 366,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'lock':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "18",
                            height: "11",
                            x: "3",
                            y: "11",
                            rx: "2",
                            ry: "2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 377,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M7 11V7a5 5 0 0 1 10 0v4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 378,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 376,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'unlock':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "18",
                            height: "11",
                            x: "3",
                            y: "11",
                            rx: "2",
                            ry: "2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 385,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M7 11V7a5 5 0 0 1 9.9-1"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 386,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 384,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'help':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "12",
                            cy: "12",
                            r: "10"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 393,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 394,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "12",
                            y1: "17",
                            x2: "12.01",
                            y2: "17"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 395,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 392,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'curve':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M3 19c6-14 12-14 18 0"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 402,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "3",
                            cy: "19",
                            r: "2",
                            fill: "currentColor"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 403,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "12",
                            cy: "5",
                            r: "2",
                            fill: "currentColor"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 404,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "21",
                            cy: "19",
                            r: "2",
                            fill: "currentColor"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 405,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 401,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'isometric-line':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M2 17 22 7"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 412,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M2 12 22 2",
                            strokeDasharray: "3 3"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 413,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M2 22 22 12",
                            strokeDasharray: "3 3"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 414,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 411,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'select-wand':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m15 4-2 2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 421,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M15 9l-2-2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 422,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M3 21l9-9"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 423,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m14 2 1.5 2.5L18 5l-2.5 1.5L14 9l-1.5-2.5L10 5l2.5-1.5Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 424,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 420,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'color-replace':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m16 3 4 4-4 4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 431,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20 7H4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 432,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m8 21-4-4 4-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 433,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M4 17h16"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 434,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 430,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'rotate':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 441,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M21 3v5h-5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 442,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 440,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'sun':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "12",
                            cy: "12",
                            r: "4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 449,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12 2v2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 450,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12 20v2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 451,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m4.93 4.93 1.41 1.41"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 452,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m17.66 17.66 1.41 1.41"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 453,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M2 12h2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 454,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20 12h2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 455,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m6.34 17.66-1.41 1.41"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 456,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m19.07 4.93-1.41 1.41"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 457,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 448,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'sparkles':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PixelIcon.tsx",
                        lineNumber: 464,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 463,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'symmetry':
            case 'symmetry-h':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "12",
                            y1: "2",
                            x2: "12",
                            y2: "22",
                            strokeDasharray: "3 3"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 472,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M4 6h4l3 6-3 6H4Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 473,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20 6h-4l-3 6 3 6h4Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 474,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 471,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'symmetry-v':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "2",
                            y1: "12",
                            x2: "22",
                            y2: "12",
                            strokeDasharray: "3 3"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 481,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M6 4v4l6 3 6-3V4Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 482,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M6 20v-4l6-3 6 3v4Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 483,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 480,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'preview':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "18",
                            height: "14",
                            x: "3",
                            y: "5",
                            rx: "2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 490,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M7 15l3-3 2 2 5-5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 491,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 489,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'warning':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 498,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "12",
                            y1: "9",
                            x2: "12",
                            y2: "13"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 499,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                            x1: "12",
                            y1: "17",
                            x2: "12.01",
                            y2: "17"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 500,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 497,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'grid-iso':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12 2L2 7l10 5 10-5-10-5Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 507,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M2 17l10 5 10-5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 508,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M2 12l10 5 10-5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 509,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 506,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'wrap':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "6",
                            height: "6",
                            x: "9",
                            y: "9",
                            rx: "1"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 516,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "4",
                            height: "4",
                            x: "3",
                            y: "3",
                            opacity: "0.5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 517,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "4",
                            height: "4",
                            x: "17",
                            y: "3",
                            opacity: "0.5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 518,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "4",
                            height: "4",
                            x: "3",
                            y: "17",
                            opacity: "0.5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 519,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "4",
                            height: "4",
                            x: "17",
                            y: "17",
                            opacity: "0.5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 520,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 515,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'lamp':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 16 16",
                    width: size,
                    height: size,
                    fill: "currentColor",
                    shapeRendering: "crispEdges",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "5",
                            y: "1",
                            width: "6",
                            height: "2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 527,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "3",
                            width: "10",
                            height: "5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 528,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "4",
                            y: "8",
                            width: "8",
                            height: "3"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 529,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "6",
                            y: "11",
                            width: "4",
                            height: "2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 530,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "7",
                            y: "13",
                            width: "2",
                            height: "1"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 531,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 526,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'tag':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12 2H2v10l9.29 9.29a2 2 0 0 0 2.83 0l6.58-6.58a2 2 0 0 0 0-2.83L12 2Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 538,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            cx: "7",
                            cy: "7",
                            r: "1.5",
                            fill: "currentColor"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 539,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 537,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'chisel':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M14 2 8 8l4 4 6-6Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 546,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m8 8-5 5 3 3 5-5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 547,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "m3 13-1 8 8-1"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 548,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 545,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'save':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    width: size,
                    height: size,
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: className,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 555,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                            points: "17 21 17 13 7 13 7 21"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 556,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                            points: "7 3 7 8 15 8"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 557,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 554,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'lamp-pixel':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 12 12",
                    width: size,
                    height: size,
                    shapeRendering: "crispEdges",
                    className: `pixelated ${className}`,
                    "aria-hidden": "true",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "4",
                            y: "1",
                            width: "4",
                            height: "2",
                            fill: "#f0be7c"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 564,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "3",
                            width: "6",
                            height: "3",
                            fill: "#f0be7c"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 565,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "5",
                            y: "6",
                            width: "2",
                            height: "3",
                            fill: "#78608a"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 566,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "9",
                            width: "6",
                            height: "2",
                            fill: "#140c1e"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 567,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 563,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'pen-pixel':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 12 12",
                    width: size,
                    height: size,
                    shapeRendering: "crispEdges",
                    className: `pixelated ${className}`,
                    "aria-hidden": "true",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "8",
                            y: "1",
                            width: "3",
                            height: "3",
                            fill: "#dcabdf"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 574,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "5",
                            y: "4",
                            width: "4",
                            height: "4",
                            fill: "#f0be7c"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 575,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "7",
                            width: "3",
                            height: "3",
                            fill: "#67558d"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 576,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "1",
                            y: "10",
                            width: "2",
                            height: "2",
                            fill: "#140c1e"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 577,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 573,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'plant-pixel':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 16 16",
                    width: size,
                    height: size,
                    shapeRendering: "crispEdges",
                    className: `pixelated ${className}`,
                    "aria-hidden": "true",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "5",
                            y: "9",
                            width: "6",
                            height: "1",
                            fill: "#140c1e"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 584,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "6",
                            y: "10",
                            width: "4",
                            height: "4",
                            fill: "#b87428"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 585,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "7",
                            y: "11",
                            width: "2",
                            height: "3",
                            fill: "#8c5120"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 586,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "7",
                            y: "4",
                            width: "2",
                            height: "5",
                            fill: "#6bc27a"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 587,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "5",
                            y: "5",
                            width: "2",
                            height: "2",
                            fill: "#44aa55"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 588,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "9",
                            y: "6",
                            width: "2",
                            height: "2",
                            fill: "#44aa55"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 589,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 583,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'clock-pixel':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 12 12",
                    width: size,
                    height: size,
                    shapeRendering: "crispEdges",
                    className: `pixelated ${className}`,
                    "aria-hidden": "true",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "2",
                            y: "2",
                            width: "8",
                            height: "8",
                            fill: "#201431"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 596,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "1",
                            width: "6",
                            height: "1",
                            fill: "#f0be7c"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 597,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "10",
                            width: "6",
                            height: "1",
                            fill: "#f0be7c"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 598,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "1",
                            y: "3",
                            width: "1",
                            height: "6",
                            fill: "#f0be7c"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 599,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "10",
                            y: "3",
                            width: "1",
                            height: "6",
                            fill: "#f0be7c"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 600,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "5",
                            y: "4",
                            width: "1",
                            height: "3",
                            fill: "#ffffff"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 601,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "6",
                            y: "6",
                            width: "2",
                            height: "1",
                            fill: "#ffffff"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 602,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 595,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            case 'mug-pixel':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 12 12",
                    width: size,
                    height: size,
                    shapeRendering: "crispEdges",
                    className: `pixelated ${className}`,
                    "aria-hidden": "true",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "2",
                            y: "3",
                            width: "6",
                            height: "7",
                            fill: "#dcabdf"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 609,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "8",
                            y: "5",
                            width: "2",
                            height: "3",
                            fill: "#dcabdf"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 610,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "9",
                            y: "6",
                            width: "1",
                            height: "1",
                            fill: "transparent"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 611,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            x: "3",
                            y: "4",
                            width: "4",
                            height: "1",
                            fill: "#ffffff"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PixelIcon.tsx",
                            lineNumber: 612,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/PixelIcon.tsx",
                    lineNumber: 608,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            default:
                return null;
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "inline-flex items-center justify-center pointer-events-none select-none",
        children: renderSvg()
    }, void 0, false, {
        fileName: "[project]/src/components/ui/PixelIcon.tsx",
        lineNumber: 621,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_c = PixelIcon;
var _c;
__turbopack_context__.k.register(_c, "PixelIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/config/canvasLimits.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * canvasLimits.ts
 *
 * Canonical Workspace & Canvas Boundaries for PixiBun Atelier.
 *
 * Provides a single source of truth across all 6 subsystems:
 * 1. Project Schema (.pixibun file import/validation)
 * 2. P2P Collaboration (STRUCTURE_SYNC and pixel operation validation)
 * 3. Export Modal & PngExportTab (canvas rendering and dimension/pixel scale clamping)
 * 4. ImageHeaderProbe (external asset probing and decompression bomb defense)
 * 5. SafeCanvas (hardware limits, WebGL probe contexts, and clamped rect extraction)
 * 6. Procedural Generation & WaveFunctionCollapse (WFC working-set resource bounds)
 */ __turbopack_context__.s([
    "EXPORT_ENVELOPE",
    ()=>EXPORT_ENVELOPE,
    "HARDWARE_LIMITS",
    ()=>HARDWARE_LIMITS,
    "MAX_CANVAS_DIMENSION",
    ()=>MAX_CANVAS_DIMENSION,
    "MAX_CANVAS_FRAMES",
    ()=>MAX_CANVAS_FRAMES,
    "MAX_CANVAS_LAYERS",
    ()=>MAX_CANVAS_LAYERS,
    "MAX_EXPORT_AGGREGATE_PIXELS",
    ()=>MAX_EXPORT_AGGREGATE_PIXELS,
    "MAX_EXPORT_DIMENSION",
    ()=>MAX_EXPORT_DIMENSION,
    "MAX_EXPORT_PIXELS",
    ()=>MAX_EXPORT_PIXELS,
    "MAX_HARDWARE_DIMENSION",
    ()=>MAX_HARDWARE_DIMENSION,
    "MAX_HARDWARE_PIXEL_AREA",
    ()=>MAX_HARDWARE_PIXEL_AREA,
    "MAX_PROBE_DIMENSION",
    ()=>MAX_PROBE_DIMENSION,
    "MAX_PROBE_PIXELS",
    ()=>MAX_PROBE_PIXELS,
    "MAX_PROJECT_AGGREGATE_PIXELS",
    ()=>MAX_PROJECT_AGGREGATE_PIXELS,
    "MAX_PROJECT_TOTAL_LAYERS",
    ()=>MAX_PROJECT_TOTAL_LAYERS,
    "MAX_SAFE_CANVAS_DIMENSION",
    ()=>MAX_SAFE_CANVAS_DIMENSION,
    "MAX_SAFE_CANVAS_PIXELS",
    ()=>MAX_SAFE_CANVAS_PIXELS,
    "MAX_WFC_WORKING_SET_BYTES",
    ()=>MAX_WFC_WORKING_SET_BYTES,
    "PROBE_ENVELOPE",
    ()=>PROBE_ENVELOPE,
    "WFC_ENVELOPE",
    ()=>WFC_ENVELOPE,
    "WORKSPACE_ENVELOPE",
    ()=>WORKSPACE_ENVELOPE,
    "assertWorkspaceDimensions",
    ()=>assertWorkspaceDimensions
]);
const WORKSPACE_ENVELOPE = {
    /** Maximum single-axis dimension for creative workstation canvas (2048px). */ MAX_CANVAS_DIMENSION: 2048,
    /** Maximum animation frames allowed in a project or synced structure (500 frames). */ MAX_CANVAS_FRAMES: 500,
    /** Maximum layers per frame allowed in a project or synced structure (100 layers). */ MAX_CANVAS_LAYERS: 100,
    /** Initial conservative project-complexity validation ceiling (67,108,864 px = 64 MP = 256 MiB base/raw RGBA). */ MAX_PROJECT_AGGREGATE_PIXELS: 67_108_864,
    /** Maximum total layers across all frames in a project structure (2,000 layers). */ MAX_PROJECT_TOTAL_LAYERS: 2000,
    /** Maximum export dimension when upscaling or downscaling (4096px, PixiBun configured safety boundary). */ MAX_EXPORT_DIMENSION: 4096,
    /** Maximum export pixel count ceiling (16,777,216 px = 16.7 MP, PixiBun configured safety boundary). */ MAX_EXPORT_PIXELS: 16_777_216,
    /** Maximum probe dimension for external reference images (8192px). */ MAX_PROBE_DIMENSION: 8192,
    /** Maximum probe pixel area for decompression bomb defense (67,108,864 px = 67.1 MP). */ MAX_PROBE_PIXELS: 67_108_864,
    /** Maximum hardware texture dimension (16384px). */ MAX_HARDWARE_DIMENSION: 16384,
    /** Hardware / WebGL context max texture area ceiling (16384 x 16384 = 268,435,456 px). */ MAX_HARDWARE_PIXEL_AREA: 16384 * 16384
};
const EXPORT_ENVELOPE = {
    MAX_EXPORT_DIMENSION: WORKSPACE_ENVELOPE.MAX_EXPORT_DIMENSION,
    MAX_EXPORT_PIXELS: WORKSPACE_ENVELOPE.MAX_EXPORT_PIXELS,
    /** Configured animated-image export budget for multi-frame exports retaining uncompressed frames (67,108,864 aggregate pixels = 64 MP = 256 MiB of raw RGBA at 4 bytes/pixel). Bounds aggregate source pixels to reduce OOM risk, not total process memory. */ MAX_EXPORT_AGGREGATE_PIXELS: WORKSPACE_ENVELOPE.MAX_PROJECT_AGGREGATE_PIXELS
};
const PROBE_ENVELOPE = {
    MAX_PROBE_DIMENSION: WORKSPACE_ENVELOPE.MAX_PROBE_DIMENSION,
    MAX_PROBE_PIXELS: WORKSPACE_ENVELOPE.MAX_PROBE_PIXELS
};
const HARDWARE_LIMITS = {
    MAX_HARDWARE_DIMENSION: WORKSPACE_ENVELOPE.MAX_HARDWARE_DIMENSION,
    MAX_HARDWARE_PIXEL_AREA: WORKSPACE_ENVELOPE.MAX_HARDWARE_PIXEL_AREA
};
const WFC_ENVELOPE = {
    /**
   * Configured admission-policy working set ceiling for WaveFunctionCollapse constraint synthesis (64 MiB).
   * Bounds modeled typed-array solver structures and structural compatibility work before dominant solver allocations.
   * Derived to align with PixiBun single-subsystem working memory budgets (e.g. DEFAULT_HISTORY_MAX_BYTES = 64 MiB).
   */ MAX_WFC_WORKING_SET_BYTES: 64 * 1024 * 1024
};
const MAX_CANVAS_DIMENSION = WORKSPACE_ENVELOPE.MAX_CANVAS_DIMENSION;
function assertWorkspaceDimensions(width, height) {
    if (![
        width,
        height
    ].every((v)=>Number.isInteger(v) && v >= 1 && v <= MAX_CANVAS_DIMENSION)) {
        throw new RangeError(`Canvas dimensions must be whole numbers between 1 and ${MAX_CANVAS_DIMENSION}.`);
    }
}
const MAX_CANVAS_FRAMES = WORKSPACE_ENVELOPE.MAX_CANVAS_FRAMES;
const MAX_CANVAS_LAYERS = WORKSPACE_ENVELOPE.MAX_CANVAS_LAYERS;
const MAX_PROJECT_AGGREGATE_PIXELS = WORKSPACE_ENVELOPE.MAX_PROJECT_AGGREGATE_PIXELS;
const MAX_PROJECT_TOTAL_LAYERS = WORKSPACE_ENVELOPE.MAX_PROJECT_TOTAL_LAYERS;
const MAX_EXPORT_DIMENSION = WORKSPACE_ENVELOPE.MAX_EXPORT_DIMENSION;
const MAX_EXPORT_PIXELS = WORKSPACE_ENVELOPE.MAX_EXPORT_PIXELS;
const MAX_PROBE_DIMENSION = WORKSPACE_ENVELOPE.MAX_PROBE_DIMENSION;
const MAX_PROBE_PIXELS = WORKSPACE_ENVELOPE.MAX_PROBE_PIXELS;
const MAX_HARDWARE_DIMENSION = WORKSPACE_ENVELOPE.MAX_HARDWARE_DIMENSION;
const MAX_HARDWARE_PIXEL_AREA = WORKSPACE_ENVELOPE.MAX_HARDWARE_PIXEL_AREA;
const MAX_SAFE_CANVAS_DIMENSION = MAX_EXPORT_DIMENSION;
const MAX_SAFE_CANVAS_PIXELS = MAX_EXPORT_PIXELS;
const MAX_EXPORT_AGGREGATE_PIXELS = EXPORT_ENVELOPE.MAX_EXPORT_AGGREGATE_PIXELS;
const MAX_WFC_WORKING_SET_BYTES = WFC_ENVELOPE.MAX_WFC_WORKING_SET_BYTES;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/config/version.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * version.ts
 *
 * Canonical application runtime version for PixiBun Atelier.
 * Single source of truth across client telemetry, API diagnostics relay, and reporting.
 */ __turbopack_context__.s([
    "APP_VERSION",
    ()=>APP_VERSION
]);
const APP_VERSION = '1.14.1';
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/animation/reviewMetadata.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAX_REVIEW_EXCEPTIONS",
    ()=>MAX_REVIEW_EXCEPTIONS,
    "MAX_REVIEW_REGIONS",
    ()=>MAX_REVIEW_REGIONS,
    "estimateClipBytes",
    ()=>estimateClipBytes,
    "parseAnimationReview",
    ()=>parseAnimationReview,
    "restoreProtectedPixels",
    ()=>restoreProtectedPixels
]);
const MAX_REVIEW_REGIONS = 32;
const MAX_REVIEW_EXCEPTIONS = 512;
const integer = (value, min, max)=>typeof value === 'number' && Number.isInteger(value) && value >= min && value <= max;
function parseAnimationReview(value) {
    if (!value || typeof value !== 'object') return null;
    const input = value;
    if (!Array.isArray(input.regions) || input.regions.length > MAX_REVIEW_REGIONS || !Array.isArray(input.exceptions) || input.exceptions.length > MAX_REVIEW_EXCEPTIONS) return null;
    const ids = new Set();
    const regions = [];
    for (const region of input.regions){
        if (!region || typeof region.id !== 'string' || !region.id.length || region.id.length > 128 || ids.has(region.id) || typeof region.name !== 'string' || !region.name.trim() || region.name.length > 64 || ![
            'protect',
            'ignore',
            'contact'
        ].includes(region.kind) || !integer(region.x, 0, 16383) || !integer(region.y, 0, 16383) || !integer(region.w, 1, 16384 - region.x) || !integer(region.h, 1, 16384 - region.y)) return null;
        ids.add(region.id);
        regions.push({
            id: region.id,
            name: region.name,
            kind: region.kind,
            x: region.x,
            y: region.y,
            w: region.w,
            h: region.h
        });
    }
    const exceptions = [];
    const keys = new Set();
    for (const mark of input.exceptions){
        if (!mark || typeof mark.fromFrameId !== 'string' || !mark.fromFrameId.length || mark.fromFrameId.length > 128 || typeof mark.toFrameId !== 'string' || !mark.toFrameId.length || mark.toFrameId.length > 128 || typeof mark.signature !== 'string' || !/^[a-f0-9]{64}$/.test(mark.signature)) return null;
        const key = `${mark.fromFrameId}:${mark.toFrameId}`;
        if (keys.has(key)) return null;
        keys.add(key);
        exceptions.push({
            fromFrameId: mark.fromFrameId,
            toFrameId: mark.toFrameId,
            signature: mark.signature
        });
    }
    return {
        regions,
        exceptions
    };
}
function estimateClipBytes(clip) {
    return 256 + clip.name.length * 2 + (clip.review?.regions.reduce((n, r)=>n + 256 + 2 * (r.id.length + r.name.length), 0) ?? 0) + (clip.review?.exceptions.reduce((n, mark)=>n + 256 + 2 * (mark.fromFrameId.length + mark.toFrameId.length + mark.signature.length), 0) ?? 0);
}
function restoreProtectedPixels(before, after, width, height, regions) {
    let restored = 0;
    for(let y = 0; y < height; y++){
        const spans = regions.filter((r)=>r.kind === 'protect' && y >= r.y && y < r.y + r.h && r.x < width).map((r)=>[
                r.x,
                Math.min(width, r.x + r.w)
            ]).sort((a, b)=>a[0] - b[0]);
        let start = -1, end = -1;
        const copy = ()=>{
            if (start < 0) return;
            for(let x = start; x < end; x++){
                const i = (y * width + x) * 4;
                if (before[i] !== after[i] || before[i + 1] !== after[i + 1] || before[i + 2] !== after[i + 2] || before[i + 3] !== after[i + 3]) restored++;
            }
            after.set(before.subarray((y * width + start) * 4, (y * width + end) * 4), (y * width + start) * 4);
        };
        for (const span of spans){
            if (span[0] > end) {
                copy();
                start = span[0];
                end = span[1];
            } else end = Math.max(end, span[1]);
        }
        copy();
    }
    return restored;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/color/paletteAdmission.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAX_PALETTE_COLORS",
    ()=>MAX_PALETTE_COLORS,
    "MAX_PALETTE_CYCLE_TRACKS",
    ()=>MAX_PALETTE_CYCLE_TRACKS,
    "MAX_PALETTE_NAME_LENGTH",
    ()=>MAX_PALETTE_NAME_LENGTH,
    "MAX_PROJECT_PALETTES",
    ()=>MAX_PROJECT_PALETTES,
    "customRampsError",
    ()=>customRampsError,
    "paletteCycleTrackError",
    ()=>paletteCycleTrackError,
    "paletteEntryError",
    ()=>paletteEntryError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/recovery/recoveryLimits.ts [app-client] (ecmascript)");
;
const MAX_PROJECT_PALETTES = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_PALETTES;
const MAX_PALETTE_COLORS = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_COLORS_PER_PALETTE;
const MAX_PALETTE_CYCLE_TRACKS = 64;
const MAX_PALETTE_NAME_LENGTH = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_IDENTIFIER_LENGTH;
const MAX_NAME_LENGTH = MAX_PALETTE_NAME_LENGTH;
const HEX_COLOR = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
function paletteEntryError(name, colors) {
    if (typeof name !== 'string' || name.length > MAX_NAME_LENGTH) {
        return `Palette names must be at most ${MAX_NAME_LENGTH} characters.`;
    }
    if (!Array.isArray(colors) || colors.length === 0 || colors.length > MAX_PALETTE_COLORS) {
        return `Palettes must contain 1–${MAX_PALETTE_COLORS} colors.`;
    }
    if (!colors.every((color)=>typeof color === 'string' && HEX_COLOR.test(color))) {
        return 'Palette colors must be valid hex values.';
    }
    return null;
}
function paletteCycleTrackError(track, colorCount) {
    if (!track || typeof track.id !== 'string' || track.id.length === 0 || track.id.length > MAX_NAME_LENGTH || track.name !== undefined && (typeof track.name !== 'string' || track.name.length > MAX_NAME_LENGTH) || !Number.isInteger(track.low) || !Number.isInteger(track.high) || track.low < 0 || track.high < track.low || track.high >= colorCount || !Number.isFinite(track.rate) || track.rate < 0 || track.rate > 1000 || ![
        'forward',
        'reverse',
        'ping-pong'
    ].includes(track.direction) || typeof track.blendShift !== 'boolean' || typeof track.enabled !== 'boolean') {
        return 'Cycle track settings must use a valid palette range and rate.';
    }
    return null;
}
function customRampsError(ramps) {
    if (!Array.isArray(ramps) || ramps.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_CUSTOM_RAMPS || !ramps.every((ramp)=>ramp && typeof ramp.baseColor === 'string' && HEX_COLOR.test(ramp.baseColor) && Array.isArray(ramp.shades) && ramp.shades.length <= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_SHADES_PER_RAMP && ramp.shades.every((shade)=>typeof shade === 'string' && HEX_COLOR.test(shade)))) {
        return 'Custom ramps exceed the project limit or contain invalid colors.';
    }
    return null;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/color/paletteCycling.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * paletteCycling.ts
 * Mark Ferrari 8-Bit Dynamic Palette Cycling Engine
 * 
 * Deluxe Paint IFF ILBM CRNG & CCRT chunk parsing and serialization,
 * 32-bit LUT renderer, ping-pong fencepost oscillation,
 * sub-step BlendShift linear color interpolation, and harmonic rational retuning
 * for seamless loop unrolling.
 */ __turbopack_context__.s([
    "CRNG_FLAGS",
    ()=>CRNG_FLAGS,
    "blendColorsRgb",
    ()=>blendColorsRgb,
    "buildCycleRegisterMask",
    ()=>buildCycleRegisterMask,
    "calculatePingPongOffset",
    ()=>calculatePingPongOffset,
    "hexToRgb",
    ()=>hexToRgb,
    "packRgb32",
    ()=>packRgb32,
    "parseCCRT",
    ()=>parseCCRT,
    "parseCRNG",
    ()=>parseCRNG,
    "retuneTracksForSeamlessLoop",
    ()=>retuneTracksForSeamlessLoop,
    "serializeCCRT",
    ()=>serializeCCRT,
    "serializeCRNG",
    ()=>serializeCRNG,
    "unpackRgb32",
    ()=>unpackRgb32,
    "updateLivePaletteLUT32",
    ()=>updateLivePaletteLUT32,
    "wrapIFFChunk",
    ()=>wrapIFFChunk
]);
function buildCycleRegisterMask(tracks, colorCount) {
    const mask = new Uint8Array(colorCount);
    for (const track of tracks){
        if (!track.enabled || track.rate <= 0 || track.high <= track.low) continue;
        const low = Math.max(0, track.low), high = Math.min(colorCount - 1, track.high);
        for(let i = low; i <= high; i++)mask[i] = 1;
    }
    return mask;
}
const CRNG_FLAGS = {
    RNG_ACTIVE: 1,
    RNG_REVERSE: 2
};
function parseCRNG(chunkBytes, id = 'crng-0') {
    if (chunkBytes.length < 8) {
        throw new Error(`CRNG chunk must be at least 8 bytes, got ${chunkBytes.length}`);
    }
    const view = new DataView(chunkBytes.buffer, chunkBytes.byteOffset, chunkBytes.byteLength);
    // pad1: int16 (reserved 0)
    const rateRaw = view.getInt16(2, false); // big-endian
    const flags = view.getUint16(4, false);
    const low = view.getUint8(6);
    const high = view.getUint8(7);
    // Electronic Arts / Commodore Amiga IFF ILBM CRNG specification:
    // - rateRaw: Q2.14 fixed-point frequency where 16384 = 60 Hz (steps/sec)
    // - flags: bit 0 = RNG_ACTIVE (1), bit 1 = RNG_REVERSE (2)
    // Track activation is strictly controlled by RNG_ACTIVE flag bit and non-zero positive rate
    const isActive = (flags & CRNG_FLAGS.RNG_ACTIVE) !== 0 && rateRaw > 0;
    const isReverse = (flags & CRNG_FLAGS.RNG_REVERSE) !== 0;
    // Rate scaling: 16384 = 60 steps/sec in standard DPaint
    const rateHz = rateRaw > 0 ? rateRaw * 60 / 16384 : 0;
    return {
        id,
        name: `CRNG [${low}..${high}]`,
        low: Math.min(low, high),
        high: Math.max(low, high),
        rate: Math.round(rateHz * 100) / 100,
        direction: isReverse ? 'reverse' : 'forward',
        blendShift: false,
        enabled: isActive
    };
}
function serializeCRNG(track) {
    const bytes = new Uint8Array(8);
    const view = new DataView(bytes.buffer);
    // pad1 = 0
    view.setInt16(0, 0, false);
    // rate: 16384 = 60 Hz
    const rateVal = Math.max(0, Math.min(32767, Math.round(track.rate * 16384 / 60)));
    view.setInt16(2, rateVal, false);
    let flags = 0;
    if (track.enabled) flags |= CRNG_FLAGS.RNG_ACTIVE;
    if (track.direction === 'reverse') flags |= CRNG_FLAGS.RNG_REVERSE;
    view.setUint16(4, flags, false);
    view.setUint8(6, Math.max(0, Math.min(255, track.low)));
    view.setUint8(7, Math.max(0, Math.min(255, track.high)));
    return bytes;
}
function parseCCRT(chunkBytes, id = 'ccrt-0') {
    if (chunkBytes.length < 14) {
        throw new Error(`CCRT chunk must be at least 14 bytes, got ${chunkBytes.length}`);
    }
    const view = new DataView(chunkBytes.buffer, chunkBytes.byteOffset, chunkBytes.byteLength);
    const directionRaw = view.getInt16(0, false);
    const start = view.getUint8(2);
    const end = view.getUint8(3);
    const seconds = view.getInt32(4, false);
    const microseconds = view.getInt32(8, false);
    const deltaSec = seconds + microseconds * 1e-6;
    const rateHz = deltaSec > 0 ? 1 / deltaSec : 0;
    let direction = 'forward';
    if (directionRaw === -1) direction = 'reverse';
    else if (directionRaw === 2) direction = 'ping-pong';
    return {
        id,
        name: `CCRT [${start}..${end}]`,
        low: Math.min(start, end),
        high: Math.max(start, end),
        rate: Math.round(rateHz * 100) / 100,
        direction,
        blendShift: false,
        enabled: directionRaw !== 0 && rateHz > 0
    };
}
function serializeCCRT(track) {
    const bytes = new Uint8Array(14);
    const view = new DataView(bytes.buffer);
    let dirVal = 0;
    if (track.enabled) {
        if (track.direction === 'reverse') dirVal = -1;
        else if (track.direction === 'ping-pong') dirVal = 2;
        else dirVal = 1;
    }
    view.setInt16(0, dirVal, false);
    view.setUint8(2, Math.max(0, Math.min(255, track.low)));
    view.setUint8(3, Math.max(0, Math.min(255, track.high)));
    if (track.rate > 0) {
        const deltaSec = 1 / track.rate;
        const sec = Math.floor(deltaSec);
        const microsec = Math.round((deltaSec - sec) * 1e6);
        view.setInt32(4, sec, false);
        view.setInt32(8, microsec, false);
    } else {
        view.setInt32(4, 0, false);
        view.setInt32(8, 0, false);
    }
    return bytes;
}
function wrapIFFChunk(chunkId, payload) {
    if (chunkId.length !== 4) {
        throw new Error(`IFF chunk ID must be exactly 4 ASCII characters, got '${chunkId}'`);
    }
    const pad = payload.length % 2 !== 0 ? 1 : 0;
    const totalLength = 8 + payload.length + pad;
    const result = new Uint8Array(totalLength);
    const view = new DataView(result.buffer);
    // 4-byte chunk ID
    for(let i = 0; i < 4; i++){
        result[i] = chunkId.charCodeAt(i);
    }
    // 4-byte big-endian payload length (pad not included)
    view.setUint32(4, payload.length, false);
    // Payload
    result.set(payload, 8);
    // Pad byte if odd
    if (pad === 1) {
        result[totalLength - 1] = 0;
    }
    return result;
}
function calculatePingPongOffset(phase, rangeSize) {
    if (rangeSize <= 1) return 0;
    const M = 2 * (rangeSize - 1);
    let p = phase % M;
    if (p < 0) p += M;
    const intP = Math.floor(p);
    if (intP < rangeSize) {
        return intP;
    }
    return M - intP;
}
function hexToRgb(hex) {
    const clean = hex.replace('#', '');
    if (clean.length === 3) {
        const r = parseInt(clean[0] + clean[0], 16) || 0;
        const g = parseInt(clean[1] + clean[1], 16) || 0;
        const b = parseInt(clean[2] + clean[2], 16) || 0;
        return [
            r,
            g,
            b
        ];
    }
    const r = parseInt(clean.substring(0, 2), 16) || 0;
    const g = parseInt(clean.substring(2, 4), 16) || 0;
    const b = parseInt(clean.substring(4, 6), 16) || 0;
    return [
        r,
        g,
        b
    ];
}
function packRgb32(r, g, b, a = 255) {
    return (a & 0xff) << 24 | (b & 0xff) << 16 | (g & 0xff) << 8 | r & 0xff;
}
function unpackRgb32(packed) {
    const r = packed & 0xff;
    const g = packed >> 8 & 0xff;
    const b = packed >> 16 & 0xff;
    return [
        r,
        g,
        b
    ];
}
function blendColorsRgb(c1, c2, t) {
    const clampedT = Math.max(0, Math.min(1, t));
    const r = Math.round(c1[0] * (1 - clampedT) + c2[0] * clampedT);
    const g = Math.round(c1[1] * (1 - clampedT) + c2[1] * clampedT);
    const b = Math.round(c1[2] * (1 - clampedT) + c2[2] * clampedT);
    return [
        r,
        g,
        b
    ];
}
function updateLivePaletteLUT32(basePaletteHex, tracks, elapsedSec, outLUT32) {
    const numColors = basePaletteHex.length;
    // 1. Initialize LUT with base colors
    for(let i = 0; i < numColors; i++){
        const [r, g, b] = hexToRgb(basePaletteHex[i] || '#000000');
        outLUT32[i] = packRgb32(r, g, b, 255);
    }
    // 2. Apply active cycle tracks
    for (const track of tracks){
        if (!track.enabled || track.rate <= 0) continue;
        const low = Math.max(0, Math.min(numColors - 1, track.low));
        const high = Math.max(0, Math.min(numColors - 1, track.high));
        if (high <= low) continue;
        const S = high - low + 1;
        const phaseFloat = elapsedSec * track.rate;
        if (track.direction === 'ping-pong') {
            const M = 2 * (S - 1);
            if (M <= 0) continue;
            for(let k = 0; k < S; k++){
                const destRegister = low + k;
                if (track.blendShift) {
                    // Continuous ping-pong position for register k
                    let p = (phaseFloat + k) % M;
                    if (p < 0) p += M;
                    const intP = Math.floor(p);
                    const frac = p - intP;
                    const getOffset = (idx)=>{
                        const modIdx = idx % M;
                        return modIdx < S ? modIdx : M - modIdx;
                    };
                    const off1 = getOffset(intP);
                    const off2 = getOffset(intP + 1);
                    const c1 = hexToRgb(basePaletteHex[low + off1] || '#000000');
                    const c2 = hexToRgb(basePaletteHex[low + off2] || '#000000');
                    const blended = blendColorsRgb(c1, c2, frac);
                    outLUT32[destRegister] = packRgb32(blended[0], blended[1], blended[2], 255);
                } else {
                    let p = (Math.floor(phaseFloat) + k) % M;
                    if (p < 0) p += M;
                    const offset = p < S ? p : M - p;
                    const [r, g, b] = hexToRgb(basePaletteHex[low + offset] || '#000000');
                    outLUT32[destRegister] = packRgb32(r, g, b, 255);
                }
            }
        } else {
            // Forward or Reverse cycling
            const dirSign = track.direction === 'reverse' ? 1 : -1;
            for(let k = 0; k < S; k++){
                const destRegister = low + k;
                if (track.blendShift) {
                    const shiftContinuous = phaseFloat * dirSign;
                    let p = (k + shiftContinuous) % S;
                    if (p < 0) p += S;
                    const intP = Math.floor(p);
                    const frac = p - intP;
                    const srcIdx1 = low + intP;
                    const srcIdx2 = low + (intP + 1) % S;
                    const c1 = hexToRgb(basePaletteHex[srcIdx1] || '#000000');
                    const c2 = hexToRgb(basePaletteHex[srcIdx2] || '#000000');
                    const blended = blendColorsRgb(c1, c2, frac);
                    outLUT32[destRegister] = packRgb32(blended[0], blended[1], blended[2], 255);
                } else {
                    const shiftInt = Math.floor(phaseFloat) * dirSign;
                    let srcK = (k + shiftInt) % S;
                    if (srcK < 0) srcK += S;
                    const [r, g, b] = hexToRgb(basePaletteHex[low + srcK] || '#000000');
                    outLUT32[destRegister] = packRgb32(r, g, b, 255);
                }
            }
        }
    }
}
function retuneTracksForSeamlessLoop(tracks, targetDurationSec) {
    const T = Math.max(0.1, targetDurationSec);
    return tracks.map((track)=>{
        if (!track.enabled || track.rate <= 0 || track.high <= track.low) {
            return {
                ...track
            };
        }
        const S = track.high - track.low + 1;
        const M = track.direction === 'ping-pong' ? Math.max(1, 2 * (S - 1)) : Math.max(1, S);
        // Number of full periods that fit into duration T
        // Period in seconds is M / rate, so numCycles = T / (M / rate) = (T * rate) / M
        const nominalCycles = T * track.rate / M;
        const harmonicCycles = Math.max(1, Math.round(nominalCycles));
        // Retuned rate ensures exact integer cycles: retunedRate = (harmonicCycles * M) / T
        const retunedRate = harmonicCycles * M / T;
        return {
            ...track,
            rate: Math.round(retunedRate * 1e6) / 1e6
        };
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/color/paletteSemantics.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultPaletteSemantics",
    ()=>defaultPaletteSemantics,
    "estimatePaletteBytes",
    ()=>estimatePaletteBytes,
    "indexSemanticPixels",
    ()=>indexSemanticPixels,
    "parsePaletteSemantics",
    ()=>parsePaletteSemantics
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteCycling.ts [app-client] (ecmascript)");
;
function defaultPaletteSemantics(palette) {
    // Entry IDs are scoped to their palette; reserve room for the register suffix.
    return {
        entries: palette.colors.map((_, i)=>({
                id: `${palette.id.slice(0, 240)}:register:${i}`,
                role: ''
            })),
        bindings: []
    };
}
function parsePaletteSemantics(input, colorCount) {
    if (!input || typeof input !== 'object' || colorCount < 1 || colorCount > 256) return null;
    const value = input;
    if (!Array.isArray(value.entries) || value.entries.length !== colorCount || !Array.isArray(value.bindings) || value.bindings.length > 128) return null;
    const validId = (id)=>typeof id === 'string' && id.length > 0 && id.length <= 256;
    const ids = new Set(), bindings = new Set();
    for (const entry of value.entries){
        if (!entry || !validId(entry.id) || ids.has(entry.id) || typeof entry.role !== 'string' || entry.role.length > 64) return null;
        ids.add(entry.id);
    }
    for (const binding of value.bindings){
        if (!binding || !validId(binding.id) || bindings.has(binding.id) || !validId(binding.frameId) || !ids.has(binding.entryId) || ![
            binding.x,
            binding.y,
            binding.w,
            binding.h
        ].every(Number.isInteger) || binding.x < 0 || binding.y < 0 || binding.w < 1 || binding.h < 1 || binding.x + binding.w > 16384 || binding.y + binding.h > 16384) return null;
        bindings.add(binding.id);
    }
    return {
        entries: value.entries.map((e)=>({
                id: e.id,
                role: e.role
            })),
        bindings: value.bindings.map((b)=>({
                id: b.id,
                frameId: b.frameId,
                entryId: b.entryId,
                x: b.x,
                y: b.y,
                w: b.w,
                h: b.h
            }))
    };
}
function estimatePaletteBytes(palette) {
    return 512 + palette.colors.length * 32 + JSON.stringify(palette.semantics ?? {}).length * 2 + JSON.stringify(palette.cycleTracks ?? []).length * 2;
}
function indexSemanticPixels(data, width, height, palette, frameId) {
    if (data.length !== width * height * 4 || palette.colors.length < 1 || palette.colors.length > 256) throw new Error('Indexed export requires 1–256 palette colors.');
    const semantics = palette.semantics ?? defaultPaletteSemantics(palette);
    if (!parsePaletteSemantics(semantics, palette.colors.length)) throw new Error('Invalid palette roles or bindings.');
    const indices = new Uint8Array(width * height), alpha = new Uint8Array(width * height);
    const registers = new Map();
    palette.colors.forEach((hex, index)=>{
        const [r, g, b] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(hex), key = r << 16 | g << 8 | b;
        const matches = registers.get(key) ?? [];
        matches.push(index);
        registers.set(key, matches);
    });
    const bindings = semantics.bindings.filter((b)=>b.frameId === frameId).map((b)=>({
            ...b,
            index: semantics.entries.findIndex((e)=>e.id === b.entryId)
        })).reverse();
    let unmapped = 0, ambiguous = 0, bound = 0;
    for(let p = 0; p < indices.length; p++){
        alpha[p] = data[p * 4 + 3];
        if (!alpha[p]) continue;
        const matches = registers.get(data[p * 4] << 16 | data[p * 4 + 1] << 8 | data[p * 4 + 2]);
        if (!matches) {
            unmapped++;
            continue;
        }
        const x = p % width, y = Math.floor(p / width);
        const binding = bindings.find((b)=>x >= b.x && y >= b.y && x < b.x + b.w && y < b.y + b.h && matches.includes(b.index));
        indices[p] = binding?.index ?? matches[0];
        if (binding) bound++;
        else if (matches.length > 1) ambiguous++;
    }
    if (unmapped) throw new Error(`${unmapped} visible pixels are outside the selected palette. Use a matching palette or export the color-only Godot kit.`);
    if (ambiguous) throw new Error(`${ambiguous} pixels match duplicate palette registers. Assign their selection to a register in Palette → Roles and index bindings.`);
    return {
        indices,
        alpha,
        bound,
        semantics
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/diagnostics/capture.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "captureDiagnostic",
    ()=>captureDiagnostic,
    "clearDiagnostics",
    ()=>clearDiagnostics,
    "exportDiagnosticsFile",
    ()=>exportDiagnosticsFile,
    "getDiagnosticsSettings",
    ()=>getDiagnosticsSettings,
    "getRecentDiagnostics",
    ()=>getRecentDiagnostics,
    "relayDiagnostics",
    ()=>relayDiagnostics,
    "setDiagnosticsSettings",
    ()=>setDiagnosticsSettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/storage/db.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$version$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/version.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
;
;
;
;
;
const SETTINGS_KEY = 'pixibun-diagnostics';
const MAX_DIAGNOSTICS_ENTRIES = 200;
const MAX_DETAIL_LENGTH = 2048;
let memorySettings = {
    enabled: true,
    relayOptIn: false
};
function getSafeStorage() {
    try {
        if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.localStorage) {
            return window.localStorage;
        }
    } catch  {
    // blocked or unavailable
    }
    return null;
}
function getDiagnosticsSettings() {
    const storage = getSafeStorage();
    if (storage) {
        try {
            const raw = storage.getItem(SETTINGS_KEY);
            if (raw) {
                const parsed = JSON.parse(raw);
                const settings = typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed) ? parsed : {};
                memorySettings = {
                    enabled: typeof settings.enabled === 'boolean' ? settings.enabled : true,
                    relayOptIn: settings.relayOptIn === true
                };
                return memorySettings;
            }
        } catch  {
            // Invalid persisted consent must never inherit a previous opt-in.
            memorySettings = {
                enabled: true,
                relayOptIn: false
            };
        }
    }
    return memorySettings;
}
function setDiagnosticsSettings(partial) {
    const current = getDiagnosticsSettings();
    const updated = {
        enabled: typeof partial.enabled === 'boolean' ? partial.enabled : current.enabled,
        relayOptIn: partial.relayOptIn === undefined ? current.relayOptIn : partial.relayOptIn === true
    };
    memorySettings = updated;
    const storage = getSafeStorage();
    if (storage) {
        try {
            storage.setItem(SETTINGS_KEY, JSON.stringify(updated));
        } catch (err) {
            console.error('Failed to save diagnostics settings:', err);
        }
    }
    return updated;
}
async function captureDiagnostic(entry) {
    try {
        const settings = getDiagnosticsSettings();
        if (!settings.enabled) {
            return null;
        }
        const route = entry.route || (("TURBOPACK compile-time value", "object") !== 'undefined' && window.location ? window.location.pathname : '/');
        const detail = entry.detail ? entry.detail.length > MAX_DETAIL_LENGTH ? `${entry.detail.slice(0, MAX_DETAIL_LENGTH)}...[truncated]` : entry.detail : undefined;
        const fullEntry = {
            id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('diag'),
            kind: entry.kind,
            timestamp: Date.now(),
            message: entry.message || 'Unknown diagnostic event',
            detail,
            route,
            appVersion: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$version$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APP_VERSION"]
        };
        if (("TURBOPACK compile-time value", "object") !== 'undefined' && typeof indexedDB !== 'undefined' && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"]?.diagnostics) {
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"].diagnostics.put(fullEntry);
                // FIFO Prune to keep at most MAX_DIAGNOSTICS_ENTRIES
                const count = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"].diagnostics.count();
                if (count > MAX_DIAGNOSTICS_ENTRIES) {
                    const excess = count - MAX_DIAGNOSTICS_ENTRIES;
                    const oldest = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"].diagnostics.orderBy('timestamp').limit(excess).primaryKeys();
                    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"].diagnostics.bulkDelete(oldest);
                }
            } catch (storageErr) {
                // IndexedDB storage failed (e.g. quota, private browsing, test env)
                console.warn('Diagnostics storage failed:', storageErr);
            }
        }
        // Strictly opt-in relay
        if (settings.relayOptIn) {
            // Fire-and-forget relay
            relayDiagnostics([
                fullEntry
            ]).catch(()=>{
            // relay failure must never crash the app
            });
        }
        return fullEntry;
    } catch (err) {
        // Diagnostics must NEVER throw or break the app
        console.warn('PixiBun diagnostics capture failed silently:', err);
        return null;
    }
}
async function getRecentDiagnostics(limit = 200) {
    try {
        if (("TURBOPACK compile-time value", "object") === 'undefined' || !__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"]?.diagnostics) return [];
        return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"].diagnostics.orderBy('timestamp').reverse().limit(limit).toArray();
    } catch (err) {
        console.error('Failed to load diagnostics:', err);
        return [];
    }
}
async function clearDiagnostics() {
    try {
        if (("TURBOPACK compile-time value", "object") !== 'undefined' && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"]?.diagnostics) {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"].diagnostics.clear();
        }
    } catch (err) {
        console.error('Failed to clear diagnostics:', err);
    }
}
async function exportDiagnosticsFile() {
    try {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        const entries = await getRecentDiagnostics(MAX_DIAGNOSTICS_ENTRIES);
        const settings = getDiagnosticsSettings();
        const payload = {
            app: 'PixiBun Atelier',
            version: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$version$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APP_VERSION"],
            exportedAt: new Date().toISOString(),
            rasterRegistry: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBufferRegistryUsage"])(),
            memoryBudget: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMemoryBudgetUsage"])(),
            settings: {
                enabled: settings.enabled,
                relayOptIn: settings.relayOptIn
            },
            entries
        };
        const blob = new Blob([
            JSON.stringify(payload, null, 2)
        ], {
            type: 'application/json'
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `pixibun-diagnostics-${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } catch (err) {
        console.error('Failed to export diagnostics file:', err);
    }
}
async function relayDiagnostics(entries) {
    try {
        const res = await fetch('/api/diagnostics/relay', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                app: 'pixibun',
                version: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$version$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APP_VERSION"],
                timestamp: Date.now(),
                events: entries
            })
        });
        return res.ok;
    } catch  {
        return false;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/diagnostics/vitals.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "initWebVitals",
    ()=>initWebVitals
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/web-vitals/dist/web-vitals.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/diagnostics/capture.ts [app-client] (ecmascript)");
;
;
let vitalsInitialized = false;
function initWebVitals() {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || vitalsInitialized) return;
    vitalsInitialized = true;
    const handleMetric = (metric)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$diagnostics$2f$capture$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureDiagnostic"])({
            kind: 'web-vital',
            message: `${metric.name}: ${Math.round(metric.value)}${metric.name === 'CLS' ? '' : 'ms'} (${metric.rating || 'n/a'})`,
            detail: JSON.stringify(metric)
        });
    };
    try {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onCLS"])(handleMetric);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onINP"])(handleMetric);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onLCP"])(handleMetric);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onTTFB"])(handleMetric);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onFCP"])(handleMetric);
    } catch (err) {
        console.warn('Failed to initialize web-vitals tracking:', err);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Engine-level pixel buffer registry.
//
// Layer bitmaps previously lived in a React ref inside CenterViewport, which
// made them unserializable (autosave and .pixibun export stored empty
// metadata), wiped on remount, and unclonable when duplicating frames or
// layers. This module is the single owner of offscreen layer canvases so the
// store can clone/delete/serialize them deterministically.
__turbopack_context__.s([
    "bufferCount",
    ()=>bufferCount,
    "clearAllBuffers",
    ()=>clearAllBuffers,
    "cloneBuffers",
    ()=>cloneBuffers,
    "createEntry",
    ()=>createEntry,
    "deleteBuffers",
    ()=>deleteBuffers,
    "getBufferGeneration",
    ()=>getBufferGeneration,
    "getBufferRegistryUsage",
    ()=>getBufferRegistryUsage,
    "getBufferRevision",
    ()=>getBufferRevision,
    "getOrCreateBuffer",
    ()=>getOrCreateBuffer,
    "hasBuffer",
    ()=>hasBuffer,
    "replaceAllBuffers",
    ()=>replaceAllBuffers,
    "resamplePixelArtBuffer",
    ()=>resamplePixelArtBuffer,
    "resizeAllBuffers",
    ()=>resizeAllBuffers,
    "setBufferRevision",
    ()=>setBufferRevision,
    "snapshotBuffers",
    ()=>snapshotBuffers,
    "touchBuffer",
    ()=>touchBuffer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
;
const buffers = new Map();
let nextBufferGeneration = 0;
function createEntry(width, height, initialRevision = 1, reserved = false) {
    if (!reserved) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertMemoryAvailable"])(width * height * 4, 'Layer allocation');
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d', {
        willReadFrequently: true
    });
    if (!ctx) {
        throw new Error('Could not acquire a 2D context for a layer buffer.');
    }
    ctx.imageSmoothingEnabled = false;
    return {
        canvas,
        ctx,
        contentRevision: initialRevision,
        generation: ++nextBufferGeneration
    };
}
function getOrCreateBuffer(layerId, width, height) {
    const existing = buffers.get(layerId);
    if (!existing) {
        const entry = createEntry(width, height, 1);
        buffers.set(layerId, entry);
        return entry;
    }
    const { canvas } = existing;
    if (canvas.width !== width || canvas.height !== height) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertMemoryAvailable"])(width * height * 4 + canvas.width * canvas.height * 4, 'Layer resize staging');
        const previous = document.createElement('canvas');
        previous.width = canvas.width;
        previous.height = canvas.height;
        previous.getContext('2d')?.drawImage(canvas, 0, 0);
        canvas.width = width;
        canvas.height = height;
        existing.ctx.imageSmoothingEnabled = false;
        existing.ctx.drawImage(previous, 0, 0);
        existing.contentRevision += 1;
    }
    return existing;
}
function touchBuffer(layerId) {
    const entry = buffers.get(layerId);
    if (entry) {
        entry.contentRevision += 1;
        return entry.contentRevision;
    }
    return 0;
}
function getBufferRevision(layerId) {
    return buffers.get(layerId)?.contentRevision ?? 0;
}
function getBufferGeneration(layerId) {
    return buffers.get(layerId)?.generation;
}
function setBufferRevision(layerId, revision) {
    const entry = buffers.get(layerId);
    if (entry) {
        entry.contentRevision = revision;
    }
}
function hasBuffer(layerId) {
    return buffers.has(layerId);
}
function cloneBuffers(srcLayerIds, dstLayerIds, width, height) {
    const count = Math.min(srcLayerIds.length, dstLayerIds.length);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertMemoryAvailable"])(count * width * height * 4, 'Layer duplication');
    for(let i = 0; i < count; i++){
        const src = buffers.get(srcLayerIds[i]);
        const dst = getOrCreateBuffer(dstLayerIds[i], width, height);
        dst.ctx.imageSmoothingEnabled = false;
        dst.ctx.clearRect(0, 0, width, height);
        if (src) {
            dst.ctx.drawImage(src.canvas, 0, 0);
        }
        dst.contentRevision += 1;
    }
}
function deleteBuffers(layerIds) {
    for (const id of layerIds){
        buffers.delete(id);
    }
}
function clearAllBuffers() {
    buffers.clear();
}
function replaceAllBuffers(entries) {
    buffers.clear();
    for (const [id, entry] of entries)buffers.set(id, entry);
}
function snapshotBuffers() {
    return new Map(buffers);
}
function getBufferRegistryUsage() {
    let bytes = 0;
    for (const { canvas } of buffers.values())bytes += canvas.width * canvas.height * 4;
    return {
        count: buffers.size,
        bytes
    };
}
function anchorOffsets(anchor, oldWidth, oldHeight, newWidth, newHeight) {
    const half = (value)=>Math.floor(value / 2);
    switch(anchor){
        case 'top-left':
            return {
                offsetX: 0,
                offsetY: 0
            };
        case 'top-center':
            return {
                offsetX: half(newWidth - oldWidth),
                offsetY: 0
            };
        case 'top-right':
            return {
                offsetX: newWidth - oldWidth,
                offsetY: 0
            };
        case 'middle-left':
            return {
                offsetX: 0,
                offsetY: half(newHeight - oldHeight)
            };
        case 'center':
            return {
                offsetX: half(newWidth - oldWidth),
                offsetY: half(newHeight - oldHeight)
            };
        case 'middle-right':
            return {
                offsetX: newWidth - oldWidth,
                offsetY: half(newHeight - oldHeight)
            };
        case 'bottom-left':
            return {
                offsetX: 0,
                offsetY: newHeight - oldHeight
            };
        case 'bottom-center':
            return {
                offsetX: half(newWidth - oldWidth),
                offsetY: newHeight - oldHeight
            };
        case 'bottom-right':
            return {
                offsetX: newWidth - oldWidth,
                offsetY: newHeight - oldHeight
            };
    }
}
function resamplePixelArtBuffer(srcCanvas, dstCtx, newWidth, newHeight) {
    const oldWidth = srcCanvas.width;
    const oldHeight = srcCanvas.height;
    if (oldWidth === 0 || oldHeight === 0 || newWidth === 0 || newHeight === 0) return;
    // When upscaling both axes, crisp nearest-neighbor drawImage is exact and immediate
    if (newWidth >= oldWidth && newHeight >= oldHeight) {
        dstCtx.imageSmoothingEnabled = false;
        dstCtx.drawImage(srcCanvas, 0, 0, newWidth, newHeight);
        return;
    }
    // When downscaling, naive drawImage skips odd coordinates and perforates 1px strokes.
    // Area-preserving downsampling with presence conservation prevents line dropouts.
    const srcCtx = srcCanvas.getContext('2d', {
        willReadFrequently: true
    });
    if (!srcCtx) {
        dstCtx.drawImage(srcCanvas, 0, 0, newWidth, newHeight);
        return;
    }
    const srcData = srcCtx.getImageData(0, 0, oldWidth, oldHeight).data;
    const dstImgData = dstCtx.createImageData(newWidth, newHeight);
    const dstData = dstImgData.data;
    const scaleX = oldWidth / newWidth;
    const scaleY = oldHeight / newHeight;
    for(let y = 0; y < newHeight; y++){
        const y0 = Math.floor(y * scaleY);
        const y1 = Math.min(oldHeight, Math.ceil((y + 1) * scaleY));
        for(let x = 0; x < newWidth; x++){
            const x0 = Math.floor(x * scaleX);
            const x1 = Math.min(oldWidth, Math.ceil((x + 1) * scaleX));
            // Scan source footprint [x0, x1) x [y0, y1)
            const colorVotes = new Map();
            let solidCount = 0;
            for(let sy = y0; sy < y1; sy++){
                for(let sx = x0; sx < x1; sx++){
                    const sIdx = (sy * oldWidth + sx) * 4;
                    const a = srcData[sIdx + 3];
                    if (a > 32) {
                        solidCount++;
                        const r = srcData[sIdx];
                        const g = srcData[sIdx + 1];
                        const b = srcData[sIdx + 2];
                        const key = r << 24 | g << 16 | b << 8 | a;
                        const entry = colorVotes.get(key);
                        if (entry) {
                            entry.count++;
                        } else {
                            colorVotes.set(key, {
                                r,
                                g,
                                b,
                                a,
                                count: 1
                            });
                        }
                    }
                }
            }
            const dIdx = (y * newWidth + x) * 4;
            // Presence conservation: Any solid stroke in the cell guarantees a solid pixel
            if (solidCount > 0 && colorVotes.size > 0) {
                let bestVote = 0;
                let bestColor = {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 255
                };
                for (const v of colorVotes.values()){
                    if (v.count > bestVote) {
                        bestVote = v.count;
                        bestColor = v;
                    }
                }
                dstData[dIdx] = bestColor.r;
                dstData[dIdx + 1] = bestColor.g;
                dstData[dIdx + 2] = bestColor.b;
                dstData[dIdx + 3] = bestColor.a;
            }
        }
    }
    dstCtx.putImageData(dstImgData, 0, 0);
}
function resizeAllBuffers(newWidth, newHeight, anchor, resample) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertMemoryAvailable"])(buffers.size * newWidth * newHeight * 4, 'Workspace resize staging');
    for (const [layerId, entry] of buffers){
        const oldWidth = entry.canvas.width;
        const oldHeight = entry.canvas.height;
        if (oldWidth === newWidth && oldHeight === newHeight) continue;
        const next = createEntry(newWidth, newHeight, entry.contentRevision + 1);
        next.ctx.imageSmoothingEnabled = false;
        if (resample) {
            resamplePixelArtBuffer(entry.canvas, next.ctx, newWidth, newHeight);
        } else {
            const { offsetX, offsetY } = anchorOffsets(anchor, oldWidth, oldHeight, newWidth, newHeight);
            next.ctx.drawImage(entry.canvas, offsetX, offsetY);
        }
        buffers.set(layerId, next);
    }
}
function bufferCount() {
    return buffers.size;
}
(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerMemoryUsage"])('rasters', ()=>getBufferRegistryUsage().bytes);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/engine/id.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createId",
    ()=>createId
]);
// Collision-proof identity generation for layers, frames, clips, and messages.
// Date.now() IDs collided when two entities were created within the same
// millisecond (e.g. addFrame cloning N layers), corrupting buffer lookups.
let counter = 0;
function getRandomEntropy() {
    if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
        const buf = new Uint32Array(1);
        crypto.getRandomValues(buf);
        return buf[0].toString(36);
    }
    return Math.floor(Math.random() * 0xffffffff).toString(36);
}
function createId(prefix) {
    counter = (counter + 1) % Number.MAX_SAFE_INTEGER;
    const random = getRandomEntropy();
    return `${prefix}-${Date.now().toString(36)}-${counter.toString(36)}-${random}`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/animationTiming.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** Timing values admitted by the project format and editable in Studio. */ __turbopack_context__.s([
    "ANIMATION_TIMING_LIMITS",
    ()=>ANIMATION_TIMING_LIMITS
]);
const ANIMATION_TIMING_LIMITS = {
    fpsMin: 1,
    fpsMax: 60,
    durationMinMs: 1,
    durationMaxMs: 60_000
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/decodeProject.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "decodeAndValidateProject",
    ()=>decodeAndValidateProject
]);
/**
 * decodeProject.ts
 *
 * Canonical Project Decoder for PixiBun Atelier.
 *
 * Provides a single trusted parsing and validation pathway:
 * Untrusted serialized JSON
 *   -> SafeJson parse (with prototype pollution & size defenses)
 *   -> Structural validation
 *   -> Version migration
 *   -> Aggregate resource budget validation
 *   -> Strongly-typed, normalized ProjectFile
 *
 * Used consistently across IndexedDB restore, duplicate, rename, file import,
 * and external project loading.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/safeJson.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/schema.ts [app-client] (ecmascript)");
;
;
function decodeAndValidateProject(raw) {
    try {
        const parsed = typeof raw === 'string' ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].parse(raw) : raw;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProjectFile"])(parsed);
    } catch (err) {
        return {
            ok: false,
            error: err instanceof Error ? err.message : 'Invalid JSON format in project data.'
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/metadataAdmission.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAX_METADATA_NAME_LENGTH",
    ()=>MAX_METADATA_NAME_LENGTH,
    "MAX_PROJECT_CLIPS",
    ()=>MAX_PROJECT_CLIPS,
    "MAX_PROJECT_NAME_LENGTH",
    ()=>MAX_PROJECT_NAME_LENGTH,
    "clipRangeError",
    ()=>clipRangeError,
    "makeLayerCopyName",
    ()=>makeLayerCopyName,
    "metadataNameError",
    ()=>metadataNameError,
    "projectNameError",
    ()=>projectNameError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/recovery/recoveryLimits.ts [app-client] (ecmascript)");
;
const MAX_PROJECT_NAME_LENGTH = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_PROJECT_NAME_LENGTH;
const MAX_METADATA_NAME_LENGTH = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_IDENTIFIER_LENGTH;
const MAX_PROJECT_CLIPS = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_CLIPS;
function makeLayerCopyName(name) {
    const suffix = ' (Copy)';
    const stemLimit = MAX_METADATA_NAME_LENGTH - suffix.length;
    let stem = '';
    for (const character of name){
        if (stem.length + character.length > stemLimit) break;
        stem += character;
    }
    return `${stem}${suffix}`;
}
function projectNameError(name) {
    if (typeof name !== 'string' || name.trim().length === 0) return 'Project name cannot be empty.';
    if (name.length > MAX_PROJECT_NAME_LENGTH) {
        return `Project name must be at most ${MAX_PROJECT_NAME_LENGTH} characters.`;
    }
    return null;
}
function metadataNameError(name, kind) {
    if (typeof name !== 'string' || name.length > MAX_METADATA_NAME_LENGTH) {
        return `${kind === 'layer' ? 'Layer' : 'Clip'} name must be at most ${MAX_METADATA_NAME_LENGTH} characters.`;
    }
    return null;
}
function clipRangeError(startFrame, endFrame, frameCount) {
    if (!Number.isInteger(startFrame) || !Number.isInteger(endFrame) || startFrame < 0 || startFrame > endFrame || endFrame >= frameCount) {
        return 'Clip frames must form a valid range within the animation.';
    }
    return null;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/persistenceRevisions.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearPersistedRevisions",
    ()=>clearPersistedRevisions,
    "commitPersistedRevisions",
    ()=>commitPersistedRevisions,
    "getPersistedRevision",
    ()=>getPersistedRevision,
    "initProjectPersistedRevisions",
    ()=>initProjectPersistedRevisions,
    "isLayerDirty",
    ()=>isLayerDirty,
    "setPersistedRevision",
    ()=>setPersistedRevision
]);
// Project-scoped revision tracking for incremental autosave persistence.
// Maintains per-project, per-layer persisted revision and frameIndex records.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
;
// Scoped by projectId -> layerId -> { revision, frameIndex }
const persistedRevisionsByProject = new Map();
function getPersistedRevision(projectId, layerId) {
    return persistedRevisionsByProject.get(projectId)?.get(layerId);
}
function setPersistedRevision(projectId, layerId, revision, frameIndex) {
    let projectMap = persistedRevisionsByProject.get(projectId);
    if (!projectMap) {
        projectMap = new Map();
        persistedRevisionsByProject.set(projectId, projectMap);
    }
    projectMap.set(layerId, {
        revision,
        frameIndex,
        generation: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBufferGeneration"])(layerId)
    });
}
function commitPersistedRevisions(projectId, captured) {
    if (!captured || typeof captured[Symbol.iterator] !== 'function') return;
    let projectMap = persistedRevisionsByProject.get(projectId);
    if (!projectMap) {
        projectMap = new Map();
        persistedRevisionsByProject.set(projectId, projectMap);
    }
    for (const [layerId, entry] of captured){
        const existing = projectMap.get(layerId);
        const generationChanged = entry.generation !== undefined && existing?.generation !== undefined && entry.generation !== existing.generation;
        if (!existing || (generationChanged ? entry.generation > existing.generation : entry.revision >= existing.revision)) {
            projectMap.set(layerId, {
                ...entry
            });
        }
    }
}
function initProjectPersistedRevisions(projectId, revisions) {
    const projectMap = new Map();
    for (const [layerId, entry] of revisions){
        projectMap.set(layerId, {
            ...entry
        });
    }
    persistedRevisionsByProject.set(projectId, projectMap);
}
function clearPersistedRevisions(projectId) {
    if (projectId) {
        persistedRevisionsByProject.delete(projectId);
    } else {
        persistedRevisionsByProject.clear();
    }
}
function isLayerDirty(projectId, layerId, currentRevision, currentFrameIndex) {
    const persisted = getPersistedRevision(projectId, layerId);
    if (!persisted) return true;
    const generation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBufferGeneration"])(layerId);
    if (persisted.generation !== undefined && generation !== persisted.generation) return true;
    if (currentRevision > persisted.revision) return true;
    if (currentFrameIndex !== persisted.frameIndex) return true;
    return false;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/resourceBudget.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateProjectResourceUsage",
    ()=>calculateProjectResourceUsage,
    "safeMultiply",
    ()=>safeMultiply,
    "validateProjectResourceBudget",
    ()=>validateProjectResourceBudget
]);
/**
 * resourceBudget.ts
 *
 * Central aggregate project resource calculation and validation envelope for PixiBun.
 *
 * Initial conservative project-complexity ceiling. This is a validation bound based
 * on base/raw RGBA footprint, not a guarantee of total browser memory consumption.
 *
 * Ensures individually valid dimensions (e.g. 2048x2048 canvas, 500 frames, 100 layers)
 * cannot combine into an unmaterializable project (e.g. 50,000 layers = 781 GiB).
 *
 * Evaluates worst-case materializable raster footprint before allocation, import,
 * hydration, or P2P structure application.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/canvasLimits.ts [app-client] (ecmascript)");
;
function safeMultiply(a, b) {
    if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b) || a < 0 || b < 0) {
        return null;
    }
    if (a === 0 || b === 0) return 0;
    if (a > Math.floor(Number.MAX_SAFE_INTEGER / b)) {
        return null;
    }
    const result = a * b;
    return Number.isSafeInteger(result) ? result : null;
}
function calculateProjectResourceUsage(width, height, frames) {
    const frameCount = frames.length;
    let layerCount = 0;
    let rasterLayerCount = 0;
    for (const frame of frames){
        if (Array.isArray(frame.layers)) {
            layerCount += frame.layers.length;
            for (const layer of frame.layers){
                if (typeof layer === 'object' && layer !== null) {
                    // In PixiBun every layer in a frame is raster-backed upon edit or render
                    rasterLayerCount += 1;
                }
            }
        }
    }
    const pxPerFrame = safeMultiply(width, height);
    const materializableRasterPixels = pxPerFrame !== null ? safeMultiply(layerCount, pxPerFrame) ?? Number.MAX_SAFE_INTEGER : Number.MAX_SAFE_INTEGER;
    const baseRawRgbaBytes = safeMultiply(materializableRasterPixels, 4) ?? Number.MAX_SAFE_INTEGER;
    return {
        frameCount,
        layerCount,
        rasterLayerCount,
        materializableRasterPixels,
        baseRawRgbaBytes
    };
}
function validateProjectResourceBudget(width, height, frames) {
    const usage = calculateProjectResourceUsage(width, height, frames);
    if (usage.layerCount > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_TOTAL_LAYERS) {
        return {
            ok: false,
            error: `Project exceeds total layer limit (${usage.layerCount.toLocaleString()} layers across all frames; maximum allowed is ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_TOTAL_LAYERS.toLocaleString()}).`,
            usage
        };
    }
    if (usage.materializableRasterPixels > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_AGGREGATE_PIXELS) {
        const mpx = (usage.materializableRasterPixels / 1_000_000).toFixed(1);
        const maxMpx = (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_AGGREGATE_PIXELS / 1_000_000).toFixed(1);
        const mib = Math.round(usage.baseRawRgbaBytes / (1024 * 1024));
        return {
            ok: false,
            error: `Project exceeds conservative resource complexity ceiling (${mpx} MP worst-case footprint, ~${mib} MiB base RGBA; maximum allowed is ${maxMpx} MP).`,
            usage
        };
    }
    return {
        ok: true,
        usage
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/project/schema.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "migrateProjectPayload",
    ()=>migrateProjectPayload,
    "validateLayerEffect",
    ()=>validateLayerEffect,
    "validateProjectFile",
    ()=>validateProjectFile,
    "validateProjectJsonWithPolicy",
    ()=>validateProjectJsonWithPolicy,
    "validateProjectWithPolicy",
    ()=>validateProjectWithPolicy
]);
// Structural validator for the `.pixibun` project format. Hand-rolled on
// purpose: importing unvetted JSON straight into the store let malformed
// files corrupt session state, so every field is checked before hydration.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/types/project.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/safeJson.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/canvasLimits.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/resourceBudget.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/recovery/recoveryLimits.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteAdmission.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/animationTiming.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/animation/reviewMetadata.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteSemantics.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$research$2f$recipes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/research/recipes.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
const BLEND_MODES = new Set([
    'source-over',
    'multiply',
    'screen',
    'overlay',
    'color-dodge',
    'source-atop'
]);
const LOOP_MODES = new Set([
    'repeat',
    'ping-pong',
    'once'
]);
const SMART_EFFECT_KINDS = new Set([
    'photometric',
    'auto-shade',
    'cast-shadow',
    'ground-shadow',
    'volumetric-optics',
    'normal-map',
    'specular',
    'sel-out',
    'outline',
    'autotile',
    'wfc'
]);
const EFFECT_SOURCE_MODES = new Set([
    'composite-excluding-self',
    'active-layer',
    'selection'
]);
function isPlainObject(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function isIntegerInRange(value, min, max) {
    return typeof value === 'number' && Number.isInteger(value) && value >= min && value <= max;
}
function isUnitInterval(value) {
    return typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1;
}
function isHexColor(value) {
    return typeof value === 'string' && /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(value);
}
function validateLayerEffect(input) {
    if (input === undefined) return undefined;
    if (!isPlainObject(input)) return 'has malformed effect metadata.';
    if (typeof input.id !== 'string' || input.id.length === 0 || input.id.length > 128) {
        return 'has an invalid effect identifier.';
    }
    if (typeof input.kind !== 'string' || !SMART_EFFECT_KINDS.has(input.kind)) {
        return 'uses an unknown smart effect.';
    }
    if (input.version !== 1 || typeof input.sourceMode !== 'string' || !EFFECT_SOURCE_MODES.has(input.sourceMode)) {
        return 'uses an unsupported effect recipe.';
    }
    if (!isPlainObject(input.params) || Object.keys(input.params).length > 64) {
        return 'has malformed effect parameters.';
    }
    const params = {};
    for (const [key, value] of Object.entries(input.params)){
        if (key.length > 64 || !/^[a-zA-Z][a-zA-Z0-9]*$/.test(key)) return 'has an invalid effect parameter name.';
        if (Array.isArray(value)) {
            if (value.length > 256 || !value.every((item)=>typeof item === 'string' && item.length <= 64)) {
                return 'has an invalid list effect parameter.';
            }
            params[key] = value.slice();
            continue;
        }
        if (value !== null && typeof value !== 'string' && typeof value !== 'number' && typeof value !== 'boolean') {
            return 'has an invalid effect parameter.';
        }
        if (typeof value === 'number' && !Number.isFinite(value)) return 'has a non-finite effect parameter.';
        params[key] = value;
    }
    let analysis;
    if (input.analysis !== undefined) {
        if (!isPlainObject(input.analysis)) return 'has malformed effect analysis.';
        analysis = {
            formType: input.analysis.formType === 'character' || input.analysis.formType === 'orb' || input.analysis.formType === 'prop' ? input.analysis.formType : undefined,
            sourceLightAzimuth: typeof input.analysis.sourceLightAzimuth === 'number' && Number.isFinite(input.analysis.sourceLightAzimuth) ? input.analysis.sourceLightAzimuth : undefined,
            sourceLightElevation: typeof input.analysis.sourceLightElevation === 'number' && Number.isFinite(input.analysis.sourceLightElevation) ? input.analysis.sourceLightElevation : undefined,
            cueStrength: typeof input.analysis.cueStrength === 'number' && Number.isFinite(input.analysis.cueStrength) ? Math.max(0, Math.min(1, input.analysis.cueStrength)) : typeof input.analysis.confidence === 'number' && Number.isFinite(input.analysis.confidence) ? Math.max(0, Math.min(1, input.analysis.confidence)) : undefined,
            rationale: typeof input.analysis.rationale === 'string' ? input.analysis.rationale.slice(0, 1000) : undefined
        };
    }
    if (!isIntegerInRange(input.updatedAt, 0, Number.MAX_SAFE_INTEGER)) return 'has an invalid effect timestamp.';
    return {
        id: input.id,
        kind: input.kind,
        version: 1,
        sourceMode: input.sourceMode,
        params,
        analysis,
        updatedAt: input.updatedAt
    };
}
function validateFrame(input, frameIndex, mode) {
    if (!isPlainObject(input)) {
        return {
            error: `Frame ${frameIndex + 1} is not structured the way PixiBun expects.`,
            reasonCode: 'INVALID_FRAME_STRUCTURE'
        };
    }
    if (typeof input.id !== 'string' || input.id.length === 0 || input.id.length > 128) {
        return {
            error: `Frame ${frameIndex + 1} has an invalid or missing identifier.`,
            reasonCode: 'INVALID_FRAME_STRUCTURE'
        };
    }
    if (!isIntegerInRange(input.durationMs, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMinMs, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMaxMs)) {
        return {
            error: `Frame ${frameIndex + 1} has an out-of-range duration.`,
            reasonCode: 'INVALID_FRAME_STRUCTURE'
        };
    }
    if (!Array.isArray(input.layers) || input.layers.length === 0) {
        return {
            error: `Frame ${frameIndex + 1} carries no layers — the file may have been truncated.`,
            reasonCode: 'INVALID_FRAME_STRUCTURE'
        };
    }
    let frameExceedsEnvelope = false;
    if (mode === 'strict') {
        if (input.layers.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS) {
            return {
                error: `Frame ${frameIndex + 1} exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS} layer ceiling.`,
                reasonCode: 'ENVELOPE_MAX_LAYERS_PER_FRAME'
            };
        }
    } else {
        // collect-recoverable mode: enforce recovery inspection ceiling
        if (input.layers.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_LAYERS_PER_FRAME) {
            return {
                error: `Frame ${frameIndex + 1} layer count (${input.layers.length}) exceeds recovery layer inspection ceiling (${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_LAYERS_PER_FRAME}).`,
                reasonCode: 'INSPECTION_CEILING_EXCEEDED'
            };
        }
        if (input.layers.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS) {
            frameExceedsEnvelope = true;
        }
    }
    const layers = [];
    for(let i = 0; i < input.layers.length; i++){
        const rawLayer = input.layers[i];
        if (!isPlainObject(rawLayer)) {
            return {
                error: `Frame ${frameIndex + 1}, layer ${i + 1} is malformed.`,
                reasonCode: 'INVALID_LAYER_STRUCTURE'
            };
        }
        if (typeof rawLayer.id !== 'string' || rawLayer.id.length === 0 || rawLayer.id.length > 128) {
            return {
                error: `Frame ${frameIndex + 1}, layer ${i + 1} has an invalid identifier.`,
                reasonCode: 'INVALID_LAYER_STRUCTURE'
            };
        }
        if (typeof rawLayer.name !== 'string' || rawLayer.name.length > 128) {
            return {
                error: `Frame ${frameIndex + 1}, layer ${i + 1} has an invalid name.`,
                reasonCode: 'INVALID_LAYER_STRUCTURE'
            };
        }
        if (typeof rawLayer.visible !== 'boolean' || typeof rawLayer.locked !== 'boolean') {
            return {
                error: `Frame ${frameIndex + 1}, layer ${i + 1} has corrupted visibility or lock flags.`,
                reasonCode: 'INVALID_LAYER_STRUCTURE'
            };
        }
        if (!isUnitInterval(rawLayer.opacity)) {
            return {
                error: `Frame ${frameIndex + 1}, layer ${i + 1} has an opacity outside 0-100%.`,
                reasonCode: 'INVALID_LAYER_STRUCTURE'
            };
        }
        if (typeof rawLayer.blendMode !== 'string' || !BLEND_MODES.has(rawLayer.blendMode)) {
            return {
                error: `Frame ${frameIndex + 1}, layer ${i + 1} uses a blend mode PixiBun does not know.`,
                reasonCode: 'INVALID_LAYER_STRUCTURE'
            };
        }
        if (rawLayer.pngBase64 !== undefined && typeof rawLayer.pngBase64 !== 'string') {
            return {
                error: `Frame ${frameIndex + 1}, layer ${i + 1} carries unreadable pixel data.`,
                reasonCode: 'INVALID_LAYER_STRUCTURE'
            };
        }
        if (rawLayer.tag !== undefined && (typeof rawLayer.tag !== 'string' || rawLayer.tag.length > 128)) {
            return {
                error: `Frame ${frameIndex + 1}, layer ${i + 1} has an invalid tag.`,
                reasonCode: 'INVALID_LAYER_STRUCTURE'
            };
        }
        const effect = validateLayerEffect(rawLayer.effect);
        let research;
        try {
            research = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$research$2f$recipes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseResearchRecipe"])(rawLayer.research);
        } catch (error) {
            return {
                error: `Frame ${frameIndex + 1}, layer ${i + 1}: ${error.message}`,
                reasonCode: 'INVALID_LAYER_STRUCTURE'
            };
        }
        if (typeof effect === 'string') {
            return {
                error: `Frame ${frameIndex + 1}, layer ${i + 1} ${effect}`,
                reasonCode: 'INVALID_LAYER_STRUCTURE'
            };
        }
        let blendMode = 'source-over';
        if (rawLayer.blendMode === 'source-over' || rawLayer.blendMode === 'multiply' || rawLayer.blendMode === 'screen' || rawLayer.blendMode === 'overlay' || rawLayer.blendMode === 'color-dodge' || rawLayer.blendMode === 'source-atop') {
            blendMode = rawLayer.blendMode;
        }
        layers.push({
            id: rawLayer.id,
            name: rawLayer.name,
            visible: rawLayer.visible,
            locked: rawLayer.locked,
            opacity: rawLayer.opacity,
            blendMode,
            pngBase64: typeof rawLayer.pngBase64 === 'string' ? rawLayer.pngBase64 : undefined,
            tag: typeof rawLayer.tag === 'string' ? rawLayer.tag : undefined,
            effect,
            research
        });
    }
    return {
        frame: {
            id: input.id,
            durationMs: input.durationMs,
            layers
        },
        exceedsEnvelope: frameExceedsEnvelope
    };
}
function migrateProjectPayload(raw) {
    const migrated = {
        ...raw
    };
    // 1. Backfill customRamps
    if (!Array.isArray(migrated.customRamps)) {
        migrated.customRamps = [];
    }
    // 2. Backfill clips
    if (!Array.isArray(migrated.clips)) {
        migrated.clips = [];
    }
    // 3. Backfill loopMode
    if (typeof migrated.loopMode !== 'string' || !LOOP_MODES.has(migrated.loopMode)) {
        migrated.loopMode = 'repeat';
    }
    // 4. Backfill onionSkin
    if (!isPlainObject(migrated.onionSkin)) {
        migrated.onionSkin = {
            enabled: false,
            prevFrames: 1,
            nextFrames: 1,
            opacity: 0.35,
            prevColor: '#7fae6b',
            nextColor: '#c792df'
        };
    }
    // 5. Backfill frame & layer properties
    if (Array.isArray(migrated.frames)) {
        migrated.frames = migrated.frames.map((f)=>{
            if (!isPlainObject(f)) return f;
            const frameObj = {
                ...f
            };
            if (frameObj.durationMs === undefined) {
                frameObj.durationMs = 100;
            }
            if (Array.isArray(frameObj.layers)) {
                frameObj.layers = frameObj.layers.map((l)=>{
                    if (!isPlainObject(l)) return l;
                    const layerObj = {
                        ...l
                    };
                    if (layerObj.visible === undefined) layerObj.visible = true;
                    if (layerObj.locked === undefined) layerObj.locked = false;
                    if (layerObj.opacity === undefined) layerObj.opacity = 1.0;
                    if (layerObj.blendMode === undefined) layerObj.blendMode = 'source-over';
                    return layerObj;
                });
            }
            return frameObj;
        });
    }
    // Upgrade version tag
    migrated.version = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_VERSION"];
    return migrated;
}
/**
 * Module-private core validator operating on already-sanitized project payloads.
 * Callers must route untrusted inputs through public entry points validateProjectWithPolicy
 * or validateProjectJsonWithPolicy.
 */ function validateSanitizedProjectCore(cleanInput, options) {
    if (!isPlainObject(cleanInput)) {
        return {
            ok: false,
            error: 'That file does not look like a PixiBun project.',
            reasonCode: 'INVALID_ROOT_TYPE'
        };
    }
    const isStrict = options.envelopeMode === 'strict';
    if (cleanInput.format !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_ID"]) {
        return {
            ok: false,
            error: 'This file was not saved by PixiBun, so it cannot be opened here.',
            reasonCode: 'INVALID_FORMAT_ID'
        };
    }
    // Validate the original tag before migration. Only a missing tag is treated
    // as legacy; strings, fractions, negatives, and zero must not be normalized
    // into a valid current project.
    if (cleanInput.version !== undefined && !isIntegerInRange(cleanInput.version, 1, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_VERSION"])) {
        if (typeof cleanInput.version === 'number' && cleanInput.version > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_VERSION"]) {
            return {
                ok: false,
                error: `This project was saved in format v${cleanInput.version}, but this version of PixiBun only supports up to v${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_VERSION"]}. Please update PixiBun to open this file.`,
                reasonCode: 'UNSUPPORTED_FUTURE_VERSION',
                details: `Saved version ${cleanInput.version} exceeds max supported version ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_VERSION"]}`,
                foundVersion: cleanInput.version
            };
        }
        return {
            ok: false,
            error: `This project uses an invalid format version (${String(cleanInput.version)}).`,
            reasonCode: 'INVALID_VERSION_FORMAT'
        };
    }
    // Backward-compatibility: migrate legacy/unversioned payloads before validation
    const normalized = migrateProjectPayload(cleanInput);
    if (!isIntegerInRange(normalized.version, 1, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_VERSION"])) {
        return {
            ok: false,
            error: `This project uses an invalid format version (${String(cleanInput.version)}).`,
            reasonCode: 'INVALID_VERSION_FORMAT'
        };
    }
    if (typeof normalized.name !== 'string' || normalized.name.trim().length === 0) {
        return {
            ok: false,
            error: 'The project inside this file has no usable name.',
            reasonCode: 'INVALID_NAME'
        };
    }
    if (normalized.name.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_PROJECT_NAME_LENGTH) {
        return {
            ok: false,
            error: `The project name exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_PROJECT_NAME_LENGTH} character limit.`,
            reasonCode: 'INVALID_NAME'
        };
    }
    const validatedName = normalized.name;
    if (!isIntegerInRange(normalized.width, 1, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION) || !isIntegerInRange(normalized.height, 1, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_DIMENSION)) {
        return {
            ok: false,
            error: 'The project canvas dimensions are out of range.',
            reasonCode: 'INVALID_DIMENSIONS'
        };
    }
    const validatedWidth = normalized.width;
    const validatedHeight = normalized.height;
    if (!isIntegerInRange(normalized.fps, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].fpsMin, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].fpsMax)) {
        return {
            ok: false,
            error: 'The project playback speed is out of range.',
            reasonCode: 'INVALID_FPS'
        };
    }
    const validatedFps = normalized.fps;
    let validatedLoopMode = 'repeat';
    if (normalized.loopMode === 'repeat' || normalized.loopMode === 'ping-pong' || normalized.loopMode === 'once') {
        validatedLoopMode = normalized.loopMode;
    } else {
        return {
            ok: false,
            error: 'The project loop mode is not recognized.',
            reasonCode: 'INVALID_LOOP_MODE'
        };
    }
    if (!isPlainObject(normalized.onionSkin)) {
        return {
            ok: false,
            error: 'The onion skin settings are missing or malformed.',
            reasonCode: 'INVALID_ONION_SKIN'
        };
    }
    const skin = normalized.onionSkin;
    if (typeof skin.enabled !== 'boolean' || !isIntegerInRange(skin.prevFrames, 0, 5) || !isIntegerInRange(skin.nextFrames, 0, 5) || !isUnitInterval(skin.opacity) || typeof skin.prevColor !== 'string' || typeof skin.nextColor !== 'string') {
        return {
            ok: false,
            error: 'The onion skin settings are corrupted.',
            reasonCode: 'INVALID_ONION_SKIN'
        };
    }
    const validatedOnionSkin = {
        enabled: skin.enabled,
        prevFrames: skin.prevFrames,
        nextFrames: skin.nextFrames,
        opacity: skin.opacity,
        prevColor: skin.prevColor,
        nextColor: skin.nextColor
    };
    if (!Array.isArray(normalized.palettes) || normalized.palettes.length === 0) {
        return {
            ok: false,
            error: 'The file carries no color palettes.',
            reasonCode: 'INVALID_PALETTES'
        };
    }
    if (normalized.palettes.length > 50) {
        return {
            ok: false,
            error: 'The project exceeds the 50 color palette limit.',
            reasonCode: 'INVALID_PALETTES'
        };
    }
    const validatedPalettes = [];
    const paletteIds = new Set();
    for(let i = 0; i < normalized.palettes.length; i++){
        const pal = normalized.palettes[i];
        if (!isPlainObject(pal) || typeof pal.id !== 'string' || typeof pal.name !== 'string' || !Array.isArray(pal.colors)) {
            return {
                ok: false,
                error: `Palette ${i + 1} is malformed.`,
                reasonCode: 'INVALID_PALETTES'
            };
        }
        if (paletteIds.has(pal.id)) {
            return {
                ok: false,
                error: `Palette ${i + 1} has duplicate identifier (${pal.id}).`,
                reasonCode: 'DUPLICATE_PALETTE_ID'
            };
        }
        if (pal.id.length === 0 || pal.id.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_IDENTIFIER_LENGTH || pal.name.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_IDENTIFIER_LENGTH || pal.author !== undefined && (typeof pal.author !== 'string' || pal.author.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_IDENTIFIER_LENGTH)) {
            return {
                ok: false,
                error: `Palette ${i + 1} is malformed.`,
                reasonCode: 'INVALID_PALETTES'
            };
        }
        if (pal.colors.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_COLORS_PER_PALETTE) {
            return {
                ok: false,
                error: isStrict ? `Palette ${i + 1} exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_COLORS_PER_PALETTE} color limit.` : `Palette ${i + 1} exceeds recovery color inspection ceiling (${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_COLORS_PER_PALETTE} colors).`,
                reasonCode: isStrict ? 'INVALID_PALETTES' : 'INSPECTION_CEILING_EXCEEDED'
            };
        }
        if (!pal.colors.every(isHexColor)) {
            return {
                ok: false,
                error: `Palette "${pal.name}" holds colors PixiBun cannot read.`,
                reasonCode: 'INVALID_PALETTES'
            };
        }
        let cycleTracks;
        if (pal.cycleTracks !== undefined) {
            if (!Array.isArray(pal.cycleTracks) || pal.cycleTracks.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_CYCLE_TRACKS"]) {
                return {
                    ok: false,
                    error: `Palette ${i + 1} has malformed cycle tracks.`,
                    reasonCode: 'INVALID_PALETTES'
                };
            }
            cycleTracks = [];
            const trackIds = new Set();
            for (const track of pal.cycleTracks){
                if (!isPlainObject(track) || typeof track.id !== 'string' || track.id.length === 0 || track.id.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_IDENTIFIER_LENGTH || trackIds.has(track.id) || track.name !== undefined && (typeof track.name !== 'string' || track.name.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_IDENTIFIER_LENGTH) || typeof track.low !== 'number' || typeof track.high !== 'number' || !Number.isInteger(track.low) || !Number.isInteger(track.high) || track.low < 0 || track.high < track.low || track.high >= pal.colors.length || typeof track.rate !== 'number' || !Number.isFinite(track.rate) || track.rate < 0 || track.rate > 1000 || track.direction !== 'forward' && track.direction !== 'reverse' && track.direction !== 'ping-pong' || typeof track.blendShift !== 'boolean' || typeof track.enabled !== 'boolean') {
                    return {
                        ok: false,
                        error: `Palette ${i + 1} has malformed cycle tracks.`,
                        reasonCode: 'INVALID_PALETTES'
                    };
                }
                trackIds.add(track.id);
                cycleTracks.push({
                    id: track.id,
                    name: typeof track.name === 'string' ? track.name : undefined,
                    low: track.low,
                    high: track.high,
                    rate: track.rate,
                    direction: track.direction,
                    blendShift: track.blendShift,
                    enabled: track.enabled
                });
            }
        }
        const semantics = pal.semantics === undefined ? undefined : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parsePaletteSemantics"])(pal.semantics, pal.colors.length);
        if (semantics === null) return {
            ok: false,
            error: `Palette ${i + 1} has invalid roles or index bindings.`,
            reasonCode: 'INVALID_PALETTES'
        };
        paletteIds.add(pal.id);
        validatedPalettes.push({
            id: pal.id,
            name: pal.name,
            author: typeof pal.author === 'string' ? pal.author : undefined,
            colors: pal.colors.slice(),
            cycleTracks,
            ...semantics ? {
                semantics
            } : {}
        });
    }
    if (typeof normalized.currentPaletteId !== 'string') {
        return {
            ok: false,
            error: 'The file does not say which palette is active.',
            reasonCode: 'INVALID_ACTIVE_PALETTE'
        };
    }
    if (!paletteIds.has(normalized.currentPaletteId)) {
        return {
            ok: false,
            error: 'The active palette reference does not match any palette in the project.',
            reasonCode: 'INVALID_ACTIVE_PALETTE'
        };
    }
    const validatedCurrentPaletteId = normalized.currentPaletteId;
    if (!Array.isArray(normalized.customRamps)) {
        return {
            ok: false,
            error: 'The custom ramp list is malformed.',
            reasonCode: 'INVALID_CUSTOM_RAMPS'
        };
    }
    if (normalized.customRamps.length > 100 || !normalized.customRamps.every((r)=>isPlainObject(r) && isHexColor(r.baseColor) && Array.isArray(r.shades) && r.shades.length <= 256 && r.shades.every(isHexColor))) {
        return {
            ok: false,
            error: 'The custom ramp entries are malformed or too large.',
            reasonCode: 'INVALID_CUSTOM_RAMPS'
        };
    }
    const validatedCustomRamps = normalized.customRamps.map((r)=>({
            baseColor: r.baseColor,
            shades: r.shades.slice()
        }));
    if (!Array.isArray(normalized.clips)) {
        return {
            ok: false,
            error: 'The animation clip list is malformed.',
            reasonCode: 'INVALID_CLIPS'
        };
    }
    if (normalized.clips.length > 100) {
        return {
            ok: false,
            error: 'The project exceeds the 100 animation clip limit.',
            reasonCode: 'INVALID_CLIPS'
        };
    }
    const clipIds = new Set();
    const validatedClips = [];
    for(let i = 0; i < normalized.clips.length; i++){
        const clip = normalized.clips[i];
        if (!isPlainObject(clip) || typeof clip.id !== 'string' || typeof clip.name !== 'string' || !isIntegerInRange(clip.startFrame, 0, Number.MAX_SAFE_INTEGER) || !isIntegerInRange(clip.endFrame, 0, Number.MAX_SAFE_INTEGER)) {
            return {
                ok: false,
                error: `Animation clip ${i + 1} is malformed.`,
                reasonCode: 'INVALID_CLIPS'
            };
        }
        if (clip.id.length === 0 || clip.id.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_IDENTIFIER_LENGTH || clip.name.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_IDENTIFIER_LENGTH) {
            return {
                ok: false,
                error: `Animation clip ${i + 1} has an invalid or oversized identifier/name.`,
                reasonCode: 'INVALID_CLIPS'
            };
        }
        if (clipIds.has(clip.id)) {
            return {
                ok: false,
                error: `Animation clip ${i + 1} has duplicate identifier (${clip.id}).`,
                reasonCode: 'DUPLICATE_CLIP_ID'
            };
        }
        clipIds.add(clip.id);
        if (clip.startFrame > clip.endFrame) {
            return {
                ok: false,
                error: `Animation clip ${i + 1} has inverted frame range (startFrame > endFrame).`,
                reasonCode: 'MALFORMED_CLIP_RANGE'
            };
        }
        const start = typeof clip.startFrame === 'number' ? clip.startFrame : typeof clip.fromFrame === 'number' ? clip.fromFrame : 0;
        const end = typeof clip.endFrame === 'number' ? clip.endFrame : typeof clip.toFrame === 'number' ? clip.toFrame : start;
        const color = typeof clip.color === 'string' && isHexColor(clip.color) ? clip.color : '#F0BE7C';
        let loopMode = 'forward';
        if (clip.loopMode === 'reverse' || clip.loopMode === 'ping-pong') {
            loopMode = clip.loopMode;
        }
        const review = clip.review === undefined ? undefined : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAnimationReview"])(clip.review);
        if (review === null) return {
            ok: false,
            error: `Animation clip ${i + 1} has invalid review regions or exceptions.`,
            reasonCode: 'INVALID_CLIPS'
        };
        validatedClips.push({
            id: clip.id,
            name: clip.name,
            startFrame: start,
            endFrame: end,
            fromFrame: start,
            toFrame: end,
            color,
            loopMode,
            ...review ? {
                review
            } : {}
        });
    }
    if (!Array.isArray(normalized.frames) || normalized.frames.length === 0) {
        return {
            ok: false,
            error: 'This project has no animation frames to open.',
            reasonCode: 'INVALID_FRAME_STRUCTURE'
        };
    }
    let framesExceedEnvelope = false;
    if (isStrict) {
        if (normalized.frames.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES) {
            return {
                ok: false,
                error: `The project exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES} animation frame limit.`,
                reasonCode: 'ENVELOPE_MAX_FRAMES'
            };
        }
    } else {
        // collect-recoverable mode: enforce recovery frame inspection ceiling
        if (normalized.frames.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_FRAMES) {
            return {
                ok: false,
                error: `Project frame count (${normalized.frames.length}) exceeds recovery frame inspection ceiling (${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_FRAMES}).`,
                reasonCode: 'INSPECTION_CEILING_EXCEEDED'
            };
        }
        if (normalized.frames.length > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES) {
            framesExceedEnvelope = true;
        }
    }
    const frames = [];
    const frameIds = new Set();
    const layerIds = new Set();
    let totalLayerCount = 0;
    let affectedFramesCount = 0;
    let maxLayersInAnyFrame = 0;
    const frameViolationDetails = [];
    for(let i = 0; i < normalized.frames.length; i++){
        const frameResult = validateFrame(normalized.frames[i], i, options.envelopeMode);
        if (frameResult.error) {
            return {
                ok: false,
                error: frameResult.error,
                reasonCode: frameResult.reasonCode ?? 'INVALID_FRAME_STRUCTURE'
            };
        }
        const frame = frameResult.frame;
        if (frameIds.has(frame.id)) {
            return {
                ok: false,
                error: 'Duplicate frame identifier.',
                reasonCode: 'DUPLICATE_FRAME_ID'
            };
        }
        frameIds.add(frame.id);
        for(let l = 0; l < frame.layers.length; l++){
            const layer = frame.layers[l];
            if (layerIds.has(layer.id)) {
                return {
                    ok: false,
                    error: 'Duplicate layer identifier.',
                    reasonCode: 'DUPLICATE_LAYER_ID'
                };
            }
            layerIds.add(layer.id);
        }
        if (frameResult.exceedsEnvelope) {
            affectedFramesCount += 1;
            if (frame.layers.length > maxLayersInAnyFrame) {
                maxLayersInAnyFrame = frame.layers.length;
            }
            if (frameViolationDetails.length < __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_RECORDED_FRAME_VIOLATION_DETAILS) {
                frameViolationDetails.push({
                    frameIndex: i,
                    actualLayers: frame.layers.length,
                    allowedLayers: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS
                });
            }
        }
        totalLayerCount += frame.layers.length;
        if (!isStrict && totalLayerCount > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_TOTAL_LAYERS) {
            return {
                ok: false,
                error: `Project total layer count (${totalLayerCount}) exceeds recovery total layer inspection ceiling (${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RECOVERY_INSPECTION_CEILINGS"].MAX_INSPECTABLE_TOTAL_LAYERS}).`,
                reasonCode: 'INSPECTION_CEILING_EXCEEDED'
            };
        }
        frames.push(frame);
    }
    for(let i = 0; i < validatedClips.length; i++){
        const clip = validatedClips[i];
        if (clip.startFrame < 0 || clip.startFrame > clip.endFrame || clip.endFrame >= frames.length) {
            return {
                ok: false,
                error: `Animation clip ${i + 1} ("${clip.name}") has frame range (${clip.startFrame}..${clip.endFrame}) outside project frame count (${frames.length}).`,
                reasonCode: 'MALFORMED_CLIP_RANGE'
            };
        }
    }
    // Aggregate resource calculation with overflow-safe arithmetic
    const pxPerFrame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeMultiply"])(validatedWidth, validatedHeight);
    if (pxPerFrame === null) {
        return {
            ok: false,
            error: 'The project canvas dimensions are out of range.',
            reasonCode: 'ARITHMETIC_OVERFLOW'
        };
    }
    const materializableRasterPixels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeMultiply"])(totalLayerCount, pxPerFrame);
    if (materializableRasterPixels === null) {
        return {
            ok: false,
            error: 'Project aggregate pixel footprint causes arithmetic overflow.',
            reasonCode: 'ARITHMETIC_OVERFLOW'
        };
    }
    const baseRawRgbaBytes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeMultiply"])(materializableRasterPixels, 4);
    if (baseRawRgbaBytes === null) {
        return {
            ok: false,
            error: 'Project aggregate memory footprint causes arithmetic overflow.',
            reasonCode: 'ARITHMETIC_OVERFLOW'
        };
    }
    if (isStrict) {
        const budgetResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$resourceBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProjectResourceBudget"])(validatedWidth, validatedHeight, frames);
        if (!budgetResult.ok) {
            const isTotalLayers = totalLayerCount > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_TOTAL_LAYERS;
            return {
                ok: false,
                error: budgetResult.error,
                reasonCode: isTotalLayers ? 'ENVELOPE_MAX_TOTAL_LAYERS' : 'ENVELOPE_MAX_MEGAPIXELS'
            };
        }
    }
    if (!isIntegerInRange(normalized.createdAt, 0, Number.MAX_SAFE_INTEGER) || !isIntegerInRange(normalized.updatedAt, 0, Number.MAX_SAFE_INTEGER)) {
        return {
            ok: false,
            error: 'The project timestamps are missing or corrupted.',
            reasonCode: 'INVALID_TIMESTAMPS'
        };
    }
    const validatedCreatedAt = normalized.createdAt;
    const validatedUpdatedAt = normalized.updatedAt;
    // Fully typed construction of ProjectFile without any 'as ProjectFile' assertions
    const validatedProject = {
        format: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_ID"],
        version: normalized.version,
        name: validatedName,
        width: validatedWidth,
        height: validatedHeight,
        fps: validatedFps,
        loopMode: validatedLoopMode,
        onionSkin: validatedOnionSkin,
        palettes: validatedPalettes,
        currentPaletteId: validatedCurrentPaletteId,
        customRamps: validatedCustomRamps,
        clips: validatedClips,
        frames,
        createdAt: validatedCreatedAt,
        updatedAt: validatedUpdatedAt
    };
    // Summarized violation collection in canonical deterministic order:
    // 1. ENVELOPE_MAX_FRAMES
    // 2. ENVELOPE_MAX_LAYERS_PER_FRAME
    // 3. ENVELOPE_MAX_TOTAL_LAYERS
    // 4. ENVELOPE_MAX_MEGAPIXELS
    const violations = [];
    const reasonCodes = [];
    if (!isStrict) {
        if (framesExceedEnvelope) {
            violations.push({
                code: 'ENVELOPE_MAX_FRAMES',
                message: `Project exceeds the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES} animation frame limit (${normalized.frames.length} frames).`,
                actual: normalized.frames.length,
                allowed: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_FRAMES
            });
            reasonCodes.push('ENVELOPE_MAX_FRAMES');
        }
        if (affectedFramesCount > 0) {
            violations.push({
                code: 'ENVELOPE_MAX_LAYERS_PER_FRAME',
                message: `${affectedFramesCount} frame(s) exceed the ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS} layer ceiling (peak: ${maxLayersInAnyFrame} layers).`,
                actual: maxLayersInAnyFrame,
                allowed: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_CANVAS_LAYERS,
                affectedFramesCount,
                detailsTruncated: affectedFramesCount > frameViolationDetails.length,
                frameDetails: frameViolationDetails
            });
            reasonCodes.push('ENVELOPE_MAX_LAYERS_PER_FRAME');
        }
        if (totalLayerCount > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_TOTAL_LAYERS) {
            violations.push({
                code: 'ENVELOPE_MAX_TOTAL_LAYERS',
                message: `Project exceeds total layer limit (${totalLayerCount.toLocaleString()} layers across all frames; maximum allowed is ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_TOTAL_LAYERS.toLocaleString()}).`,
                actual: totalLayerCount,
                allowed: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_TOTAL_LAYERS
            });
            reasonCodes.push('ENVELOPE_MAX_TOTAL_LAYERS');
        }
        if (materializableRasterPixels > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_AGGREGATE_PIXELS) {
            const mpx = (materializableRasterPixels / 1_000_000).toFixed(1);
            const maxMpx = (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_AGGREGATE_PIXELS / 1_000_000).toFixed(1);
            const mib = Math.round(baseRawRgbaBytes / (1024 * 1024));
            violations.push({
                code: 'ENVELOPE_MAX_MEGAPIXELS',
                message: `Project exceeds conservative resource complexity ceiling (${mpx} MP worst-case footprint, ~${mib} MiB base RGBA; maximum allowed is ${maxMpx} MP).`,
                actual: materializableRasterPixels,
                allowed: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_ENVELOPE"].MAX_PROJECT_AGGREGATE_PIXELS
            });
            reasonCodes.push('ENVELOPE_MAX_MEGAPIXELS');
        }
    }
    return {
        ok: true,
        value: validatedProject,
        violations,
        reasonCodes
    };
}
function validateProjectWithPolicy(input, options) {
    if (!isPlainObject(input)) {
        return {
            ok: false,
            error: 'That file does not look like a PixiBun project.',
            reasonCode: 'INVALID_ROOT_TYPE'
        };
    }
    const clean = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].sanitizeObject(input);
    return validateSanitizedProjectCore(clean, options);
}
function validateProjectJsonWithPolicy(rawJson, validationOptions, safeJsonOptions) {
    if (typeof rawJson !== 'string') {
        return {
            ok: false,
            error: 'That file does not look like a PixiBun project.',
            reasonCode: 'INVALID_ROOT_TYPE'
        };
    }
    const parsed = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].parse(rawJson, safeJsonOptions);
    if (!isPlainObject(parsed)) {
        return {
            ok: false,
            error: 'That file does not look like a PixiBun project.',
            reasonCode: 'INVALID_ROOT_TYPE'
        };
    }
    return validateSanitizedProjectCore(parsed, validationOptions);
}
function validateProjectFile(input) {
    const result = validateProjectWithPolicy(input, {
        envelopeMode: 'strict'
    });
    if (!result.ok) {
        return {
            ok: false,
            error: result.error
        };
    }
    return {
        ok: true,
        value: result.value
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/recovery/recoveryLimits.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * recoveryLimits.ts
 *
 * Bounded Recovery Inspection Ceilings for PixiBun Atelier.
 *
 * These limits are bounded recovery inspection ceilings designed specifically for
 * Restricted Recovery Mode and the recovery metadata classifier. They are distinct
 * from normal WORKSPACE_ENVELOPE boundaries (which define active editing capacity)
 * Some identifier and palette color ceilings are also applied by normal project
 * validation so newly admitted documents stay inside the recovery inspection bound.
 *
 * Note on Memory & Allocation:
 * classifyProjectMetadata operates on project metadata without decoding raster layers,
 * canvases, or Base64 images, but it is not non-allocating. JSON.parse necessarily
 * materializes the JSON document into JavaScript engine objects, and SafeJson
 * sanitization creates a sanitized copy while enforcing prototype-pollution defense.
 * The MAX_METADATA_NODES ceiling bounds the sanitization traversal to prevent CPU
 * exhaustion or memory denial-of-service from pathological metadata structures.
 */ __turbopack_context__.s([
    "RECOVERY_BACKUP_LIMITS",
    ()=>RECOVERY_BACKUP_LIMITS,
    "RECOVERY_INSPECTION_CEILINGS",
    ()=>RECOVERY_INSPECTION_CEILINGS
]);
const RECOVERY_INSPECTION_CEILINGS = {
    /** Maximum number of animation frames inspected during recovery (normal envelope is 500). */ MAX_INSPECTABLE_FRAMES: 2000,
    /** Maximum layers per frame inspected during recovery (normal envelope is 100). */ MAX_INSPECTABLE_LAYERS_PER_FRAME: 200,
    /** Maximum total layers across all frames inspected during recovery (normal envelope is 2,000). */ MAX_INSPECTABLE_TOTAL_LAYERS: 5000,
    /** Maximum animation clips inspected. */ MAX_INSPECTABLE_CLIPS: 100,
    /** Maximum color palettes inspected. */ MAX_INSPECTABLE_PALETTES: 50,
    /** Maximum colors per palette inspected in recovery mode. */ MAX_INSPECTABLE_COLORS_PER_PALETTE: 512,
    /** Maximum custom color ramps inspected. */ MAX_INSPECTABLE_CUSTOM_RAMPS: 100,
    /** Maximum shades per custom ramp inspected. */ MAX_INSPECTABLE_SHADES_PER_RAMP: 256,
    /** Maximum parameters per smart effect recipe inspected. */ MAX_INSPECTABLE_EFFECT_PARAMS: 64,
    /** Maximum items in a list-type effect parameter. */ MAX_INSPECTABLE_EFFECT_LIST_ITEMS: 256,
    /** Maximum metadata nodes (root + property values + array elements) traversed during SafeJson sanitization. */ MAX_METADATA_NODES: 50_000,
    /** Maximum individual frame violation details recorded for ENVELOPE_MAX_LAYERS_PER_FRAME. */ MAX_RECORDED_FRAME_VIOLATION_DETAILS: 20,
    /** Maximum stored layer blobs inspected for a single project during recovery. */ MAX_INSPECTABLE_STORED_BLOBS: 10_000,
    /** Batch size for paginated resumable layer blob scanning. */ BLOB_SCAN_BATCH_SIZE: 25,
    /** Maximum orphan details retained in diagnostic summary. */ MAX_RECORDED_ORPHAN_DETAILS: 20,
    /** Maximum invalid layer details retained in diagnostic summary. */ MAX_RECORDED_INVALID_LAYERS: 100,
    /** Maximum length of reasonCodes array accepted by the recovery ledger. */ MAX_LEDGER_INPUT_REASON_CODES: 256,
    /** Recovery string length limits. */ MAX_PROJECT_NAME_LENGTH: 256,
    MAX_IDENTIFIER_LENGTH: 128,
    MAX_TAG_LENGTH: 128,
    MAX_EFFECT_RATIONALE_LENGTH: 1000,
    /** Maximum byte size for a single stored layer blob during recovery (80 MiB). */ MAX_SINGLE_BLOB_BYTES: 80 * 1024 * 1024,
    /** Maximum aggregate byte size for all stored layer blobs in a project (256 MiB). */ MAX_AGGREGATE_BLOB_BYTES: 256 * 1024 * 1024,
    /** Timeout in milliseconds for kept-alive transaction blob operations (30,000 ms). */ TRANSACTION_DIGEST_TIMEOUT_MS: 30_000,
    /** Maximum destination ID collision retry attempts (3). */ MAX_ID_GENERATION_RETRIES: 3
};
const RECOVERY_BACKUP_LIMITS = {
    /** Maximum bytes for the generated recovery manifest JSON (16 MiB). Derived from 10,000 blobs and worst-case escaping. */ MAX_MANIFEST_BYTES: 16 * 1024 * 1024,
    /** Maximum bytes for in-memory Blob fallback archive accumulation (250 MB). */ MAX_FALLBACK_BLOB_BYTES: 250 * 1024 * 1024,
    /** Maximum chunk size for incremental UTF-8 string streaming (64 KiB). */ MAX_UTF8_STREAM_CHUNK_BYTES: 65536,
    /** Maximum length for a stored blob MIME type in manifest. */ MAX_MIME_TYPE_LENGTH: 128
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/research/recipes.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parseResearchRecipe",
    ()=>parseResearchRecipe,
    "parseResearchSettings",
    ()=>parseResearchSettings,
    "researchBytes",
    ()=>researchBytes
]);
const object = (v)=>{
    if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('Research recipe must be an object.');
    return v;
};
const text = (v, max)=>{
    if (typeof v !== 'string' || !v.trim() || v.length > max) throw new Error('Invalid research recipe label.');
    return v;
};
const number = (v, min, max, integer = true)=>{
    if (typeof v !== 'number' || !Number.isFinite(v) || v < min || v > max || integer && !Number.isInteger(v)) throw new Error('Invalid research recipe number.');
    return v;
};
const choice = (v, allowed)=>{
    if (!allowed.includes(v)) throw new Error('Unknown research recipe option.');
    return v;
};
const array = (v, max)=>{
    if (!Array.isArray(v) || v.length > max) throw new Error('Research recipe list exceeds its limit.');
    return v;
};
const material = (v)=>choice(v, [
        'cloth',
        'metal',
        'skin',
        'emissive'
    ]);
function region(v, width, height) {
    const r = object(v), x = number(r.x, 0, width - 1), y = number(r.y, 0, height - 1);
    return {
        name: text(r.name, 64),
        x,
        y,
        w: number(r.w, 1, width - x),
        h: number(r.h, 1, height - y)
    };
}
function parseResearchSettings(v, width, height) {
    const s = object(v);
    number(width, 1, 256);
    number(height, 1, 256);
    if (s.kind === 'pixelize') {
        if (s.preserveEdges !== undefined && typeof s.preserveEdges !== 'boolean') throw new Error('Outline protection must be a boolean.');
        const colors = array(s.colors, 256).map((c)=>{
            if (typeof c !== 'string' || !/^#[a-f\d]{6}$/i.test(c)) throw new Error('Invalid allowed palette color.');
            return c.toLowerCase();
        });
        // Empty colors means no palette remapping. Existing nonempty recipes retain their restriction.
        return {
            kind: 'pixelize',
            block: number(s.block, 1, 16),
            candidate: choice(s.candidate, [
                'average',
                'contrast',
                'nearest'
            ]),
            colors,
            protected: array(s.protected, 16).map((r)=>region(r, width, height)),
            ...s.preserveEdges === undefined ? {} : {
                preserveEdges: s.preserveEdges
            }
        };
    }
    if (s.kind === 'light') return {
        kind: 'light',
        azimuth: number(s.azimuth, 0, 359),
        elevation: number(s.elevation, 5, 90),
        ambient: number(s.ambient, 0, 1, false),
        intensity: number(s.intensity, 0, 2, false),
        height: number(s.height, 0, 16),
        material: material(s.material),
        regions: array(s.regions, 16).map((v)=>({
                ...region(v, width, height),
                material: material(object(v).material)
            })),
        ...s.shape === undefined ? {} : {
            shape: choice(s.shape, [
                'flat',
                'rounded'
            ])
        }
    };
    if (s.kind === 'scene') {
        const tileSize = number(s.tileSize, 1, 64);
        if (width % tileSize || height % tileSize || width * height / tileSize ** 2 > 16) throw new Error('Scene preview needs an evenly divided atlas with at most 16 tiles.');
        const tiles = array(s.tiles, 16).map((v)=>{
            const t = object(v);
            if (typeof t.walkable !== 'boolean') throw new Error('Tile walkability must be explicit.');
            return {
                north: text(t.north, 16),
                east: text(t.east, 16),
                south: text(t.south, 16),
                west: text(t.west, 16),
                walkable: t.walkable
            };
        });
        if (tiles.length !== width * height / tileSize ** 2) throw new Error('Every atlas tile needs an edge rule.');
        const pins = array(s.pins, 16).map((v)=>{
            const p = object(v);
            return {
                cell: number(p.cell, 0, tiles.length - 1),
                tile: number(p.tile, 0, tiles.length - 1)
            };
        });
        if (new Set(pins.map((p)=>p.cell)).size !== pins.length) throw new Error('A scene cell has contradictory pins.');
        return {
            kind: 'scene',
            tileSize,
            seed: number(s.seed, 0, 0xffffffff),
            path: choice(s.path, [
                'none',
                'horizontal',
                'vertical'
            ]),
            tiles,
            pins
        };
    }
    throw new Error('Unknown research workflow.');
}
function parseResearchRecipe(v) {
    if (v === undefined) return undefined;
    const r = object(v);
    if (r.version !== 1) throw new Error('Unsupported research recipe version.');
    const width = number(r.width, 1, 256), height = number(r.height, 1, 256), s = object(r.source);
    const hash = (v)=>{
        if (typeof v !== 'string' || !/^[a-f\d]{64}$/.test(v)) throw new Error('Invalid research source fingerprint.');
        return v;
    };
    const source = {
        frameId: text(s.frameId, 128),
        layerId: text(s.layerId, 128),
        sha256: hash(s.sha256)
    };
    if (s.normalLayerId !== undefined || s.normalSha256 !== undefined) {
        source.normalLayerId = text(s.normalLayerId, 128);
        source.normalSha256 = hash(s.normalSha256);
    }
    return {
        version: 1,
        name: text(r.name, 64),
        width,
        height,
        settings: parseResearchSettings(r.settings, width, height),
        source
    };
}
const researchBytes = (recipe)=>recipe ? 256 + JSON.stringify(recipe).length * 2 : 0;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** Estimated application-owned CPU memory. Excludes browser/GPU/codec internals. */ __turbopack_context__.s([
    "COMBINED_MEMORY_LIMIT_BYTES",
    ()=>COMBINED_MEMORY_LIMIT_BYTES,
    "assertMemoryAvailable",
    ()=>assertMemoryAvailable,
    "getMemoryBudgetUsage",
    ()=>getMemoryBudgetUsage,
    "registerMemoryUsage",
    ()=>registerMemoryUsage,
    "reserveMemory",
    ()=>reserveMemory
]);
const COMBINED_MEMORY_LIMIT_BYTES = 512 * 1024 * 1024;
const providers = new Map();
let reservedBytes = 0;
function registerMemoryUsage(owner, read) {
    providers.set(owner, read);
}
function getMemoryBudgetUsage() {
    const retained = Object.fromEntries([
        ...providers
    ].map(([owner, read])=>[
            owner,
            read()
        ]));
    const totalBytes = Object.values(retained).reduce((a, b)=>a + b, 0) + reservedBytes;
    return {
        retained,
        reservedBytes,
        totalBytes,
        limitBytes: COMBINED_MEMORY_LIMIT_BYTES
    };
}
function assertMemoryAvailable(bytes, operation) {
    if (!Number.isSafeInteger(bytes) || bytes < 0 || getMemoryBudgetUsage().totalBytes + bytes > COMBINED_MEMORY_LIMIT_BYTES) {
        throw new RangeError(`${operation} exceeds the combined artwork memory budget. Try exporting fewer frames, using a smaller scale, or closing other exports before retrying.`);
    }
}
function reserveMemory(bytes, operation) {
    assertMemoryAvailable(bytes, operation);
    reservedBytes += bytes;
    let released = false;
    return ()=>{
        if (!released) {
            reservedBytes -= bytes;
            released = true;
        }
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/safety/safeJson.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * safeJson.ts
 *
 * Prototype-pollution immune JSON parsing and sanitization for PixiBun Atelier.
 *
 * Academic & Security References:
 * 1. Common Weakness Enumeration (CWE): CWE-1321
 *    "Improperly Controlled Modification of Dynamically-Determined Object Attributes ('Prototype Pollution')"
 * 2. Arteau, Olivier. "Prototype Pollution: The New Vulnerability Class in Node.js Applications."
 *    NorthSec Conference, 2018.
 */ /**
 * Computes the exact UTF-8 byte length of a string without allocating memory on the heap.
 * Handles single-byte ASCII, multi-byte code points, and UTF-16 surrogate pairs.
 */ __turbopack_context__.s([
    "SafeJson",
    ()=>SafeJson,
    "SafeJsonNestingDepthError",
    ()=>SafeJsonNestingDepthError,
    "SafeJsonOptionError",
    ()=>SafeJsonOptionError,
    "SafeJsonPayloadLimitError",
    ()=>SafeJsonPayloadLimitError,
    "SafeJsonSyntaxError",
    ()=>SafeJsonSyntaxError,
    "SafeJsonTraversalLimitError",
    ()=>SafeJsonTraversalLimitError,
    "getUtf8ByteLength",
    ()=>getUtf8ByteLength
]);
function getUtf8ByteLength(str) {
    let bytes = 0;
    const len = str.length;
    for(let i = 0; i < len; i++){
        const code = str.charCodeAt(i);
        if (code <= 0x7f) {
            bytes += 1;
        } else if (code <= 0x7ff) {
            bytes += 2;
        } else if (code >= 0xd800 && code <= 0xdbff) {
            // High surrogate: check if followed by low surrogate
            if (i + 1 < len) {
                const next = str.charCodeAt(i + 1);
                if (next >= 0xdc00 && next <= 0xdfff) {
                    bytes += 4;
                    i++;
                    continue;
                }
            }
            bytes += 3;
        } else {
            bytes += 3;
        }
    }
    return bytes;
}
class SafeJsonPayloadLimitError extends RangeError {
    code = 'SAFE_JSON_PAYLOAD_LIMIT';
    byteLength;
    maxBytes;
    constructor(byteLength, maxBytes){
        super(`[SafeJson] JSON payload size (${byteLength} bytes) exceeds maximum limit (${maxBytes} bytes)`);
        this.name = 'SafeJsonPayloadLimitError';
        this.byteLength = byteLength;
        this.maxBytes = maxBytes;
        Object.setPrototypeOf(this, SafeJsonPayloadLimitError.prototype);
    }
}
class SafeJsonNestingDepthError extends RangeError {
    code = 'SAFE_JSON_NESTING_DEPTH';
    depth;
    maxDepth;
    constructor(depth, maxDepth, detail){
        const msg = detail ? `[SafeJson] JSON nesting exceeded max recursion depth of ${maxDepth}` : `[SafeJson] JSON nesting exceeded max recursion depth`;
        super(msg);
        this.name = 'SafeJsonNestingDepthError';
        this.depth = depth;
        this.maxDepth = maxDepth;
        Object.setPrototypeOf(this, SafeJsonNestingDepthError.prototype);
    }
}
class SafeJsonTraversalLimitError extends RangeError {
    code = 'SAFE_JSON_TRAVERSAL_LIMIT';
    limit;
    observed;
    constructor(observed, limit){
        super(`[SafeJson] JSON metadata traversal exceeded ceiling (${observed} nodes visited; limit is ${limit})`);
        this.name = 'SafeJsonTraversalLimitError';
        this.limit = limit;
        this.observed = observed;
        Object.setPrototypeOf(this, SafeJsonTraversalLimitError.prototype);
    }
}
class SafeJsonOptionError extends RangeError {
    code = 'SAFE_JSON_OPTION_ERROR';
    constructor(message){
        super(`[SafeJson] ${message}`);
        this.name = 'SafeJsonOptionError';
        Object.setPrototypeOf(this, SafeJsonOptionError.prototype);
    }
}
function validatePositiveSafeInteger(name, value) {
    if (typeof value !== 'number' || !Number.isFinite(value) || !Number.isInteger(value) || value < 1 || value > Number.MAX_SAFE_INTEGER) {
        throw new SafeJsonOptionError(`Option "${name}" must be a positive safe integer (received: ${String(value)})`);
    }
    return value;
}
class SafeJsonSyntaxError extends SyntaxError {
    code = 'SAFE_JSON_SYNTAX_ERROR';
    constructor(message = '[SafeJson] Invalid JSON syntax'){
        super(message);
        this.name = 'SafeJsonSyntaxError';
        Object.setPrototypeOf(this, SafeJsonSyntaxError.prototype);
    }
}
class SafeJson {
    /**
   * Maximum allowed JSON payload size (50 MB).
   * Mitigates Denial-of-Service (DoS) and heap out-of-memory crashes on untrusted imports.
   */ static MAX_PAYLOAD_BYTES = 50 * 1024 * 1024;
    /**
   * Maximum recursion depth to prevent call-stack overflow attacks.
   */ static MAX_RECURSION_DEPTH = 32;
    /**
   * Parses untrusted JSON while stripping prototype-pollution keys (__proto__, constructor, prototype)
   * and enforcing recursion depth and optional traversal node limits.
   *
   * Note on Allocation:
   * JSON.parse necessarily performs initial memory allocation of the parsed AST in the JavaScript
   * engine heap. The optional maxTraversedNodes limit bounds the subsequent sanitization/copy pass,
   * guaranteeing that processing terminates immediately if the node count exceeds the ceiling.
   */ static parse(rawJson, optionsOrMaxDepth) {
        if (typeof rawJson !== 'string') {
            throw new TypeError('[SafeJson] Input must be a string');
        }
        let maxDepth = SafeJson.MAX_RECURSION_DEPTH;
        let maxTraversedNodes;
        if (typeof optionsOrMaxDepth === 'number') {
            maxDepth = validatePositiveSafeInteger('maxDepth', optionsOrMaxDepth);
        } else if (optionsOrMaxDepth !== undefined) {
            if (typeof optionsOrMaxDepth !== 'object' || optionsOrMaxDepth === null || Array.isArray(optionsOrMaxDepth)) {
                throw new SafeJsonOptionError('Parse options must be a plain object or number');
            }
            if (optionsOrMaxDepth.maxDepth !== undefined) {
                maxDepth = validatePositiveSafeInteger('maxDepth', optionsOrMaxDepth.maxDepth);
            }
            if (optionsOrMaxDepth.maxTraversedNodes !== undefined) {
                maxTraversedNodes = validatePositiveSafeInteger('maxTraversedNodes', optionsOrMaxDepth.maxTraversedNodes);
            }
        }
        const byteLength = getUtf8ByteLength(rawJson);
        if (byteLength > this.MAX_PAYLOAD_BYTES) {
            throw new SafeJsonPayloadLimitError(byteLength, this.MAX_PAYLOAD_BYTES);
        }
        // Reject nesting before JSON.parse's recursive reviver (or our sanitizer) runs.
        let depth = 0;
        let quoted = false;
        let escaped = false;
        for (const char of rawJson){
            if (quoted) {
                if (escaped) escaped = false;
                else if (char === '\\') escaped = true;
                else if (char === '"') quoted = false;
            } else if (char === '"') quoted = true;
            else if (char === '{' || char === '[') {
                if (++depth > maxDepth) throw new SafeJsonNestingDepthError(depth, maxDepth);
            } else if (char === '}' || char === ']') depth--;
        }
        let parsed;
        try {
            parsed = JSON.parse(rawJson);
        } catch (err) {
            if (err instanceof SyntaxError) {
                throw new SafeJsonSyntaxError('[SafeJson] Invalid JSON syntax');
            }
            throw err;
        }
        const traversalBudget = maxTraversedNodes !== undefined ? {
            count: 0,
            max: maxTraversedNodes
        } : undefined;
        return this.sanitizeObject(parsed, traversalBudget, 1, maxDepth);
    }
    /**
   * Recursively sanitizes an existing in-memory object by removing any prototype pollution keys.
   * Returns a standard plain object preserving Object.prototype methods.
   *
   * Node Traversal Counting Definition:
   * A node is defined as any value (object, array, or primitive) visited during traversal:
   * - The root value counts as node 1.
   * - Each array element counts as 1 node.
   * - Each object property value counts as 1 node.
   * If a traversalBudget is provided and budget.count exceeds budget.max, traversal aborts
   * immediately by throwing SafeJsonTraversalLimitError.
   */ static sanitizeObject(obj, traversalBudget, currentDepth = 1, maxDepth = SafeJson.MAX_RECURSION_DEPTH) {
        if (traversalBudget !== undefined) {
            traversalBudget.count += 1;
            if (traversalBudget.count > traversalBudget.max) {
                throw new SafeJsonTraversalLimitError(traversalBudget.count, traversalBudget.max);
            }
        }
        if (currentDepth > maxDepth) {
            throw new SafeJsonNestingDepthError(currentDepth, maxDepth, 'with-detail');
        }
        if (obj === null || typeof obj !== 'object') {
            return obj;
        }
        if (Array.isArray(obj)) {
            if (traversalBudget !== undefined) {
                // Check whether the minimum required element visits already exceed remaining budget
                const remaining = traversalBudget.max - traversalBudget.count;
                if (obj.length > remaining) {
                    traversalBudget.count = traversalBudget.max + 1;
                    throw new SafeJsonTraversalLimitError(traversalBudget.max + 1, traversalBudget.max);
                }
                // Bounded incremental growing array - avoid preallocating destination array
                const arr = [];
                for(let i = 0; i < obj.length; i++){
                    arr.push(this.sanitizeObject(obj[i], traversalBudget, currentDepth + 1, maxDepth));
                }
                // T is the caller's input shape; recursive sanitation preserves its array shape.
                return arr;
            }
            const arr = new Array(obj.length);
            for(let i = 0; i < obj.length; i++){
                arr[i] = this.sanitizeObject(obj[i], undefined, currentDepth + 1, maxDepth);
            }
            // T is the caller's input shape; recursive sanitation preserves its array shape.
            return arr;
        }
        const clean = {};
        for (const key of Object.keys(obj)){
            if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
                continue;
            }
            clean[key] = this.sanitizeObject(obj[key], traversalBudget, currentDepth + 1, maxDepth);
        }
        // Sanitization removes forbidden keys, so callers must still validate the result's schema.
        return clean;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/safety/storageResilience.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * storageResilience.ts
 *
 * Client-side storage resilience and QuotaExceededError recovery for PixiBun Atelier.
 *
 * Specification References:
 * 1. WHATWG / W3C Storage Living Standard: Section 3 "Quota and Usage"
 *    - Specification of QuotaExceededError DOMException (legacy code 22).
 */ __turbopack_context__.s([
    "StorageResilience",
    ()=>StorageResilience
]);
class StorageResilience {
    /**
   * Defensive detector for IndexedDB QuotaExceededError across all major browsers.
   * Handles Chromium (name: 'QuotaExceededError'), WebKit/Safari (code: 22 / DOMException),
   * and Firefox storage exhaustion variants.
   */ static isQuotaExceeded(err) {
        if (!err || typeof err !== 'object') return false;
        const error = err;
        if (error.name === 'QuotaExceededError') return true;
        if (error.code === 22) return true; // Legacy DOMException.QUOTA_EXCEEDED_ERR
        if (typeof error.message === 'string' && error.message.toLowerCase().includes('quota')) return true;
        return false;
    }
    /**
   * Queries the browser StorageManager estimate defensively.
   * Returns safe fallbacks if the API is unsupported or rejects.
   */ static async queryStorageEstimate() {
        if (typeof navigator !== 'undefined' && navigator.storage && typeof navigator.storage.estimate === 'function') {
            try {
                const estimate = await navigator.storage.estimate();
                const usageBytes = estimate.usage ?? 0;
                const quotaBytes = estimate.quota ?? 0;
                const usagePercent = quotaBytes > 0 ? usageBytes / quotaBytes * 100 : 0;
                return {
                    usageBytes,
                    quotaBytes,
                    usagePercent
                };
            } catch  {
            // Ignore estimation errors
            }
        }
        return {
            usageBytes: 0,
            quotaBytes: 0,
            usagePercent: 0
        };
    }
    /**
   * Emergency cache eviction of non-critical telemetry and diagnostics tables.
   * Protects core project data and active layer buffers from being purged.
   */ static async pruneVolatileCaches(dbInstance) {
        let evictedCount = 0;
        try {
            const candidate = dbInstance;
            if (candidate?.diagnostics && typeof candidate.diagnostics.clear === 'function') {
                const count = await candidate.diagnostics.count();
                await candidate.diagnostics.clear();
                evictedCount += count;
            }
        } catch (e) {
            console.warn('[StorageResilience] Failed to prune volatile caches:', e);
        }
        return evictedCount;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/storage/db.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PixiBunDatabase",
    ()=>PixiBunDatabase,
    "autoSaveWorkspaceDetailed",
    ()=>autoSaveWorkspaceDetailed,
    "createBlankProject",
    ()=>createBlankProject,
    "createBlankProjectFile",
    ()=>createBlankProjectFile,
    "db",
    ()=>db,
    "deleteLayerBlobsForProject",
    ()=>deleteLayerBlobsForProject,
    "deleteProject",
    ()=>deleteProject,
    "duplicateProject",
    ()=>duplicateProject,
    "encodeLayerBlobRecord",
    ()=>encodeLayerBlobRecord,
    "getLatestStoredProjectId",
    ()=>getLatestStoredProjectId,
    "getLayerBlobsForProject",
    ()=>getLayerBlobsForProject,
    "getProjectById",
    ()=>getProjectById,
    "getStoredProjectVersion",
    ()=>getStoredProjectVersion,
    "listAllProjects",
    ()=>listAllProjects,
    "loadLatestSavedWorkspace",
    ()=>loadLatestSavedWorkspace,
    "renameProject",
    ()=>renameProject,
    "saveLayerBlobs",
    ()=>saveLayerBlobs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dexie/import-wrapper.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/types/project.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$storageResilience$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/storageResilience.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/canvasLimits.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$decodeProject$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/decodeProject.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/persistenceRevisions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/schema.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/metadataAdmission.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
async function encodeLayerBlobRecord(record) {
    return {
        ...record,
        blob: await record.blob.arrayBuffer(),
        blobType: record.blob.type
    };
}
class PixiBunDatabase extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] {
    projects;
    diagnostics;
    layerBlobs;
    recoveryRecords;
    constructor(){
        super('PixiBunDB');
        this.version(1).stores({
            projects: 'id, name, updatedAt'
        });
        this.version(2).stores({
            projects: 'id, name, updatedAt',
            diagnostics: 'id, kind, timestamp'
        });
        this.version(3).stores({
            projects: 'id, name, updatedAt, createdAt',
            diagnostics: 'id, kind, timestamp'
        }).upgrade(async (tx)=>{
            await tx.table('projects').toCollection().modify((p)=>{
                if (!p.createdAt) {
                    p.createdAt = p.updatedAt || Date.now();
                }
            });
        });
        this.version(4).stores({
            projects: 'id, name, updatedAt, createdAt',
            diagnostics: 'id, kind, timestamp',
            layerBlobs: '++id, [projectId+layerId+frameIndex], projectId, layerId'
        });
        this.version(5).stores({
            projects: 'id, name, updatedAt, createdAt',
            diagnostics: 'id, kind, timestamp',
            layerBlobs: '++id, [projectId+layerId+frameIndex], projectId, layerId, [projectId+id]',
            recoveryRecords: 'projectId, classificationState, lastConfirmedAt'
        });
        this.layerBlobs.hook('reading', (record)=>{
            const stored = record;
            return stored.blob instanceof ArrayBuffer ? {
                ...stored,
                blob: new Blob([
                    stored.blob
                ], {
                    type: stored.blobType ?? 'image/png'
                })
            } : record;
        });
    }
}
const db = new PixiBunDatabase();
if ("TURBOPACK compile-time truthy", 1) {
    if ("TURBOPACK compile-time truthy", 1) {
        window.__pixibunDb = db;
    }
}
async function blobsEqual(b1, b2) {
    if (b1 === b2) return true;
    if (!b1 || !b2 || b1.size !== b2.size || b1.type !== b2.type) return false;
    if (b1.size === 0) return true;
    const buf1 = await b1.arrayBuffer();
    const buf2 = await b2.arrayBuffer();
    if (buf1.byteLength !== buf2.byteLength) return false;
    const u1 = new Uint8Array(buf1);
    const u2 = new Uint8Array(buf2);
    for(let i = 0; i < u1.length; i++){
        if (u1[i] !== u2[i]) return false;
    }
    return true;
}
async function saveLayerBlobs(projectId, blobs) {
    const now = Date.now();
    const keyOf = (layerId, frameIndex)=>`${layerId}::${frameIndex}`;
    // Deduplicate incoming blobs by keeping the latest entry for each (layerId, frameIndex)
    const incomingMap = new Map();
    for (const b of blobs){
        incomingMap.set(keyOf(b.layerId, b.frameIndex), b);
    }
    const deduplicatedBlobs = Array.from(incomingMap.values());
    // 1. Query existing records outside the write transaction
    const existingRecords = await db.layerBlobs.where('projectId').equals(projectId).toArray();
    const existingMap = new Map();
    const idsToDelete = [];
    for (const rec of existingRecords){
        const k = keyOf(rec.layerId, rec.frameIndex);
        if (!incomingMap.has(k)) {
            if (rec.id !== undefined) {
                idsToDelete.push(rec.id);
            }
        } else {
            if (existingMap.has(k)) {
                // If a duplicate record already exists in the database for this key, mark it for pruning
                if (rec.id !== undefined) {
                    idsToDelete.push(rec.id);
                }
            } else {
                existingMap.set(k, rec);
            }
        }
    }
    const recordsToAdd = [];
    const recordsToPut = [];
    // 2. Perform native async Blob comparisons OUTSIDE the write transaction.
    // Native microtasks from blob.arrayBuffer() can otherwise detach from Dexie's PSD zone
    // and cause TransactionInactiveError in strict browser environments.
    for (const b of deduplicatedBlobs){
        const k = keyOf(b.layerId, b.frameIndex);
        const existing = existingMap.get(k);
        if (!existing) {
            recordsToAdd.push({
                projectId,
                layerId: b.layerId,
                frameIndex: b.frameIndex,
                blob: b.blob,
                updatedAt: now
            });
        } else {
            const isIdentical = await blobsEqual(existing.blob, b.blob);
            if (!isIdentical) {
                recordsToPut.push({
                    id: existing.id,
                    projectId,
                    layerId: b.layerId,
                    frameIndex: b.frameIndex,
                    blob: b.blob,
                    updatedAt: now
                });
            }
        }
    }
    // 3. If nothing changed, return immediately without opening an IndexedDB transaction
    if (idsToDelete.length === 0 && recordsToAdd.length === 0 && recordsToPut.length === 0) {
        return;
    }
    // 4. Execute atomic batch writes with purely synchronous Dexie calls inside the transaction
    const releaseBytes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reserveMemory"])([
        ...recordsToAdd,
        ...recordsToPut
    ].reduce((sum, row)=>sum + row.blob.size, 0), 'Layer storage bytes');
    try {
        const encodedAdds = await Promise.all(recordsToAdd.map(encodeLayerBlobRecord));
        const encodedPuts = await Promise.all(recordsToPut.map(encodeLayerBlobRecord));
        await db.transaction('rw', db.layerBlobs, async ()=>{
            if (idsToDelete.length > 0) {
                await db.layerBlobs.bulkDelete(idsToDelete);
            }
            if (recordsToAdd.length > 0) {
                await db.layerBlobs.bulkAdd(encodedAdds);
            }
            if (recordsToPut.length > 0) {
                await db.layerBlobs.bulkPut(encodedPuts);
            }
        });
    } catch (err) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$storageResilience$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageResilience"].isQuotaExceeded(err)) {
            console.warn('[saveLayerBlobs] IndexedDB QuotaExceededError encountered. Pruning volatile caches.');
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$storageResilience$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageResilience"].pruneVolatileCaches(db);
        }
        throw err;
    } finally{
        releaseBytes();
    }
}
async function getLayerBlobsForProject(projectId) {
    return await db.layerBlobs.where('projectId').equals(projectId).toArray();
}
async function deleteLayerBlobsForProject(projectId) {
    try {
        await db.layerBlobs.where('projectId').equals(projectId).delete();
    } catch (err) {
        console.error(`Failed to delete layer blobs for project ${projectId}:`, err);
    }
}
/**
 * Determines whether an error was caused by an expected database closure or abort
 * (e.g. during page unload, navigation, or explicit test connection teardown).
 */ function isIgnorableDbClosure(err) {
    if (!db.isOpen()) return true;
    const e = err;
    if (!e) return false;
    return e.name === 'DatabaseClosedError' || e.name === 'AbortError' || typeof e.message === 'string' && e.message.includes('Database has been closed');
}
async function autoSaveWorkspaceDetailed(projectId, project, thumbnailDataUrl, layerBlobs, activeLayerKeys, expectedStorageVersion) {
    // Pre-transaction validation: abort immediately before opening transaction or mutating DB
    const validation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProjectFile"])(project);
    if (!validation.ok) {
        return {
            ok: false,
            reason: 'invariant-invalid',
            error: validation.error
        };
    }
    const validProject = validation.value;
    const name = validProject.name;
    const width = validProject.width;
    const height = validProject.height;
    const fps = validProject.fps;
    const storageVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('save');
    let releaseBytes;
    try {
        releaseBytes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reserveMemory"])(layerBlobs?.reduce((sum, row)=>sum + row.blob.size, 0) ?? 0, 'Autosave storage bytes');
        // Native byte conversion completes before the transaction; its version check still
        // compares against the exact snapshot hydrated by this tab, never a refreshed base.
        const encodedBlobs = layerBlobs === undefined ? undefined : await Promise.all(layerBlobs.map(async (row)=>({
                ...row,
                blob: await row.blob.arrayBuffer(),
                blobType: row.blob.type
            })));
        if (!db.isOpen()) await db.open();
        await db.transaction('rw', db.projects, db.layerBlobs, async ()=>{
            const existing = await db.projects.get(projectId);
            // Compare and write in the same overlapping readwrite transaction across tabs.
            // undefined is reserved for legacy CRUD callers; the studio always supplies a base.
            if (expectedStorageVersion !== undefined && (existing ? getStoredProjectVersion(existing) : null) !== expectedStorageVersion) {
                throw new ProjectSaveConflict();
            }
            const createdAt = existing?.createdAt || validProject.createdAt || Date.now();
            const now = Date.now();
            const dataJson = JSON.stringify(validProject);
            await db.projects.put({
                id: projectId,
                name,
                width,
                height,
                fps,
                createdAt,
                updatedAt: now,
                thumbnailDataUrl: thumbnailDataUrl || existing?.thumbnailDataUrl,
                dataJson,
                storageVersion
            });
            if (layerBlobs !== undefined || activeLayerKeys !== undefined) {
                // Collect all active layer keys from valid project frames
                const activeKeySet = new Set();
                if (activeLayerKeys) {
                    for (const k of activeLayerKeys){
                        activeKeySet.add(`${k.layerId}::${k.frameIndex}`);
                    }
                } else {
                    for(let fIdx = 0; fIdx < validProject.frames.length; fIdx++){
                        const frame = validProject.frames[fIdx];
                        for (const layer of frame.layers){
                            if (layer?.id) activeKeySet.add(`${layer.id}::${fIdx}`);
                        }
                    }
                }
                const existingRecords = await db.layerBlobs.where('projectId').equals(projectId).toArray();
                const existingMap = new Map();
                const idsToDelete = [];
                for (const rec of existingRecords){
                    const k = `${rec.layerId}::${rec.frameIndex}`;
                    if (!activeKeySet.has(k)) {
                        if (rec.id !== undefined) idsToDelete.push(rec.id);
                    } else {
                        if (existingMap.has(k)) {
                            if (rec.id !== undefined) idsToDelete.push(rec.id);
                        } else {
                            existingMap.set(k, rec);
                        }
                    }
                }
                const recordsToPut = [];
                const recordsToAdd = [];
                if (encodedBlobs && encodedBlobs.length > 0) {
                    for (const b of encodedBlobs){
                        const k = `${b.layerId}::${b.frameIndex}`;
                        const existingRec = existingMap.get(k);
                        if (existingRec && existingRec.id !== undefined) {
                            recordsToPut.push({
                                id: existingRec.id,
                                projectId,
                                layerId: b.layerId,
                                frameIndex: b.frameIndex,
                                blob: b.blob,
                                blobType: b.blobType,
                                updatedAt: now
                            });
                        } else {
                            recordsToAdd.push({
                                projectId,
                                layerId: b.layerId,
                                frameIndex: b.frameIndex,
                                blob: b.blob,
                                blobType: b.blobType,
                                updatedAt: now
                            });
                        }
                    }
                }
                if (idsToDelete.length > 0) {
                    await db.layerBlobs.bulkDelete(idsToDelete);
                }
                if (recordsToPut.length > 0) {
                    await db.layerBlobs.bulkPut(recordsToPut);
                }
                if (recordsToAdd.length > 0) {
                    await db.layerBlobs.bulkAdd(recordsToAdd);
                }
            }
        });
        return {
            ok: true,
            status: 'saved',
            storageVersion
        };
    } catch (err) {
        if (err instanceof ProjectSaveConflict) {
            return {
                ok: false,
                reason: 'conflict',
                error: 'This project changed in another tab or was deleted. Your work is still here. Save a copy to keep both versions.'
            };
        }
        if (err instanceof RangeError && err.message.includes('memory budget')) return {
            ok: false,
            reason: 'memory-limit',
            error: err.message
        };
        if (isIgnorableDbClosure(err)) {
            console.warn('Autosave aborted (database closed or reset in progress)');
            return {
                ok: false,
                reason: 'aborted',
                error: err instanceof Error ? err.message : String(err)
            };
        }
        if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$storageResilience$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageResilience"].isQuotaExceeded(err)) {
            console.warn('[autoSaveWorkspaceDetailed] Storage quota exceeded. Pruning volatile caches.');
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$storageResilience$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageResilience"].pruneVolatileCaches(db);
            return {
                ok: false,
                reason: 'quota-exceeded',
                error: err instanceof Error ? err.message : String(err)
            };
        }
        console.error('Autosave error:', err);
        return {
            ok: false,
            reason: 'error',
            error: err instanceof Error ? err.message : String(err)
        };
    } finally{
        releaseBytes?.();
    }
}
class ProjectSaveConflict extends Error {
}
function getStoredProjectVersion(project) {
    return project.storageVersion ?? `legacy:${project.updatedAt}`;
}
async function getLatestStoredProjectId() {
    try {
        if (!db.isOpen()) await db.open();
        const keys = await db.projects.orderBy('updatedAt').reverse().limit(1).primaryKeys();
        const id = keys[0];
        return typeof id === 'string' ? id : null;
    } catch (err) {
        if (isIgnorableDbClosure(err)) return null;
        throw new Error('Latest project identity could not be read.', {
            cause: err
        });
    }
}
async function loadLatestSavedWorkspace() {
    try {
        if (!db.isOpen()) await db.open();
        return await db.transaction('r', db.projects, db.layerBlobs, async ()=>{
            const projects = await db.projects.orderBy('updatedAt').reverse().limit(1).toArray();
            const project = projects[0];
            return project ? {
                ...project,
                layerBlobs: await db.layerBlobs.where('projectId').equals(project.id).toArray()
            } : null;
        });
    } catch (err) {
        throw new Error('Saved workspace could not be read.', {
            cause: err
        });
    }
}
async function listAllProjects() {
    try {
        if (!db.isOpen()) await db.open();
        return await db.projects.orderBy('updatedAt').reverse().toArray();
    } catch (err) {
        if (isIgnorableDbClosure(err)) return [];
        console.error('List projects error:', err);
        throw new Error('Database storage is unavailable; could not read project list.', {
            cause: err
        });
    }
}
async function getProjectById(id) {
    try {
        if (!db.isOpen()) await db.open();
        return await db.transaction('r', db.projects, db.layerBlobs, async ()=>{
            const project = await db.projects.get(id);
            return project ? {
                ...project,
                layerBlobs: await db.layerBlobs.where('projectId').equals(id).toArray()
            } : null;
        });
    } catch (err) {
        if (isIgnorableDbClosure(err)) return null;
        console.error(`Get project ${id} error:`, err);
        return null;
    }
}
async function deleteProject(id) {
    try {
        if (!db.isOpen()) await db.open();
        await db.transaction('rw', db.projects, db.layerBlobs, db.recoveryRecords, async ()=>{
            await db.projects.delete(id);
            await db.layerBlobs.where('projectId').equals(id).delete();
            await db.recoveryRecords.delete(id);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearPersistedRevisions"])(id);
        return true;
    } catch (err) {
        if (isIgnorableDbClosure(err)) return false;
        console.error(`Delete project ${id} error:`, err);
        return false;
    }
}
async function duplicateProject(id, newName) {
    try {
        if (!db.isOpen()) await db.open();
        return await db.transaction('rw', db.projects, db.layerBlobs, async ()=>{
            const source = await db.projects.get(id);
            if (!source) return null;
            const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
            const now = Date.now();
            const clonedName = newName ?? `Copy of ${source.name}`.slice(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PROJECT_NAME_LENGTH"]);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["projectNameError"])(clonedName)) return null;
            let updatedDataJson = source.dataJson;
            const decoded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$decodeProject$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodeAndValidateProject"])(source.dataJson);
            if (decoded.ok) {
                const validated = decoded.value;
                validated.name = clonedName;
                validated.createdAt = now;
                validated.updatedAt = now;
                updatedDataJson = JSON.stringify(validated);
            } else {
                console.warn(`Duplicate project ${id}: source data failed validation (${decoded.error}), preserving data structure.`);
            }
            const duplicate = {
                ...source,
                id: newId,
                name: clonedName,
                createdAt: now,
                updatedAt: now,
                dataJson: updatedDataJson
            };
            const sourceBlobs = await db.layerBlobs.where('projectId').equals(id).toArray();
            const releaseBytes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reserveMemory"])(sourceBlobs.reduce((sum, row)=>sum + row.blob.size, 0), 'Duplicate storage bytes');
            try {
                const encodedBlobs = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].waitFor(Promise.all(sourceBlobs.map(encodeLayerBlobRecord)));
                await db.projects.put(duplicate);
                await db.layerBlobs.bulkAdd(encodedBlobs.map((b)=>({
                        projectId: newId,
                        updatedAt: now,
                        layerId: b.layerId,
                        frameIndex: b.frameIndex,
                        blob: b.blob,
                        blobType: b.blobType
                    })));
                return duplicate;
            } finally{
                releaseBytes();
            }
        });
    } catch (err) {
        console.error(`Duplicate project ${id} error:`, err);
        return null;
    }
}
async function renameProject(id, newName) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["projectNameError"])(newName)) return false;
    try {
        if (!db.isOpen()) await db.open();
        return await db.transaction('rw', db.projects, async ()=>{
            const project = await db.projects.get(id);
            if (!project) return false;
            const now = Date.now();
            const decoded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$decodeProject$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodeAndValidateProject"])(project.dataJson);
            if (!decoded.ok) return false;
            const validated = decoded.value;
            validated.name = newName;
            validated.updatedAt = now;
            const renamed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProjectFile"])(validated);
            if (!renamed.ok) return false;
            const updatedDataJson = JSON.stringify(renamed.value);
            await db.projects.update(id, {
                storageVersion: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('save'),
                name: newName,
                updatedAt: now,
                dataJson: updatedDataJson
            });
            return true;
        });
    } catch (err) {
        if (isIgnorableDbClosure(err)) return false;
        console.error(`Rename project ${id} error:`, err);
        return false;
    }
}
function createBlankProjectFile(name = 'Untitled Sprite', width = 32, height = 32, fps = 8) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$canvasLimits$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertWorkspaceDimensions"])(width, height);
    const initialLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('layer');
    const initialFrameId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('frame');
    const now = Date.now();
    return {
        format: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_ID"],
        version: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$project$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROJECT_FORMAT_VERSION"],
        name,
        width,
        height,
        fps,
        loopMode: 'repeat',
        onionSkin: {
            enabled: false,
            prevFrames: 1,
            nextFrames: 1,
            prevColor: '#7fae6b',
            nextColor: '#c792df',
            opacity: 0.35
        },
        palettes: [
            {
                id: 'pal-default-atelier',
                name: 'Atelier Hearth',
                colors: [
                    '#140d1f',
                    '#281b3d',
                    '#3a2e4c',
                    '#6a5880',
                    '#a86ec6',
                    '#c792df',
                    '#dcabdf',
                    '#d0c4df',
                    '#dddddf',
                    '#dddfdf',
                    '#f0be7c',
                    '#e2a35d'
                ]
            }
        ],
        currentPaletteId: 'pal-default-atelier',
        customRamps: [],
        clips: [
            {
                id: 'clip-1',
                name: 'Default Clip',
                startFrame: 0,
                endFrame: 0
            }
        ],
        frames: [
            {
                id: initialFrameId,
                durationMs: 125,
                layers: [
                    {
                        id: initialLayerId,
                        name: 'Base Layer',
                        visible: true,
                        locked: false,
                        opacity: 1,
                        blendMode: 'source-over'
                    }
                ]
            }
        ],
        createdAt: now,
        updatedAt: now
    };
}
async function createBlankProject(name = 'Untitled Sprite', width = 32, height = 32) {
    const nameError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["projectNameError"])(name);
    if (nameError) throw new RangeError(nameError);
    const initialProjectFile = createBlankProjectFile(name, width, height);
    const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
    const now = initialProjectFile.createdAt;
    const stored = {
        id: newId,
        name,
        width,
        height,
        fps: initialProjectFile.fps,
        createdAt: now,
        updatedAt: now,
        dataJson: JSON.stringify(initialProjectFile)
    };
    await db.projects.put(stored);
    return stored;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/types/project.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PROJECT_FORMAT_ID",
    ()=>PROJECT_FORMAT_ID,
    "PROJECT_FORMAT_VERSION",
    ()=>PROJECT_FORMAT_VERSION
]);
const PROJECT_FORMAT_VERSION = 3;
const PROJECT_FORMAT_ID = 'pixibun-project';
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_11ch1gq._.js.map