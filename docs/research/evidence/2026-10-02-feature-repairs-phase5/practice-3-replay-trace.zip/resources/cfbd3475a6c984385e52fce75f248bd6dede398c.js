(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/layout/AtelierRail.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AtelierRail",
    ()=>AtelierRail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/importFile.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixiBunLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixiBunLogo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$AppearancePopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/AppearancePopover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$HeaderFileMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/HeaderFileMenu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioTooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/StudioTooltip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/TactileButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$system$2f$OfflineIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/system/OfflineIndicator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/zoom.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/cvdLens.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/metadataAdmission.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const CVD_LENS_BUTTON_LABELS = {
    none: 'OFF',
    protanopia: 'Pro',
    deuteranopia: 'Deu',
    tritanopia: 'Tri',
    monochromacy: 'Mono'
};
const CVD_LENS_TITLES = {
    none: 'Colorblindness Lens (P): OFF — cycles Protanopia / Deuteranopia / Tritanopia / Monochromacy',
    protanopia: 'Colorblindness Lens (P): Protanopia (red-weak) — cycles lens modes',
    deuteranopia: 'Colorblindness Lens (P): Deuteranopia (green-weak) — cycles lens modes',
    tritanopia: 'Colorblindness Lens (P): Tritanopia (blue-weak) — cycles lens modes',
    monochromacy: 'Colorblindness Lens (P): Monochromacy (luminance only) — cycles lens modes'
};
const AtelierRail = ({ onOpenExport, onOpenImport, onOpenShortcuts, onOpenResize, onNewDrawing, onSaveNow, onOpenGallery, onOpenCoDraw, onUndo, onRedo, canUndo: propCanUndo, canRedo: propCanRedo })=>{
    _s();
    const projectName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[projectName]": (s)=>s.projectName
    }["AtelierRail.useStudioStore[projectName]"]);
    const setProjectName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setProjectName]": (s)=>s.setProjectName
    }["AtelierRail.useStudioStore[setProjectName]"]);
    const canvasWidth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[canvasWidth]": (s)=>s.canvasWidth
    }["AtelierRail.useStudioStore[canvasWidth]"]);
    const canvasHeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[canvasHeight]": (s)=>s.canvasHeight
    }["AtelierRail.useStudioStore[canvasHeight]"]);
    const zoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[zoom]": (s)=>s.zoom
    }["AtelierRail.useStudioStore[zoom]"]);
    const setZoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setZoom]": (s)=>s.setZoom
    }["AtelierRail.useStudioStore[setZoom]"]);
    const setPan = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setPan]": (s)=>s.setPan
    }["AtelierRail.useStudioStore[setPan]"]);
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[tools]": (s)=>s.tools
    }["AtelierRail.useStudioStore[tools]"]);
    const setBrushSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setBrushSize]": (s)=>s.setBrushSize
    }["AtelierRail.useStudioStore[setBrushSize]"]);
    const setPixelPerfect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setPixelPerfect]": (s)=>s.setPixelPerfect
    }["AtelierRail.useStudioStore[setPixelPerfect]"]);
    const setDitherMatrix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setDitherMatrix]": (s)=>s.setDitherMatrix
    }["AtelierRail.useStudioStore[setDitherMatrix]"]);
    const setDitherDensity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setDitherDensity]": (s)=>s.setDitherDensity
    }["AtelierRail.useStudioStore[setDitherDensity]"]);
    const setBucketContiguous = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setBucketContiguous]": (s)=>s.setBucketContiguous
    }["AtelierRail.useStudioStore[setBucketContiguous]"]);
    const setBucketTolerance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setBucketTolerance]": (s)=>s.setBucketTolerance
    }["AtelierRail.useStudioStore[setBucketTolerance]"]);
    const setFillTolerance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setFillTolerance]": (s)=>s.setFillTolerance
    }["AtelierRail.useStudioStore[setFillTolerance]"]);
    const setFillEnclosedSpecks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setFillEnclosedSpecks]": (s)=>s.setFillEnclosedSpecks
    }["AtelierRail.useStudioStore[setFillEnclosedSpecks]"]);
    const setEraseColorTolerance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setEraseColorTolerance]": (s)=>s.setEraseColorTolerance
    }["AtelierRail.useStudioStore[setEraseColorTolerance]"]);
    const setEraseColorContiguous = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setEraseColorContiguous]": (s)=>s.setEraseColorContiguous
    }["AtelierRail.useStudioStore[setEraseColorContiguous]"]);
    const setEraseColorFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setEraseColorFamily]": (s)=>s.setEraseColorFamily
    }["AtelierRail.useStudioStore[setEraseColorFamily]"]);
    const setEraseColorAllFrames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setEraseColorAllFrames]": (s)=>s.setEraseColorAllFrames
    }["AtelierRail.useStudioStore[setEraseColorAllFrames]"]);
    const setShapeFilled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setShapeFilled]": (s)=>s.setShapeFilled
    }["AtelierRail.useStudioStore[setShapeFilled]"]);
    const setCurveTightness = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setCurveTightness]": (s)=>s.setCurveTightness
    }["AtelierRail.useStudioStore[setCurveTightness]"]);
    const setIsoAngleSnap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setIsoAngleSnap]": (s)=>s.setIsoAngleSnap
    }["AtelierRail.useStudioStore[setIsoAngleSnap]"]);
    const toggleSymmetryH = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[toggleSymmetryH]": (s)=>s.toggleSymmetryH
    }["AtelierRail.useStudioStore[toggleSymmetryH]"]);
    const toggleSymmetryV = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[toggleSymmetryV]": (s)=>s.toggleSymmetryV
    }["AtelierRail.useStudioStore[toggleSymmetryV]"]);
    const setSymmetryGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setSymmetryGroup]": (s)=>s.setSymmetryGroup
    }["AtelierRail.useStudioStore[setSymmetryGroup]"]);
    const showGrid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[showGrid]": (s)=>s.showGrid
    }["AtelierRail.useStudioStore[showGrid]"]);
    const toggleGrid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[toggleGrid]": (s)=>s.toggleGrid
    }["AtelierRail.useStudioStore[toggleGrid]"]);
    const showIsoGuides = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[showIsoGuides]": (s)=>s.showIsoGuides
    }["AtelierRail.useStudioStore[showIsoGuides]"]);
    const toggleIsoGuides = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[toggleIsoGuides]": (s)=>s.toggleIsoGuides
    }["AtelierRail.useStudioStore[toggleIsoGuides]"]);
    const showTilePreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[showTilePreview]": (s)=>s.showTilePreview
    }["AtelierRail.useStudioStore[showTilePreview]"]);
    const toggleTilePreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[toggleTilePreview]": (s)=>s.toggleTilePreview
    }["AtelierRail.useStudioStore[toggleTilePreview]"]);
    const showFloatingPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[showFloatingPreview]": (s)=>s.showFloatingPreview
    }["AtelierRail.useStudioStore[showFloatingPreview]"]);
    const toggleFloatingPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[toggleFloatingPreview]": (s)=>s.toggleFloatingPreview
    }["AtelierRail.useStudioStore[toggleFloatingPreview]"]);
    const cvdLens = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[cvdLens]": (s)=>s.cvdLens
    }["AtelierRail.useStudioStore[cvdLens]"]);
    const squintMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[squintMode]": (s)=>s.squintMode
    }["AtelierRail.useStudioStore[squintMode]"]);
    const setCvdLens = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[setCvdLens]": (s)=>s.setCvdLens
    }["AtelierRail.useStudioStore[setCvdLens]"]);
    const toggleSquintMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[toggleSquintMode]": (s)=>s.toggleSquintMode
    }["AtelierRail.useStudioStore[toggleSquintMode]"]);
    const referenceOverlay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[referenceOverlay]": (s)=>s.referenceOverlay
    }["AtelierRail.useStudioStore[referenceOverlay]"]);
    const cycleReferenceOverlay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[cycleReferenceOverlay]": (s)=>s.cycleReferenceOverlay
    }["AtelierRail.useStudioStore[cycleReferenceOverlay]"]);
    const storeCanUndo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[storeCanUndo]": (s)=>s.canUndo
    }["AtelierRail.useStudioStore[storeCanUndo]"]);
    const storeCanRedo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[storeCanRedo]": (s)=>s.canRedo
    }["AtelierRail.useStudioStore[storeCanRedo]"]);
    const isDirty = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[isDirty]": (s)=>s.isDirty
    }["AtelierRail.useStudioStore[isDirty]"]);
    const saveStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "AtelierRail.useStudioStore[saveStatus]": (s)=>s.saveStatus
    }["AtelierRail.useStudioStore[saveStatus]"]);
    const isUndoEnabled = propCanUndo !== undefined ? propCanUndo : storeCanUndo;
    const isRedoEnabled = propCanRedo !== undefined ? propCanRedo : storeCanRedo;
    const [isEditingName, setIsEditingName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [tempName, setTempName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(projectName);
    const [isBrushMenuOpen, setIsBrushMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isZoomMenuOpen, setIsZoomMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [toolMenuFor, setToolMenuFor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const toolOptionsId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const isToolMenuOpen = toolMenuFor === tools.activeTool;
    const toolMenuRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const brushMenuRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const zoomMenuRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // View Options Popover state
    const [isViewMenuOpen, setIsViewMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const viewMenuRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const popoverRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [popoverCoords, setPopoverCoords] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isMounted, setIsMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AtelierRail.useEffect": ()=>{
            setIsMounted(true);
        }
    }["AtelierRail.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AtelierRail.useEffect": ()=>{
            if (!isBrushMenuOpen && !isZoomMenuOpen && !isToolMenuOpen) return;
            const onPointerDown = {
                "AtelierRail.useEffect.onPointerDown": (event)=>{
                    const target = event.target;
                    if (!brushMenuRef.current?.contains(target)) setIsBrushMenuOpen(false);
                    if (!zoomMenuRef.current?.contains(target)) setIsZoomMenuOpen(false);
                    if (!toolMenuRef.current?.contains(target)) setToolMenuFor(null);
                }
            }["AtelierRail.useEffect.onPointerDown"];
            const onEscape = {
                "AtelierRail.useEffect.onEscape": (event)=>{
                    if (event.key === 'Escape') {
                        setIsBrushMenuOpen(false);
                        setIsZoomMenuOpen(false);
                        if (isToolMenuOpen) {
                            setToolMenuFor(null);
                            toolMenuRef.current?.querySelector('[data-testid="tool-options-button"]')?.focus();
                        }
                    }
                }
            }["AtelierRail.useEffect.onEscape"];
            document.addEventListener('mousedown', onPointerDown);
            document.addEventListener('keydown', onEscape);
            return ({
                "AtelierRail.useEffect": ()=>{
                    document.removeEventListener('mousedown', onPointerDown);
                    document.removeEventListener('keydown', onEscape);
                }
            })["AtelierRail.useEffect"];
        }
    }["AtelierRail.useEffect"], [
        isBrushMenuOpen,
        isZoomMenuOpen,
        isToolMenuOpen
    ]);
    const updatePopoverCoords = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AtelierRail.useCallback[updatePopoverCoords]": ()=>{
            if (viewMenuRef.current) {
                const rect = viewMenuRef.current.getBoundingClientRect();
                setPopoverCoords({
                    top: rect.bottom + 4,
                    right: Math.max(16, window.innerWidth - rect.right)
                });
            }
        }
    }["AtelierRail.useCallback[updatePopoverCoords]"], []);
    const handleToggleViewMenu = ()=>{
        setIsViewMenuOpen((prev)=>{
            const next = !prev;
            if (next) updatePopoverCoords();
            return next;
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AtelierRail.useEffect": ()=>{
            if (!isViewMenuOpen) return;
            updatePopoverCoords();
            const handleClickOutside = {
                "AtelierRail.useEffect.handleClickOutside": (e)=>{
                    const target = e.target;
                    if (viewMenuRef.current && !viewMenuRef.current.contains(target) && popoverRef.current && !popoverRef.current.contains(target)) {
                        setIsViewMenuOpen(false);
                    }
                }
            }["AtelierRail.useEffect.handleClickOutside"];
            const handleKeyDown = {
                "AtelierRail.useEffect.handleKeyDown": (e)=>{
                    if (e.key === 'Escape') setIsViewMenuOpen(false);
                }
            }["AtelierRail.useEffect.handleKeyDown"];
            window.addEventListener('resize', updatePopoverCoords);
            window.addEventListener('scroll', updatePopoverCoords, true);
            document.addEventListener('mousedown', handleClickOutside);
            document.addEventListener('keydown', handleKeyDown);
            return ({
                "AtelierRail.useEffect": ()=>{
                    window.removeEventListener('resize', updatePopoverCoords);
                    window.removeEventListener('scroll', updatePopoverCoords, true);
                    document.removeEventListener('mousedown', handleClickOutside);
                    document.removeEventListener('keydown', handleKeyDown);
                }
            })["AtelierRail.useEffect"];
        }
    }["AtelierRail.useEffect"], [
        isViewMenuOpen,
        updatePopoverCoords
    ]);
    const activeViewModifiers = [
        showGrid,
        showIsoGuides,
        showTilePreview,
        showFloatingPreview,
        cvdLens !== 'none',
        squintMode,
        referenceOverlay !== 'none',
        tools.symmetryHorizontal,
        tools.symmetryVertical,
        tools.symmetryGroup && tools.symmetryGroup !== 'none'
    ].filter(Boolean).length;
    const handleFileChange = (e)=>{
        const file = e.target.files?.[0];
        if (!file) return;
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readImportFile"])(file).then((payload)=>onOpenImport?.(payload)).catch(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportImportError"]);
        if (fileInputRef.current) fileInputRef.current.value = '';
    };
    const isShapeTool = tools.activeTool === 'rectangle' || tools.activeTool === 'ellipse' || tools.activeTool === 'line' || tools.activeTool === 'isometric-line';
    const hasToolParams = tools.activeTool === 'pen' || tools.activeTool === 'curve' || tools.activeTool === 'eraser' || tools.activeTool === 'bucket' || tools.activeTool === 'color-replace' || tools.activeTool === 'erase-color' || tools.activeTool === 'dither' || isShapeTool;
    const hasExpandedToolParams = hasToolParams && tools.activeTool !== 'pen' && tools.activeTool !== 'eraser';
    const toolLabel = tools.activeTool === 'erase-color' ? 'Erase color' : tools.activeTool === 'color-replace' ? 'Replace color' : tools.activeTool.charAt(0).toUpperCase() + tools.activeTool.slice(1);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        role: "banner",
        className: "h-12 bg-[var(--desk-surface)] border-b border-[var(--desk-border)] flex items-center px-2 xl:px-3 gap-2 xl:gap-3 select-none shrink-0 z-30 font-sans text-xs transition-colors duration-150 relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: "group",
                "aria-label": "Project controls",
                className: "flex min-w-0 items-center gap-1.5 xl:gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        title: "Return to PixiBun Home",
                        "aria-label": "PixiBun Home",
                        className: "flex shrink-0 items-center pr-1.5 xl:pr-2.5 border-r border-[var(--desk-border)] hover:opacity-90 transition-opacity",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixiBunLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixiBunLogo"], {
                            size: "sm",
                            wordmarkClassName: "hidden xl:flex",
                            className: "drop-shadow-sm"
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/AtelierRail.tsx",
                            lineNumber: 265,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 259,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$HeaderFileMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeaderFileMenu"], {
                        actions: [
                            {
                                label: 'Projects',
                                icon: 'layers',
                                testId: 'gallery-button',
                                onSelect: ()=>onOpenGallery?.()
                            },
                            {
                                label: 'New drawing',
                                icon: 'plus',
                                testId: 'new-drawing-button',
                                onSelect: ()=>onNewDrawing?.()
                            },
                            {
                                label: 'Import…',
                                icon: 'import',
                                testId: 'import-button',
                                onSelect: ()=>fileInputRef.current?.click()
                            },
                            {
                                label: 'Canvas size…',
                                icon: 'rectangle',
                                testId: 'resize-canvas-button',
                                onSelect: ()=>onOpenResize?.()
                            }
                        ]
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 268,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    isEditingName ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        maxLength: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PROJECT_NAME_LENGTH"],
                        value: tempName,
                        onChange: (e)=>setTempName(e.target.value),
                        onBlur: ()=>{
                            setIsEditingName(false);
                            if (tempName.trim()) setProjectName(tempName.trim());
                        },
                        onKeyDown: (e)=>{
                            if (e.key === 'Enter') {
                                setIsEditingName(false);
                                if (tempName.trim()) setProjectName(tempName.trim());
                            } else if (e.key === 'Escape') {
                                setIsEditingName(false);
                                setTempName(projectName);
                            }
                        },
                        ref: (el)=>el?.focus(),
                        className: "h-7 min-w-6 w-20 xl:w-[120px] bg-[var(--surface-0)] text-[var(--text-heading)] px-2 rounded-[2px] border border-[var(--accent-gold)] outline-none text-xs font-mono font-medium"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 276,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setTempName(projectName);
                            setIsEditingName(true);
                        },
                        className: "h-7 min-w-6 max-w-20 xl:max-w-[120px] font-medium text-xs text-[var(--text-heading)] hover:text-[var(--accent-gold)] transition-colors truncate cursor-pointer text-left leading-none",
                        "aria-label": `Rename project ${projectName}`,
                        title: `${projectName} · ${canvasWidth}×${canvasHeight}px · Click to rename`,
                        children: projectName
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 298,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        title: "Canvas size · change it in File",
                        className: "hidden xl:inline shrink-0 text-[10px] font-mono text-[var(--text-muted)]",
                        children: [
                            canvasWidth,
                            "×",
                            canvasHeight
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 310,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                        size: "sm",
                        variant: "default",
                        onClick: onSaveNow,
                        title: saveStatus === 'saving' ? 'Saving locally… (Ctrl+S)' : saveStatus === 'error' ? 'Save issue · Click to retry (Ctrl+S)' : isDirty ? 'Unsaved changes · Click to save (Ctrl+S)' : 'All changes saved (Ctrl+S)',
                        "aria-label": saveStatus === 'saving' ? 'Saving locally' : saveStatus === 'error' ? 'Save issue' : isDirty ? 'Save unsaved changes' : 'Save now',
                        "data-testid": "save-button",
                        className: "h-7 min-w-[64px] px-2.5 text-xs flex items-center gap-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: saveStatus === 'error' ? 'warning' : 'save',
                                size: 12,
                                className: saveStatus === 'error' ? 'text-[#eb5a66]' : saveStatus === 'saving' ? 'text-[var(--accent-gold)] animate-pulse' : isDirty ? 'text-[var(--accent-gold)]' : 'text-[var(--text-muted)]'
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 339,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 352,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 314,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$system$2f$OfflineIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OfflineIndicator"], {}, void 0, false, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 356,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-7 flex items-center gap-1 border-l border-[var(--desk-border)] pl-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioTooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                content: "Undo",
                                shortcut: "Ctrl+Z",
                                position: "bottom",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onUndo,
                                    disabled: !isUndoEnabled,
                                    "data-testid": "undo-button",
                                    title: "Undo (Ctrl+Z)",
                                    "aria-label": "Undo last action",
                                    className: "w-7 h-7 rounded-[2px] flex items-center justify-center pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--text-heading)] disabled:opacity-25 disabled:pointer-events-none cursor-pointer",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                        name: "undo",
                                        size: 12
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 369,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                    lineNumber: 361,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 360,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioTooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                content: "Redo",
                                shortcut: "Ctrl+Y",
                                position: "bottom",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onRedo,
                                    disabled: !isRedoEnabled,
                                    "data-testid": "redo-button",
                                    title: "Redo (Ctrl+Y)",
                                    "aria-label": "Redo last action",
                                    className: "w-7 h-7 rounded-[2px] flex items-center justify-center pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--text-heading)] disabled:opacity-25 disabled:pointer-events-none cursor-pointer",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                        name: "redo",
                                        size: 12
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 382,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                    lineNumber: 374,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 373,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 359,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                lineNumber: 257,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: toolMenuRef,
                role: "group",
                "aria-label": "Drawing controls",
                className: "relative flex shrink-0 items-center",
                children: [
                    hasExpandedToolParams && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        "data-testid": "tool-options-button",
                        "aria-label": `${toolLabel} tool options`,
                        "aria-expanded": isToolMenuOpen,
                        "aria-controls": toolOptionsId,
                        onClick: ()=>setToolMenuFor(isToolMenuOpen ? null : tools.activeTool),
                        className: "h-7 px-2 flex items-center gap-1.5 bg-[var(--surface-0)] border border-[var(--desk-border)] rounded-[2px] text-[var(--text-heading)]",
                        children: [
                            toolLabel,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                "aria-hidden": "true",
                                className: "text-[8px]",
                                children: "▼"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 394,
                                columnNumber: 22
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 390,
                        columnNumber: 35
                    }, ("TURBOPACK compile-time value", void 0)),
                    hasToolParams ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: toolOptionsId,
                        role: hasExpandedToolParams ? 'group' : undefined,
                        "data-testid": "tool-options-rail",
                        "aria-label": hasExpandedToolParams ? `${toolLabel} settings` : 'Tool options rail',
                        className: `${hasExpandedToolParams ? `${isToolMenuOpen ? 'flex' : 'hidden'} absolute top-full left-0 mt-1 z-[100] w-[360px] max-w-[calc(100vw-16px)] p-3 shadow-xl` : 'flex h-7 px-2 xl:px-2.5'} bg-[var(--surface-0)] border border-[var(--desk-border)] rounded-[2px] flex-wrap items-center gap-2`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `text-[10px] font-sans font-medium text-[var(--text-heading)] shrink-0 ${hasExpandedToolParams ? 'w-full' : 'hidden xl:inline'}`,
                                children: [
                                    tools.activeTool.charAt(0).toUpperCase() + tools.activeTool.slice(1),
                                    ":"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 399,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            (tools.activeTool === 'pen' || tools.activeTool === 'curve' || tools.activeTool === 'eraser' || tools.activeTool === 'dither' || isShapeTool) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                ref: brushMenuRef,
                                className: "relative shrink-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setIsBrushMenuOpen((open)=>!open),
                                        "aria-label": `Brush size ${tools.brushSize} pixels`,
                                        "aria-expanded": isBrushMenuOpen,
                                        className: "h-6 px-2 flex items-center gap-1.5 rounded-[2px] text-xs text-[var(--text-heading)] hover:bg-[var(--surface-2)]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Size"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 413,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-mono tabular-nums",
                                                children: [
                                                    tools.brushSize,
                                                    " px"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 413,
                                                columnNumber: 36
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                "aria-hidden": "true",
                                                children: "▾"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 413,
                                                columnNumber: 104
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 410,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    isBrushMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        role: "group",
                                        "aria-label": "Brush size controls",
                                        className: "absolute top-full left-0 mt-1 z-[100] w-56 bg-[var(--surface-2)] border border-[var(--desk-border-highlight)] rounded-[2px] p-3 shadow-lg space-y-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "flex items-center gap-2 text-xs text-[var(--text-heading)]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Size"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 419,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "range",
                                                        min: "1",
                                                        max: "32",
                                                        value: tools.brushSize,
                                                        onChange: (event)=>setBrushSize(Number(event.target.value)),
                                                        "aria-label": "Brush size",
                                                        className: "min-w-0 flex-1 accent-[var(--accent-gold)]"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 420,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "number",
                                                        min: "1",
                                                        max: "32",
                                                        value: tools.brushSize,
                                                        onChange: (event)=>setBrushSize(Number(event.target.value)),
                                                        "aria-label": "Brush size in pixels",
                                                        className: "w-12 h-8 bg-[var(--surface-0)] border border-[var(--desk-border)] rounded-[2px] text-center font-mono"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 423,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 418,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex gap-1",
                                                "aria-label": "Common brush sizes",
                                                children: [
                                                    1,
                                                    2,
                                                    3,
                                                    4,
                                                    8
                                                ].map((size)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        onClick: ()=>{
                                                            setBrushSize(size);
                                                            setIsBrushMenuOpen(false);
                                                            brushMenuRef.current?.querySelector('button')?.focus();
                                                        },
                                                        "aria-label": `${size} pixel brush preset`,
                                                        "aria-pressed": tools.brushSize === size,
                                                        className: `h-8 flex-1 rounded-[2px] text-xs font-mono ${tools.brushSize === size ? 'bg-[var(--accent-gold)] text-[var(--surface-0)]' : 'bg-[var(--surface-1)] text-[var(--text-body)]'}`,
                                                        children: size
                                                    }, size, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 430,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0)))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 428,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            (tools.activeTool === 'pen' || tools.activeTool === 'curve') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "flex items-start gap-2 border-t border-[var(--desk-border)] pt-2 text-xs text-[var(--text-heading)] cursor-pointer",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "checkbox",
                                                        checked: tools.pixelPerfect,
                                                        onChange: (event)=>setPixelPerfect(event.target.checked),
                                                        "aria-label": "Clean corners",
                                                        className: "mt-0.5 accent-[var(--accent-gold)]"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 443,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: [
                                                            "Clean corners",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "block text-[10px] text-[var(--text-muted)]",
                                                                children: "Removes doubled pixels at turns."
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                                lineNumber: 446,
                                                                columnNumber: 44
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 446,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 442,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 416,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 409,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            tools.activeTool === 'curve' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1 shrink-0 text-[10px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[var(--text-muted)]",
                                        children: "Tight:"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 457,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        min: "0.1",
                                        max: "1.0",
                                        step: "0.05",
                                        value: tools.curveTightness,
                                        onChange: (e)=>setCurveTightness(parseFloat(e.target.value)),
                                        "aria-label": "Curve tightness",
                                        className: "w-12 h-6 accent-[var(--accent-gold)] cursor-pointer"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 458,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 456,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            tools.activeTool === 'bucket' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setBucketContiguous(!tools.bucketContiguous),
                                        title: tools.bucketContiguous ? 'Contiguous Island Fill' : 'Global Color Replace',
                                        className: `h-6 px-1.5 text-[9px] font-bold rounded-[1px] cursor-pointer shrink-0 flex items-center justify-center transition-all ${!tools.bucketContiguous ? 'pixel-primary-btn shadow-[0_1px_0_var(--btn-shadow)]' : 'pixel-tactile-btn border border-[var(--desk-border)] text-[var(--text-body)] hover:text-[var(--text-heading)]'}`,
                                        children: tools.bucketContiguous ? 'Contiguous' : 'Global Replace'
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 473,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "flex items-center gap-1 shrink-0 text-[10px]",
                                        title: "Include nearby shades when filling imported or shaded artwork. Lower this if the fill crosses an outline.",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[var(--text-muted)]",
                                                children: "Tolerance:"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 485,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "range",
                                                min: "0",
                                                max: "255",
                                                step: "1",
                                                value: tools.fillTolerance,
                                                onChange: (event)=>setFillTolerance(Number(event.target.value)),
                                                "aria-label": "Bucket fill tolerance",
                                                className: "w-20 h-6 accent-[var(--accent-gold)] cursor-pointer"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 486,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-mono text-[var(--text-heading)] min-w-[22px] text-right tabular-nums",
                                                children: tools.fillTolerance
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 491,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 484,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    tools.bucketContiguous && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setFillEnclosedSpecks(!tools.fillEnclosedSpecks),
                                        "aria-label": "Fill enclosed specks",
                                        "aria-pressed": tools.fillEnclosedSpecks,
                                        title: "Also fill color islands of up to 8 pixels fully enclosed by the filled area. Can replace small intentional details.",
                                        className: `h-6 px-1.5 text-[9px] font-bold rounded-[1px] cursor-pointer shrink-0 ${tools.fillEnclosedSpecks ? 'pixel-primary-btn' : 'pixel-tactile-btn border border-[var(--desk-border)] text-[var(--text-body)]'}`,
                                        children: [
                                            "Enclosed specks: ",
                                            tools.fillEnclosedSpecks ? 'On' : 'Off'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 493,
                                        columnNumber: 42
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 472,
                                columnNumber: 48
                            }, ("TURBOPACK compile-time value", void 0)),
                            tools.activeTool === 'color-replace' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1.5 shrink-0 text-[10px]",
                                title: "Replaces matching colors on the active layer. Increase tolerance to include similar shades; transparent pixels and other layers are preserved.",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[var(--text-muted)]",
                                        children: "Active layer · Tolerance:"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 505,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        min: "0",
                                        max: "255",
                                        step: "1",
                                        value: tools.bucketTolerance,
                                        onChange: (e)=>setBucketTolerance(Number(e.target.value)),
                                        "aria-label": "Color Replace tolerance",
                                        className: "w-24 h-6 accent-[var(--accent-gold)] cursor-pointer"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 506,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-mono text-[var(--text-heading)] min-w-[22px] text-right tabular-nums",
                                        children: tools.bucketTolerance
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 516,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 504,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            tools.activeTool === 'erase-color' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap items-center gap-1.5 text-[10px]",
                                title: "Click a visible color to make matching pixels transparent. All frames edits the same layer position in each frame, skipping locked layers. Undo restores the artwork.",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[var(--text-muted)]",
                                        children: "Erase color · Tolerance:"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 522,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        min: "0",
                                        max: "255",
                                        step: "1",
                                        value: tools.eraseColorTolerance,
                                        onChange: (event)=>setEraseColorTolerance(Number(event.target.value)),
                                        "aria-label": "Erase Color tolerance",
                                        className: "w-20 h-6 accent-[var(--accent-gold)] cursor-pointer"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 523,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-mono text-[var(--text-heading)] min-w-[22px] text-right tabular-nums",
                                        children: tools.eraseColorTolerance
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 528,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setEraseColorContiguous(!tools.eraseColorContiguous),
                                        "aria-label": "Erase Color matching mode",
                                        className: "h-6 px-1.5 pixel-tactile-btn text-[9px] font-bold cursor-pointer",
                                        children: tools.eraseColorContiguous ? 'Connected' : 'All matches'
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 529,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setEraseColorFamily(!tools.eraseColorFamily),
                                        "aria-label": "Erase Color family mode",
                                        "aria-pressed": tools.eraseColorFamily,
                                        title: "Remove shades of the clicked color, including dark edge spill. The tolerance slider widens the hue range. Enabling this also searches all matching pixels; neutral outlines are protected.",
                                        className: "h-6 px-1.5 pixel-tactile-btn text-[9px] font-bold cursor-pointer",
                                        children: tools.eraseColorFamily ? 'Color family: On' : 'Color family: Off'
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 534,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setEraseColorAllFrames(!tools.eraseColorAllFrames),
                                        "aria-label": "Erase Color frame scope",
                                        "aria-pressed": tools.eraseColorAllFrames,
                                        "data-testid": "erase-color-frame-scope",
                                        title: "Erase Color frame scope: Erase color across all animation frames or active frame only",
                                        className: `h-6 px-1.5 text-[9px] font-bold rounded-[1px] cursor-pointer shrink-0 transition-all ${tools.eraseColorAllFrames ? 'pixel-primary-btn shadow-[0_1px_0_var(--btn-shadow)]' : 'pixel-tactile-btn border border-[var(--desk-border)] text-[var(--text-body)] hover:text-[var(--text-heading)]'}`,
                                        children: tools.eraseColorAllFrames ? 'All frames' : 'This frame'
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 541,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 521,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            tools.activeTool === 'dither' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1.5 shrink-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: tools.ditherMatrix,
                                        "aria-label": "Dither matrix algorithm",
                                        onChange: (e)=>setDitherMatrix(e.target.value),
                                        className: "h-6 bg-[var(--surface-0)] text-[var(--accent-gold)] text-[9px] px-1.5 py-0 rounded-[1px] border border-[var(--desk-border)] outline-none cursor-pointer",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "2x2",
                                                children: "Bayer 2x2"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 568,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "4x4",
                                                children: "Bayer 4x4"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 569,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "8x8",
                                                children: "Bayer 8x8"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 570,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "blue-noise",
                                                children: "Blue Noise"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 571,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "atkinson",
                                                children: "Atkinson"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 572,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 562,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        min: "0.1",
                                        max: "0.9",
                                        step: "0.05",
                                        value: tools.ditherDensity,
                                        onChange: (e)=>setDitherDensity(parseFloat(e.target.value)),
                                        "aria-label": "Dither density",
                                        className: "w-12 h-6 accent-[var(--accent-gold)] cursor-pointer"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 574,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 561,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            (tools.activeTool === 'rectangle' || tools.activeTool === 'ellipse') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setShapeFilled(!tools.shapeFilled),
                                "aria-label": tools.shapeFilled ? 'Shape: Filled Solid' : 'Shape: Outline Stroke',
                                "data-testid": "shape-fill-toggle",
                                className: `h-6 px-1.5 text-[9px] font-bold rounded-[1px] cursor-pointer shrink-0 flex items-center justify-center transition-all ${tools.shapeFilled ? 'pixel-primary-btn shadow-[0_1px_0_var(--btn-shadow)]' : 'pixel-tactile-btn border border-[var(--desk-border)] text-[var(--text-body)] hover:text-[var(--text-heading)]'}`,
                                children: tools.shapeFilled ? 'Filled' : 'Outline'
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 589,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            tools.activeTool === 'isometric-line' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setIsoAngleSnap(!tools.isoAngleSnap),
                                "aria-pressed": tools.isoAngleSnap,
                                title: "Snap to a 2:1 pixel slope, or choose FREE to follow your drag",
                                className: `h-6 px-1.5 text-[9px] font-bold rounded-[1px] cursor-pointer shrink-0 flex items-center justify-center transition-all ${tools.isoAngleSnap ? 'pixel-primary-btn shadow-[0_1px_0_var(--btn-shadow)]' : 'pixel-tactile-btn border border-[var(--desk-border)] text-[var(--text-body)] hover:text-[var(--text-heading)]'}`,
                                children: [
                                    "2:1 Snap: ",
                                    tools.isoAngleSnap ? 'ON' : 'FREE'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 605,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 397,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)) : null
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                lineNumber: 389,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "ml-auto flex shrink-0 items-center gap-2 xl:gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        role: "group",
                        "aria-label": "Canvas controls",
                        className: "h-7 flex items-center bg-[var(--surface-0)] border border-[var(--desk-border)] rounded-[2px] p-px text-xs",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                role: "group",
                                "aria-label": "Mirror drawing",
                                className: "h-6 flex items-center gap-0.5 px-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "px-1 text-[10px] text-[var(--text-body)]",
                                        children: "Mirror"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 626,
                                        columnNumber: 11
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioTooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        position: "bottom",
                                        content: `Horizontal symmetry (Shift+H) — ${tools.symmetryHorizontal ? 'Active' : 'Off'}`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: toggleSymmetryH,
                                            "aria-label": "Horizontal symmetry",
                                            "aria-pressed": tools.symmetryHorizontal,
                                            "data-testid": "toggle-symmetry-h",
                                            className: `w-6 h-6 rounded-[2px] cursor-pointer flex items-center justify-center transition-all active:translate-y-[1px] ${tools.symmetryHorizontal ? 'bg-[var(--surface-3)] text-[var(--accent-gold)] border border-[var(--accent-gold)]/60 shadow-xs font-bold' : 'text-[var(--text-muted)] hover:text-[var(--text-heading)] hover:bg-[var(--surface-2)] border border-transparent hover:border-[var(--desk-border)]/50'}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                name: "symmetry-h",
                                                size: 13
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 639,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                            lineNumber: 628,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 627,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioTooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        position: "bottom",
                                        content: `Vertical symmetry (Shift+V) — ${tools.symmetryVertical ? 'Active' : 'Off'}`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: toggleSymmetryV,
                                            "aria-label": "Vertical symmetry",
                                            "aria-pressed": tools.symmetryVertical,
                                            "data-testid": "toggle-symmetry-v",
                                            className: `w-6 h-6 rounded-[2px] cursor-pointer flex items-center justify-center transition-all active:translate-y-[1px] ${tools.symmetryVertical ? 'bg-[var(--surface-3)] text-[var(--accent-gold)] border border-[var(--accent-gold)]/60 shadow-xs font-bold' : 'text-[var(--text-muted)] hover:text-[var(--text-heading)] hover:bg-[var(--surface-2)] border border-transparent hover:border-[var(--desk-border)]/50'}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                name: "symmetry-v",
                                                size: 13
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 655,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                            lineNumber: 644,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 643,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 625,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "aria-hidden": "true",
                                className: "w-px h-3.5 bg-[var(--desk-border)] mx-0.5"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 660,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setZoom((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPrevZoomStep"])(zoom)),
                                                className: "w-6 h-6 flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--text-heading)] hover:bg-[var(--surface-2)] active:translate-y-[1px] rounded-[1px] cursor-pointer font-mono text-xs transition-colors",
                                                title: "Zoom Out (-)",
                                                "aria-label": "Zoom Out",
                                                children: "−"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 664,
                                                columnNumber: 13
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                ref: zoomMenuRef,
                                                className: "relative",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        onClick: ()=>setIsZoomMenuOpen((open)=>!open),
                                                        "aria-label": `Zoom ${zoom} percent. Choose zoom level`,
                                                        "aria-expanded": isZoomMenuOpen,
                                                        className: "h-6 px-1.5 min-w-[52px] text-center text-[var(--text-heading)] font-mono text-xs font-semibold tabular-nums hover:bg-[var(--surface-2)]",
                                                        children: [
                                                            zoom,
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 673,
                                                        columnNumber: 15
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    isZoomMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        role: "group",
                                                        "aria-label": "Zoom levels",
                                                        className: "absolute top-full right-0 mt-1 z-[100] w-28 bg-[var(--surface-2)] border border-[var(--desk-border-highlight)] rounded-[2px] p-1 shadow-lg",
                                                        children: [
                                                            100,
                                                            200,
                                                            400,
                                                            800,
                                                            1600
                                                        ].map((level)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: ()=>{
                                                                    setZoom(level);
                                                                    setIsZoomMenuOpen(false);
                                                                },
                                                                className: "block w-full text-left px-2 py-1.5 text-xs font-mono text-[var(--text-body)] hover:bg-[var(--surface-3)] hover:text-[var(--text-heading)]",
                                                                children: [
                                                                    level,
                                                                    "%",
                                                                    level === 100 ? ' · Actual size' : ''
                                                                ]
                                                            }, level, true, {
                                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                                lineNumber: 683,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0)))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 680,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 672,
                                                columnNumber: 13
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setZoom((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNextZoomStep"])(zoom)),
                                                className: "w-6 h-6 flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--text-heading)] hover:bg-[var(--surface-2)] active:translate-y-[1px] rounded-[1px] cursor-pointer font-mono text-xs transition-colors",
                                                title: "Zoom In (+)",
                                                "aria-label": "Zoom In",
                                                children: "+"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 691,
                                                columnNumber: 13
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 663,
                                        columnNumber: 11
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-px h-3.5 bg-[var(--desk-border)] mx-0.5"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 701,
                                        columnNumber: 11
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            const targetZoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateFitZoom"])(canvasWidth, canvasHeight);
                                            setZoom(targetZoom);
                                            setPan(0, 0);
                                        },
                                        "aria-label": "Fit Canvas to Viewport (Ctrl+0)",
                                        "data-testid": "fit-canvas-button",
                                        className: "h-6 px-1.5 flex items-center justify-center text-xs font-sans font-medium text-[var(--text-body)] hover:text-[var(--text-heading)] hover:bg-[var(--surface-2)] active:translate-y-[1px] rounded-[1px] cursor-pointer transition-colors",
                                        title: "Fit Canvas to Viewport (Ctrl+0)",
                                        children: "Fit"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 704,
                                        columnNumber: 11
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 661,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "aria-hidden": "true",
                                className: "w-px h-3.5 bg-[var(--desk-border)] mx-0.5"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 719,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    ref: viewMenuRef,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleToggleViewMenu,
                                        title: "Canvas view options (Grids, guides, previews, lenses, symmetry)",
                                        "aria-label": "View options menu",
                                        "aria-expanded": isViewMenuOpen,
                                        className: `h-6 px-2 min-w-[66px] text-xs font-sans font-medium rounded-[1px] cursor-pointer flex items-center justify-between gap-1.5 transition-colors ${isViewMenuOpen ? 'bg-[var(--surface-2)] text-[var(--accent-gold)]' : 'text-[var(--text-body)] hover:text-[var(--text-heading)] hover:bg-[var(--surface-2)] active:translate-y-[1px]'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex items-center gap-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                        name: "eye",
                                                        size: 12,
                                                        className: isViewMenuOpen ? 'text-[var(--accent-wisteria)]' : 'text-[var(--text-muted)]'
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 736,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "View"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 741,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    activeViewModifiers > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "w-1.5 h-1.5 rounded-full bg-[var(--accent-wisteria)] shrink-0",
                                                        title: `${activeViewModifiers} active view options`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 743,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 735,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[8px] text-[var(--text-muted)] ml-0.5",
                                                children: "▼"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 749,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 724,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                    lineNumber: 723,
                                    columnNumber: 11
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 720,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 624,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        role: "group",
                        "aria-label": "Studio settings and help",
                        className: "h-7 flex items-center text-xs border-l border-[var(--desk-border)] pl-2 xl:pl-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$AppearancePopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AppearancePopover"], {
                            label: "Studio",
                            actions: [
                                {
                                    label: 'Co-Draw',
                                    icon: 'sparkles',
                                    ariaLabel: 'Co-Draw session',
                                    onSelect: onOpenCoDraw
                                },
                                {
                                    label: 'Help',
                                    icon: 'help',
                                    ariaLabel: 'Atelier Guide, Diagnostics and Shortcuts',
                                    testId: 'shortcuts-guide-button',
                                    onSelect: onOpenShortcuts
                                }
                            ]
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/AtelierRail.tsx",
                            lineNumber: 757,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 756,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-7 flex items-center gap-1 text-xs",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                            size: "sm",
                            variant: "primary",
                            onClick: onOpenExport,
                            title: "Export PNG, GIF, or Spritesheet",
                            "aria-label": "Export drawing",
                            "data-testid": "export-button",
                            className: "h-7 px-2.5 text-xs font-bold font-sans tracking-wide flex items-center gap-1.5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: "export",
                                    size: 12,
                                    className: "text-[#16141a]"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                    lineNumber: 774,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Export"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                    lineNumber: 775,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/AtelierRail.tsx",
                            lineNumber: 765,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 764,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                lineNumber: 623,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "file",
                ref: fileInputRef,
                onChange: handleFileChange,
                accept: ".pixibun,.json,image/png,image/jpeg,image/webp",
                className: "hidden",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                lineNumber: 781,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            isViewMenuOpen && isMounted && popoverCoords && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: popoverRef,
                role: "region",
                "aria-label": "View options menu",
                style: {
                    position: 'fixed',
                    top: `${popoverCoords.top}px`,
                    right: `${popoverCoords.right}px`,
                    zIndex: 9999
                },
                className: "w-64 bg-[var(--surface-2)] border border-[var(--desk-border-highlight)] rounded-[2px] shadow-[0_8px_24px_rgba(0,0,0,0.7)] p-2.5 flex flex-col gap-2 text-xs font-sans select-none animate-in fade-in duration-100",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between pb-1 border-b border-[var(--desk-border)]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-bold tracking-wider text-[var(--text-heading)]",
                                children: "View Options"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 805,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[9px] text-[var(--text-muted)]",
                                children: "ESC to close"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 808,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 804,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-sans font-medium text-[var(--text-muted)]",
                                children: "Grids & Guides"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 813,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: toggleGrid,
                                        className: `pixel-tactile-btn px-2 py-1 text-[10px] font-medium rounded-[2px] border flex items-center justify-between cursor-pointer transition-colors ${showGrid ? 'bg-[var(--surface-3)] text-[var(--text-heading)] border-[var(--desk-border-highlight)] shadow-inner font-semibold' : 'bg-[var(--surface-0)] text-[var(--text-muted)] border-[var(--desk-border)] hover:text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex items-center gap-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `w-1.5 h-1.5 rounded-[1px] ${showGrid ? 'bg-[var(--accent-wisteria)]' : 'bg-transparent border border-[var(--desk-border)]'}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 824,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                        name: "grid-iso",
                                                        size: 11
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 825,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Pixel Grid"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 826,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 823,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[8px] font-mono opacity-70",
                                                children: "Ctrl+'"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 828,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 815,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: toggleIsoGuides,
                                        className: `pixel-tactile-btn px-2 py-1 text-[10px] font-medium rounded-[2px] border flex items-center justify-between cursor-pointer transition-colors ${showIsoGuides ? 'bg-[var(--surface-3)] text-[var(--text-heading)] border-[var(--desk-border-highlight)] shadow-inner font-semibold' : 'bg-[var(--surface-0)] text-[var(--text-muted)] border-[var(--desk-border)] hover:text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]'}`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-1.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: `w-1.5 h-1.5 rounded-[1px] ${showIsoGuides ? 'bg-[var(--accent-wisteria)]' : 'bg-transparent border border-[var(--desk-border)]'}`
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                    lineNumber: 840,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                    name: "grid-iso",
                                                    size: 11
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                    lineNumber: 841,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "2:1 Iso Grid"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                    lineNumber: 842,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                            lineNumber: 839,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 831,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 814,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: cycleReferenceOverlay,
                                className: `pixel-tactile-btn w-full px-2 py-1 text-[10px] font-medium rounded-[2px] border flex items-center justify-between cursor-pointer mt-0.5 transition-colors ${referenceOverlay !== 'none' ? 'bg-[var(--surface-3)] text-[var(--text-heading)] border-[var(--desk-border-highlight)] shadow-inner font-semibold' : 'bg-[var(--surface-0)] text-[var(--text-muted)] border-[var(--desk-border)] hover:text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `w-1.5 h-1.5 rounded-[1px] ${referenceOverlay !== 'none' ? 'bg-[var(--accent-wisteria)]' : 'bg-transparent border border-[var(--desk-border)]'}`
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 857,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                name: "grid",
                                                size: 11
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 858,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Composition Overlay"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 859,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 856,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[9px] text-[var(--text-heading)] font-medium",
                                        children: referenceOverlay === 'none' ? 'Off' : referenceOverlay === 'thirds' ? 'Thirds' : referenceOverlay === 'golden' ? 'Golden' : 'Center'
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 861,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 848,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 812,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-px bg-[var(--desk-border)]"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 867,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-sans font-medium text-[var(--text-muted)]",
                                children: "Previews"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 871,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: toggleTilePreview,
                                        className: `pixel-tactile-btn px-2 py-1 text-[10px] font-medium rounded-[2px] border flex items-center justify-between cursor-pointer transition-colors ${showTilePreview ? 'bg-[var(--surface-3)] text-[var(--text-heading)] border-[var(--desk-border-highlight)] shadow-inner font-semibold' : 'bg-[var(--surface-0)] text-[var(--text-muted)] border-[var(--desk-border)] hover:text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]'}`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-1.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: `w-1.5 h-1.5 rounded-[1px] ${showTilePreview ? 'bg-[var(--accent-wisteria)]' : 'bg-transparent border border-[var(--desk-border)]'}`
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                    lineNumber: 882,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                    name: "grid-iso",
                                                    size: 11
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                    lineNumber: 883,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "3x3 Tiling"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                    lineNumber: 884,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                            lineNumber: 881,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 873,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: toggleFloatingPreview,
                                        "aria-label": "Toggle Live PiP Preview Window",
                                        className: `pixel-tactile-btn px-2 py-1 text-[10px] font-medium rounded-[2px] border flex items-center justify-between cursor-pointer transition-colors ${showFloatingPreview ? 'bg-[var(--surface-3)] text-[var(--text-heading)] border-[var(--desk-border-highlight)] shadow-inner font-semibold' : 'bg-[var(--surface-0)] text-[var(--text-muted)] border-[var(--desk-border)] hover:text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]'}`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-1.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: `w-1.5 h-1.5 rounded-[1px] ${showFloatingPreview ? 'bg-[var(--accent-wisteria)]' : 'bg-transparent border border-[var(--desk-border)]'}`
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                    lineNumber: 898,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                    name: "preview",
                                                    size: 11
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                    lineNumber: 899,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "Live PiP"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                    lineNumber: 900,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                            lineNumber: 897,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 888,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 872,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 870,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-px bg-[var(--desk-border)]"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 906,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-sans font-medium text-[var(--text-muted)]",
                                children: "Perceptual Lenses"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 910,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setCvdLens((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cycleCvdLens"])(cvdLens)),
                                        title: CVD_LENS_TITLES[cvdLens],
                                        className: `pixel-tactile-btn px-2 py-1 text-[10px] font-medium rounded-[2px] border flex items-center justify-between cursor-pointer transition-colors ${cvdLens !== 'none' ? 'bg-[var(--surface-3)] text-[var(--text-heading)] border-[var(--desk-border-highlight)] shadow-inner font-semibold' : 'bg-[var(--surface-0)] text-[var(--text-muted)] border-[var(--desk-border)] hover:text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex items-center gap-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `w-1.5 h-1.5 rounded-[1px] ${cvdLens !== 'none' ? 'bg-[var(--accent-wisteria)]' : 'bg-transparent border border-[var(--desk-border)]'}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 922,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                        name: "eyedropper",
                                                        size: 11
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 923,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: [
                                                            "CVD: ",
                                                            CVD_LENS_BUTTON_LABELS[cvdLens]
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 924,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 921,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[8px] font-mono opacity-70",
                                                children: "P"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 926,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 912,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: toggleSquintMode,
                                        title: "Silhouette / Squint Mode (S)",
                                        className: `pixel-tactile-btn px-2 py-1 text-[10px] font-medium rounded-[2px] border flex items-center justify-between cursor-pointer transition-colors ${squintMode ? 'bg-[var(--surface-3)] text-[var(--text-heading)] border-[var(--desk-border-highlight)] shadow-inner font-semibold' : 'bg-[var(--surface-0)] text-[var(--text-muted)] border-[var(--desk-border)] hover:text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex items-center gap-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `w-1.5 h-1.5 rounded-[1px] ${squintMode ? 'bg-[var(--accent-wisteria)]' : 'bg-transparent border border-[var(--desk-border)]'}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 939,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                        name: "select-box",
                                                        size: 11
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 940,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Silhouette"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 941,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 938,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[8px] font-mono opacity-70",
                                                children: "S"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 943,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 929,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 911,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 909,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-px bg-[var(--desk-border)]"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 948,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-sans font-medium text-[var(--text-muted)]",
                                children: "Symmetry & Mirroring"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 952,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: toggleSymmetryH,
                                        className: `pixel-tactile-btn px-2 py-1 text-[10px] font-medium rounded-[2px] border flex items-center justify-between cursor-pointer transition-colors ${tools.symmetryHorizontal ? 'bg-[var(--surface-3)] text-[var(--text-heading)] border-[var(--desk-border-highlight)] shadow-inner font-semibold' : 'bg-[var(--surface-0)] text-[var(--text-muted)] border-[var(--desk-border)] hover:text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex items-center gap-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `w-1.5 h-1.5 rounded-[1px] ${tools.symmetryHorizontal ? 'bg-[var(--accent-gold)]' : 'bg-transparent border border-[var(--desk-border)]'}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 963,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                        name: "symmetry-h",
                                                        size: 11
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 964,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Mirror H"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 965,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 962,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[8px] font-mono opacity-70",
                                                children: "Shift+H"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 967,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 954,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: toggleSymmetryV,
                                        className: `pixel-tactile-btn px-2 py-1 text-[10px] font-medium rounded-[2px] border flex items-center justify-between cursor-pointer transition-colors ${tools.symmetryVertical ? 'bg-[var(--surface-3)] text-[var(--text-heading)] border-[var(--desk-border-highlight)] shadow-inner font-semibold' : 'bg-[var(--surface-0)] text-[var(--text-muted)] border-[var(--desk-border)] hover:text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex items-center gap-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `w-1.5 h-1.5 rounded-[1px] ${tools.symmetryVertical ? 'bg-[var(--accent-gold)]' : 'bg-transparent border border-[var(--desk-border)]'}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 979,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                        name: "symmetry-v",
                                                        size: 11
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 980,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Mirror V"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                        lineNumber: 981,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 978,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[8px] font-mono opacity-70",
                                                children: "Shift+V"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 983,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 970,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 953,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1 mt-0.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[9px] text-[var(--text-muted)] uppercase font-bold shrink-0",
                                        children: "Group:"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 989,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: tools.symmetryGroup || 'none',
                                        "aria-label": "Wallpaper group symmetry brush mode",
                                        onChange: (e)=>setSymmetryGroup(e.target.value),
                                        className: "w-full bg-[var(--surface-0)] text-[var(--text-heading)] font-medium text-[10px] px-1.5 py-0.5 rounded-[2px] border border-[var(--desk-border)] outline-none cursor-pointer hover:border-[var(--desk-border-highlight)]",
                                        title: "Crystallographic Wallpaper Group Symmetry Brush (Schattschneider 1978): p2, pm, p4, p4m, p6m",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "none",
                                                children: "None (Standard)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 997,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "p2",
                                                children: "p2 (180° Rotational)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 998,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "pm",
                                                children: "pm (Mirror Reflection)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 999,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "p4",
                                                children: "p4 (4-Fold 90° Rotational)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 1000,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "p4m",
                                                children: "p4m (8-Way Dihedral D4)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 1001,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "p6m",
                                                children: "p6m (12-Way Hexagonal D6)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                                lineNumber: 1002,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                        lineNumber: 990,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                                lineNumber: 988,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/AtelierRail.tsx",
                        lineNumber: 951,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/AtelierRail.tsx",
                lineNumber: 792,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)), document.body)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/AtelierRail.tsx",
        lineNumber: 252,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(AtelierRail, "R16/tRkiQWgHbpgz8F9IQTImaNc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = AtelierRail;
var _c;
__turbopack_context__.k.register(_c, "AtelierRail");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/BottomTimeline.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BottomTimeline",
    ()=>BottomTimeline
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/TactileButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/render/compositor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$modals$2f$TagManagerModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/modals/TagManagerModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useCoDrawStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useCoDrawStatus.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/animationTiming.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$export$2f$animationModel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/export/animationModel.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const FrameThumbnail = ({ frameIndex })=>{
    _s();
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const canvasWidth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FrameThumbnail.useStudioStore[canvasWidth]": (state)=>state.canvasWidth
    }["FrameThumbnail.useStudioStore[canvasWidth]"]);
    const canvasHeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FrameThumbnail.useStudioStore[canvasHeight]": (state)=>state.canvasHeight
    }["FrameThumbnail.useStudioStore[canvasHeight]"]);
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FrameThumbnail.useStudioStore[frames]": (state)=>state.frames
    }["FrameThumbnail.useStudioStore[frames]"]);
    const bufferVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FrameThumbnail.useStudioStore[bufferVersion]": (state)=>state.bufferVersion
    }["FrameThumbnail.useStudioStore[bufferVersion]"]);
    const currentProjectId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FrameThumbnail.useStudioStore[currentProjectId]": (state)=>state.currentProjectId
    }["FrameThumbnail.useStudioStore[currentProjectId]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FrameThumbnail.useEffect": ()=>{
            const canvas = canvasRef.current;
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            if (!ctx) return;
            ctx.clearRect(0, 0, canvasWidth, canvasHeight);
            ctx.imageSmoothingEnabled = false;
            const comp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compositeFrame"])(frames, frameIndex, canvasWidth, canvasHeight);
            if (comp) {
                ctx.drawImage(comp, 0, 0);
            }
        }
    }["FrameThumbnail.useEffect"], [
        frameIndex,
        canvasWidth,
        canvasHeight,
        frames,
        currentProjectId,
        bufferVersion
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-6 h-6 bg-[var(--desk-surface-raised)] border border-[var(--desk-border)] rounded-[1px] flex items-center justify-center overflow-hidden",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
            ref: canvasRef,
            width: canvasWidth,
            height: canvasHeight,
            "data-testid": `frame-thumbnail-${frameIndex}`,
            className: "w-full h-full pixelated"
        }, void 0, false, {
            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
            lineNumber: 52,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(FrameThumbnail, "VryPBLCX8j3VUB1UAa3opF1SQXo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c = FrameThumbnail;
const FrameScrubPreview = ({ frameIndex, duration, layerCount, anchor })=>{
    _s1();
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const canvasWidth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FrameScrubPreview.useStudioStore[canvasWidth]": (state)=>state.canvasWidth
    }["FrameScrubPreview.useStudioStore[canvasWidth]"]);
    const canvasHeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FrameScrubPreview.useStudioStore[canvasHeight]": (state)=>state.canvasHeight
    }["FrameScrubPreview.useStudioStore[canvasHeight]"]);
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FrameScrubPreview.useStudioStore[frames]": (state)=>state.frames
    }["FrameScrubPreview.useStudioStore[frames]"]);
    const bufferVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "FrameScrubPreview.useStudioStore[bufferVersion]": (state)=>state.bufferVersion
    }["FrameScrubPreview.useStudioStore[bufferVersion]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FrameScrubPreview.useEffect": ()=>{
            const canvas = canvasRef.current;
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            if (!ctx) return;
            ctx.clearRect(0, 0, canvasWidth, canvasHeight);
            ctx.imageSmoothingEnabled = false;
            const comp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compositeFrame"])(frames, frameIndex, canvasWidth, canvasHeight);
            if (comp) {
                ctx.drawImage(comp, 0, 0);
            }
        }
    }["FrameScrubPreview.useEffect"], [
        frameIndex,
        canvasWidth,
        canvasHeight,
        frames,
        bufferVersion
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "tooltip",
        style: {
            left: Math.max(8, Math.min(window.innerWidth - 120, anchor.x - 56)),
            top: Math.max(8, anchor.y - 168)
        },
        className: "fixed z-[100] pointer-events-none flex flex-col items-center gap-1.5 p-2 bg-[var(--surface-3)] border-2 border-[var(--desk-border)] rounded-[var(--radius-md)] shadow-[0_8px_20px_rgba(0,0,0,0.5)] animate-in fade-in zoom-in-95 duration-100 whitespace-nowrap",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-24 h-24 bg-[var(--surface-0)] border border-[var(--desk-border)] rounded-[2px] overflow-hidden flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                    ref: canvasRef,
                    width: canvasWidth,
                    height: canvasHeight,
                    className: "w-full h-full object-contain pixelated"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                    lineNumber: 97,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                lineNumber: 96,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between w-full px-0.5 text-[10px] font-mono text-[var(--text-heading)]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[var(--accent-gold)] font-bold",
                        children: [
                            "Frame #",
                            frameIndex + 1
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                        lineNumber: 105,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[var(--text-muted)]",
                        children: [
                            duration,
                            "ms"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-[9px] font-mono text-[var(--text-muted)] w-full text-left px-0.5",
                children: [
                    layerCount,
                    " ",
                    layerCount === 1 ? 'layer' : 'layers'
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                lineNumber: 108,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
        lineNumber: 91,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(FrameScrubPreview, "XAld0Rq9M6+gHNJg2Glxf0FPCwI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c1 = FrameScrubPreview;
const BottomTimeline = ({ isPlaygroundMode = false })=>{
    _s2();
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[frames]": (s)=>s.frames
    }["BottomTimeline.useStudioStore[frames]"]);
    const activeFrameIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[activeFrameIndex]": (s)=>s.activeFrameIndex
    }["BottomTimeline.useStudioStore[activeFrameIndex]"]);
    const currentProjectId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[currentProjectId]": (s)=>s.currentProjectId
    }["BottomTimeline.useStudioStore[currentProjectId]"]);
    const setActiveFrame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[setActiveFrame]": (s)=>s.setActiveFrame
    }["BottomTimeline.useStudioStore[setActiveFrame]"]);
    const reorderFrames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[reorderFrames]": (s)=>s.reorderFrames
    }["BottomTimeline.useStudioStore[reorderFrames]"]);
    const addFrame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[addFrame]": (s)=>s.addFrame
    }["BottomTimeline.useStudioStore[addFrame]"]);
    const duplicateFrame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[duplicateFrame]": (s)=>s.duplicateFrame
    }["BottomTimeline.useStudioStore[duplicateFrame]"]);
    const deleteFrame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[deleteFrame]": (s)=>s.deleteFrame
    }["BottomTimeline.useStudioStore[deleteFrame]"]);
    const setFrameDuration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[setFrameDuration]": (s)=>s.setFrameDuration
    }["BottomTimeline.useStudioStore[setFrameDuration]"]);
    const durationGestureFrameRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BottomTimeline.useEffect": ()=>{
            durationGestureFrameRef.current = null;
        }
    }["BottomTimeline.useEffect"], [
        activeFrameIndex,
        currentProjectId
    ]);
    const isPlaying = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[isPlaying]": (s)=>s.isPlaying
    }["BottomTimeline.useStudioStore[isPlaying]"]);
    const setIsPlaying = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[setIsPlaying]": (s)=>s.setIsPlaying
    }["BottomTimeline.useStudioStore[setIsPlaying]"]);
    const fps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[fps]": (s)=>s.fps
    }["BottomTimeline.useStudioStore[fps]"]);
    const loopMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[loopMode]": (s)=>s.loopMode
    }["BottomTimeline.useStudioStore[loopMode]"]);
    const setLoopMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[setLoopMode]": (s)=>s.setLoopMode
    }["BottomTimeline.useStudioStore[setLoopMode]"]);
    const onionSkin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[onionSkin]": (s)=>s.onionSkin
    }["BottomTimeline.useStudioStore[onionSkin]"]);
    const setOnionSkin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[setOnionSkin]": (s)=>s.setOnionSkin
    }["BottomTimeline.useStudioStore[setOnionSkin]"]);
    const onionNotice = onionSkin.enabled ? frames.length <= 1 ? 'Add another frame to see neighboring drawings.' : isPlaying ? 'Pause to see onion skin while editing.' : null : null;
    const clips = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[clips]": (s)=>s.clips
    }["BottomTimeline.useStudioStore[clips]"]);
    const activeClipId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[activeClipId]": (s)=>s.activeClipId
    }["BottomTimeline.useStudioStore[activeClipId]"]);
    const setActiveClipId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "BottomTimeline.useStudioStore[setActiveClipId]": (s)=>s.setActiveClipId
    }["BottomTimeline.useStudioStore[setActiveClipId]"]);
    const { isGuest } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useCoDrawStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCoDrawStatus"])();
    const guestFrameLockTitle = 'Frame structure is managed by the session host.';
    const [isTagManagerOpen, setIsTagManagerOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [draggedFrameIndex, setDraggedFrameIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [dragOverFrameIndex, setDragOverFrameIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [hoveredFrameIndex, setHoveredFrameIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [hoverPreviewAnchor, setHoverPreviewAnchor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isCollapsed, setIsCollapsed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [previewSpeed, setPreviewSpeed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [isPreviewMenuOpen, setIsPreviewMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const previewMenuRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const previewSpeedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(previewSpeed);
    previewSpeedRef.current = previewSpeed;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BottomTimeline.useEffect": ()=>{
            if (!isPreviewMenuOpen) return;
            const closeOutside = {
                "BottomTimeline.useEffect.closeOutside": (event)=>{
                    if (!previewMenuRef.current?.contains(event.target)) setIsPreviewMenuOpen(false);
                }
            }["BottomTimeline.useEffect.closeOutside"];
            const closeOnEscape = {
                "BottomTimeline.useEffect.closeOnEscape": (event)=>{
                    if (event.key === 'Escape') setIsPreviewMenuOpen(false);
                }
            }["BottomTimeline.useEffect.closeOnEscape"];
            document.addEventListener('mousedown', closeOutside);
            document.addEventListener('keydown', closeOnEscape);
            return ({
                "BottomTimeline.useEffect": ()=>{
                    document.removeEventListener('mousedown', closeOutside);
                    document.removeEventListener('keydown', closeOnEscape);
                }
            })["BottomTimeline.useEffect"];
        }
    }["BottomTimeline.useEffect"], [
        isPreviewMenuOpen
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BottomTimeline.useEffect": ()=>{
            try {
                if ("TURBOPACK compile-time truthy", 1) {
                    const stored = localStorage.getItem('pixibun:timeline-collapsed');
                    if (stored === 'true') {
                        setIsCollapsed(true);
                    }
                }
            } catch  {
            // Ignore localStorage access errors
            }
        }
    }["BottomTimeline.useEffect"], []);
    const toggleCollapsed = ()=>{
        setIsCollapsed((prev)=>{
            const next = !prev;
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem('pixibun:timeline-collapsed', String(next));
            }
            return next;
        });
    };
    const activeClip = clips.find((c)=>c.id === activeClipId);
    // Frame Drag-and-Drop Reordering Handlers
    const handleDragStart = (e, index)=>{
        if (isGuest) {
            e.preventDefault();
            return;
        }
        e.dataTransfer.setData('text/plain', String(index));
        e.dataTransfer.effectAllowed = 'move';
        setDraggedFrameIndex(index);
    };
    const handleDragOver = (e, index)=>{
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        if (dragOverFrameIndex !== index) {
            setDragOverFrameIndex(index);
        }
    };
    const handleDragLeave = (e, index)=>{
        if (e.currentTarget.contains(e.relatedTarget)) return;
        if (dragOverFrameIndex === index) {
            setDragOverFrameIndex(null);
        }
    };
    const handleDrop = (e, targetIndex)=>{
        e.preventDefault();
        const sourceIndexStr = e.dataTransfer.getData('text/plain');
        const sourceIndex = sourceIndexStr ? parseInt(sourceIndexStr, 10) : draggedFrameIndex;
        if (sourceIndex !== null && !isNaN(sourceIndex) && sourceIndex !== targetIndex) {
            reorderFrames(sourceIndex, targetIndex);
        }
        setDraggedFrameIndex(null);
        setDragOverFrameIndex(null);
    };
    const handleDragEnd = ()=>{
        setDraggedFrameIndex(null);
        setDragOverFrameIndex(null);
    };
    // Keep one clock for the playback session. Frame changes must not discard elapsed time.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BottomTimeline.useEffect": ()=>{
            if (!isPlaying) return;
            let lastTimestamp = null;
            let accumulator = 0;
            let animFrameId;
            let sequenceKey = '', position = 0;
            let sequence = [];
            let publishedIndex = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().activeFrameIndex;
            const onVisibilityChange = {
                "BottomTimeline.useEffect.onVisibilityChange": ()=>{
                    // A background tab is suspended; resume without replaying hidden time.
                    lastTimestamp = null;
                }
            }["BottomTimeline.useEffect.onVisibilityChange"];
            document.addEventListener('visibilitychange', onVisibilityChange);
            const tick = {
                "BottomTimeline.useEffect.tick": (timestamp)=>{
                    if (document.hidden) {
                        lastTimestamp = null;
                        animFrameId = requestAnimationFrame(tick);
                        return;
                    }
                    if (lastTimestamp !== null) accumulator += Math.max(0, Math.min(250, timestamp - lastTimestamp));
                    lastTimestamp = timestamp;
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    if (!state.isPlaying) return;
                    const clip = state.clips.find({
                        "BottomTimeline.useEffect.tick.clip": (item)=>item.id === state.activeClipId
                    }["BottomTimeline.useEffect.tick.clip"]);
                    const first = clip?.startFrame ?? 0;
                    const last = Math.min(clip?.endFrame ?? state.frames.length - 1, state.frames.length - 1);
                    const key = `${clip?.id}:${first}:${last}:${clip?.loopMode}:${state.loopMode}`;
                    if (key !== sequenceKey) {
                        sequenceKey = key;
                        sequence = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$export$2f$animationModel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["playbackOrder"])(first, last, clip?.loopMode, state.loopMode);
                        position = 0;
                        accumulator = 0;
                    } else if (state.activeFrameIndex !== publishedIndex) {
                        // An explicit scrub starts a fresh hold on the forward leg.
                        position = Math.max(0, sequence.indexOf(state.activeFrameIndex));
                        accumulator = 0;
                    }
                    let index = sequence[position] ?? first;
                    let stopped = false;
                    if (first === last && state.loopMode === 'once') {
                        const duration = state.frames[index]?.durationMs ?? Math.round(1000 / state.fps);
                        stopped = accumulator >= duration / previewSpeedRef.current;
                    }
                    // 250ms of catch-up is the most one RAF can contribute; even 1ms frames fit.
                    for(let steps = 0; steps < 256 && first < last; steps++){
                        const duration = state.frames[index]?.durationMs ?? Math.round(1000 / state.fps);
                        const previewDuration = duration / previewSpeedRef.current;
                        if (accumulator < previewDuration) break;
                        accumulator -= previewDuration;
                        if (state.loopMode === 'once' && position === sequence.length - 1) {
                            stopped = true;
                            accumulator = 0;
                            break;
                        }
                        position = (position + 1) % sequence.length;
                        index = sequence[position];
                    }
                    if (index !== publishedIndex) {
                        publishedIndex = index;
                        state.setActiveFrame(index);
                    }
                    if (stopped) {
                        state.setIsPlaying(false);
                        return;
                    }
                    animFrameId = requestAnimationFrame(tick);
                }
            }["BottomTimeline.useEffect.tick"];
            animFrameId = requestAnimationFrame(tick);
            return ({
                "BottomTimeline.useEffect": ()=>{
                    cancelAnimationFrame(animFrameId);
                    document.removeEventListener('visibilitychange', onVisibilityChange);
                }
            })["BottomTimeline.useEffect"];
        }
    }["BottomTimeline.useEffect"], [
        isPlaying
    ]);
    const handleStepForward = ()=>{
        if (activeFrameIndex < frames.length - 1) {
            setActiveFrame(activeFrameIndex + 1);
        } else {
            setActiveFrame(0);
        }
    };
    const handleStepBack = ()=>{
        if (activeFrameIndex > 0) {
            setActiveFrame(activeFrameIndex - 1);
        } else {
            setActiveFrame(frames.length - 1);
        }
    };
    const cycleLoopMode = ()=>{
        const modes = [
            'repeat',
            'ping-pong',
            'once'
        ];
        const nextIdx = (modes.indexOf(loopMode) + 1) % modes.length;
        setLoopMode(modes[nextIdx]);
    };
    if (isCollapsed) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
            "data-testid": "bottom-timeline-collapsed",
            className: "h-9 bg-[var(--desk-surface)] border-t border-[var(--desk-border)] px-3 flex items-center justify-between select-none z-20 text-[var(--text-heading)] shadow-sm transition-colors duration-150 shrink-0",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: toggleCollapsed,
                            className: "h-7 flex items-center gap-1 text-[10px] font-sans font-medium text-[var(--text-body)] hover:text-[var(--text-heading)] pixel-tactile-btn px-2 rounded-[2px] border border-[var(--desk-border)] cursor-pointer",
                            title: "Expand Full Animation Timeline",
                            "aria-label": "Expand Timeline",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: "play",
                                    size: 10
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                    lineNumber: 362,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: [
                                        "Timeline (",
                                        frames.length,
                                        ")"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                    lineNumber: 363,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[8px] text-[var(--text-muted)]",
                                    children: "▲"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                    lineNumber: 364,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                            lineNumber: 356,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[10px] font-sans text-[var(--text-muted)]",
                            children: [
                                "Frame ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-mono font-bold text-[var(--text-heading)]",
                                    children: activeFrameIndex + 1
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                    lineNumber: 368,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)),
                                " / ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-mono",
                                    children: frames.length
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                    lineNumber: 368,
                                    columnNumber: 116
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                            lineNumber: 367,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                    lineNumber: 355,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-1.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleStepBack,
                            title: "Previous Frame (,)",
                            className: "w-7 h-7 flex items-center justify-center rounded-[2px] border border-[var(--desk-border)] pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--accent-gold)] cursor-pointer",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "step-backward",
                                size: 10
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 379,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                            lineNumber: 374,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setIsPlaying(!isPlaying),
                            title: "Play / Pause Animation (Space)",
                            className: `h-7 min-w-[68px] px-2 text-[10px] font-bold rounded-[2px] border cursor-pointer flex items-center justify-center gap-1 ${isPlaying ? 'pixel-primary-btn shadow-[0_2px_0_#8c5120]' : 'pixel-tactile-btn border-[var(--desk-border)] text-[var(--text-heading)] hover:text-[var(--accent-gold)]'}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: isPlaying ? 'pause' : 'play',
                                    size: 10
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                    lineNumber: 391,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: isPlaying ? 'Pause' : 'Play'
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                    lineNumber: 392,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                            lineNumber: 382,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleStepForward,
                            title: "Next Frame (.)",
                            className: "w-7 h-7 flex items-center justify-center rounded-[2px] border border-[var(--desk-border)] pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--accent-gold)] cursor-pointer",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "step-forward",
                                size: 10
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 400,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                            lineNumber: 395,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[10px] font-mono text-[var(--text-muted)] ml-1",
                            children: [
                                previewSpeed,
                                "× preview"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                            lineNumber: 403,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                    lineNumber: 373,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            disabled: isGuest,
                            onClick: addFrame,
                            title: isGuest ? guestFrameLockTitle : 'Add blank frame with the current layer names and settings (no artwork)',
                            className: `h-7 px-2 text-[10px] font-sans font-medium rounded-[2px] border border-[var(--desk-border)] pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--text-heading)] cursor-pointer flex items-center gap-1 ${isGuest ? 'opacity-40 cursor-not-allowed' : ''}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: "plus",
                                    size: 10
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                    lineNumber: 418,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Frame"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                    lineNumber: 419,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                            lineNumber: 410,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: toggleCollapsed,
                            className: "h-7 text-[10px] font-sans font-medium pixel-tactile-btn rounded-[2px] border border-[var(--desk-border)] text-[var(--text-muted)] hover:text-[var(--text-heading)] flex items-center gap-1 cursor-pointer px-2",
                            title: "Expand Full Timeline",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "▲ Expand"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 427,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                            lineNumber: 422,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                    lineNumber: 409,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
            lineNumber: 350,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        "data-testid": "bottom-timeline",
        className: "h-32 bg-[var(--desk-surface)] border-t border-[var(--desk-border)] px-4 py-1.5 flex flex-col justify-between select-none z-20 text-[var(--text-heading)] shadow-sm transition-colors duration-150",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between border-b border-[var(--desk-border)] pb-1.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                        size: "sm",
                                        variant: isPlaying ? 'primary' : 'default',
                                        onClick: ()=>setIsPlaying(!isPlaying),
                                        title: "Play / Pause Animation (Space)",
                                        "data-tutorial": "play-button",
                                        className: `h-7 min-w-[78px] px-2 text-xs flex items-center justify-center gap-1.5 font-medium ${isPlaying ? 'pixel-primary-btn' : 'pixel-tactile-btn text-[var(--text-heading)] hover:text-[var(--accent-gold)]'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                name: isPlaying ? 'pause' : 'play',
                                                size: 12
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 454,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: isPlaying ? 'Pause' : 'Play'
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 455,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 442,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                        size: "icon-sm",
                                        variant: "default",
                                        onClick: handleStepBack,
                                        title: "Previous Frame (,)",
                                        className: "w-7 h-7 flex items-center justify-center pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--accent-gold)]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                            name: "step-backward",
                                            size: 11
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                            lineNumber: 465,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 458,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                        size: "icon-sm",
                                        variant: "default",
                                        onClick: handleStepForward,
                                        title: "Next Frame (.)",
                                        className: "w-7 h-7 flex items-center justify-center pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--accent-gold)]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                            name: "step-forward",
                                            size: 11
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                            lineNumber: 475,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 468,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    !isPlaygroundMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                        size: "sm",
                                        variant: "default",
                                        onClick: cycleLoopMode,
                                        title: `Loop Mode: ${loopMode}`,
                                        className: "h-7 px-2 text-xs font-sans font-medium pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--text-heading)] flex items-center justify-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                name: loopMode === 'ping-pong' ? 'ping-pong' : 'loop',
                                                size: 11
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 486,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: loopMode === 'ping-pong' ? 'Ping-Pong' : loopMode === 'repeat' ? 'Repeat' : 'Once'
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 487,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 479,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 441,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            !isPlaygroundMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-4 w-px bg-[var(--desk-border)]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 494,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-1.5 text-xs",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                ref: previewMenuRef,
                                                className: "relative",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        onClick: ()=>setIsPreviewMenuOpen((open)=>!open),
                                                        "aria-label": "Preview speed",
                                                        "aria-expanded": isPreviewMenuOpen,
                                                        className: "h-7 min-w-[102px] flex items-center justify-between gap-2 bg-[var(--surface-0)] px-2 rounded-[2px] border border-[var(--desk-border)] text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-[var(--text-muted)] text-[10px]",
                                                                children: "Preview"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                                lineNumber: 502,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-mono text-[11px]",
                                                                children: [
                                                                    previewSpeed,
                                                                    "×"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                                lineNumber: 503,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                "aria-hidden": "true",
                                                                className: "text-[var(--text-muted)]",
                                                                children: "▾"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                                lineNumber: 504,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                        lineNumber: 499,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    isPreviewMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        role: "group",
                                                        "aria-label": "Preview speeds",
                                                        className: "absolute bottom-full left-0 mb-1 z-[100] w-full bg-[var(--surface-2)] border border-[var(--desk-border-highlight)] rounded-[2px] p-1 shadow-lg",
                                                        children: [
                                                            0.5,
                                                            1,
                                                            2
                                                        ].map((speed)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: ()=>{
                                                                    setPreviewSpeed(speed);
                                                                    setIsPreviewMenuOpen(false);
                                                                },
                                                                "aria-label": `${speed}× preview speed`,
                                                                "aria-pressed": previewSpeed === speed,
                                                                className: `block w-full px-2 py-1.5 text-left font-mono text-xs rounded-[2px] hover:bg-[var(--surface-3)] ${previewSpeed === speed ? 'text-[var(--accent-gold)] bg-[var(--surface-3)]' : 'text-[var(--text-heading)]'}`,
                                                                children: [
                                                                    speed,
                                                                    "×"
                                                                ]
                                                            }, speed, true, {
                                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                                lineNumber: 510,
                                                                columnNumber: 25
                                                            }, ("TURBOPACK compile-time value", void 0)))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                        lineNumber: 507,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 498,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "h-7 flex items-center gap-1 bg-[var(--surface-0)] px-1.5 rounded-[2px] border border-[var(--desk-border)]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[var(--text-muted)] font-sans text-[10px]",
                                                        children: "Frame time"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                        lineNumber: 522,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "number",
                                                        min: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMinMs,
                                                        max: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMaxMs,
                                                        step: "1",
                                                        "aria-label": "Active frame duration in milliseconds",
                                                        value: frames[activeFrameIndex]?.durationMs ?? Math.round(1000 / fps),
                                                        onChange: (e)=>{
                                                            const val = parseInt(e.target.value, 10);
                                                            if (!isNaN(val) && val >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$animationTiming$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ANIMATION_TIMING_LIMITS"].durationMinMs) {
                                                                if (setFrameDuration(activeFrameIndex, val, durationGestureFrameRef.current === activeFrameIndex)) {
                                                                    durationGestureFrameRef.current = activeFrameIndex;
                                                                }
                                                            }
                                                        },
                                                        onPointerUp: ()=>{
                                                            durationGestureFrameRef.current = null;
                                                        },
                                                        onKeyDown: (e)=>{
                                                            if ((e.ctrlKey || e.metaKey) && [
                                                                'z',
                                                                'y'
                                                            ].includes(e.key.toLowerCase())) durationGestureFrameRef.current = null;
                                                        },
                                                        onBlur: ()=>{
                                                            durationGestureFrameRef.current = null;
                                                        },
                                                        className: "w-11 h-5 bg-transparent text-[var(--text-heading)] font-mono text-right px-0.5 outline-none text-[10px] tabular-nums"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                        lineNumber: 523,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[var(--text-muted)] text-[9px] font-mono",
                                                        children: "ms"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                        lineNumber: 545,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 521,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                                size: "sm",
                                                variant: "default",
                                                onClick: ()=>setOnionSkin({
                                                        enabled: !onionSkin.enabled
                                                    }),
                                                title: onionNotice ?? 'Toggle Onion Skinning',
                                                "aria-pressed": onionSkin.enabled,
                                                "aria-describedby": onionNotice ? 'onion-skin-notice' : undefined,
                                                className: `h-7 px-2 text-xs font-sans font-medium flex items-center justify-center gap-1 pixel-tactile-btn ${onionSkin.enabled ? 'bg-[var(--surface-3)] text-[var(--accent-gold)] border-[var(--accent-gold)] shadow-[inset_1px_1px_0_rgba(229,169,98,0.2)] font-bold' : 'text-[var(--text-body)] hover:text-[var(--text-heading)]'}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                        name: "onion",
                                                        size: 12
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                        lineNumber: 562,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Onion Skin"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                        lineNumber: 563,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 549,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                id: "onion-skin-notice",
                                                className: "w-[94px] shrink-0 text-[9px] leading-tight text-[var(--text-muted)]",
                                                "aria-live": "polite",
                                                children: onionNotice
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 565,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 497,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 493,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                        lineNumber: 439,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                variant: "default",
                                disabled: isGuest,
                                onClick: addFrame,
                                title: isGuest ? guestFrameLockTitle : 'Add blank frame with the current layer names and settings (no artwork)',
                                "aria-label": "+ Frame",
                                "data-testid": "add-frame-button",
                                "data-tutorial": "add-frame",
                                className: `h-7 px-2.5 text-xs pixel-tactile-btn text-[var(--text-heading)] hover:text-[var(--accent-gold)] flex items-center justify-center gap-1 font-medium ${isGuest ? 'opacity-40 cursor-not-allowed' : ''}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                        name: "plus",
                                        size: 12
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 588,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Frame"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 589,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 575,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            !isPlaygroundMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                className: "relative group",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                        className: "h-7 px-2 flex items-center gap-1 text-xs pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--text-heading)] cursor-pointer list-none rounded-[2px]",
                                        children: [
                                            "Frame actions ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                "aria-hidden": "true",
                                                children: "▾"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 595,
                                                columnNumber: 31
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 594,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute right-0 bottom-full mb-1 z-40 min-w-40 p-1 bg-[var(--surface-2)] border border-[var(--desk-border-highlight)] rounded-[2px] shadow-lg",
                                        children: [
                                            [
                                                'Duplicate frame',
                                                ()=>duplicateFrame(activeFrameIndex),
                                                isGuest
                                            ],
                                            [
                                                'Move frame earlier',
                                                ()=>reorderFrames(activeFrameIndex, activeFrameIndex - 1),
                                                isGuest || isPlaying || activeFrameIndex === 0
                                            ],
                                            [
                                                'Move frame later',
                                                ()=>reorderFrames(activeFrameIndex, activeFrameIndex + 1),
                                                isGuest || isPlaying || activeFrameIndex >= frames.length - 1
                                            ],
                                            [
                                                'Delete frame',
                                                ()=>deleteFrame(activeFrameIndex),
                                                isGuest || frames.length <= 1
                                            ]
                                        ].map(([label, action, disabled])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                disabled: disabled,
                                                onClick: (event)=>{
                                                    action();
                                                    event.currentTarget.closest('details')?.removeAttribute('open');
                                                },
                                                className: "block w-full text-left px-2 py-1.5 text-xs text-[var(--text-body)] hover:bg-[var(--surface-3)] disabled:opacity-40 rounded-[2px]",
                                                children: label
                                            }, label, false, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 604,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 597,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 593,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-4 w-px bg-[var(--desk-border)] mx-0.5"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 615,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                variant: "default",
                                onClick: toggleCollapsed,
                                title: "Collapse Timeline to compact strip",
                                "aria-label": "Collapse Timeline",
                                className: "h-7 text-xs px-2 pixel-tactile-btn text-[var(--text-muted)] hover:text-[var(--text-heading)] flex items-center justify-center gap-1 font-medium",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[9px]",
                                        children: "▼"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 625,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Collapse"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 626,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 617,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                        lineNumber: 574,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                lineNumber: 437,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 min-w-0 pt-1",
                children: [
                    !isPlaygroundMode && (clips.length > 1 || activeClipId !== null) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1 border-r border-[var(--desk-border)] pr-2 shrink-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setActiveClipId(null),
                                "aria-label": `Filter clips: All frames (${frames.length})`,
                                title: "Show all frames in timeline",
                                "data-testid": "timeline-clip-filter-all",
                                className: `h-7 px-2 rounded-[2px] text-[10px] font-sans font-medium pixel-tactile-chip cursor-pointer ${activeClipId === null ? 'bg-[var(--surface-3)] text-[var(--accent-gold)] border-[var(--accent-gold)] font-bold shadow-xs' : 'text-[var(--text-body)] hover:text-[var(--text-heading)]'}`,
                                children: [
                                    "All Frames (",
                                    frames.length,
                                    ")"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 635,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            clips.map((clip)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `h-7 flex items-center gap-1.5 px-2 rounded-[2px] text-[10px] font-sans font-medium pixel-tactile-chip ${activeClipId === clip.id ? 'bg-[var(--surface-3)] text-[var(--accent-gold)] border-[var(--accent-gold)] font-bold shadow-xs' : 'text-[var(--text-body)] hover:text-[var(--text-heading)]'}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setActiveClipId(clip.id),
                                        className: "cursor-pointer font-medium font-sans text-[10px] bg-transparent border-0 p-0 text-inherit text-left leading-none",
                                        children: [
                                            clip.name,
                                            " (",
                                            clip.startFrame + 1,
                                            "-",
                                            clip.endFrame + 1,
                                            ")"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 658,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, clip.id, false, {
                                    fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                    lineNumber: 650,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                        lineNumber: 634,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 min-w-0 flex-1 overflow-x-auto py-0.5",
                        children: frames.map((frame, index)=>{
                            const isActive = index === activeFrameIndex;
                            const isInsideClip = activeClip ? index >= activeClip.startFrame && index <= activeClip.endFrame : true;
                            const isBeingDragged = draggedFrameIndex === index;
                            const isDropTarget = dragOverFrameIndex === index && draggedFrameIndex !== index;
                            const baseTime = Math.round(1000 / fps);
                            const duration = frame.durationMs ?? baseTime;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                draggable: !isPlaying && !isGuest,
                                onDragStart: (e)=>handleDragStart(e, index),
                                onDragOver: (e)=>handleDragOver(e, index),
                                onDragLeave: (e)=>handleDragLeave(e, index),
                                onDrop: (e)=>handleDrop(e, index),
                                onDragEnd: handleDragEnd,
                                onMouseEnter: (event)=>{
                                    const rect = event.currentTarget.getBoundingClientRect();
                                    setHoverPreviewAnchor({
                                        x: rect.left + rect.width / 2,
                                        y: rect.top
                                    });
                                    setHoveredFrameIndex(index);
                                },
                                onMouseLeave: ()=>setHoveredFrameIndex((cur)=>cur === index ? null : cur),
                                onClick: ()=>setActiveFrame(index),
                                "aria-label": `Select frame ${index + 1}. Duration: ${duration}ms. Drag to reorder.`,
                                title: isGuest ? `Frame #${index + 1} (${duration}ms) - ${guestFrameLockTitle}` : `Frame #${index + 1} (${duration}ms) - Drag to reorder`,
                                className: `relative w-[72px] h-16 shrink-0 rounded-[2px] border-2 ${isGuest ? 'cursor-pointer' : 'cursor-grab active:cursor-grabbing'} transition-all flex flex-col items-center justify-between px-1.5 py-1 select-none text-left ${isBeingDragged ? 'opacity-30 scale-95 border-dashed border-[var(--accent-gold)] bg-[#1a0f2e]' : isDropTarget ? 'border-[var(--accent-gold)] bg-[#3d2757] ring-2 ring-[var(--accent-gold)] shadow-[0_0_12px_rgba(240,190,124,0.6)] scale-105' : isActive ? 'bg-[var(--timeline-frame-active-bg)] border-[var(--timeline-frame-active-border)] shadow-[var(--timeline-frame-active-shadow,none)]' : isInsideClip ? 'bg-[var(--desk-surface-raised)] border-[var(--desk-border)] hover:bg-[var(--timeline-frame-hover-bg)] hover:border-[var(--timeline-frame-hover-border)]' : 'bg-[var(--desk-surface-raised)] border-[#2c1e3a] opacity-50 hover:opacity-80'}`,
                                children: [
                                    hoveredFrameIndex === index && hoverPreviewAnchor && !isBeingDragged && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FrameScrubPreview, {
                                        frameIndex: index,
                                        duration: duration,
                                        layerCount: frame.layers.length,
                                        anchor: hoverPreviewAnchor
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 721,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)), document.body),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full flex justify-between items-center text-[9px] font-mono leading-none pointer-events-none",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: isActive ? 'text-[var(--accent-gold)] font-bold' : 'text-[var(--text-heading)] font-bold',
                                                children: [
                                                    "#",
                                                    index + 1
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 730,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: isActive ? 'text-[var(--accent-gold)] font-medium' : 'text-[var(--text-body)] font-medium',
                                                children: [
                                                    duration,
                                                    "ms"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                                lineNumber: 733,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 729,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "pointer-events-none",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FrameThumbnail, {
                                            frameIndex: index,
                                            isActive: isActive
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                            lineNumber: 740,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                        lineNumber: 739,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, frame.id, true, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 683,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0));
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                        lineNumber: 672,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    !isPlaygroundMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        "data-testid": "manage-tags-button",
                        onClick: ()=>setIsTagManagerOpen(true),
                        className: "h-7 px-2 shrink-0 rounded-[2px] text-xs font-sans pixel-tactile-chip text-[var(--text-body)] hover:text-[var(--text-heading)] flex items-center gap-1",
                        title: "Create and manage animation clips",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "tag",
                                size: 11
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                                lineNumber: 750,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            " Clips"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                        lineNumber: 747,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                lineNumber: 632,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$modals$2f$TagManagerModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TagManagerModal"], {
                isOpen: isTagManagerOpen,
                onClose: ()=>setIsTagManagerOpen(false)
            }, void 0, false, {
                fileName: "[project]/src/components/layout/BottomTimeline.tsx",
                lineNumber: 756,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/BottomTimeline.tsx",
        lineNumber: 435,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s2(BottomTimeline, "X5jpmCZYYuZY4cPtqfXsQQeIyiI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useCoDrawStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCoDrawStatus"]
    ];
});
_c2 = BottomTimeline;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "FrameThumbnail");
__turbopack_context__.k.register(_c1, "FrameScrubPreview");
__turbopack_context__.k.register(_c2, "BottomTimeline");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/CenterViewport.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CenterViewport",
    ()=>CenterViewport
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/importFile.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/stores/onboardingStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$FloatingPreviewWindow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/studio/FloatingPreviewWindow.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$ViewportLensFilters$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/studio/ViewportLensFilters.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$RadialContextMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/studio/RadialContextMenu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRadialContextMenu$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useRadialContextMenu.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/render/compositor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$smartMathEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/smartMathEngine.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/edtNormalMap.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/art/normalSculptor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteCycling.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$export$2f$shaderExporter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/export/shaderExporter.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportTransform$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useViewportTransform.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportOverlays$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useViewportOverlays.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportSelection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useViewportSelection.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportSelectionTransform$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useViewportSelectionTransform.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$SelectionTransformGizmo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/studio/SelectionTransformGizmo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportDrawing$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useViewportDrawing.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportPointerEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useViewportPointerEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportStudioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useViewportStudioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$PixelLightBulbGizmo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/studio/PixelLightBulbGizmo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$RemoteCursorsOverlay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/studio/RemoteCursorsOverlay.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$CursorStatusBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/CursorStatusBadge.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function ScreenGuide({ axis, fraction, color, thickness = 1 }) {
    const vertical = axis === 'vertical';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "aria-hidden": "true",
        className: "absolute pointer-events-none",
        style: {
            left: vertical ? `${fraction * 100}%` : 0,
            top: vertical ? 0 : `${fraction * 100}%`,
            width: vertical ? `${thickness}px` : '100%',
            height: vertical ? '100%' : `${thickness}px`,
            backgroundImage: `repeating-linear-gradient(to ${vertical ? 'bottom' : 'right'}, ${color} 0 4px, transparent 4px 8px)`
        }
    }, void 0, false, {
        fileName: "[project]/src/components/layout/CenterViewport.tsx",
        lineNumber: 53,
        columnNumber: 10
    }, this);
}
_c = ScreenGuide;
const CenterViewport = ({ onCommitHistory, onOpenImport, retainHistory = false })=>{
    _s();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mainCanvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const stencilCanvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const onionCanvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const previewCanvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const gridCanvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const cursorCanvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Store atomic subscriptions
    const canvasWidth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[canvasWidth]": (s)=>s.canvasWidth
    }["CenterViewport.useStudioStore[canvasWidth]"]);
    const canvasHeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[canvasHeight]": (s)=>s.canvasHeight
    }["CenterViewport.useStudioStore[canvasHeight]"]);
    const zoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[zoom]": (s)=>s.zoom
    }["CenterViewport.useStudioStore[zoom]"]);
    const setZoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[setZoom]": (s)=>s.setZoom
    }["CenterViewport.useStudioStore[setZoom]"]);
    const panX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[panX]": (s)=>s.panX
    }["CenterViewport.useStudioStore[panX]"]);
    const panY = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[panY]": (s)=>s.panY
    }["CenterViewport.useStudioStore[panY]"]);
    const setPan = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[setPan]": (s)=>s.setPan
    }["CenterViewport.useStudioStore[setPan]"]);
    const setZoomAndPan = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[setZoomAndPan]": (s)=>s.setZoomAndPan
    }["CenterViewport.useStudioStore[setZoomAndPan]"]);
    const showGrid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[showGrid]": (s)=>s.showGrid
    }["CenterViewport.useStudioStore[showGrid]"]);
    const referenceOverlay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[referenceOverlay]": (s)=>s.referenceOverlay
    }["CenterViewport.useStudioStore[referenceOverlay]"]);
    const showIsoGuides = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[showIsoGuides]": (s)=>s.showIsoGuides
    }["CenterViewport.useStudioStore[showIsoGuides]"]);
    const isPlaygroundActive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"])({
        "CenterViewport.useOnboardingStore[isPlaygroundActive]": (s)=>s.isPlaygroundActive
    }["CenterViewport.useOnboardingStore[isPlaygroundActive]"]);
    const activeLessonId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"])({
        "CenterViewport.useOnboardingStore[activeLessonId]": (s)=>s.activeLessonId
    }["CenterViewport.useOnboardingStore[activeLessonId]"]);
    const showTilePreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[showTilePreview]": (s)=>s.showTilePreview
    }["CenterViewport.useStudioStore[showTilePreview]"]);
    const showNormalMapPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[showNormalMapPreview]": (s)=>s.showNormalMapPreview
    }["CenterViewport.useStudioStore[showNormalMapPreview]"]);
    const photometricGizmoActive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[photometricGizmoActive]": (s)=>s.photometricGizmoActive
    }["CenterViewport.useStudioStore[photometricGizmoActive]"]);
    const cvdLens = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[cvdLens]": (s)=>s.cvdLens
    }["CenterViewport.useStudioStore[cvdLens]"]);
    const squintMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[squintMode]": (s)=>s.squintMode
    }["CenterViewport.useStudioStore[squintMode]"]);
    const onionSkin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[onionSkin]": (s)=>s.onionSkin
    }["CenterViewport.useStudioStore[onionSkin]"]);
    const isPlaying = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[isPlaying]": (s)=>s.isPlaying
    }["CenterViewport.useStudioStore[isPlaying]"]);
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[tools]": (s)=>s.tools
    }["CenterViewport.useStudioStore[tools]"]);
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[frames]": (s)=>s.frames
    }["CenterViewport.useStudioStore[frames]"]);
    const activeFrameIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[activeFrameIndex]": (s)=>s.activeFrameIndex
    }["CenterViewport.useStudioStore[activeFrameIndex]"]);
    const activeLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[activeLayerId]": (s)=>s.activeLayerId
    }["CenterViewport.useStudioStore[activeLayerId]"]);
    const isPaletteCycling = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[isPaletteCycling]": (s)=>s.isPaletteCycling
    }["CenterViewport.useStudioStore[isPaletteCycling]"]);
    const paletteCycleSpeedMultiplier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[paletteCycleSpeedMultiplier]": (s)=>s.paletteCycleSpeedMultiplier
    }["CenterViewport.useStudioStore[paletteCycleSpeedMultiplier]"]);
    const palettes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[palettes]": (s)=>s.palettes
    }["CenterViewport.useStudioStore[palettes]"]);
    const currentPaletteId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[currentPaletteId]": (s)=>s.currentPaletteId
    }["CenterViewport.useStudioStore[currentPaletteId]"]);
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[selection]": (s)=>s.selection
    }["CenterViewport.useStudioStore[selection]"]);
    const selectionMask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CenterViewport.useStudioStore[selectionMask]": (s)=>s.selectionMask
    }["CenterViewport.useStudioStore[selectionMask]"]);
    const [isDragOver, setIsDragOver] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const radialMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRadialContextMenu$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRadialContextMenu"])(containerRef);
    // Initialize or fetch the offscreen canvas for a layer
    const getOrCreateLayerCanvas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CenterViewport.useCallback[getOrCreateLayerCanvas]": (layerId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layerId, canvasWidth, canvasHeight).canvas
    }["CenterViewport.useCallback[getOrCreateLayerCanvas]"], [
        canvasWidth,
        canvasHeight
    ]);
    // Hook 1: Viewport transform & pan/zoom
    const { isPanning, setIsPanning, panStart, setPanStart, clientToCanvasCoords, handleWheel } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportTransform$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportTransform"])({
        containerRef,
        mainCanvasRef,
        canvasWidth,
        canvasHeight,
        zoom,
        setZoom,
        panX,
        panY,
        setPan,
        setZoomAndPan
    });
    // Hook 2: Viewport drawing
    const { isDrawingRef, isDrawing, setIsDrawing, strokeStart, setStrokeStart, lastPoint, setLastPoint, cursorCoordsRef, lockedWarning, setLockedWarning, lockedWarningTimerRef, captureSnapshot, commitSnapshot, discardSnapshot, performUndo, performRedo, drawPointsOnActiveLayer, currentStrokeSnapshotRef, setPrimaryColor } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportDrawing$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportDrawing"])({
        canvasWidth,
        canvasHeight,
        renderComposite: {
            "CenterViewport.useViewportDrawing": ()=>renderComposite()
        }["CenterViewport.useViewportDrawing"],
        getOrCreateLayerCanvas,
        onCommitHistory,
        retainHistory
    });
    // Hook 3: Viewport selection & clipboard
    const { floatingSelection, setFloatingSelection, isDraggingSelection, setIsDraggingSelection, dragOffset, setDragOffset, lassoPoints, setLassoPoints, selectionModifierRef, baseSelectionMaskRef, liftSelectionToFloating, commitFloatingSelection, createBoxMask, mergeSelectionMask } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportSelection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportSelection"])({
        canvasWidth,
        canvasHeight,
        activeLayerId,
        previewCanvasRef,
        getOrCreateLayerCanvas,
        renderComposite: {
            "CenterViewport.useViewportSelection": ()=>renderComposite()
        }["CenterViewport.useViewportSelection"],
        captureSnapshot,
        commitSnapshot
    });
    const { transform: selectionTransform, handlePointerDown: handleGizmoPointerDown, handlePointerMove: handleGizmoPointerMove, handlePointerUp: handleGizmoPointerUp, commitTransform: commitGizmoTransform, cancelTransform: cancelGizmoTransform, handleFlipH: handleGizmoFlipH, handleFlipV: handleGizmoFlipV, handleRotate90CW: handleGizmoRotate90CW, handleRotate90CCW: handleGizmoRotate90CCW } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportSelectionTransform$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportSelectionTransform"])({
        canvasWidth,
        canvasHeight,
        activeLayerId,
        selection,
        selectionMask,
        floatingSelection,
        setFloatingSelection,
        setSelection: {
            "CenterViewport.useViewportSelectionTransform": (box)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setSelection(box)
        }["CenterViewport.useViewportSelectionTransform"],
        getOrCreateLayerCanvas,
        renderComposite: {
            "CenterViewport.useViewportSelectionTransform": ()=>renderComposite()
        }["CenterViewport.useViewportSelectionTransform"],
        captureSnapshot,
        commitSnapshot,
        bumpBufferVersion: {
            "CenterViewport.useViewportSelectionTransform": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().bumpBufferVersion()
        }["CenterViewport.useViewportSelectionTransform"],
        liftSelectionToFloating,
        commitFloatingSelection
    });
    const normalMapCacheRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Pure composite of all visible layers onto the main viewport canvas
    const renderComposite = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CenterViewport.useCallback[renderComposite]": ()=>{
            const mainCanvas = mainCanvasRef.current;
            if (!mainCanvas) return;
            const ctx = mainCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (!ctx) return;
            ctx.clearRect(0, 0, canvasWidth, canvasHeight);
            ctx.imageSmoothingEnabled = false;
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            const currentFrame = state.frames[state.activeFrameIndex];
            // 1. Main Active Frame Layers (Unified Bottom-to-Top Compositing)
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compositeFrame"])(state.frames, state.activeFrameIndex, canvasWidth, canvasHeight, {}, mainCanvas);
            // 2. Floating Selection Buffer overlay
            if (floatingSelection) {
                ctx.save();
                ctx.imageSmoothingEnabled = false;
                ctx.globalAlpha = 1.0;
                ctx.globalCompositeOperation = 'source-over';
                if (selectionTransform && Math.abs(selectionTransform.rotation) > 1e-4) {
                    ctx.translate(selectionTransform.pivot.x, selectionTransform.pivot.y);
                    ctx.rotate(selectionTransform.rotation);
                    ctx.translate(-selectionTransform.pivot.x, -selectionTransform.pivot.y);
                }
                ctx.drawImage(floatingSelection.canvas, floatingSelection.x, floatingSelection.y);
                ctx.restore();
            }
            // 3. Tangent-Space Normal Map Live Viewport Mode
            if (state.showNormalMapPreview) {
                const layersSig = currentFrame ? currentFrame.layers.map({
                    "CenterViewport.useCallback[renderComposite]": (l)=>`${l.id}:${l.visible ? 1 : 0}:${l.opacity}:${l.blendMode}`
                }["CenterViewport.useCallback[renderComposite]"]).join(';') : '';
                const floatKey = floatingSelection ? `${floatingSelection.x}_${floatingSelection.y}` : 'none';
                const cacheKey = `${state.bufferVersion}_${state.activeFrameIndex}_${canvasWidth}_${canvasHeight}_${layersSig}_${floatKey}`;
                let normalCanvas;
                if (normalMapCacheRef.current && normalMapCacheRef.current.cacheKey === cacheKey) {
                    normalCanvas = normalMapCacheRef.current.canvas;
                } else {
                    const data = ctx.getImageData(0, 0, canvasWidth, canvasHeight).data;
                    const isOpaque = {
                        "CenterViewport.useCallback[renderComposite].isOpaque": (x, y)=>{
                            if (x < 0 || x >= canvasWidth || y < 0 || y >= canvasHeight) return false;
                            return data[(y * canvasWidth + x) * 4 + 3] > 30;
                        }
                    }["CenterViewport.useCallback[renderComposite].isOpaque"];
                    const distanceMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])(isOpaque, canvasWidth, canvasHeight);
                    const rawHeightmap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateInflatedHeightmap"])(distanceMap, canvasWidth, canvasHeight, 0.5);
                    const smoothHeightmap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyBilateralFilter"])(rawHeightmap, canvasWidth, canvasHeight, 1.5, 2.0);
                    const normalField = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeTangentNormalField"])(smoothHeightmap, canvasWidth, canvasHeight, 2.0);
                    // Blend custom normal sculpt layers (e.g. tag === 'normal') using RNM
                    if (currentFrame) {
                        const normalLayers = currentFrame.layers.filter({
                            "CenterViewport.useCallback[renderComposite].normalLayers": (l)=>l.visible && (l.tag === 'normal' || l.tag === 'normal-map')
                        }["CenterViewport.useCallback[renderComposite].normalLayers"]);
                        for (const nLayer of normalLayers){
                            const nlCanvas = getOrCreateLayerCanvas(nLayer.id);
                            const nlCtx = nlCanvas.getContext('2d', {
                                willReadFrequently: true
                            });
                            if (nlCtx) {
                                const nlData = nlCtx.getImageData(0, 0, canvasWidth, canvasHeight).data;
                                for(let y = 0; y < canvasHeight; y++){
                                    for(let x = 0; x < canvasWidth; x++){
                                        const pIdx = (y * canvasWidth + x) * 4;
                                        const idx = y * canvasWidth + x;
                                        if (nlData[pIdx + 3] > 20) {
                                            const detail = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodeNormalRGB"])(nlData[pIdx], nlData[pIdx + 1], nlData[pIdx + 2], true);
                                            const base = [
                                                normalField.nx[idx],
                                                normalField.ny[idx],
                                                normalField.nz[idx]
                                            ];
                                            const blended = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["blendNormalsRNM"])(base, detail);
                                            normalField.nx[idx] = blended[0];
                                            normalField.ny[idx] = blended[1];
                                            normalField.nz[idx] = blended[2];
                                        }
                                    }
                                }
                            }
                        }
                    }
                    normalCanvas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bakeNormalMapToCanvas"])(normalField, canvasWidth, canvasHeight, isOpaque);
                    normalMapCacheRef.current = {
                        cacheKey,
                        canvas: normalCanvas
                    };
                }
                ctx.clearRect(0, 0, canvasWidth, canvasHeight);
                ctx.drawImage(normalCanvas, 0, 0);
            }
            ctx.globalAlpha = 1.0;
            ctx.globalCompositeOperation = 'source-over';
        }
    }["CenterViewport.useCallback[renderComposite]"], [
        canvasHeight,
        canvasWidth,
        floatingSelection,
        getOrCreateLayerCanvas,
        selectionTransform
    ]);
    // Mark Ferrari 8-Bit Dynamic Palette Cycling 60 FPS Engine
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CenterViewport.useEffect": ()=>{
            if (!isPaletteCycling) return;
            const currentPalette = palettes.find({
                "CenterViewport.useEffect.currentPalette": (p)=>p.id === currentPaletteId
            }["CenterViewport.useEffect.currentPalette"]);
            const tracks = currentPalette?.cycleTracks?.filter({
                "CenterViewport.useEffect": (t)=>t.enabled && t.rate > 0
            }["CenterViewport.useEffect"]);
            if (!currentPalette || !tracks || tracks.length === 0) return;
            const mainCanvas = mainCanvasRef.current;
            if (!mainCanvas) return;
            const ctx = mainCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (!ctx) return;
            const baseImg = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
            const indexMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$export$2f$shaderExporter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildCanvasPaletteIndexMap"])(ctx, canvasWidth, canvasHeight, currentPalette.colors);
            const numPixels = canvasWidth * canvasHeight;
            const outLUT32 = new Uint32Array(currentPalette.colors.length);
            const cyclingRegisters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildCycleRegisterMask"])(tracks, currentPalette.colors.length);
            const frameData = ctx.createImageData(canvasWidth, canvasHeight);
            const data32 = new Uint32Array(frameData.data.buffer);
            const baseData32 = new Uint32Array(baseImg.data.buffer);
            let animationFrameId;
            const startTime = performance.now();
            const cycleLoop = {
                "CenterViewport.useEffect.cycleLoop": (time)=>{
                    const elapsedSec = (time - startTime) / 1000 * paletteCycleSpeedMultiplier;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateLivePaletteLUT32"])(currentPalette.colors, tracks, elapsedSec, outLUT32);
                    for(let i = 0; i < numPixels; i++){
                        const palIdx = indexMap.indices[i];
                        if (indexMap.alpha[i] === 0 || !cyclingRegisters[palIdx]) {
                            data32[i] = baseData32[i];
                        } else {
                            data32[i] = (outLUT32[palIdx] ?? baseData32[i]) & 0x00ffffff | indexMap.alpha[i] << 24;
                        }
                    }
                    ctx.putImageData(frameData, 0, 0);
                    animationFrameId = requestAnimationFrame(cycleLoop);
                }
            }["CenterViewport.useEffect.cycleLoop"];
            animationFrameId = requestAnimationFrame(cycleLoop);
            return ({
                "CenterViewport.useEffect": ()=>{
                    cancelAnimationFrame(animationFrameId);
                    renderComposite();
                }
            })["CenterViewport.useEffect"];
        }
    }["CenterViewport.useEffect"], [
        isPaletteCycling,
        currentPaletteId,
        palettes,
        paletteCycleSpeedMultiplier,
        canvasWidth,
        canvasHeight,
        renderComposite
    ]);
    // Hook 4: Viewport overlays
    const { cvdFilterCss, mainFilterCss, renderOnionSkin, renderBrushGhost } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportOverlays$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportOverlays"])({
        gridCanvasRef,
        onionCanvasRef,
        stencilCanvasRef,
        cursorCanvasRef,
        canvasWidth,
        canvasHeight,
        zoom,
        selection,
        selectionMask,
        floatingSelection,
        cvdLens,
        squintMode,
        activeTool: tools.activeTool,
        brushSize: tools.brushSize
    });
    // Hook 5: Studio events and AI operations
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportStudioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportStudioEvents"])({
        mainCanvasRef,
        canvasWidth,
        canvasHeight,
        activeLayerId,
        getOrCreateLayerCanvas,
        renderComposite,
        captureSnapshot,
        commitSnapshot,
        discardSnapshot,
        performUndo,
        performRedo
    });
    // Hook 6: Pointer event routing and drawing dispatch
    const { handlePointerDown, handlePointerMove, handlePointerUp, handlePointerCancel } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportPointerEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportPointerEvents"])({
        canvasWidth,
        canvasHeight,
        panX,
        panY,
        setPan,
        isPanning,
        setIsPanning,
        panStart,
        setPanStart,
        clientToCanvasCoords,
        isDrawing,
        setIsDrawing,
        isDrawingRef,
        strokeStart,
        setStrokeStart,
        lastPoint,
        setLastPoint,
        cursorCoordsRef,
        currentStrokeSnapshotRef,
        drawPointsOnActiveLayer,
        captureSnapshot,
        commitSnapshot,
        discardSnapshot,
        setPrimaryColor,
        renderBrushGhost,
        renderComposite,
        getOrCreateLayerCanvas,
        previewCanvasRef,
        floatingSelection,
        setFloatingSelection,
        isDraggingSelection,
        setIsDraggingSelection,
        dragOffset,
        setDragOffset,
        lassoPoints,
        setLassoPoints,
        selectionModifierRef,
        baseSelectionMaskRef,
        liftSelectionToFloating,
        commitFloatingSelection,
        createBoxMask,
        mergeSelectionMask,
        lockedWarningTimerRef,
        setLockedWarning
    });
    // Live Composite & Onion Skin Rendering
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CenterViewport.useEffect": ()=>{
            if (!isDrawingRef.current) {
                renderComposite();
            }
            renderOnionSkin();
        // eslint-disable-next-line react-hooks/exhaustive-deps -- isDrawingRef is an inert mutable ref
        }
    }["CenterViewport.useEffect"], [
        renderComposite,
        renderOnionSkin,
        frames,
        activeFrameIndex,
        activeLayerId,
        showNormalMapPreview,
        onionSkin,
        isPlaying
    ]);
    // Remote co-draw peers paint layer buffers directly (outside React state),
    // so the bridge requests an explicit composite re-render per applied batch.
    // Coalesce rapid bursts using requestAnimationFrame (B20).
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CenterViewport.useEffect": ()=>{
            let rafId = null;
            const unsub = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:request-composite', {
                "CenterViewport.useEffect.unsub": ()=>{
                    if (rafId !== null) return;
                    rafId = requestAnimationFrame({
                        "CenterViewport.useEffect.unsub": ()=>{
                            rafId = null;
                            renderComposite();
                        }
                    }["CenterViewport.useEffect.unsub"]);
                }
            }["CenterViewport.useEffect.unsub"]);
            return ({
                "CenterViewport.useEffect": ()=>{
                    unsub();
                    if (rafId !== null) {
                        cancelAnimationFrame(rafId);
                        rafId = null;
                    }
                }
            })["CenterViewport.useEffect"];
        }
    }["CenterViewport.useEffect"], [
        renderComposite
    ]);
    // Interruption safety: window blur (Alt-tab), tab visibility hidden, or lost pointer capture (B19)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CenterViewport.useEffect": ()=>{
            const onWindowBlur = {
                "CenterViewport.useEffect.onWindowBlur": ()=>{
                    handlePointerCancel();
                }
            }["CenterViewport.useEffect.onWindowBlur"];
            const onVisibilityChange = {
                "CenterViewport.useEffect.onVisibilityChange": ()=>{
                    if (document.visibilityState === 'hidden') {
                        handlePointerCancel();
                    }
                }
            }["CenterViewport.useEffect.onVisibilityChange"];
            window.addEventListener('blur', onWindowBlur);
            document.addEventListener('visibilitychange', onVisibilityChange);
            return ({
                "CenterViewport.useEffect": ()=>{
                    window.removeEventListener('blur', onWindowBlur);
                    document.removeEventListener('visibilitychange', onVisibilityChange);
                }
            })["CenterViewport.useEffect"];
        }
    }["CenterViewport.useEffect"], [
        handlePointerCancel
    ]);
    // Drag and drop imports
    const handleDragOver = (e)=>{
        e.preventDefault();
        setIsDragOver(true);
    };
    const handleDragLeave = ()=>{
        setIsDragOver(false);
    };
    const handleDrop = (e)=>{
        e.preventDefault();
        setIsDragOver(false);
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            const file = e.dataTransfer.files[0];
            void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readImportFile"])(file).then((payload)=>onOpenImport?.(payload)).catch(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportImportError"]);
        }
    };
    // Native non-passive wheel listener to allow smooth zoom preventDefault without Chrome passive warnings
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CenterViewport.useEffect": ()=>{
            const el = containerRef.current;
            if (!el) return;
            const onNativeWheel = {
                "CenterViewport.useEffect.onNativeWheel": (e)=>{
                    handleWheel(e);
                }
            }["CenterViewport.useEffect.onNativeWheel"];
            el.addEventListener('wheel', onNativeWheel, {
                passive: false
            });
            return ({
                "CenterViewport.useEffect": ()=>{
                    el.removeEventListener('wheel', onNativeWheel);
                }
            })["CenterViewport.useEffect"];
        }
    }["CenterViewport.useEffect"], [
        handleWheel
    ]);
    const stageWidth = canvasWidth * zoom / 100;
    const stageHeight = canvasHeight * zoom / 100;
    const referenceFractions = referenceOverlay === 'thirds' ? [
        1 / 3,
        2 / 3
    ] : referenceOverlay === 'golden' ? [
        0.382,
        0.618
    ] : referenceOverlay === 'center' ? [
        0.5
    ] : [];
    const referenceColor = referenceOverlay === 'thirds' ? 'rgba(199, 146, 223, 0.7)' : referenceOverlay === 'golden' ? 'rgba(240, 190, 124, 0.75)' : 'rgba(220, 171, 223, 0.7)';
    const screenScale = zoom / 100;
    const isoGuidePeriod = 16 * screenScale / Math.sqrt(5);
    const hasGroundGuide = isPlaygroundActive && (activeLessonId === 'master-bouncing-ball' || activeLessonId === 'character-hop-shock' || activeLessonId === 'combat-slash-hitstop');
    const trajectoryStart = activeLessonId === 'master-bouncing-ball' ? 10 : activeLessonId === 'character-hop-shock' ? 8 : null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        ref: containerRef,
        id: "main-content",
        tabIndex: -1,
        "aria-label": "Pixel art canvas workspace",
        className: "relative flex-1 h-full w-full overflow-hidden flex items-center justify-center select-none outline-none",
        style: {
            backgroundColor: 'var(--canvas-well)',
            boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.4), inset 0 0 0 1px var(--canvas-border)'
        },
        onPointerDown: handlePointerDown,
        onPointerMove: handlePointerMove,
        onPointerUp: handlePointerUp,
        onPointerCancel: handlePointerCancel,
        onLostPointerCapture: handlePointerCancel,
        onPointerLeave: ()=>{
            cursorCoordsRef.current = null;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$CursorStatusBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateCursorHUD"])(null);
            renderBrushGhost(null);
        },
        onDragOver: handleDragOver,
        onDragLeave: handleDragLeave,
        onDrop: handleDrop,
        onContextMenu: radialMenu.handleContextMenu,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute z-50 flex flex-col gap-2 items-end pointer-events-none",
                style: {
                    top: 'var(--space-3)',
                    right: 'var(--space-3)'
                },
                children: [
                    showNormalMapPreview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-[var(--surface-3)] text-[var(--accent-gold)] font-mono text-[10px] px-2 py-0.5 rounded-full shadow-md",
                        children: "Normal Map"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 614,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    isPaletteCycling && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-[var(--surface-3)] text-[var(--accent-gold)] font-mono text-[10px] px-2 py-0.5 rounded-full shadow-md",
                        children: "Cycling"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 619,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    showTilePreview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-[var(--surface-3)] text-[var(--accent-gold)] font-mono text-[10px] px-2 py-0.5 rounded-full shadow-md",
                        children: "Tiling"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 624,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                lineNumber: 609,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$ViewportLensFilters$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ViewportLensFilters"], {}, void 0, false, {
                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                lineNumber: 631,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$FloatingPreviewWindow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FloatingPreviewWindow"], {}, void 0, false, {
                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                lineNumber: 634,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$RadialContextMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadialContextMenu"], {
                isOpen: radialMenu.isOpen,
                position: radialMenu.position,
                onClose: radialMenu.closeMenu
            }, void 0, false, {
                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                lineNumber: 637,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            lockedWarning && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: "status",
                "aria-live": "polite",
                className: "absolute top-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-3 py-1.5 bg-[var(--desk-border)] text-[#DDDFDF] text-xs font-mono rounded border border-[var(--accent-wisteria)]/40 shadow-pixel-glow pointer-events-none animate-fade-in",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                        name: "lock",
                        size: 14,
                        className: "text-[var(--accent-plum)]"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 650,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "Active layer is locked! Unlock it in the inspector to paint."
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 651,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                lineNumber: 645,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "center-canvas-area",
                "data-tutorial": "canvas",
                role: "application",
                tabIndex: 0,
                "aria-label": "Pixel art drawing canvas. Use mouse or stylus to paint, arrow keys to pan viewport or nudge selection, and Alt+drag to pan.",
                className: "relative shrink-0 outline outline-1 outline-[var(--desk-border)] focus:ring-2 focus:ring-[var(--accent-gold)]",
                style: {
                    width: `${stageWidth}px`,
                    height: `${stageHeight}px`,
                    minWidth: `${stageWidth}px`,
                    minHeight: `${stageHeight}px`,
                    flexShrink: 0,
                    transform: `translate(${panX}px, ${panY}px)`,
                    transition: 'none',
                    boxShadow: 'var(--canvas-shadow)'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "aria-hidden": "true",
                        className: "absolute -inset-3 bg-[var(--platen-bg)] border border-[var(--platen-border)]/60 rounded-[2px] shadow-[0_4px_16px_rgba(0,0,0,0.3),0_0_0_1px_var(--desk-border)] pointer-events-none -z-10"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 675,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute -top-3 -left-3 w-2 h-2 border-t border-l border-[var(--platen-mark)]/50 pointer-events-none",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 676,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute -top-3 -right-3 w-2 h-2 border-t border-r border-[var(--platen-mark)]/50 pointer-events-none",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 677,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute -bottom-3 -left-3 w-2 h-2 border-b border-l border-[var(--platen-mark)]/50 pointer-events-none",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 678,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute -bottom-3 -right-3 w-2 h-2 border-b border-r border-[var(--platen-mark)]/50 pointer-events-none",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 679,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    showTilePreview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 pointer-events-none z-0 opacity-60",
                        children: [
                            -1,
                            0,
                            1
                        ].map((ox)=>[
                                -1,
                                0,
                                1
                            ].map((oy)=>{
                                if (ox === 0 && oy === 0) return null;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute border border-dashed border-[var(--accent-gold)]/40 overflow-hidden",
                                    style: {
                                        left: `${ox * stageWidth}px`,
                                        top: `${oy * stageHeight}px`,
                                        width: `${stageWidth}px`,
                                        height: `${stageHeight}px`
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                                        ref: (el)=>{
                                            if (el && mainCanvasRef.current) {
                                                const ctx = el.getContext('2d');
                                                if (ctx) {
                                                    el.width = canvasWidth;
                                                    el.height = canvasHeight;
                                                    ctx.imageSmoothingEnabled = false;
                                                    ctx.clearRect(0, 0, canvasWidth, canvasHeight);
                                                    ctx.drawImage(mainCanvasRef.current, 0, 0);
                                                }
                                            }
                                        },
                                        className: "w-full h-full pixelated"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                                        lineNumber: 697,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, `tile-${ox}-${oy}`, false, {
                                    fileName: "[project]/src/components/layout/CenterViewport.tsx",
                                    lineNumber: 687,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0));
                            }))
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 682,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-testid": "canvas-solid-underlay",
                        className: "absolute inset-0 bg-[#ffffff] pointer-events-none",
                        style: {
                            filter: cvdFilterCss
                        },
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 720,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$RemoteCursorsOverlay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoteCursorsOverlay"], {
                        zoom: zoom
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 728,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                        ref: onionCanvasRef,
                        "data-testid": "onion-skin-canvas",
                        width: canvasWidth,
                        height: canvasHeight,
                        className: "absolute inset-0 w-full h-full pointer-events-none pixelated",
                        style: {
                            filter: cvdFilterCss,
                            imageRendering: 'pixelated'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 731,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                        ref: stencilCanvasRef,
                        width: canvasWidth,
                        height: canvasHeight,
                        className: "absolute inset-0 w-full h-full pointer-events-none pixelated",
                        style: {
                            filter: cvdFilterCss,
                            imageRendering: 'pixelated'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 741,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                        ref: mainCanvasRef,
                        "data-testid": "main-composite-canvas",
                        width: canvasWidth,
                        height: canvasHeight,
                        className: "absolute inset-0 w-full h-full pixelated shadow-pixel-frame cursor-crosshair",
                        style: {
                            filter: mainFilterCss,
                            imageRendering: 'pixelated'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 750,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                        ref: previewCanvasRef,
                        "data-testid": "stroke-preview-canvas",
                        width: canvasWidth,
                        height: canvasHeight,
                        className: "absolute inset-0 w-full h-full pointer-events-none pixelated",
                        style: {
                            filter: cvdFilterCss,
                            imageRendering: 'pixelated'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 760,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                        ref: gridCanvasRef,
                        "data-testid": "grid-selection-overlay",
                        width: canvasWidth,
                        height: canvasHeight,
                        className: "absolute inset-0 w-full h-full pointer-events-none pixelated",
                        style: showGrid && zoom >= 400 ? {
                            backgroundImage: 'linear-gradient(to right, rgba(58, 46, 76, 0.16) 1px, transparent 1px), linear-gradient(to bottom, rgba(58, 46, 76, 0.16) 1px, transparent 1px)',
                            backgroundSize: `${zoom / 100}px ${zoom / 100}px`
                        } : undefined
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 770,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 pointer-events-none",
                        "aria-hidden": "true",
                        children: [
                            showIsoGuides && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-testid": "isometric-guide-overlay",
                                className: "absolute inset-0",
                                style: {
                                    backgroundImage: [
                                        26.565,
                                        153.435
                                    ].map((angle)=>`repeating-linear-gradient(${angle}deg, rgba(240, 190, 124, 0.45) 0 1px, transparent 1px ${isoGuidePeriod}px)`).join(', ')
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                                lineNumber: 784,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0)),
                            referenceFractions.flatMap((fraction)=>[
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScreenGuide, {
                                        axis: "vertical",
                                        fraction: fraction,
                                        color: referenceColor
                                    }, `reference-v-${fraction}`, false, {
                                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                                        lineNumber: 790,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScreenGuide, {
                                        axis: "horizontal",
                                        fraction: fraction,
                                        color: referenceColor
                                    }, `reference-h-${fraction}`, false, {
                                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                                        lineNumber: 791,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]),
                            tools.symmetryHorizontal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScreenGuide, {
                                axis: "vertical",
                                fraction: 0.5,
                                color: "rgba(199, 146, 223, 0.85)",
                                thickness: 2
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                                lineNumber: 793,
                                columnNumber: 40
                            }, ("TURBOPACK compile-time value", void 0)),
                            tools.symmetryVertical && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScreenGuide, {
                                axis: "horizontal",
                                fraction: 0.5,
                                color: "rgba(199, 146, 223, 0.85)",
                                thickness: 2
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                                lineNumber: 794,
                                columnNumber: 38
                            }, ("TURBOPACK compile-time value", void 0)),
                            hasGroundGuide && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-testid": "playground-ground-guide",
                                className: "absolute left-0 w-full",
                                style: {
                                    top: `${26 * screenScale}px`,
                                    height: '1.5px',
                                    backgroundImage: 'repeating-linear-gradient(to right, rgba(240, 190, 124, 0.6) 0 4px, transparent 4px 6px)'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                                lineNumber: 795,
                                columnNumber: 30
                            }, ("TURBOPACK compile-time value", void 0)),
                            isPlaygroundActive && trajectoryStart !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-testid": "playground-trajectory-guide",
                                className: "absolute",
                                style: {
                                    left: `${16 * screenScale}px`,
                                    top: `${trajectoryStart * screenScale}px`,
                                    width: '1px',
                                    height: `${(26 - trajectoryStart) * screenScale}px`,
                                    backgroundImage: 'repeating-linear-gradient(to bottom, rgba(240, 190, 124, 0.35) 0 2px, transparent 2px 6px)'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                                lineNumber: 799,
                                columnNumber: 62
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 783,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: cursorCanvasRef,
                        "data-testid": "brush-ghost-overlay",
                        className: "absolute pointer-events-none",
                        style: {
                            display: 'none',
                            boxSizing: 'border-box',
                            border: '1px solid rgba(240, 190, 124, 0.6)',
                            outline: '1px solid rgba(20, 12, 30, 0.5)'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 807,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    (selection || floatingSelection) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$SelectionTransformGizmo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectionTransformGizmo"], {
                        canvasWidth: canvasWidth,
                        canvasHeight: canvasHeight,
                        zoom: zoom,
                        selectionMask: selectionMask,
                        transform: selectionTransform,
                        interactive: tools.activeTool.startsWith('select-') || !!floatingSelection || selectionTransform.isTransforming,
                        onHandlePointerDown: handleGizmoPointerDown,
                        onPointerMove: handleGizmoPointerMove,
                        onPointerUp: handleGizmoPointerUp,
                        onCommit: commitGizmoTransform,
                        onCancel: cancelGizmoTransform,
                        onFlipH: handleGizmoFlipH,
                        onFlipV: handleGizmoFlipV,
                        onRotate90CW: handleGizmoRotate90CW,
                        onRotate90CCW: handleGizmoRotate90CCW
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 821,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    photometricGizmoActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$studio$2f$PixelLightBulbGizmo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelLightBulbGizmo"], {
                        canvasWidth: canvasWidth,
                        canvasHeight: canvasHeight,
                        zoom: zoom,
                        mainCanvasRef: mainCanvasRef,
                        onCommit: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:photometric-gizmo-commit'),
                        onCancel: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:photometric-gizmo-cancel'),
                        onLightChange: (azimuth, elevation, cx, cy, brightness)=>{
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:photometric-lighting-live', {
                                lightAzimuth: azimuth,
                                lightElevation: elevation,
                                lightCenterX: cx,
                                lightCenterY: cy,
                                lightBrightness: brightness
                            });
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 846,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    isDragOver && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 border-4 border-dashed border-[var(--accent-plum)] bg-[var(--accent-wisteria)]/20 flex items-center justify-center pointer-events-none z-30",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[var(--desk-border)] font-mono text-sm font-bold bg-[#DDDFDF] px-3 py-1.5 rounded shadow",
                            children: "Drop file to import"
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/CenterViewport.tsx",
                            lineNumber: 868,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/CenterViewport.tsx",
                        lineNumber: 867,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/CenterViewport.tsx",
                lineNumber: 656,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/CenterViewport.tsx",
        lineNumber: 583,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(CenterViewport, "8B5BmYAJxGdd4ns0v9AwbbeeLPM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useRadialContextMenu$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRadialContextMenu"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportTransform$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportTransform"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportDrawing$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportDrawing"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportSelection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportSelection"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportSelectionTransform$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportSelectionTransform"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportOverlays$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportOverlays"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportStudioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportStudioEvents"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useViewportPointerEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useViewportPointerEvents"]
    ];
});
_c1 = CenterViewport;
var _c, _c1;
__turbopack_context__.k.register(_c, "ScreenGuide");
__turbopack_context__.k.register(_c1, "CenterViewport");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/CursorStatusBadge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CursorStatusBadge",
    ()=>CursorStatusBadge,
    "subscribeCursorHUD",
    ()=>subscribeCursorHUD,
    "updateCursorHUD",
    ()=>updateCursorHUD
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
;
;
const listeners = new Set();
function updateCursorHUD(coords) {
    listeners.forEach((fn)=>fn(coords));
}
function subscribeCursorHUD(handler) {
    listeners.add(handler);
    return ()=>{
        listeners.delete(handler);
    };
}
const CursorStatusBadge = /*#__PURE__*/ _s(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_c = _s(()=>{
    _s();
    const [coords, setCoords] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const activeTool = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "CursorStatusBadge.useStudioStore[activeTool]": (state)=>state.tools.activeTool
    }["CursorStatusBadge.useStudioStore[activeTool]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CursorStatusBadge.useEffect": ()=>subscribeCursorHUD(setCoords)
    }["CursorStatusBadge.useEffect"], []);
    if (!coords) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "cursor-status-badge",
        className: "absolute bottom-4 right-4 z-20 flex items-center gap-2 bg-[var(--desk-surface-raised)] border-2 border-[var(--desk-border)] rounded-[2px] shadow-[0_2px_0_var(--btn-shadow)] text-[var(--accent-gold)] font-mono text-[10px] px-2.5 py-1 pointer-events-none select-none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: [
                    "X: ",
                    coords.x,
                    " Y: ",
                    coords.y
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/CursorStatusBadge.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-1 h-1 rounded-full bg-[var(--accent-wisteria)]"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/CursorStatusBadge.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "capitalize",
                children: activeTool
            }, void 0, false, {
                fileName: "[project]/src/components/layout/CursorStatusBadge.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/CursorStatusBadge.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
}, "V/Jv6HWt2uXW7ekK92bEo/2dZIU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
})), "V/Jv6HWt2uXW7ekK92bEo/2dZIU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c1 = CursorStatusBadge;
CursorStatusBadge.displayName = 'CursorStatusBadge';
var _c, _c1;
__turbopack_context__.k.register(_c, "CursorStatusBadge$React.memo");
__turbopack_context__.k.register(_c1, "CursorStatusBadge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/HeaderFileMenu.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HeaderFileMenu",
    ()=>HeaderFileMenu
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function HeaderFileMenu({ actions }) {
    _s();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const trigger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const menu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [position, setPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const initialIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const focusItem = (index)=>{
        const items = menu.current?.querySelectorAll('[role="menuitem"]');
        if (!items?.length) return;
        const next = (index + items.length) % items.length;
        items.forEach((item, itemIndex)=>{
            item.tabIndex = itemIndex === next ? 0 : -1;
        });
        items[next].focus();
    };
    const open = (last = false)=>{
        const bounds = trigger.current?.getBoundingClientRect();
        if (!bounds) return;
        initialIndex.current = last ? actions.length - 1 : 0;
        setPosition({
            top: bounds.bottom + 4,
            left: Math.max(8, Math.min(bounds.left, window.innerWidth - 232))
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeaderFileMenu.useEffect": ()=>{
            if (!position) return;
            focusItem(initialIndex.current);
            const outside = {
                "HeaderFileMenu.useEffect.outside": (event)=>{
                    if (!menu.current?.contains(event.target) && !trigger.current?.contains(event.target)) setPosition(null);
                }
            }["HeaderFileMenu.useEffect.outside"];
            // Closing on viewport movement avoids a detached or clipped menu.
            const close = {
                "HeaderFileMenu.useEffect.close": ()=>setPosition(null)
            }["HeaderFileMenu.useEffect.close"];
            document.addEventListener('pointerdown', outside);
            window.addEventListener('resize', close);
            window.addEventListener('scroll', close, true);
            return ({
                "HeaderFileMenu.useEffect": ()=>{
                    document.removeEventListener('pointerdown', outside);
                    window.removeEventListener('resize', close);
                    window.removeEventListener('scroll', close, true);
                }
            })["HeaderFileMenu.useEffect"];
        }
    }["HeaderFileMenu.useEffect"], [
        position
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                ref: trigger,
                type: "button",
                "data-testid": "file-menu-button",
                "aria-haspopup": "menu",
                "aria-expanded": Boolean(position),
                "aria-controls": position ? id : undefined,
                title: "File: projects, new drawing, import and canvas size",
                onClick: ()=>position ? setPosition(null) : open(),
                onKeyDown: (event)=>{
                    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
                        event.preventDefault();
                        open(event.key === 'ArrowUp');
                    }
                },
                className: "h-7 px-2.5 flex items-center gap-1.5 text-xs pixel-tactile-btn rounded-[2px] border border-[var(--desk-border)] text-[var(--text-body)] hover:text-[var(--text-heading)]",
                children: [
                    "File ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "aria-hidden": "true",
                        className: "text-[8px] text-[var(--text-muted)]",
                        children: "▼"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/HeaderFileMenu.tsx",
                        lineNumber: 67,
                        columnNumber: 12
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/HeaderFileMenu.tsx",
                lineNumber: 56,
                columnNumber: 5
            }, this),
            position && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: menu,
                id: id,
                role: "menu",
                tabIndex: -1,
                "aria-label": "File",
                style: position,
                onBlur: (event)=>{
                    if (!event.currentTarget.contains(event.relatedTarget) && event.relatedTarget !== trigger.current) setPosition(null);
                },
                onKeyDown: (event)=>{
                    const items = Array.from(menu.current.querySelectorAll('[role="menuitem"]'));
                    const index = items.findIndex((item)=>item === document.activeElement);
                    if ([
                        'ArrowDown',
                        'ArrowUp',
                        'Home',
                        'End'
                    ].includes(event.key)) {
                        event.preventDefault();
                        event.stopPropagation();
                        focusItem(event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : index + (event.key === 'ArrowDown' ? 1 : -1));
                    } else if (event.key === 'Escape' || event.key === 'Tab') {
                        if (event.key === 'Escape') {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        setPosition(null);
                        trigger.current?.focus();
                    }
                },
                className: "fixed z-[9999] w-56 max-w-[calc(100vw-16px)] bg-[var(--surface-2)] border border-[var(--desk-border-highlight)] rounded-[2px] shadow-xl p-1 font-sans text-xs",
                children: actions.map((action)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        role: "menuitem",
                        tabIndex: -1,
                        "data-testid": action.testId,
                        onClick: ()=>{
                            setPosition(null);
                            trigger.current?.focus();
                            action.onSelect();
                        },
                        className: "w-full min-h-9 px-2 flex items-center gap-2 rounded-[2px] text-left text-[var(--text-body)] hover:bg-[var(--surface-3)] focus-visible:bg-[var(--surface-3)] focus-visible:outline focus-visible:outline-1 focus-visible:outline-[var(--accent-gold)]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: action.icon,
                                size: 12
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/HeaderFileMenu.tsx",
                                lineNumber: 92,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: action.label
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/HeaderFileMenu.tsx",
                                lineNumber: 92,
                                columnNumber: 51
                            }, this)
                        ]
                    }, action.testId, true, {
                        fileName: "[project]/src/components/layout/HeaderFileMenu.tsx",
                        lineNumber: 88,
                        columnNumber: 32
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/layout/HeaderFileMenu.tsx",
                lineNumber: 69,
                columnNumber: 31
            }, this), document.body)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/HeaderFileMenu.tsx",
        lineNumber: 55,
        columnNumber: 10
    }, this);
}
_s(HeaderFileMenu, "Y4Ajw86UVRjxtXKMl4r34tPgKCQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = HeaderFileMenu;
var _c;
__turbopack_context__.k.register(_c, "HeaderFileMenu");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/LeftToolbar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LeftToolbar",
    ()=>LeftToolbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$motion$2f$dist$2f$es$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/motion/dist/es/react.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/ToolMotionPreview.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$shortcuts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/shortcuts.ts [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
// Heavy color picker dialog is code-split client-side (Phase 33): it mounts
// only while open, so its chunk is fetched on first open, never on page load.
const ColorPickerModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/modals/ColorPickerModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.ColorPickerModal), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/modals/ColorPickerModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = ColorPickerModal;
;
const LeftToolbar = ({ isPlaygroundMode = false })=>{
    _s();
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[tools]": (s)=>s.tools
    }["LeftToolbar.useStudioStore[tools]"]);
    const setActiveTool = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[setActiveTool]": (s)=>s.setActiveTool
    }["LeftToolbar.useStudioStore[setActiveTool]"]);
    const primaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[primaryColor]": (s)=>s.primaryColor
    }["LeftToolbar.useStudioStore[primaryColor]"]);
    const secondaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[secondaryColor]": (s)=>s.secondaryColor
    }["LeftToolbar.useStudioStore[secondaryColor]"]);
    const setPrimaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[setPrimaryColor]": (s)=>s.setPrimaryColor
    }["LeftToolbar.useStudioStore[setPrimaryColor]"]);
    const setSecondaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[setSecondaryColor]": (s)=>s.setSecondaryColor
    }["LeftToolbar.useStudioStore[setSecondaryColor]"]);
    const swapColors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[swapColors]": (s)=>s.swapColors
    }["LeftToolbar.useStudioStore[swapColors]"]);
    const palettes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[palettes]": (s)=>s.palettes
    }["LeftToolbar.useStudioStore[palettes]"]);
    const currentPaletteId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[currentPaletteId]": (s)=>s.currentPaletteId
    }["LeftToolbar.useStudioStore[currentPaletteId]"]);
    const recentColors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[recentColors]": (s)=>s.recentColors
    }["LeftToolbar.useStudioStore[recentColors]"]);
    const loadRecentColors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[loadRecentColors]": (s)=>s.loadRecentColors
    }["LeftToolbar.useStudioStore[loadRecentColors]"]);
    const setActiveInspectorTab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LeftToolbar.useStudioStore[setActiveInspectorTab]": (s)=>s.setActiveInspectorTab
    }["LeftToolbar.useStudioStore[setActiveInspectorTab]"]);
    const [colorPickerTarget, setColorPickerTarget] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isMounted, setIsMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isFlyoutOpen, setIsFlyoutOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeFlyoutTarget, setActiveFlyoutTarget] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('primary');
    const wellsContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const flyoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [flyoutBottom, setFlyoutBottom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LeftToolbar.useEffect": ()=>{
            setIsMounted(true);
            loadRecentColors();
        }
    }["LeftToolbar.useEffect"], [
        loadRecentColors
    ]);
    const calculateFlyoutBottom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "LeftToolbar.useCallback[calculateFlyoutBottom]": (triggerEl)=>{
            const el = triggerEl || wellsContainerRef.current;
            if (el) {
                const rect = el.getBoundingClientRect();
                const timelineEl = typeof document !== 'undefined' ? document.querySelector('footer') : null;
                const timelineHeight = timelineEl ? timelineEl.getBoundingClientRect().height : 112;
                const desiredBottom = window.innerHeight - rect.bottom;
                return Math.max(timelineHeight + 8, desiredBottom);
            }
            return 120;
        }
    }["LeftToolbar.useCallback[calculateFlyoutBottom]"], []);
    const openFlyout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "LeftToolbar.useCallback[openFlyout]": (target, triggerEl)=>{
            setActiveFlyoutTarget(target);
            const calculated = calculateFlyoutBottom(triggerEl);
            setFlyoutBottom(calculated);
            setIsFlyoutOpen(true);
        }
    }["LeftToolbar.useCallback[openFlyout]"], [
        calculateFlyoutBottom
    ]);
    const toggleFlyout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "LeftToolbar.useCallback[toggleFlyout]": (e)=>{
            if (!isFlyoutOpen) {
                openFlyout('primary', e?.currentTarget);
            } else {
                setIsFlyoutOpen(false);
            }
        }
    }["LeftToolbar.useCallback[toggleFlyout]"], [
        isFlyoutOpen,
        openFlyout
    ]);
    const updateFlyoutCoords = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "LeftToolbar.useCallback[updateFlyoutCoords]": ()=>{
            const calculated = calculateFlyoutBottom();
            setFlyoutBottom(calculated);
        }
    }["LeftToolbar.useCallback[updateFlyoutCoords]"], [
        calculateFlyoutBottom
    ]);
    const resetDefaultColors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "LeftToolbar.useCallback[resetDefaultColors]": ()=>{
            setPrimaryColor('#000000');
            setSecondaryColor('#ffffff');
        }
    }["LeftToolbar.useCallback[resetDefaultColors]"], [
        setPrimaryColor,
        setSecondaryColor
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LeftToolbar.useEffect": ()=>{
            if (!isFlyoutOpen) return;
            updateFlyoutCoords();
            const handleClickOutside = {
                "LeftToolbar.useEffect.handleClickOutside": (e)=>{
                    const target = e.target;
                    if (wellsContainerRef.current && !wellsContainerRef.current.contains(target) && flyoutRef.current && !flyoutRef.current.contains(target)) {
                        setIsFlyoutOpen(false);
                    }
                }
            }["LeftToolbar.useEffect.handleClickOutside"];
            const handleKeyDown = {
                "LeftToolbar.useEffect.handleKeyDown": (e)=>{
                    if (e.key === 'Escape') setIsFlyoutOpen(false);
                }
            }["LeftToolbar.useEffect.handleKeyDown"];
            window.addEventListener('resize', updateFlyoutCoords);
            document.addEventListener('mousedown', handleClickOutside);
            document.addEventListener('keydown', handleKeyDown);
            return ({
                "LeftToolbar.useEffect": ()=>{
                    window.removeEventListener('resize', updateFlyoutCoords);
                    document.removeEventListener('mousedown', handleClickOutside);
                    document.removeEventListener('keydown', handleKeyDown);
                }
            })["LeftToolbar.useEffect"];
        }
    }["LeftToolbar.useEffect"], [
        isFlyoutOpen,
        updateFlyoutCoords
    ]);
    const currentPalette = palettes.find((p)=>p.id === currentPaletteId) || palettes[0];
    const activeToolGroups = isPlaygroundMode ? [
        {
            groupName: 'Essential Drawing',
            tools: [
                {
                    id: 'pen',
                    label: 'Pen',
                    shortcut: 'B',
                    icon: 'pen'
                },
                {
                    id: 'eraser',
                    label: 'Eraser',
                    shortcut: 'E',
                    icon: 'eraser'
                }
            ]
        }
    ] : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$shortcuts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TOOL_GROUPS"];
    const handleApplyColor = (color, overrideTarget)=>{
        const target = overrideTarget || activeFlyoutTarget;
        if (target === 'primary') {
            setPrimaryColor(color);
        } else {
            setSecondaryColor(color);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        className: "w-14 bg-[var(--desk-surface)] border-r border-[var(--desk-border)] flex flex-col items-center py-2 justify-between select-none z-10 overflow-y-auto transition-colors duration-150",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawingToolsPreviewLayer"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-2 w-full px-1.5 items-center",
                    children: activeToolGroups.map((group, gIdx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1 w-full items-center",
                            children: [
                                gIdx > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-7 h-[1px] bg-gradient-to-r from-transparent via-[var(--desk-border-highlight)]/40 to-transparent my-1"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                    lineNumber: 150,
                                    columnNumber: 28
                                }, ("TURBOPACK compile-time value", void 0)),
                                group.tools.map((tool)=>{
                                    const isActive = tools.activeTool === tool.id;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ToolMotionPreview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawingToolPreview"], {
                                        toolId: tool.id,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setActiveTool(tool.id),
                                            "aria-label": tool.label,
                                            "data-testid": `${tool.id}-tool`,
                                            "data-tutorial": `${tool.id}-tool`,
                                            className: `w-8 h-8 rounded-[2px] flex items-center justify-center cursor-pointer ${isActive ? 'pixel-primary-btn font-bold shadow-[inset_0_1px_0_rgba(255,255,255,0.35),0_1px_0_var(--btn-shadow)]' : 'pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--text-heading)]'}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                name: tool.icon,
                                                size: 16
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                                lineNumber: 169,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                            lineNumber: 158,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, tool.id, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 154,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0));
                                })
                            ]
                        }, group.groupName, true, {
                            fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                            lineNumber: 149,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)))
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                    lineNumber: 147,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                lineNumber: 146,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: wellsContainerRef,
                className: "flex flex-col items-center gap-2 w-full px-1.5 pt-2 pb-1 border-t border-[var(--desk-border)] shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative w-10 h-10 select-none",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: swapColors,
                                title: "Swap Foreground & Background Colors (X)",
                                "aria-label": "Swap colors (X)",
                                className: "absolute top-0 right-0 w-3.5 h-3.5 rounded-[1px] border border-[var(--desk-border)] bg-[var(--surface-0)] text-[var(--text-muted)] hover:text-[var(--accent-gold)] hover:border-[var(--accent-gold)] hover:bg-[var(--surface-2)] active:scale-90 flex items-center justify-center cursor-pointer transition-colors z-20 p-0 text-[9px] leading-none",
                                children: "⇄"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 187,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: resetDefaultColors,
                                title: "Default Colors: Black & White (Shift+D)",
                                "aria-label": "Reset default black and white colors (Shift+D)",
                                className: "absolute bottom-0 left-0 w-3.5 h-3.5 rounded-[1px] border border-[var(--desk-border)] bg-[var(--surface-0)] hover:border-[var(--accent-gold)] hover:bg-[var(--surface-2)] active:scale-90 flex items-center justify-center cursor-pointer transition-colors z-20 group p-0",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "relative w-2.5 h-2.5 block pointer-events-none",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute bottom-0 right-0 w-1.5 h-1.5 bg-white border border-black/80 rounded-[0.5px]"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                            lineNumber: 207,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute top-0 left-0 w-1.5 h-1.5 bg-black border border-white/60 rounded-[0.5px]"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                            lineNumber: 208,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                    lineNumber: 206,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 198,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>openFlyout('secondary'),
                                onDoubleClick: ()=>{
                                    setIsFlyoutOpen(false);
                                    setColorPickerTarget('secondary');
                                },
                                onContextMenu: (e)=>{
                                    e.preventDefault();
                                    swapColors();
                                },
                                style: {
                                    backgroundColor: secondaryColor
                                },
                                className: `absolute bottom-0.5 right-0.5 w-[22px] h-[22px] rounded-[2px] border border-black/70 shadow-[inset_0_1px_0_rgba(255,255,255,0.15),0_1px_3px_rgba(0,0,0,0.5)] cursor-pointer hover:brightness-110 active:scale-95 transition-transform p-0 ${isFlyoutOpen && activeFlyoutTarget === 'secondary' ? 'ring-1.5 ring-[var(--accent-plum)] z-15' : 'hover:ring-1 hover:ring-white/40 z-0'}`,
                                "aria-label": `Secondary color ${secondaryColor}. Click for quick swatches, double click for picker, right click to swap`,
                                title: `Secondary Color (${secondaryColor})\nClick: Quick Swatches | Double click: Picker | Right-click: Swap`
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 213,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>openFlyout('primary'),
                                onDoubleClick: ()=>{
                                    setIsFlyoutOpen(false);
                                    setColorPickerTarget('primary');
                                },
                                onContextMenu: (e)=>{
                                    e.preventDefault();
                                    swapColors();
                                },
                                style: {
                                    backgroundColor: primaryColor
                                },
                                className: `absolute top-0.5 left-0.5 w-[24px] h-[24px] rounded-[2px] border border-black/80 shadow-[inset_0_1px_0_rgba(255,255,255,0.25),0_2px_4px_rgba(0,0,0,0.6)] cursor-pointer hover:brightness-110 active:scale-95 transition-transform p-0 z-10 ${isFlyoutOpen && activeFlyoutTarget === 'primary' ? 'ring-1.5 ring-[var(--accent-gold)]' : 'hover:ring-1 hover:ring-white/40'}`,
                                "aria-label": `Primary color ${primaryColor}. Click for quick swatches, double click for picker, right click to swap`,
                                title: `Primary Color (${primaryColor})\nClick: Quick Swatches | Double click: Picker | Right-click: Swap`
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 235,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                        lineNumber: 185,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-center gap-1 w-full pt-0.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-1 p-0.5 bg-[var(--surface-0)]/60 rounded-[2px] border border-[var(--desk-border)]",
                                suppressHydrationWarning: true,
                                children: (isMounted && recentColors.length >= 4 ? recentColors.slice(0, 4) : currentPalette.colors.slice(0, 4)).map((color, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setPrimaryColor(color),
                                        onContextMenu: (e)=>{
                                            e.preventDefault();
                                            setSecondaryColor(color);
                                        },
                                        style: {
                                            backgroundColor: color
                                        },
                                        className: "w-3.5 h-3.5 rounded-[1px] border border-black/40 hover:border-[var(--accent-gold)] hover:scale-110 transition-transform cursor-pointer",
                                        title: `${color} (Click: Primary | Right-click: Secondary)`
                                    }, `rail-swatch-${color}-${idx}`, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 261,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 259,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: toggleFlyout,
                                title: "Quick Swatches & Color Access (Click to toggle)",
                                "aria-label": "Quick Swatches Flyout",
                                className: `w-9 h-3.5 rounded-[2px] border text-[8px] font-mono flex items-center justify-center gap-0.5 cursor-pointer transition-colors pixel-tactile-btn ${isFlyoutOpen ? 'bg-[var(--surface-2)] text-[var(--accent-gold)] border-[var(--accent-gold)]/60' : 'text-[var(--text-muted)] border-[var(--desk-border)] hover:text-[var(--text-heading)] hover:border-[var(--desk-border-highlight)]'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "w-0.5 h-0.5 rounded-full bg-current"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 286,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "w-0.5 h-0.5 rounded-full bg-current"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 287,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "w-0.5 h-0.5 rounded-full bg-current"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 288,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 276,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                        lineNumber: 258,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                lineNumber: 180,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            isFlyoutOpen && isMounted && flyoutBottom !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$motion$2f$dist$2f$es$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["motion"].div, {
                ref: flyoutRef,
                role: "region",
                "aria-label": "Color quick access flyout",
                initial: {
                    opacity: 0,
                    x: -8
                },
                animate: {
                    opacity: 1,
                    x: 0
                },
                exit: {
                    opacity: 0,
                    x: -8
                },
                transition: {
                    duration: 0.1,
                    ease: 'easeOut'
                },
                style: {
                    position: 'fixed',
                    left: '58px',
                    bottom: `${flyoutBottom}px`,
                    zIndex: 9999,
                    transformOrigin: 'left bottom',
                    maxHeight: 'calc(100vh - 120px)'
                },
                className: "w-56 bg-[var(--surface-2)] border border-[var(--desk-border-highlight)] rounded-[2px] shadow-[0_8px_24px_rgba(0,0,0,0.7)] p-2.5 flex flex-col gap-2.5 text-xs font-sans select-none overflow-y-auto",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between pb-1 border-b border-[var(--desk-border)]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-bold uppercase tracking-wider text-[var(--accent-gold)] font-sans",
                                children: "Color Access"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 315,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[9px] text-[var(--text-muted)] font-mono",
                                children: "ESC"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 318,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                        lineNumber: 314,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between gap-1 p-1 bg-[var(--surface-0)] rounded-[2px] border border-[var(--desk-border)]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setActiveFlyoutTarget('primary'),
                                className: `flex-1 flex items-center gap-1.5 px-1.5 py-0.5 rounded-[2px] transition-colors cursor-pointer ${activeFlyoutTarget === 'primary' ? 'bg-[var(--surface-2)] text-[var(--text-heading)] border border-[var(--accent-gold)]' : 'text-[var(--text-muted)] hover:text-[var(--text-heading)] border border-transparent'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "w-3.5 h-3.5 rounded-[1px] border border-[var(--desk-border)] shrink-0",
                                        style: {
                                            backgroundColor: primaryColor
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 331,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col text-left leading-tight",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[8px] font-sans font-medium text-[var(--text-muted)] uppercase",
                                                children: "Pri"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                                lineNumber: 336,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[9px] font-mono font-bold text-[var(--text-heading)] truncate max-w-[50px]",
                                                children: primaryColor
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                                lineNumber: 337,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 335,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 323,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: swapColors,
                                title: "Swap Colors (X)",
                                className: "px-1 py-0.5 text-[10px] text-[var(--text-muted)] hover:text-[var(--accent-gold)] cursor-pointer",
                                children: "⇄"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 343,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setActiveFlyoutTarget('secondary'),
                                className: `flex-1 flex items-center gap-1.5 px-1.5 py-0.5 rounded-[2px] transition-colors cursor-pointer ${activeFlyoutTarget === 'secondary' ? 'bg-[var(--surface-2)] text-[var(--text-heading)] border border-[var(--accent-plum)]' : 'text-[var(--text-muted)] hover:text-[var(--text-heading)] border border-transparent'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "w-3.5 h-3.5 rounded-[1px] border border-[var(--desk-border)] shrink-0",
                                        style: {
                                            backgroundColor: secondaryColor
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 359,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col text-left leading-tight",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[8px] font-sans font-medium text-[var(--text-muted)] uppercase",
                                                children: "Sec"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                                lineNumber: 364,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[9px] font-mono font-bold text-[var(--text-heading)] truncate max-w-[50px]",
                                                children: secondaryColor
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                                lineNumber: 365,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 363,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 351,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                        lineNumber: 322,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between text-[9px] text-[var(--text-muted)]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "truncate max-w-[120px] font-medium font-sans",
                                        children: currentPalette.name
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 375,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-mono text-[8px]",
                                        children: [
                                            currentPalette.colors.length,
                                            "c"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 376,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 374,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-8 gap-1",
                                children: currentPalette.colors.slice(0, 16).map((color, idx)=>{
                                    const isSelected = (activeFlyoutTarget === 'primary' ? primaryColor : secondaryColor).toLowerCase() === color.toLowerCase();
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>handleApplyColor(color),
                                        onContextMenu: (e)=>{
                                            e.preventDefault();
                                            handleApplyColor(color, activeFlyoutTarget === 'primary' ? 'secondary' : 'primary');
                                        },
                                        style: {
                                            backgroundColor: color
                                        },
                                        className: `w-[21px] h-[21px] rounded-[1px] border transition-transform hover:scale-110 active:scale-95 cursor-pointer relative ${isSelected ? 'border-white ring-1 ring-[var(--accent-gold)] z-10' : 'border-[var(--desk-border)]'}`,
                                        title: `${color} (Click: ${activeFlyoutTarget} | Right-click: alternate)`
                                    }, `flyout-pal-${color}-${idx}`, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 384,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0));
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 378,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                        lineNumber: 373,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    recentColors.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1 pt-1 border-t border-[var(--desk-border)]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[9px] text-[var(--text-muted)] font-medium font-sans",
                                children: "Recent Colors"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 407,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1 flex-wrap",
                                children: recentColors.slice(0, 8).map((color, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>handleApplyColor(color),
                                        onContextMenu: (e)=>{
                                            e.preventDefault();
                                            handleApplyColor(color, activeFlyoutTarget === 'primary' ? 'secondary' : 'primary');
                                        },
                                        style: {
                                            backgroundColor: color
                                        },
                                        className: "w-4 h-4 rounded-[1px] border border-[var(--desk-border)] hover:scale-110 cursor-pointer",
                                        title: `${color} (Recent)`
                                    }, `flyout-rec-${color}-${idx}`, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 410,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 408,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                        lineNumber: 406,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1 pt-1 border-t border-[var(--desk-border)]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    setIsFlyoutOpen(false);
                                    setColorPickerTarget(activeFlyoutTarget);
                                },
                                className: "w-full py-1 px-2 text-[10px] font-sans font-medium pixel-tactile-btn text-[var(--text-body)] hover:text-[var(--text-heading)] border border-[var(--desk-border)] rounded-[2px] cursor-pointer flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Custom Spectrum Picker..."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 435,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px] text-[var(--accent-gold)] font-mono",
                                        children: "+"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 436,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 428,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    setIsFlyoutOpen(false);
                                    setActiveInspectorTab('palette');
                                },
                                className: "w-full py-1 px-2 text-[10px] font-sans font-medium pixel-tactile-btn text-[var(--accent-gold)] hover:bg-[var(--surface-3)] border border-transparent hover:border-[var(--desk-border)] rounded-[2px] cursor-pointer flex items-center justify-between transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Open Full Palette Tab"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 445,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px]",
                                        children: "▸"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                        lineNumber: 446,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                                lineNumber: 438,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                        lineNumber: 427,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                lineNumber: 295,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)), document.body),
            colorPickerTarget && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ColorPickerModal, {
                isOpen: Boolean(colorPickerTarget),
                onClose: ()=>setColorPickerTarget(null),
                target: colorPickerTarget
            }, void 0, false, {
                fileName: "[project]/src/components/layout/LeftToolbar.tsx",
                lineNumber: 455,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/LeftToolbar.tsx",
        lineNumber: 144,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(LeftToolbar, "OpCEah3wUiUm4CoJsYBXDxicxZ4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c1 = LeftToolbar;
var _c, _c1;
__turbopack_context__.k.register(_c, "ColorPickerModal");
__turbopack_context__.k.register(_c1, "LeftToolbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/MobileStudioGate.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MobileStudioGate",
    ()=>MobileStudioGate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixiBunLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixiBunLogo.tsx [app-client] (ecmascript)");
'use client';
;
;
;
const MobileStudioGate = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "lg:hidden fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[var(--desk-bg)] text-[var(--text-heading)] p-6 text-center font-mono",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6 flex justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixiBunLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixiBunLogo"], {
                    size: "lg",
                    className: "drop-shadow-md"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/MobileStudioGate.tsx",
                    lineNumber: 11,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/layout/MobileStudioGate.tsx",
                lineNumber: 10,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-xl font-bold font-display text-[var(--accent-gold)] mb-3",
                children: "Desk Too Small"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/MobileStudioGate.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-[var(--text-body)] mb-6 max-w-sm leading-relaxed",
                children: "PixiBun Atelier is a desktop workstation featuring multi-layer timelines, color ramps, and pixel math tools. Please open this studio on a laptop, desktop screen, or rotate your tablet to landscape mode (1024px+)."
            }, void 0, false, {
                fileName: "[project]/src/components/layout/MobileStudioGate.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: "px-4 py-2 bg-[var(--desk-surface)] text-[var(--accent-gold)] border border-[var(--desk-border)] rounded text-xs font-bold hover:bg-[var(--desk-surface-raised)] transition-colors",
                        children: "Return Home"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/MobileStudioGate.tsx",
                        lineNumber: 20,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/playground",
                        className: "px-4 py-2 bg-[var(--accent-gold)] text-[var(--desk-bg)] font-bold border border-[#8c5120] rounded text-xs hover:bg-[#ffd699] transition-colors",
                        children: "Try Pocket Doodle Pad"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/MobileStudioGate.tsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/MobileStudioGate.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/MobileStudioGate.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = MobileStudioGate;
var _c;
__turbopack_context__.k.register(_c, "MobileStudioGate");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/RightInspector.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RightInspector",
    ()=>RightInspector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$inspector$2f$LayersPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/inspector/LayersPanel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$inspector$2f$PalettePanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/inspector/PalettePanel.tsx [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const AiToolsPanel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/layout/inspector/AiToolsPanel.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.AiToolsPanel), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/layout/inspector/AiToolsPanel.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = AiToolsPanel;
const RightInspector = ()=>{
    _s();
    const activeInspectorTab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "RightInspector.useStudioStore[activeInspectorTab]": (s)=>s.activeInspectorTab
    }["RightInspector.useStudioStore[activeInspectorTab]"]);
    const setActiveInspectorTab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "RightInspector.useStudioStore[setActiveInspectorTab]": (s)=>s.setActiveInspectorTab
    }["RightInspector.useStudioStore[setActiveInspectorTab]"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        "data-testid": "right-inspector",
        className: "w-[292px] border-l shrink-0 bg-[var(--desk-surface)] border-[var(--desk-border)] flex flex-col justify-between select-none z-10 text-[var(--text-heading)] transition-all duration-150",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex bg-[var(--desk-surface)] border-b border-[var(--desk-border)] h-9 p-1 gap-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setActiveInspectorTab('layers'),
                        "aria-label": "Layers",
                        "data-testid": "tab-layers",
                        className: `flex-1 flex items-center justify-center gap-1.5 text-xs font-sans cursor-pointer rounded-[2px] transition-all duration-100 ${activeInspectorTab === 'layers' ? 'bg-[var(--inspector-tab-active-bg)] text-[var(--inspector-tab-active-fg)] border border-[var(--inspector-tab-active-border)] font-bold shadow-[inset_1px_1px_0_rgba(255,255,255,0.15),0_1px_0_var(--btn-shadow)]' : 'pixel-tactile-btn border border-[var(--desk-border)] text-[var(--text-muted)] hover:text-[var(--text-heading)]'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "layers",
                                size: 13
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/RightInspector.tsx",
                                lineNumber: 36,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Layers"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/RightInspector.tsx",
                                lineNumber: 37,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/RightInspector.tsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setActiveInspectorTab('palette'),
                        "aria-label": "Palette",
                        "data-testid": "tab-palette",
                        className: `flex-1 flex items-center justify-center gap-1.5 text-xs font-sans cursor-pointer rounded-[2px] transition-all duration-100 ${activeInspectorTab === 'palette' ? 'bg-[var(--inspector-tab-active-bg)] text-[var(--inspector-tab-active-fg)] border border-[var(--inspector-tab-active-border)] font-bold shadow-[inset_1px_1px_0_rgba(255,255,255,0.15),0_1px_0_var(--btn-shadow)]' : 'pixel-tactile-btn border border-[var(--desk-border)] text-[var(--text-muted)] hover:text-[var(--text-heading)]'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "palette",
                                size: 13
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/RightInspector.tsx",
                                lineNumber: 50,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Palette"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/RightInspector.tsx",
                                lineNumber: 51,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/RightInspector.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setActiveInspectorTab('ai'),
                        "aria-label": "PixiTools",
                        "data-testid": "tab-ai",
                        title: "PixiTools",
                        className: `flex-1 flex items-center justify-center gap-1.5 text-xs font-sans cursor-pointer rounded-[2px] transition-all duration-100 ${activeInspectorTab === 'ai' ? 'bg-[var(--inspector-tab-active-bg)] text-[var(--inspector-tab-active-fg)] border border-[var(--inspector-tab-active-border)] font-bold shadow-[inset_1px_1px_0_rgba(255,255,255,0.15),0_1px_0_var(--btn-shadow)]' : 'pixel-tactile-btn border border-[var(--desk-border)] text-[var(--text-muted)] hover:text-[var(--text-heading)]'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "chisel",
                                size: 13
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/RightInspector.tsx",
                                lineNumber: 65,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "PixiTools"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/RightInspector.tsx",
                                lineNumber: 66,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/RightInspector.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/RightInspector.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 min-h-0 overflow-y-auto",
                children: [
                    activeInspectorTab === 'layers' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$inspector$2f$LayersPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LayersPanel"], {}, void 0, false, {
                        fileName: "[project]/src/components/layout/RightInspector.tsx",
                        lineNumber: 72,
                        columnNumber: 45
                    }, ("TURBOPACK compile-time value", void 0)),
                    activeInspectorTab === 'palette' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$inspector$2f$PalettePanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PalettePanel"], {}, void 0, false, {
                        fileName: "[project]/src/components/layout/RightInspector.tsx",
                        lineNumber: 73,
                        columnNumber: 46
                    }, ("TURBOPACK compile-time value", void 0)),
                    activeInspectorTab === 'ai' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AiToolsPanel, {}, void 0, false, {
                        fileName: "[project]/src/components/layout/RightInspector.tsx",
                        lineNumber: 74,
                        columnNumber: 41
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/RightInspector.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/RightInspector.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(RightInspector, "MTWonJoO7eXiVkEikMRU/j6lbck=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c1 = RightInspector;
var _c, _c1;
__turbopack_context__.k.register(_c, "AiToolsPanel");
__turbopack_context__.k.register(_c1, "RightInspector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/StatusBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StatusBar",
    ()=>StatusBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$CursorStatusBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/CursorStatusBadge.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const StatusBar = /*#__PURE__*/ _s(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_c = _s(()=>{
    _s();
    const [coords, setCoords] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const activeTool = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StatusBar.useStudioStore[activeTool]": (s)=>s.tools.activeTool
    }["StatusBar.useStudioStore[activeTool]"]);
    const canvasWidth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StatusBar.useStudioStore[canvasWidth]": (s)=>s.canvasWidth
    }["StatusBar.useStudioStore[canvasWidth]"]);
    const canvasHeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StatusBar.useStudioStore[canvasHeight]": (s)=>s.canvasHeight
    }["StatusBar.useStudioStore[canvasHeight]"]);
    const zoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StatusBar.useStudioStore[zoom]": (s)=>s.zoom
    }["StatusBar.useStudioStore[zoom]"]);
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StatusBar.useStudioStore[frames]": (s)=>s.frames
    }["StatusBar.useStudioStore[frames]"]);
    const activeFrameIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StatusBar.useStudioStore[activeFrameIndex]": (s)=>s.activeFrameIndex
    }["StatusBar.useStudioStore[activeFrameIndex]"]);
    const activeLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StatusBar.useStudioStore[activeLayerId]": (s)=>s.activeLayerId
    }["StatusBar.useStudioStore[activeLayerId]"]);
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StatusBar.useStudioStore[selection]": (s)=>s.selection
    }["StatusBar.useStudioStore[selection]"]);
    const isDirty = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StatusBar.useStudioStore[isDirty]": (s)=>s.isDirty
    }["StatusBar.useStudioStore[isDirty]"]);
    const saveStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StatusBar.useStudioStore[saveStatus]": (s)=>s.saveStatus
    }["StatusBar.useStudioStore[saveStatus]"]);
    const saveLabel = saveStatus === 'saving' ? 'Saving…' : saveStatus === 'error' ? 'Save issue' : isDirty ? 'Unsaved' : 'Saved';
    const saveTitle = saveStatus === 'saving' ? 'Saving changes to local storage…' : saveStatus === 'error' ? 'Save paused. Your artwork remains safe in memory.' : isDirty ? 'You have unsaved changes' : 'All changes saved to local storage';
    /* Derive active layer name */ const activeLayerName = frames[activeFrameIndex]?.layers.find((l)=>l.id === activeLayerId)?.name;
    /* Derive selection dimensions */ const selectionInfo = selection != null ? {
        w: selection.x + selection.w > 0 ? selection.w : 0,
        h: selection.y + selection.h > 0 ? selection.h : 0
    } : null;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StatusBar.useEffect": ()=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$CursorStatusBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subscribeCursorHUD"])({
                "StatusBar.useEffect": (c)=>setCoords(c)
            }["StatusBar.useEffect"]);
        }
    }["StatusBar.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "status-bar",
        className: "flex items-center h-6 px-[var(--space-4)] gap-[var(--space-5)] bg-[var(--desk-surface)] border-t border-[var(--desk-border)] text-[var(--text-muted)] font-mono text-[10px] select-none shrink-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "data-testid": "cursor-status-badge",
                className: "flex items-center gap-1 min-w-[90px]",
                children: coords ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[var(--accent-gold)]",
                        children: [
                            "X: ",
                            coords.x,
                            " Y: ",
                            coords.y
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/StatusBar.tsx",
                        lineNumber: 56,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/StatusBar.tsx",
                    lineNumber: 55,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-[var(--text-body)]",
                    children: "X: — Y: —"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/StatusBar.tsx",
                    lineNumber: 61,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-px h-3 bg-[var(--desk-border)]"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex items-center gap-1",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-[var(--text-muted)]",
                    children: [
                        canvasWidth,
                        "×",
                        canvasHeight
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/layout/StatusBar.tsx",
                    lineNumber: 70,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 69,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-px h-3 bg-[var(--desk-border)]"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[var(--text-muted)]",
                children: [
                    zoom,
                    "%"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 79,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-px h-3 bg-[var(--desk-border)]"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 82,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[var(--text-muted)]",
                children: [
                    "Frame ",
                    activeFrameIndex + 1,
                    "/",
                    frames.length
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-px h-3 bg-[var(--desk-border)]"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "truncate max-w-[120px] text-[var(--text-body)]",
                children: activeLayerName ?? 'No Layer'
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex-1"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 98,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            selectionInfo && selectionInfo.w > 0 && selectionInfo.h > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[var(--accent-plum)]",
                        children: [
                            "Sel: ",
                            selectionInfo.w,
                            "×",
                            selectionInfo.h
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/StatusBar.tsx",
                        lineNumber: 103,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "w-px h-3 bg-[var(--desk-border)]"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/StatusBar.tsx",
                        lineNumber: 106,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 102,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex items-center gap-1.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "w-1.5 h-1.5 rounded-full bg-[var(--accent-wisteria)]"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/StatusBar.tsx",
                        lineNumber: 112,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "capitalize text-[var(--accent-gold)]",
                        children: activeTool
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/StatusBar.tsx",
                        lineNumber: 113,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 111,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-px h-3 shrink-0 bg-[var(--desk-border)]"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "data-testid": "status-bar-save-indicator",
                className: "shrink-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    "data-testid": "save-status-badge",
                    role: "status",
                    "aria-live": "polite",
                    title: saveTitle,
                    className: `h-5 px-2 flex items-center gap-1.5 whitespace-nowrap rounded-[2px] border ${saveStatus === 'error' ? 'bg-[#2e111a] border-[#eb5a66]/60 text-[#ffb4b9]' : saveStatus === 'saving' || isDirty ? 'bg-[var(--surface-0)] border-[var(--desk-border)] text-[var(--accent-gold)]' : 'bg-[var(--surface-0)] border-[var(--desk-border)] text-[var(--text-muted)]'}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "aria-hidden": "true",
                            className: `w-1.5 h-1.5 shrink-0 rounded-full ${saveStatus === 'error' ? 'bg-[#eb5a66]' : saveStatus === 'saving' ? 'bg-[var(--accent-gold)] animate-pulse' : isDirty ? 'bg-[var(--accent-gold)]' : 'bg-[var(--accent-sage,#7d9d7f)]'}`
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/StatusBar.tsx",
                            lineNumber: 132,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: saveLabel
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/StatusBar.tsx",
                            lineNumber: 133,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/layout/StatusBar.tsx",
                    lineNumber: 119,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StatusBar.tsx",
                lineNumber: 118,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/StatusBar.tsx",
        lineNumber: 45,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
}, "UgHEpxr6OkafSHPsdE4rZcxixvc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
})), "UgHEpxr6OkafSHPsdE4rZcxixvc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c1 = StatusBar;
StatusBar.displayName = 'StatusBar';
var _c, _c1;
__turbopack_context__.k.register(_c, "StatusBar$React.memo");
__turbopack_context__.k.register(_c1, "StatusBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/StudioLayout.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StudioLayout",
    ()=>StudioLayout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$AtelierRail$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/AtelierRail.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$LeftToolbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/LeftToolbar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$CenterViewport$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/CenterViewport.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$RightInspector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/RightInspector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$BottomTimeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/BottomTimeline.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$StatusBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/StatusBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ModalWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/ModalWrapper.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/TactileButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/project/serialize.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$decodeProject$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/decodeProject.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$imageImportExecution$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/imageImportExecution.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$localSaveLabel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/localSaveLabel.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/studio/useStudioAutosave.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioClipboard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/studio/useStudioClipboard.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/studio/useStudioFileSystem.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioKeyboard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/studio/useStudioKeyboard.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Heavy dialogs are code-split client-side (Phase 33): none of these bundles
// are part of the /studio first-load JS. They render only while open, so the
// chunks are fetched on first open rather than on page load.
const ExportModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/modals/ExportModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.ExportModal), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/modals/ExportModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = ExportModal;
const ShortcutsModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/modals/ShortcutsModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.ShortcutsModal), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/modals/ShortcutsModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c1 = ShortcutsModal;
const CanvasResizeModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/modals/CanvasResizeModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.CanvasResizeModal), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/modals/CanvasResizeModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c2 = CanvasResizeModal;
const ImportModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/modals/ImportModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.ImportModal), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/modals/ImportModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c3 = ImportModal;
const ProjectsGalleryModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/modals/ProjectsGalleryModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.ProjectsGalleryModal), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/modals/ProjectsGalleryModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c4 = ProjectsGalleryModal;
const CoDrawModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/modals/CoDrawModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.CoDrawModal), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/modals/CoDrawModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c5 = CoDrawModal;
const DiagnosticsModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/modals/DiagnosticsModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.DiagnosticsModal), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/modals/DiagnosticsModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c6 = DiagnosticsModal;
const CommandPaletteModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/modals/CommandPaletteModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.CommandPaletteModal), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/modals/CommandPaletteModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c7 = CommandPaletteModal;
const RecoveryModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/modals/RecoveryModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>m.RecoveryModal), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/modals/RecoveryModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c8 = RecoveryModal;
const StudioLayout = ()=>{
    _s();
    const [isExportOpen, setIsExportOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [exportInitialType, setExportInitialType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('png');
    const [isShortcutsOpen, setIsShortcutsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isDiagnosticsOpen, setIsDiagnosticsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isResizeOpen, setIsResizeOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isImportOpen, setIsImportOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isNewConfirmOpen, setIsNewConfirmOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isGalleryOpen, setIsGalleryOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCoDrawOpen, setIsCoDrawOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCommandPaletteOpen, setIsCommandPaletteOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [importPayload, setImportPayload] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [importError, setImportError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const openExport = (type = 'png')=>{
        setExportInitialType(type);
        setIsExportOpen(true);
    };
    const [recoveryTarget, setRecoveryTarget] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isRecoveryOpen, setIsRecoveryOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const startupRecoveryPromptedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [activeToast, setActiveToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const toastTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudioLayout.useEffect": ()=>{
            const unsub = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:toast', {
                "StudioLayout.useEffect.unsub": (payload)=>{
                    if (toastTimerRef.current !== null) {
                        window.clearTimeout(toastTimerRef.current);
                    }
                    setActiveToast({
                        message: payload.message,
                        type: payload.type || 'default',
                        action: payload.action
                    });
                    toastTimerRef.current = window.setTimeout({
                        "StudioLayout.useEffect.unsub": ()=>{
                            setActiveToast(null);
                            toastTimerRef.current = null;
                        }
                    }["StudioLayout.useEffect.unsub"], payload.action ? 5000 : 3500);
                }
            }["StudioLayout.useEffect.unsub"]);
            return ({
                "StudioLayout.useEffect": ()=>{
                    unsub();
                    if (toastTimerRef.current !== null) {
                        window.clearTimeout(toastTimerRef.current);
                    }
                }
            })["StudioLayout.useEffect"];
        }
    }["StudioLayout.useEffect"], []);
    const { autosaveTimerRef, runAutosave, handleCommitHistory, autosaveError, saveConflict, saveConflictCopy, setAutosaveError, openStoredProject, lifecycleState, clearPendingRecovery } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStudioAutosave"])();
    const pendingRecovery = lifecycleState.phase === 'active' ? lifecycleState.pendingRecovery : undefined;
    // Auto-prompt Recovery Modal on startup when pending recovery is detected
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudioLayout.useEffect": ()=>{
            if (pendingRecovery) {
                if (startupRecoveryPromptedRef.current !== pendingRecovery.sourceProjectId) {
                    startupRecoveryPromptedRef.current = pendingRecovery.sourceProjectId;
                    setRecoveryTarget(pendingRecovery);
                    setIsRecoveryOpen(true);
                }
            }
        }
    }["StudioLayout.useEffect"], [
        pendingRecovery
    ]);
    const { saveToast, triggerSaveToast, handleSaveDesktopProject } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStudioFileSystem"])();
    const canUndo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StudioLayout.useStudioStore[canUndo]": (s)=>s.canUndo
    }["StudioLayout.useStudioStore[canUndo]"]);
    const canRedo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StudioLayout.useStudioStore[canRedo]": (s)=>s.canRedo
    }["StudioLayout.useStudioStore[canRedo]"]);
    const setCanvasSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StudioLayout.useStudioStore[setCanvasSize]": (s)=>s.setCanvasSize
    }["StudioLayout.useStudioStore[setCanvasSize]"]);
    const currentProjectId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StudioLayout.useStudioStore[currentProjectId]": (s)=>s.currentProjectId
    }["StudioLayout.useStudioStore[currentProjectId]"]);
    const projectName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StudioLayout.useStudioStore[projectName]": (s)=>s.projectName
    }["StudioLayout.useStudioStore[projectName]"]);
    const resetToNewProject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StudioLayout.useStudioStore[resetToNewProject]": (s)=>s.resetToNewProject
    }["StudioLayout.useStudioStore[resetToNewProject]"]);
    const saveBeforeReplacingWorkspace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[saveBeforeReplacingWorkspace]": async ()=>{
            if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().isDirty) return true;
            const result = await runAutosave();
            if (result.ok && !__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().isDirty) return true;
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                type: 'error',
                message: 'The current drawing could not be saved. Export a backup before replacing it.'
            });
            return false;
        }
    }["StudioLayout.useCallback[saveBeforeReplacingWorkspace]"], [
        runAutosave
    ]);
    const startNewWorkspace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[startNewWorkspace]": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearAllBuffers"])();
            resetToNewProject();
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:history-clear');
            void runAutosave();
        }
    }["StudioLayout.useCallback[startNewWorkspace]"], [
        resetToNewProject,
        runAutosave
    ]);
    const handleConfirmNewDrawing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[handleConfirmNewDrawing]": async ()=>{
            if (!await saveBeforeReplacingWorkspace()) return;
            startNewWorkspace();
            setIsNewConfirmOpen(false);
        }
    }["StudioLayout.useCallback[handleConfirmNewDrawing]"], [
        saveBeforeReplacingWorkspace,
        startNewWorkspace
    ]);
    const handleOpenProject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[handleOpenProject]": async (projectId)=>{
            const result = await openStoredProject(projectId);
            if (!result.success) {
                if (result.reason === 'recovery-required') {
                    throw new Error('This project requires recovery and cannot be opened directly.');
                }
                if (result.reason === 'unsupported-version') {
                    throw new Error(result.message);
                }
                if (result.reason === 'blocked') {
                    throw new Error(result.message);
                }
                if (result.reason === 'transient-failure') {
                    throw new Error(result.message);
                }
                if (result.reason === 'hydration-failure') {
                    throw new Error(`Project could not be loaded into the workspace: ${result.message}`);
                }
                if (result.reason === 'not-found') {
                    throw new Error('Project not found in storage.');
                }
            }
        }
    }["StudioLayout.useCallback[handleOpenProject]"], [
        openStoredProject
    ]);
    const handleRecoveryComplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[handleRecoveryComplete]": async (recoveredProjectId)=>{
            const openRes = await openStoredProject(recoveredProjectId, true);
            if (openRes.success) {
                clearPendingRecovery();
                setRecoveryTarget(null);
                setIsRecoveryOpen(false);
                return true;
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                type: 'error',
                message: 'Failed to admit recovered project workspace. Previous workspace preserved.'
            });
            return false;
        }
    }["StudioLayout.useCallback[handleRecoveryComplete]"], [
        clearPendingRecovery,
        openStoredProject
    ]);
    const isDirty = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StudioLayout.useStudioStore[isDirty]": (s)=>s.isDirty
    }["StudioLayout.useStudioStore[isDirty]"]);
    const saveStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "StudioLayout.useStudioStore[saveStatus]": (s)=>s.saveStatus
    }["StudioLayout.useStudioStore[saveStatus]"]);
    // Synchronize document title with unsaved dirty indicator
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudioLayout.useEffect": ()=>{
            document.title = `${isDirty ? '● ' : ''}${projectName} — PixiBun`;
            return ({
                "StudioLayout.useEffect": ()=>{
                    document.title = 'PixiBun Atelier — 2.5D Photometric Pixel Art Studio & Animation Engine';
                }
            })["StudioLayout.useEffect"];
        }
    }["StudioLayout.useEffect"], [
        isDirty,
        projectName
    ]);
    // Undo / Redo handlers dispatching to canvas engine
    const handleUndo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[handleUndo]": ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:undo');
        }
    }["StudioLayout.useCallback[handleUndo]"], []);
    const handleRedo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[handleRedo]": ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:redo');
        }
    }["StudioLayout.useCallback[handleRedo]"], []);
    // Handle Canvas Resize - anchor and resample choices flow through so
    // content lands where the user asked instead of hugging the top-left.
    // History MUST be invalidated here: undo snapshots store full-canvas
    // ImageData at the old dimensions, so Ctrl+Z after a resize would
    // putImageData stale-size pixels onto the resized buffers and corrupt
    // the artwork.
    const handleResize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[handleResize]": (newWidth, newHeight, anchor, resample)=>{
            try {
                setCanvasSize(newWidth, newHeight, anchor, resample);
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:history-clear');
            } catch (e) {
                const message = e instanceof Error ? e.message : 'Failed to resize canvas';
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    message,
                    type: 'error'
                });
            }
        }
    }["StudioLayout.useCallback[handleResize]"], [
        setCanvasSize
    ]);
    // Handle File Import Trigger
    const handleOpenImport = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[handleOpenImport]": (payload)=>{
            setImportPayload(payload || null);
            setIsImportOpen(true);
        }
    }["StudioLayout.useCallback[handleOpenImport]"], []);
    // Confirm Image Import & Inject Pixel Art to Target Buffer
    const handleConfirmImportImage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[handleConfirmImportImage]": (confirmData)=>{
            const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$imageImportExecution$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["executeImageImport"])(confirmData);
            if (result.ok) {
                setIsImportOpen(false);
            }
        }
    }["StudioLayout.useCallback[handleConfirmImportImage]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioClipboard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStudioClipboard"])(handleOpenImport);
    // Confirm Project Import - validate before touching live state so a
    // malformed file explains itself instead of corrupting the session.
    const handleConfirmImportProject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "StudioLayout.useCallback[handleConfirmImportProject]": async ()=>{
            if (!importPayload?.projectJson) return;
            const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$decodeProject$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodeAndValidateProject"])(importPayload.projectJson);
            if (!result.ok) {
                setImportError(result.error);
                return;
            }
            try {
                const saveRes = await runAutosave();
                if (!saveRes.ok && saveRes.reason !== 'restore-invalid') {
                    setImportError('The current project could not be saved. Export a backup before replacing it.');
                    return;
                }
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["hydrateProject"])(result.value);
                setImportError(null);
                setIsImportOpen(false);
                void runAutosave();
            } catch (error) {
                setImportError(error instanceof Error ? error.message : 'The project could not be opened.');
            }
        }
    }["StudioLayout.useCallback[handleConfirmImportProject]"], [
        importPayload,
        runAutosave
    ]);
    // Global Keyboard Shortcuts
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioKeyboard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStudioKeyboard"])({
        autosaveTimerRef,
        runAutosave,
        triggerSaveToast,
        handleSaveDesktopProject,
        setIsShortcutsOpen,
        setIsCommandPaletteOpen,
        handleUndo,
        handleRedo
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-restoration-phase": lifecycleState.phase,
        className: "flex flex-col h-screen w-screen bg-[var(--desk-bg)] text-[var(--text-heading)] transition-colors duration-300 overflow-hidden select-none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$AtelierRail$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AtelierRail"], {
                onOpenExport: ()=>openExport(),
                onOpenImport: handleOpenImport,
                onOpenShortcuts: ()=>setIsShortcutsOpen(true),
                onOpenResize: ()=>setIsResizeOpen(true),
                onNewDrawing: ()=>setIsNewConfirmOpen(true),
                onOpenGallery: ()=>setIsGalleryOpen(true),
                onOpenCoDraw: ()=>setIsCoDrawOpen(true),
                onUndo: handleUndo,
                onRedo: handleRedo,
                canUndo: canUndo,
                canRedo: canRedo,
                onSaveNow: ()=>{
                    void runAutosave().then((res)=>{
                        if (res.ok) triggerSaveToast();
                    });
                }
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 322,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sr-only",
                role: "status",
                "aria-live": "polite",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$localSaveLabel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocalSaveLabel"])(saveStatus, isDirty)
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 340,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            autosaveError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: "alert",
                className: `fixed bottom-10 left-16 max-w-md shadow-2xl p-3.5 rounded-[3px] flex flex-col gap-2 z-40 text-xs font-mono backdrop-blur-sm animate-in fade-in slide-in-from-bottom-2 duration-150 ${saveConflict ? 'bg-[#251829]/95 border-2 border-[#f0be7c] text-[#ede8f4]' : 'bg-[#2e111a]/95 border-2 border-[#eb5a66] text-[#ffb4b9]'}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `flex items-center justify-between gap-2 border-b pb-1.5 ${saveConflict ? 'border-[#5a3a28]' : 'border-[#6b283d]'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `flex items-center gap-1.5 font-bold ${saveConflict ? 'text-[#f0be7c]' : 'text-[#eb5a66]'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                        name: "warning",
                                        size: 13,
                                        className: "shrink-0"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                        lineNumber: 364,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: saveConflict ? 'This project was changed in another PixiBun tab.' : 'Storage issue · Artwork safe in tab'
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                        lineNumber: 365,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 359,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setAutosaveError(null),
                                className: "px-1.5 py-0.5 text-xs text-[#d0c4df] hover:text-white transition-colors cursor-pointer leading-none",
                                title: "Dismiss warning",
                                "aria-label": "Dismiss error",
                                children: "✕"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 371,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 354,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-[11px] leading-relaxed space-y-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: `font-semibold ${saveConflict ? 'text-[#5cdaac]' : 'text-[#f0be7c]'}`,
                                children: saveConflict ? 'Your current artwork is safe in this tab.' : 'Your current drawing is preserved in memory.'
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 381,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: saveConflict ? 'text-[#d0c4df]' : 'text-[#ffb4b9]',
                                children: autosaveError
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 386,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 380,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-end gap-2 pt-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setAutosaveError(null),
                                className: "text-[11px] px-2 py-0.5 text-[#a599b5] hover:text-white transition-colors cursor-pointer",
                                children: "Keep editing"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 391,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            saveConflict && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                onClick: ()=>void saveConflictCopy(),
                                children: "Save a copy"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 399,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                variant: saveConflict ? 'default' : 'danger',
                                onClick: ()=>openExport(),
                                title: "Open Export Dialog",
                                className: saveConflict ? 'text-xs px-2.5 py-1 font-bold' : 'text-xs px-2.5 py-1 bg-[#eb5a66] hover:bg-[#ff8c94] text-[#140d1f] font-bold border border-[#8c202a]',
                                children: "Export Drawing"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 403,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 390,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 346,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "main-workspace",
                tabIndex: -1,
                className: "flex flex-1 overflow-hidden outline-none relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$LeftToolbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftToolbar"], {}, void 0, false, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 418,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$CenterViewport$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CenterViewport"], {
                        retainHistory: true,
                        onCommitHistory: handleCommitHistory,
                        onOpenImport: handleOpenImport
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 419,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$RightInspector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RightInspector"], {}, void 0, false, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 424,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 417,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$BottomTimeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BottomTimeline"], {}, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 428,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$StatusBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StatusBar"], {}, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 431,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ModalWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModalWrapper"], {
                isOpen: isNewConfirmOpen,
                onClose: ()=>setIsNewConfirmOpen(false),
                title: "Start a New Drawing?",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-5 flex flex-col gap-4 text-sm text-[var(--text-body)]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "leading-relaxed",
                            children: "Starting a new drawing will clear the current canvas and reset the studio to a fresh blank project."
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/StudioLayout.tsx",
                            lineNumber: 440,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-[var(--accent-gold)] font-mono",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: "export",
                                    size: 12,
                                    className: "inline align-[-2px] mr-1"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                    lineNumber: 444,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                " If you want to keep your current artwork, remember to export it as PNG or a .pixibun project file first."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/StudioLayout.tsx",
                            lineNumber: 443,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-end gap-2.5 pt-2 border-t border-[var(--desk-border)]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                    size: "sm",
                                    variant: "default",
                                    onClick: ()=>setIsNewConfirmOpen(false),
                                    children: "Keep Drawing"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                    lineNumber: 447,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                    size: "sm",
                                    variant: "danger",
                                    onClick: handleConfirmNewDrawing,
                                    children: "Start New Drawing"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                    lineNumber: 454,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/StudioLayout.tsx",
                            lineNumber: 446,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/layout/StudioLayout.tsx",
                    lineNumber: 439,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 434,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            isExportOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExportModal, {
                isOpen: isExportOpen,
                initialType: exportInitialType,
                onClose: ()=>setIsExportOpen(false)
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 467,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            isShortcutsOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShortcutsModal, {
                isOpen: isShortcutsOpen,
                onClose: ()=>setIsShortcutsOpen(false),
                onOpenDiagnostics: ()=>setIsDiagnosticsOpen(true)
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 476,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            isDiagnosticsOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DiagnosticsModal, {
                isOpen: isDiagnosticsOpen,
                onClose: ()=>setIsDiagnosticsOpen(false)
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 485,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            isResizeOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CanvasResizeModal, {
                isOpen: isResizeOpen,
                onClose: ()=>setIsResizeOpen(false),
                onResize: handleResize
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 493,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            isImportOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ImportModal, {
                isOpen: isImportOpen,
                payload: importPayload,
                error: importError,
                onClose: ()=>{
                    setImportError(null);
                    setImportPayload(null);
                    setIsImportOpen(false);
                },
                onConfirmImage: handleConfirmImportImage,
                onConfirmProject: handleConfirmImportProject,
                onFileSelected: handleOpenImport
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 502,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            isGalleryOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ProjectsGalleryModal, {
                isOpen: isGalleryOpen,
                onClose: ()=>setIsGalleryOpen(false),
                currentProjectId: currentProjectId,
                onOpenProject: handleOpenProject,
                onNewProject: async (skipCurrentSave = false)=>{
                    if (!skipCurrentSave && !await saveBeforeReplacingWorkspace()) return false;
                    startNewWorkspace();
                    return true;
                },
                onOpenImport: ()=>handleOpenImport()
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 519,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            isCoDrawOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CoDrawModal, {
                isOpen: isCoDrawOpen,
                onClose: ()=>setIsCoDrawOpen(false)
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 535,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            isCommandPaletteOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CommandPaletteModal, {
                isOpen: isCommandPaletteOpen,
                onClose: ()=>setIsCommandPaletteOpen(false),
                onOpenExport: ()=>openExport(),
                onOpenImport: ()=>handleOpenImport(),
                onOpenResize: ()=>setIsResizeOpen(true),
                onOpenGallery: ()=>setIsGalleryOpen(true),
                onOpenCoDraw: ()=>setIsCoDrawOpen(true),
                onOpenShortcuts: ()=>setIsShortcutsOpen(true),
                onNewDrawing: ()=>setIsNewConfirmOpen(true),
                onSaveNow: ()=>{
                    void runAutosave().then((res)=>{
                        if (res.ok) triggerSaveToast();
                    });
                },
                onUndo: handleUndo,
                onRedo: handleRedo
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 543,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            isRecoveryOpen && recoveryTarget && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RecoveryModal, {
                isOpen: isRecoveryOpen,
                sourceProjectId: recoveryTarget.sourceProjectId,
                initialAssessment: recoveryTarget.assessment,
                onClose: ()=>{
                    setIsRecoveryOpen(false);
                },
                onRecoveryComplete: handleRecoveryComplete
            }, void 0, false, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 563,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            pendingRecovery && !isRecoveryOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: "region",
                "aria-label": "Pending Project Recovery",
                "data-testid": "pending-recovery-banner",
                className: "fixed top-12 left-1/2 -translate-x-1/2 z-40 max-w-xl w-[90%] bg-[var(--surface-1)] border border-[var(--accent-gold)] shadow-2xl p-2.5 rounded-[4px] flex items-center justify-between gap-3 text-xs font-mono text-[var(--text-heading)] backdrop-blur-sm animate-in fade-in slide-in-from-top-2 duration-150",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 truncate",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "lock",
                                size: 14,
                                className: "text-[var(--accent-gold)] shrink-0"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 583,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "truncate",
                                children: "A previous project requires safe recovery. Original data is preserved untouched."
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 584,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 582,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 shrink-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                variant: "primary",
                                onClick: ()=>{
                                    setRecoveryTarget(pendingRecovery);
                                    setIsRecoveryOpen(true);
                                },
                                className: "text-xs font-bold",
                                "data-testid": "review-recovery-button",
                                children: "Review Recovery Plan"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 589,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>clearPendingRecovery(),
                                className: "p-1 text-[var(--text-muted)] hover:text-[var(--text-heading)] transition-colors cursor-pointer text-xs leading-none",
                                title: "Dismiss banner",
                                "aria-label": "Dismiss recovery banner",
                                "data-testid": "dismiss-recovery-button",
                                children: "✕"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                                lineNumber: 601,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 588,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 576,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            (activeToast || saveToast) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: activeToast?.type === 'error' ? 'alert' : 'status',
                "aria-live": activeToast?.type === 'error' ? 'assertive' : 'polite',
                "data-testid": activeToast ? 'studio-toast' : 'save-affirmation-toast',
                className: `fixed bottom-14 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-2 font-mono text-xs rounded-lg shadow-xl backdrop-blur-sm transition-all ${activeToast?.action ? 'pointer-events-auto' : 'pointer-events-none'} ${activeToast?.type === 'error' ? 'bg-[#2e111a]/95 border border-[#eb5a66] text-[#ffb4b9]' : activeToast?.type === 'success' ? 'bg-[#15241b]/95 border border-[#5cdaac] text-[#8ceec5]' : 'bg-[var(--surface-sunken,#191326)]/95 border border-[var(--accent-gold,#f0be7c)] text-[var(--accent-gold,#f0be7c)]'}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                        name: activeToast?.type === 'error' ? 'warning' : activeToast?.type === 'success' ? 'sparkles' : 'save',
                        size: 14,
                        className: activeToast?.type === 'error' ? 'text-[#eb5a66] shrink-0' : activeToast?.type === 'success' ? 'text-[#5cdaac] shrink-0' : 'text-[var(--accent-gold,#f0be7c)] shrink-0'
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 630,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: activeToast?.message || saveToast
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 641,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    activeToast?.action && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>{
                            activeToast.action?.onClick();
                            setActiveToast(null);
                        },
                        "data-testid": "toast-action-button",
                        className: "ml-2 px-2 py-0.5 rounded-[2px] bg-[var(--surface-2)] hover:bg-[var(--surface-3)] text-[var(--text-heading)] border border-[var(--desk-border)] hover:border-[var(--accent-gold)] cursor-pointer text-[11px] font-sans font-semibold underline transition-colors",
                        children: activeToast.action.label
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/StudioLayout.tsx",
                        lineNumber: 643,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/StudioLayout.tsx",
                lineNumber: 616,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/StudioLayout.tsx",
        lineNumber: 320,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(StudioLayout, "Vg6fDgroBKQvZvf3wrsJ9+2JfQE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStudioAutosave"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStudioFileSystem"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioClipboard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStudioClipboard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$studio$2f$useStudioKeyboard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStudioKeyboard"]
    ];
});
_c9 = StudioLayout;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
__turbopack_context__.k.register(_c, "ExportModal");
__turbopack_context__.k.register(_c1, "ShortcutsModal");
__turbopack_context__.k.register(_c2, "CanvasResizeModal");
__turbopack_context__.k.register(_c3, "ImportModal");
__turbopack_context__.k.register(_c4, "ProjectsGalleryModal");
__turbopack_context__.k.register(_c5, "CoDrawModal");
__turbopack_context__.k.register(_c6, "DiagnosticsModal");
__turbopack_context__.k.register(_c7, "CommandPaletteModal");
__turbopack_context__.k.register(_c8, "RecoveryModal");
__turbopack_context__.k.register(_c9, "StudioLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/inspector/LayersPanel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LayersPanel",
    ()=>LayersPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useCoDrawStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useCoDrawStatus.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/TactileButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/metadataAdmission.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
const EFFECT_LABELS = {
    photometric: '2.5D lighting',
    'auto-shade': 'auto shade',
    'cast-shadow': 'cast shadow',
    'ground-shadow': 'ground shadow',
    'volumetric-optics': 'older material shading',
    'normal-map': 'normal map',
    specular: 'specular light',
    'sel-out': 'selective outline',
    outline: 'outer outline',
    autotile: 'autotile contours',
    wfc: 'older pattern synthesis'
};
function formatRecipeValue(value) {
    if (Array.isArray(value)) return `${value.length} colors`;
    if (value === null) return 'auto';
    if (typeof value === 'boolean') return value ? 'on' : 'off';
    if (typeof value === 'number') return Number.isInteger(value) ? String(value) : value.toFixed(2);
    return value;
}
const LayersPanel = ()=>{
    _s();
    const { isGuest } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useCoDrawStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCoDrawStatus"])();
    const guestLockTitle = 'Layer structure is managed by the session host.';
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[frames]": (s)=>s.frames
    }["LayersPanel.useStudioStore[frames]"]);
    const activeFrameIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[activeFrameIndex]": (s)=>s.activeFrameIndex
    }["LayersPanel.useStudioStore[activeFrameIndex]"]);
    const activeLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[activeLayerId]": (s)=>s.activeLayerId
    }["LayersPanel.useStudioStore[activeLayerId]"]);
    const currentProjectId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[currentProjectId]": (s)=>s.currentProjectId
    }["LayersPanel.useStudioStore[currentProjectId]"]);
    const setActiveLayer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[setActiveLayer]": (s)=>s.setActiveLayer
    }["LayersPanel.useStudioStore[setActiveLayer]"]);
    const addLayer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[addLayer]": (s)=>s.addLayer
    }["LayersPanel.useStudioStore[addLayer]"]);
    const duplicateLayer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[duplicateLayer]": (s)=>s.duplicateLayer
    }["LayersPanel.useStudioStore[duplicateLayer]"]);
    const reorderLayers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[reorderLayers]": (s)=>s.reorderLayers
    }["LayersPanel.useStudioStore[reorderLayers]"]);
    const deleteLayer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[deleteLayer]": (s)=>s.deleteLayer
    }["LayersPanel.useStudioStore[deleteLayer]"]);
    const mergeLayerDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[mergeLayerDown]": (s)=>s.mergeLayerDown
    }["LayersPanel.useStudioStore[mergeLayerDown]"]);
    const toggleLayerVisibility = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[toggleLayerVisibility]": (s)=>s.toggleLayerVisibility
    }["LayersPanel.useStudioStore[toggleLayerVisibility]"]);
    const toggleLayerLock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[toggleLayerLock]": (s)=>s.toggleLayerLock
    }["LayersPanel.useStudioStore[toggleLayerLock]"]);
    const setLayerOpacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[setLayerOpacity]": (s)=>s.setLayerOpacity
    }["LayersPanel.useStudioStore[setLayerOpacity]"]);
    const setLayerBlendMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[setLayerBlendMode]": (s)=>s.setLayerBlendMode
    }["LayersPanel.useStudioStore[setLayerBlendMode]"]);
    const renameLayer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "LayersPanel.useStudioStore[renameLayer]": (s)=>s.renameLayer
    }["LayersPanel.useStudioStore[renameLayer]"]);
    const currentFrame = frames[activeFrameIndex];
    const activeLayer = currentFrame?.layers.find((l)=>l.id === activeLayerId);
    const activeLayerIndex = currentFrame?.layers.findIndex((l)=>l.id === activeLayerId) ?? -1;
    const isMergeDownAvailable = activeLayerIndex >= 0 && !!currentFrame && activeLayerIndex < currentFrame.layers.length - 1 && !activeLayer?.locked && !currentFrame.layers[activeLayerIndex + 1]?.locked;
    const [editingLayerId, setEditingLayerId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [layerNameInput, setLayerNameInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [mergeConfirmLayerId, setMergeConfirmLayerId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [draggedLayerId, setDraggedLayerId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [dropTargetLayerId, setDropTargetLayerId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const mergeTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const opacityGestureLayerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LayersPanel.useEffect": ()=>{
            opacityGestureLayerRef.current = null;
        }
    }["LayersPanel.useEffect"], [
        activeLayerId,
        activeFrameIndex,
        currentProjectId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LayersPanel.useEffect": ()=>{
            return ({
                "LayersPanel.useEffect": ()=>{
                    if (mergeTimerRef.current !== null) {
                        window.clearTimeout(mergeTimerRef.current);
                    }
                }
            })["LayersPanel.useEffect"];
        }
    }["LayersPanel.useEffect"], []);
    const requestMergeDown = (layerId)=>{
        if (mergeTimerRef.current !== null) {
            window.clearTimeout(mergeTimerRef.current);
            mergeTimerRef.current = null;
        }
        if (mergeConfirmLayerId === layerId) {
            setMergeConfirmLayerId(null);
            mergeLayerDown(layerId);
            return;
        }
        setMergeConfirmLayerId(layerId);
        mergeTimerRef.current = window.setTimeout(()=>{
            setMergeConfirmLayerId((current)=>current === layerId ? null : current);
            mergeTimerRef.current = null;
        }, 2500);
    };
    const moveLayer = (sourceId, targetId)=>{
        if (isGuest || sourceId === targetId || !currentFrame) return;
        const sourceIndex = currentFrame.layers.findIndex((layer)=>layer.id === sourceId);
        const targetIndex = currentFrame.layers.findIndex((layer)=>layer.id === targetId);
        if (sourceIndex >= 0 && targetIndex >= 0) reorderLayers(sourceIndex, targetIndex);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-full bg-[var(--desk-surface)]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-8 px-3 flex items-center justify-between bg-[var(--desk-surface-raised)]/40 border-b border-[var(--desk-border)] shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[11px] font-sans font-medium text-[var(--text-muted)]",
                        "data-testid": "layers-stack-header",
                        title: "Each frame has its own layer pixels. A new blank frame keeps the layer names and settings.",
                        children: [
                            "Frame ",
                            activeFrameIndex + 1,
                            " · Layers ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                "data-testid": "layers-stack-count",
                                className: "font-mono text-[10px] text-[var(--text-body)]",
                                children: [
                                    "(",
                                    currentFrame?.layers.length || 0,
                                    ")"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 109,
                                columnNumber: 49
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                        lineNumber: 108,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "icon-sm",
                                variant: "default",
                                disabled: isGuest,
                                onClick: ()=>addLayer(),
                                title: isGuest ? guestLockTitle : 'Add New Layer',
                                "aria-label": "Add New Layer",
                                className: "w-6 h-6 p-0 text-xs",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: "plus",
                                    size: 12
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                    lineNumber: 121,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 112,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "icon-sm",
                                variant: "default",
                                disabled: !activeLayer || isGuest,
                                onClick: ()=>activeLayer && duplicateLayer(activeLayer.id),
                                title: isGuest ? guestLockTitle : 'Duplicate Layer',
                                "aria-label": "Duplicate Layer",
                                className: "w-6 h-6 p-0 text-xs",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: "copy",
                                    size: 12
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                    lineNumber: 132,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 123,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "icon-sm",
                                variant: mergeConfirmLayerId === activeLayer?.id ? 'accent' : 'default',
                                disabled: !activeLayer || !isMergeDownAvailable || isGuest,
                                onClick: ()=>activeLayer && requestMergeDown(activeLayer.id),
                                title: isGuest ? guestLockTitle : mergeConfirmLayerId === activeLayer?.id ? 'Click again to merge layers and flatten the lower effect recipe. Undo is available while history is retained.' : 'Merge Down (flattens the lower effect recipe)',
                                "aria-label": "Merge Down",
                                className: "w-6 h-6 p-0 text-xs",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: "merge-down",
                                    size: 12
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                    lineNumber: 149,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 134,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "icon-sm",
                                variant: "danger",
                                disabled: !currentFrame || currentFrame.layers.length <= 1 || isGuest,
                                onClick: ()=>activeLayer && deleteLayer(activeLayer.id),
                                title: isGuest ? guestLockTitle : 'Delete Layer',
                                "aria-label": "Delete Layer",
                                className: "w-6 h-6 p-0 text-xs",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: "trash",
                                    size: 12
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                    lineNumber: 160,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 151,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                        lineNumber: 111,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                lineNumber: 107,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            activeLayer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-7 px-2.5 flex items-center justify-between gap-2 bg-[var(--desk-surface-raised)]/30 border-b border-[var(--desk-border)] text-[10px] shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1.5 flex-1 min-w-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[var(--text-muted)] font-sans text-[10px] shrink-0",
                                children: "Opacity"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 169,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "range",
                                min: "0",
                                max: "100",
                                step: "5",
                                value: Math.round(activeLayer.opacity * 100),
                                onChange: (e)=>{
                                    const layerId = activeLayer.id;
                                    if (setLayerOpacity(layerId, parseFloat(e.target.value) / 100, opacityGestureLayerRef.current === layerId)) {
                                        opacityGestureLayerRef.current = layerId;
                                    }
                                },
                                onPointerUp: ()=>{
                                    opacityGestureLayerRef.current = null;
                                },
                                onPointerCancel: ()=>{
                                    opacityGestureLayerRef.current = null;
                                },
                                onKeyDown: (e)=>{
                                    if ((e.ctrlKey || e.metaKey) && [
                                        'z',
                                        'y'
                                    ].includes(e.key.toLowerCase())) opacityGestureLayerRef.current = null;
                                },
                                onKeyUp: ()=>{
                                    opacityGestureLayerRef.current = null;
                                },
                                onBlur: ()=>{
                                    opacityGestureLayerRef.current = null;
                                },
                                "aria-label": "Layer opacity",
                                className: "w-12 h-1 accent-[var(--accent-gold)] cursor-pointer"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 170,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-mono text-[10px] text-[var(--text-heading)] font-medium min-w-[28px] text-right shrink-0",
                                children: [
                                    Math.round(activeLayer.opacity * 100),
                                    "%"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 192,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                        lineNumber: 168,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1 shrink-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[var(--text-muted)] font-sans text-[10px]",
                                children: "Blend"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 198,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: activeLayer.blendMode,
                                onChange: (e)=>setLayerBlendMode(activeLayer.id, e.target.value),
                                "aria-label": "Layer blend mode",
                                className: "bg-[var(--desk-surface-raised)] text-[var(--text-heading)] px-1.5 py-0.5 rounded-[2px] border border-[var(--desk-border)] outline-none text-[10px] font-sans cursor-pointer hover:border-[var(--desk-border-highlight)] focus:border-[var(--accent-gold)]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "source-over",
                                        children: "Normal"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 205,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "multiply",
                                        children: "Multiply"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 206,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "screen",
                                        children: "Screen"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 207,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "overlay",
                                        children: "Overlay"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 208,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "color-dodge",
                                        children: "Color Dodge"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 209,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "source-atop",
                                        children: "On artwork only"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 210,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 199,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                        lineNumber: 197,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                lineNumber: 167,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            activeLayer?.effect && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-2.5 py-1.5 border-b border-[var(--desk-border)] bg-[var(--accent-wisteria)]/[0.06] shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[9px] font-mono uppercase tracking-wide text-[var(--accent-wisteria)]",
                                children: [
                                    "Generated layer · ",
                                    EFFECT_LABELS[activeLayer.effect.kind] ?? activeLayer.effect.kind
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 219,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[8px] font-mono text-[var(--text-muted)]",
                                title: new Date(activeLayer.effect.updatedAt).toLocaleString(),
                                children: [
                                    "provenance v",
                                    activeLayer.effect.version
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 222,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                        lineNumber: 218,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-[8px] font-mono text-[var(--text-muted)]",
                        children: [
                            "Source: ",
                            activeLayer.effect.sourceMode.replaceAll('-', ' ')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                        lineNumber: 229,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    (activeLayer.effect.kind === 'volumetric-optics' || activeLayer.effect.kind === 'wfc') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-1 text-[9px] text-[var(--text-body)]",
                        children: "This older generated layer is saved as pixels. Hide it to see the original artwork below."
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                        lineNumber: 233,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-1 text-[9px] font-sans text-[var(--text-muted)] truncate",
                        children: Object.entries(activeLayer.effect.params).slice(0, 4).map(([key, value])=>`${key.replace(/([A-Z])/g, ' $1').toLowerCase()}: ${formatRecipeValue(value)}`).join(' · ') || 'No adjustable parameters'
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                        lineNumber: 237,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    activeLayer.effect.analysis?.rationale && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-0.5 text-[9px] font-sans text-[var(--text-body)] truncate",
                        title: activeLayer.effect.analysis.rationale,
                        children: [
                            "Auto analysis: ",
                            activeLayer.effect.analysis.rationale
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                        lineNumber: 244,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                lineNumber: 217,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "overflow-y-auto flex-1 min-h-[60px] divide-y divide-[var(--desk-border)]/40 bg-[var(--desk-surface)]",
                children: currentFrame?.layers.map((layer, index)=>{
                    const isActive = layer.id === activeLayerId;
                    const canMergeDown = !isGuest && !layer.locked && index < (currentFrame?.layers.length || 0) - 1 && !currentFrame?.layers[index + 1]?.locked;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-testid": `layer-row-${layer.id}`,
                        onDragOver: (event)=>{
                            if (isGuest || !draggedLayerId) return;
                            event.preventDefault();
                            event.dataTransfer.dropEffect = 'move';
                            setDropTargetLayerId(layer.id);
                        },
                        onDragLeave: (event)=>{
                            if (!event.currentTarget.contains(event.relatedTarget)) setDropTargetLayerId(null);
                        },
                        onDrop: (event)=>{
                            event.preventDefault();
                            const sourceId = event.dataTransfer.getData('application/x-pixibun-layer') || draggedLayerId;
                            if (sourceId) moveLayer(sourceId, layer.id);
                            setDraggedLayerId(null);
                            setDropTargetLayerId(null);
                        },
                        className: `h-8 px-3 flex items-center justify-between text-xs transition-colors group ${isActive ? 'bg-[var(--desk-surface-raised)] border-l-2 border-l-[var(--desk-border-highlight)] text-[var(--text-heading)] font-medium' : 'text-[var(--text-body)] hover:bg-[var(--desk-surface-raised)]/40'} ${layer.locked ? 'opacity-70' : ''} ${dropTargetLayerId === layer.id && draggedLayerId !== layer.id ? 'outline outline-2 outline-[var(--accent-gold)] outline-offset-[-2px]' : ''} ${draggedLayerId === layer.id ? 'opacity-50' : ''}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 flex-1 min-w-0 pr-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        draggable: !isGuest && currentFrame.layers.length > 1,
                                        disabled: isGuest || currentFrame.layers.length <= 1,
                                        onDragStart: (event)=>{
                                            event.dataTransfer.setData('application/x-pixibun-layer', layer.id);
                                            event.dataTransfer.effectAllowed = 'move';
                                            setDraggedLayerId(layer.id);
                                        },
                                        onDragEnd: ()=>{
                                            setDraggedLayerId(null);
                                            setDropTargetLayerId(null);
                                        },
                                        onKeyDown: (event)=>{
                                            if (event.key !== 'ArrowUp' && event.key !== 'ArrowDown') return;
                                            event.preventDefault();
                                            const targetIndex = index + (event.key === 'ArrowUp' ? -1 : 1);
                                            if (targetIndex >= 0 && targetIndex < currentFrame.layers.length) reorderLayers(index, targetIndex);
                                        },
                                        title: "Drag to reorder; use arrow keys when focused",
                                        "aria-label": `Reorder layer ${layer.name}`,
                                        className: "w-4 h-6 shrink-0 flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--accent-gold)] cursor-grab active:cursor-grabbing disabled:opacity-40 disabled:cursor-default focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent-gold)]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            "aria-hidden": "true",
                                            className: "text-[13px] leading-none",
                                            children: "⠿"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                            lineNumber: 303,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 286,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    editingLayerId === layer.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        maxLength: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$metadataAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_METADATA_NAME_LENGTH"],
                                        value: layerNameInput,
                                        onChange: (e)=>setLayerNameInput(e.target.value),
                                        onBlur: ()=>{
                                            if (layerNameInput.trim()) {
                                                renameLayer(layer.id, layerNameInput.trim());
                                            }
                                            setEditingLayerId(null);
                                        },
                                        onKeyDown: (e)=>{
                                            if (e.key === 'Enter') {
                                                if (layerNameInput.trim()) {
                                                    renameLayer(layer.id, layerNameInput.trim());
                                                }
                                                setEditingLayerId(null);
                                            }
                                        },
                                        ref: (el)=>el?.focus(),
                                        "aria-label": "Layer name",
                                        className: "bg-[var(--desk-surface-raised)] text-[var(--text-heading)] px-1.5 py-0.5 text-xs font-sans rounded-[2px] border border-[var(--accent-gold)] outline-none w-full"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 306,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-1.5 flex-1 min-w-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setActiveLayer(layer.id),
                                                onDoubleClick: ()=>{
                                                    setEditingLayerId(layer.id);
                                                    setLayerNameInput(layer.name);
                                                },
                                                className: `truncate text-left bg-transparent border-0 p-0 cursor-pointer flex-1 font-sans text-xs ${isActive ? 'text-[var(--text-heading)] font-semibold' : 'text-inherit'}`,
                                                "aria-label": `Select layer ${layer.name}. Double click to rename`,
                                                title: "Click to select, double-click to rename",
                                                children: layer.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                                lineNumber: 331,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            layer.effect && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "px-1 py-px rounded-[2px] border border-[var(--accent-wisteria)]/50 bg-[var(--accent-wisteria)]/10 text-[8px] font-mono font-bold text-[var(--accent-wisteria)] shrink-0",
                                                title: `Generated from a saved ${layer.effect.kind} recipe`,
                                                children: "FX"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                                lineNumber: 347,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: (e)=>{
                                                    e.stopPropagation();
                                                    setEditingLayerId(layer.id);
                                                    setLayerNameInput(layer.name);
                                                },
                                                className: "opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent-gold)] text-[var(--text-muted)] hover:text-[var(--accent-gold)] text-[10px] p-0.5 cursor-pointer transition-opacity",
                                                title: "Rename Layer",
                                                "aria-label": `Rename layer ${layer.name}`,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                                    name: "chisel",
                                                    size: 10
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                                    lineNumber: 365,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                                lineNumber: 354,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 330,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 285,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1",
                                children: [
                                    (layer.effect?.kind === 'photometric' || layer.effect?.kind === 'specular') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            setActiveLayer(layer.id);
                                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:photometric-gizmo-start', {
                                                auto: false,
                                                layerId: layer.id
                                            });
                                        },
                                        className: "h-5 px-1 rounded-[2px] border border-[var(--desk-border)] text-[8px] font-mono text-[var(--accent-gold)] hover:bg-[var(--surface-2)] cursor-pointer",
                                        title: "Reopen this lighting recipe and move the bulb",
                                        "aria-label": `Edit ${layer.effect.kind === 'specular' ? 'glint' : 'lighting'} effect on ${layer.name}`,
                                        children: "Edit FX"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 373,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    canMergeDown && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        icon: "merge-down",
                                        size: "sm",
                                        label: mergeConfirmLayerId === layer.id ? `Confirm merge down layer ${layer.name}` : `Merge down layer ${layer.name}`,
                                        variant: mergeConfirmLayerId === layer.id ? 'surface' : 'ghost',
                                        active: mergeConfirmLayerId === layer.id,
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            requestMergeDown(layer.id);
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 388,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        icon: layer.locked ? 'lock' : 'unlock',
                                        size: "sm",
                                        label: layer.locked ? `Unlock layer ${layer.name}` : `Lock layer ${layer.name}`,
                                        active: layer.locked,
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            toggleLayerLock(layer.id);
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 404,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        icon: layer.visible ? 'eye' : 'eye-off',
                                        size: "sm",
                                        label: layer.visible ? `Hide layer ${layer.name}` : `Show layer ${layer.name}`,
                                        active: layer.visible,
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            toggleLayerVisibility(layer.id);
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                        lineNumber: 414,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                                lineNumber: 371,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, layer.id, true, {
                        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                        lineNumber: 260,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0));
                })
            }, void 0, false, {
                fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
                lineNumber: 255,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/inspector/LayersPanel.tsx",
        lineNumber: 105,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(LayersPanel, "a8KJFP5DcSWqmyW24gDirKBLuZo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useCoDrawStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCoDrawStatus"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c = LayersPanel;
var _c;
__turbopack_context__.k.register(_c, "LayersPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/inspector/PaletteCycleColors.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PaletteCycleColors",
    ()=>PaletteCycleColors
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
function PaletteCycleColors({ colors, track, onChange }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[11px] text-[var(--text-heading)]",
                children: "Choose the first and last colors to animate."
            }, void 0, false, {
                fileName: "[project]/src/components/layout/inspector/PaletteCycleColors.tsx",
                lineNumber: 11,
                columnNumber: 5
            }, this),
            [
                'First',
                'Last'
            ].map((end)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[10px] text-[var(--text-muted)]",
                            children: [
                                end,
                                " color"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/inspector/PaletteCycleColors.tsx",
                            lineNumber: 13,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-8 gap-1.5 p-1 max-h-36 overflow-y-auto",
                            role: "group",
                            "aria-label": `${end} cycle color`,
                            children: colors.map((color, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    "aria-label": `${end} color ${index}: ${color}`,
                                    "aria-pressed": index === (end === 'First' ? track.low : track.high),
                                    title: `${color} · color ${index}`,
                                    style: {
                                        backgroundColor: color
                                    },
                                    onClick: ()=>onChange(end === 'First' ? {
                                            low: index,
                                            high: Math.max(index, track.high)
                                        } : {
                                            low: Math.min(index, track.low),
                                            high: index
                                        }),
                                    className: `min-h-6 aspect-square w-full rounded-[2px] border cursor-pointer relative focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--accent-gold)] ${index === (end === 'First' ? track.low : track.high) ? 'border-[var(--accent-gold)] ring-2 ring-[var(--accent-gold)]' : 'border-[var(--desk-border)]'}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute bottom-0 right-0 bg-black/80 px-0.5 text-white text-[8px] leading-3",
                                        children: index
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PaletteCycleColors.tsx",
                                        lineNumber: 20,
                                        columnNumber: 11
                                    }, this)
                                }, index, false, {
                                    fileName: "[project]/src/components/layout/inspector/PaletteCycleColors.tsx",
                                    lineNumber: 15,
                                    columnNumber: 39
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/inspector/PaletteCycleColors.tsx",
                            lineNumber: 14,
                            columnNumber: 7
                        }, this)
                    ]
                }, end, true, {
                    fileName: "[project]/src/components/layout/inspector/PaletteCycleColors.tsx",
                    lineNumber: 12,
                    columnNumber: 46
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex h-4 border border-[var(--desk-border)] overflow-hidden rounded-[2px]",
                "aria-label": "Colors that will animate",
                children: colors.slice(track.low, track.high + 1).map((color, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            backgroundColor: color
                        },
                        className: "flex-1"
                    }, i, false, {
                        fileName: "[project]/src/components/layout/inspector/PaletteCycleColors.tsx",
                        lineNumber: 25,
                        columnNumber: 66
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/layout/inspector/PaletteCycleColors.tsx",
                lineNumber: 24,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/inspector/PaletteCycleColors.tsx",
        lineNumber: 10,
        columnNumber: 10
    }, this);
}
_c = PaletteCycleColors;
var _c;
__turbopack_context__.k.register(_c, "PaletteCycleColors");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/inspector/PalettePanel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PalettePanel",
    ()=>PalettePanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/safeJson.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/importFile.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$lospecPalette$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/lospecPalette.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteCycling.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteAdmission.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PanelSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PanelSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioSelect$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/StudioSelect.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioNumberInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/StudioNumberInput.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/StudioToggle.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/TactileButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$inspector$2f$PaletteRolesSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/inspector/PaletteRolesSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$modals$2f$CreatePaletteModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/modals/CreatePaletteModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$inspector$2f$PaletteCycleColors$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/inspector/PaletteCycleColors.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const PalettePanel = ()=>{
    _s();
    const palettes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[palettes]": (s)=>s.palettes
    }["PalettePanel.useStudioStore[palettes]"]);
    const currentPaletteId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[currentPaletteId]": (s)=>s.currentPaletteId
    }["PalettePanel.useStudioStore[currentPaletteId]"]);
    const selectPalette = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[selectPalette]": (s)=>s.selectPalette
    }["PalettePanel.useStudioStore[selectPalette]"]);
    const primaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[primaryColor]": (s)=>s.primaryColor
    }["PalettePanel.useStudioStore[primaryColor]"]);
    const secondaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[secondaryColor]": (s)=>s.secondaryColor
    }["PalettePanel.useStudioStore[secondaryColor]"]);
    const setPrimaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[setPrimaryColor]": (s)=>s.setPrimaryColor
    }["PalettePanel.useStudioStore[setPrimaryColor]"]);
    const setSecondaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[setSecondaryColor]": (s)=>s.setSecondaryColor
    }["PalettePanel.useStudioStore[setSecondaryColor]"]);
    const generateAndAddRamp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[generateAndAddRamp]": (s)=>s.generateAndAddRamp
    }["PalettePanel.useStudioStore[generateAndAddRamp]"]);
    const addExtractedPalette = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[addExtractedPalette]": (s)=>s.addExtractedPalette
    }["PalettePanel.useStudioStore[addExtractedPalette]"]);
    const removePaletteColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[removePaletteColor]": (s)=>s.removePaletteColor
    }["PalettePanel.useStudioStore[removePaletteColor]"]);
    const isPaletteCycling = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[isPaletteCycling]": (s)=>s.isPaletteCycling
    }["PalettePanel.useStudioStore[isPaletteCycling]"]);
    const togglePaletteCycling = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[togglePaletteCycling]": (s)=>s.togglePaletteCycling
    }["PalettePanel.useStudioStore[togglePaletteCycling]"]);
    const paletteCycleSpeedMultiplier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[paletteCycleSpeedMultiplier]": (s)=>s.paletteCycleSpeedMultiplier
    }["PalettePanel.useStudioStore[paletteCycleSpeedMultiplier]"]);
    const setPaletteCycleSpeedMultiplier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[setPaletteCycleSpeedMultiplier]": (s)=>s.setPaletteCycleSpeedMultiplier
    }["PalettePanel.useStudioStore[setPaletteCycleSpeedMultiplier]"]);
    const addPaletteCycleTrack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[addPaletteCycleTrack]": (s)=>s.addPaletteCycleTrack
    }["PalettePanel.useStudioStore[addPaletteCycleTrack]"]);
    const updatePaletteCycleTrack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[updatePaletteCycleTrack]": (s)=>s.updatePaletteCycleTrack
    }["PalettePanel.useStudioStore[updatePaletteCycleTrack]"]);
    const deletePaletteCycleTrack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PalettePanel.useStudioStore[deletePaletteCycleTrack]": (s)=>s.deletePaletteCycleTrack
    }["PalettePanel.useStudioStore[deletePaletteCycleTrack]"]);
    const currentPalette = palettes.find((p)=>p.id === currentPaletteId) || palettes[0];
    const paletteFileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const crngFileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [creatingPalette, setCreatingPalette] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const closePaletteCreator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PalettePanel.useCallback[closePaletteCreator]": ()=>setCreatingPalette(false)
    }["PalettePanel.useCallback[closePaletteCreator]"], []);
    const [selectedSwatch, setSelectedSwatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const selectedIndex = selectedSwatch?.paletteId === currentPalette.id ? Math.min(selectedSwatch.index, currentPalette.colors.length - 1) : currentPalette.colors.findIndex((color)=>color.toLowerCase() === primaryColor.toLowerCase());
    const tracks = currentPalette.cycleTracks || [];
    const handlePaletteImportFile = (file)=>{
        if (file.size > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeJson$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeJson"].MAX_PAYLOAD_BYTES) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportImportError"])(new Error('Palette file exceeds the 50 MB limit.'));
            return;
        }
        const reader = new FileReader();
        reader.onload = (e)=>{
            const content = e.target?.result;
            if (!content) return;
            try {
                const pal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$lospecPalette$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parsePaletteFile"])(content, file.name);
                addExtractedPalette(pal.name, pal.colors);
            } catch (err) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportImportError"])(err);
            }
        };
        reader.readAsText(file);
    };
    const handleCRNGImport = (file)=>{
        const reader = new FileReader();
        reader.onload = (e)=>{
            const buffer = e.target?.result;
            if (!buffer) return;
            const bytes = new Uint8Array(buffer);
            try {
                // If file starts with 'CRNG', payload is at offset 8
                let payload = bytes;
                if (bytes.length >= 16 && String.fromCharCode(...bytes.slice(0, 4)) === 'CRNG') {
                    payload = bytes.slice(8, 16);
                }
                const track = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseCRNG"])(payload, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('track'));
                const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paletteCycleTrackError"])(track, currentPalette.colors.length);
                if (error) throw new Error(error);
                addPaletteCycleTrack(currentPalette.id, track);
            } catch (err) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportImportError"])(err);
            }
        };
        reader.readAsArrayBuffer(file);
    };
    const handleExportCRNG = (track)=>{
        const payload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serializeCRNG"])(track);
        const chunk = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteCycling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapIFFChunk"])('CRNG', payload);
        const blob = new Blob([
            chunk.buffer
        ], {
            type: 'application/octet-stream'
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${(track.name || 'track').toLowerCase().replace(/\s+/g, '-')}.crng`;
        a.click();
        URL.revokeObjectURL(url);
    };
    const handleAddTrack = ()=>{
        const numColors = currentPalette.colors.length;
        const low = 0;
        const high = Math.min(numColors - 1, 3);
        const newTrack = {
            id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('track'),
            name: `Cycle ${tracks.length + 1}`,
            low,
            high,
            rate: 6,
            direction: 'forward',
            blendShift: true,
            enabled: true
        };
        addPaletteCycleTrack(currentPalette.id, newTrack);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        onDragOver: (e)=>{
            e.preventDefault();
            e.stopPropagation();
        },
        onDrop: (e)=>{
            e.preventDefault();
            e.stopPropagation();
            const file = e.dataTransfer.files?.[0];
            if (file) handlePaletteImportFile(file);
        },
        className: "flex flex-col bg-[var(--desk-surface)]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-8 px-3 flex items-center justify-between bg-[var(--desk-surface-raised)]/40 border-b border-[var(--desk-border)] shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 flex-1 min-w-0 pr-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[11px] font-sans font-medium text-[var(--text-muted)] shrink-0",
                                children: "Palette"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                lineNumber: 145,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: currentPaletteId,
                                onChange: (e)=>selectPalette(e.target.value),
                                "aria-label": "Color palette preset",
                                className: "w-full max-w-[150px] truncate bg-[var(--desk-surface-raised)] text-[var(--text-heading)] px-2 py-0.5 rounded-[2px] border border-[var(--desk-border)] outline-none text-xs font-sans cursor-pointer hover:border-[var(--accent-gold)]/40 transition-colors",
                                children: palettes.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: p.id,
                                        children: [
                                            p.name,
                                            " (",
                                            p.colors.length,
                                            ")"
                                        ]
                                    }, p.id, true, {
                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                        lineNumber: 155,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                lineNumber: 148,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                        lineNumber: 144,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 font-mono text-[10px] shrink-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "flex items-center gap-1 text-[var(--text-body)] font-medium",
                                title: `Primary Color: ${primaryColor}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "w-3.5 h-3.5 rounded-[2px] border border-white shadow-xs inline-block ring-1 ring-[var(--accent-gold)]",
                                        style: {
                                            backgroundColor: primaryColor
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                        lineNumber: 165,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "1"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                        lineNumber: 169,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                lineNumber: 164,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[var(--text-muted)]",
                                children: "|"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                lineNumber: 171,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "flex items-center gap-1 text-[var(--text-body)] font-medium",
                                title: `Secondary Color: ${secondaryColor}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "w-3.5 h-3.5 rounded-[2px] border border-white shadow-xs inline-block ring-1 ring-[var(--accent-plum)]",
                                        style: {
                                            backgroundColor: secondaryColor
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                        lineNumber: 173,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                        lineNumber: 177,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                lineNumber: 172,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                        lineNumber: 163,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                lineNumber: 143,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-3 bg-[var(--desk-surface)] border-b border-[var(--desk-border)] shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-8 gap-1.5 bg-[var(--desk-surface-raised)]/60 p-2 rounded-[var(--radius-sm)] border border-[var(--desk-border)] shadow-xs min-h-[90px] max-h-[220px] overflow-y-auto",
                        children: currentPalette.colors.map((color, idx)=>{
                            const isPrimary = color.toLowerCase() === primaryColor.toLowerCase();
                            const isSecondary = color.toLowerCase() === secondaryColor.toLowerCase();
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    setPrimaryColor(color);
                                    setSelectedSwatch({
                                        paletteId: currentPalette.id,
                                        index: idx
                                    });
                                },
                                onContextMenu: (e)=>{
                                    e.preventDefault();
                                    setSecondaryColor(color);
                                },
                                style: {
                                    backgroundColor: color
                                },
                                className: `aspect-square w-full rounded-[2px] border transition-all hover:brightness-110 active:translate-y-[1px] cursor-pointer relative flex items-center justify-center ${isPrimary ? 'border-white ring-2 ring-[var(--accent-gold)] shadow-xs z-10 scale-[1.04]' : isSecondary ? 'border-white ring-2 ring-[var(--accent-plum)] z-10 scale-[1.04]' : 'border-[var(--desk-border)] hover:border-white/60'}`,
                                title: `${color} [#${idx}] (Left-click: Primary | Right-click: Secondary)`,
                                "aria-label": `Select color ${color}`,
                                children: [
                                    isPrimary && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-[var(--accent-gold)] border border-white text-[7px] text-[#16141a] font-black flex items-center justify-center select-none shadow-xs",
                                        children: "1"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                        lineNumber: 209,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    isSecondary && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-[var(--accent-plum)] border border-white text-[7px] text-white font-black flex items-center justify-center select-none shadow-xs",
                                        children: "2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                        lineNumber: 214,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, `${color}-${idx}`, true, {
                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                lineNumber: 190,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0));
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                        lineNumber: 184,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between gap-2 mt-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[11px] font-mono text-[var(--text-muted)]",
                                children: selectedIndex >= 0 ? currentPalette.colors[selectedIndex] : 'Choose a color'
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                lineNumber: 223,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                disabled: selectedIndex < 0 || currentPalette.colors.length <= 1,
                                title: currentPalette.colors.length <= 1 ? 'Keep at least one color.' : 'Remove the selected swatch. Artwork stays unchanged.',
                                onClick: ()=>{
                                    if (removePaletteColor(currentPalette.id, selectedIndex)) setSelectedSwatch({
                                        paletteId: currentPalette.id,
                                        index: Math.max(0, selectedIndex - 1)
                                    });
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                        name: "trash",
                                        size: 12
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                        lineNumber: 227,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    " Remove color"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                lineNumber: 224,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                        lineNumber: 222,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                lineNumber: 183,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-2.5 border-b border-[var(--desk-border)] grid grid-cols-3 gap-2 bg-[var(--desk-surface)]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                        variant: "primary",
                        size: "sm",
                        onClick: ()=>setCreatingPalette(true),
                        className: "col-span-3 justify-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                name: "plus",
                                size: 12
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                lineNumber: 235,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            " Create palette"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                        lineNumber: 234,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                        variant: "tactile",
                        size: "sm",
                        onClick: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:extract-palette'),
                        title: "Group the visible artwork into up to 6 main colors. Artwork stays unchanged.",
                        className: "flex-1 text-[11px] font-sans",
                        children: "Scan Canvas"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                        lineNumber: 237,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                        variant: "tactile",
                        size: "sm",
                        onClick: ()=>generateAndAddRamp(primaryColor),
                        title: "Generate 5-step highlight & shadow ramp in OKLCH",
                        "aria-label": "+ OKLCH Ramp",
                        "data-testid": "oklch-ramp-button",
                        className: "flex-1 text-[11px] font-sans",
                        children: "+ OKLCH"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                        lineNumber: 247,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                        variant: "tactile",
                        size: "sm",
                        onClick: ()=>paletteFileInputRef.current?.click(),
                        title: "Import Lospec .hex or GIMP .gpl palette file (or drag and drop)",
                        className: "flex-1 text-[11px] font-sans",
                        children: "+ Lospec"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                        lineNumber: 259,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: paletteFileInputRef,
                        type: "file",
                        accept: ".hex,.gpl,.txt,.json",
                        className: "hidden",
                        onChange: (e)=>{
                            const file = e.target.files?.[0];
                            if (file) handlePaletteImportFile(file);
                            e.target.value = '';
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                        lineNumber: 269,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                lineNumber: 233,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            creatingPalette && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$modals$2f$CreatePaletteModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CreatePaletteModal"], {
                onClose: closePaletteCreator
            }, void 0, false, {
                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                lineNumber: 282,
                columnNumber: 27
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$inspector$2f$PaletteRolesSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaletteRolesSection"], {
                palette: currentPalette
            }, currentPalette.id, false, {
                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                lineNumber: 285,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PanelSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Cycle Engine",
                defaultOpen: isPaletteCycling,
                storageKey: "palette-panel-cycling",
                actions: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    icon: isPaletteCycling ? 'pause' : 'play',
                    onClick: togglePaletteCycling,
                    label: isPaletteCycling ? 'Pause Cycle' : 'Play Cycle',
                    size: "sm",
                    active: isPaletteCycling
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                    lineNumber: 291,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioSelect$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: "Playback Speed",
                            value: paletteCycleSpeedMultiplier.toString(),
                            options: [
                                {
                                    value: "0.25",
                                    label: "0.25x"
                                },
                                {
                                    value: "0.5",
                                    label: "0.5x"
                                },
                                {
                                    value: "1",
                                    label: "1.0x"
                                },
                                {
                                    value: "2",
                                    label: "2.0x"
                                },
                                {
                                    value: "4",
                                    label: "4.0x"
                                }
                            ],
                            onChange: (val)=>setPaletteCycleSpeedMultiplier(parseFloat(val))
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                            lineNumber: 301,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between mt-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[10px] font-mono text-[var(--text-muted)] font-bold",
                                    children: [
                                        "CYCLE TRACKS (",
                                        tracks.length,
                                        ")"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                    lineNumber: 315,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>crngFileInputRef.current?.click(),
                                            disabled: tracks.length >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_CYCLE_TRACKS"],
                                            className: "text-[var(--accent-gold)] hover:underline cursor-pointer text-[10px] font-mono disabled:opacity-50 disabled:cursor-not-allowed",
                                            title: tracks.length >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_CYCLE_TRACKS"] ? 'Cycle track limit reached' : 'Import Deluxe Paint CRNG binary chunk',
                                            children: "+ Import CRNG"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                            lineNumber: 317,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            ref: crngFileInputRef,
                                            type: "file",
                                            accept: ".crng,.bin",
                                            className: "hidden",
                                            onChange: (e)=>{
                                                const f = e.target.files?.[0];
                                                if (f) handleCRNGImport(f);
                                                e.target.value = '';
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                            lineNumber: 325,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                    lineNumber: 316,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                            lineNumber: 314,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        tracks.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-[11px] font-mono text-[var(--text-muted)] p-3 text-center bg-[var(--surface-1)] rounded-[var(--radius-sm)] border border-dashed border-[var(--desk-border)]",
                            children: "No cycle tracks configured. Click below to create one!"
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                            lineNumber: 340,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-2",
                            children: tracks.map((track)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PanelSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    title: track.name || `Track [${track.low}..${track.high}]`,
                                    defaultOpen: false,
                                    className: `border border-[var(--desk-border)] rounded-[var(--radius-sm)] overflow-hidden ${track.enabled ? 'border-[var(--accent-gold)]/60' : 'opacity-80'}`,
                                    actions: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                label: "",
                                                checked: track.enabled,
                                                onChange: (val)=>updatePaletteCycleTrack(currentPalette.id, track.id, {
                                                        enabled: val
                                                    })
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                lineNumber: 353,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                                variant: "ghost",
                                                size: "sm",
                                                onClick: ()=>handleExportCRNG(track),
                                                title: "Export as Deluxe Paint CRNG binary file",
                                                children: "CRNG"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                lineNumber: 358,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                icon: "trash",
                                                variant: "danger",
                                                size: "sm",
                                                onClick: ()=>deletePaletteCycleTrack(currentPalette.id, track.id),
                                                label: "Delete track"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                lineNumber: 366,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                        lineNumber: 352,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$inspector$2f$PaletteCycleColors$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaletteCycleColors"], {
                                                colors: currentPalette.colors,
                                                track: track,
                                                onChange: (range)=>updatePaletteCycleTrack(currentPalette.id, track.id, range)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                lineNumber: 377,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                                        className: "text-[10px] text-[var(--text-muted)]",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                                                className: "cursor-pointer min-h-6 leading-6",
                                                                children: "Color index numbers"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                                lineNumber: 382,
                                                                columnNumber: 25
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex flex-col gap-2 pt-1",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioNumberInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                        label: "Low Index",
                                                                        value: track.low,
                                                                        min: 0,
                                                                        max: track.high,
                                                                        onChange: (val)=>updatePaletteCycleTrack(currentPalette.id, track.id, {
                                                                                low: val
                                                                            })
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                                        lineNumber: 384,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioNumberInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                        label: "High Index",
                                                                        value: track.high,
                                                                        min: track.low,
                                                                        max: currentPalette.colors.length - 1,
                                                                        onChange: (val)=>updatePaletteCycleTrack(currentPalette.id, track.id, {
                                                                                high: val
                                                                            })
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                                        lineNumber: 391,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                                lineNumber: 383,
                                                                columnNumber: 25
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                        lineNumber: 381,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioNumberInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        label: "Rate (Hz)",
                                                        value: track.rate,
                                                        min: 0.1,
                                                        max: 60,
                                                        step: 0.5,
                                                        onChange: (val)=>updatePaletteCycleTrack(currentPalette.id, track.id, {
                                                                rate: val
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                        lineNumber: 400,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioSelect$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        label: "Direction",
                                                        value: track.direction,
                                                        options: [
                                                            {
                                                                value: 'forward',
                                                                label: 'Forward'
                                                            },
                                                            {
                                                                value: 'reverse',
                                                                label: 'Reverse'
                                                            },
                                                            {
                                                                value: 'ping-pong',
                                                                label: 'Ping-Pong'
                                                            }
                                                        ],
                                                        onChange: (val)=>updatePaletteCycleTrack(currentPalette.id, track.id, {
                                                                direction: val
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                        lineNumber: 408,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$StudioToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        label: "BlendShift (Smooth)",
                                                        checked: track.blendShift,
                                                        onChange: (val)=>updatePaletteCycleTrack(currentPalette.id, track.id, {
                                                                blendShift: val
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                        lineNumber: 418,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                                lineNumber: 380,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                        lineNumber: 376,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, track.id, false, {
                                    fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                    lineNumber: 346,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                            lineNumber: 344,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                            variant: "tactile",
                            size: "md",
                            onClick: handleAddTrack,
                            disabled: tracks.length >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_PALETTE_CYCLE_TRACKS"],
                            className: "w-full mt-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                    name: "plus",
                                    size: 12
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                    lineNumber: 437,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Add Color Range Track"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                                    lineNumber: 438,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                            lineNumber: 430,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                    lineNumber: 300,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
                lineNumber: 286,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/inspector/PalettePanel.tsx",
        lineNumber: 129,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(PalettePanel, "BUSF48zPwEhcvFEY8YwSfrMOr50=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c = PalettePanel;
var _c;
__turbopack_context__.k.register(_c, "PalettePanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/layout/inspector/PaletteRolesSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PaletteRolesSection",
    ()=>PaletteRolesSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteSemantics.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/TactileButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PixelIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
const COMMON_ROLE_SUGGESTIONS = [
    'Skin',
    'Outline',
    'Shade',
    'Highlight',
    'Metal',
    'Cloth',
    'Glow',
    'FX'
];
function PaletteRolesSection({ palette }) {
    _s();
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PaletteRolesSection.useStudioStore[selection]": (s)=>s.selection
    }["PaletteRolesSection.useStudioStore[selection]"]);
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "PaletteRolesSection.useStudioStore[frames]": (s)=>s.frames
    }["PaletteRolesSection.useStudioStore[frames]"]);
    const [index, setIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0), [role, setRole] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(palette.semantics?.entries[0]?.role ?? '');
    if (palette.colors.length < 1 || palette.colors.length > 256) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        className: "text-xs",
        children: "Index roles require a palette with 1–256 colors."
    }, void 0, false, {
        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
        lineNumber: 18,
        columnNumber: 72
    }, this);
    const semantics = palette.semantics ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPaletteSemantics"])(palette);
    const selectedIndex = Math.min(index, semantics.entries.length - 1);
    const entry = semantics.entries[selectedIndex];
    const update = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setPaletteSemantics;
    // Duplicate color detection across registers
    const duplicateIndices = palette.colors.map((c, i)=>c.toLowerCase() === palette.colors[selectedIndex]?.toLowerCase() ? i : -1).filter((i)=>i !== -1);
    const isDuplicate = duplicateIndices.length > 1;
    const locatePixels = ()=>{
        const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
        const hex = palette.colors[selectedIndex];
        if (!hex) return;
        const clean = hex.slice(1);
        const fullHex = clean.length === 3 ? clean.split('').map((c)=>c + c).join('') : clean;
        const r = parseInt(fullHex.slice(0, 2), 16);
        const g = parseInt(fullHex.slice(2, 4), 16);
        const b = parseInt(fullHex.slice(4, 6), 16);
        const { canvasWidth: w, canvasHeight: h } = state;
        const activeFrame = state.frames[state.activeFrameIndex];
        if (!activeFrame) return;
        let minX = w, minY = h, maxX = -1, maxY = -1, count = 0;
        for (const layer of activeFrame.layers){
            if (!layer.visible) continue;
            const buf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateBuffer"])(layer.id, w, h);
            const data = buf.ctx.getImageData(0, 0, w, h).data;
            for(let y = 0; y < h; y++){
                for(let x = 0; x < w; x++){
                    const p = (y * w + x) * 4;
                    if (data[p + 3] > 0 && data[p] === r && data[p + 1] === g && data[p + 2] === b) {
                        count++;
                        if (x < minX) minX = x;
                        if (y < minY) minY = y;
                        if (x > maxX) maxX = x;
                        if (y > maxY) maxY = y;
                    }
                }
            }
        }
        if (count > 0) {
            state.setSelection({
                x: minX,
                y: minY,
                w: maxX - minX + 1,
                h: maxY - minY + 1
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                type: 'success',
                message: `Found ${count} pixel${count === 1 ? '' : 's'} matching #${selectedIndex} on Frame ${state.activeFrameIndex + 1}. Selection box created.`
            });
        } else {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                type: 'default',
                message: `No pixels matching #${selectedIndex} found on Frame ${state.activeFrameIndex + 1}.`
            });
        }
    };
    const bind = ()=>{
        if (!selection || semantics.bindings.length >= 128) return;
        const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
        const x = Math.max(0, Math.floor(selection.x)), y = Math.max(0, Math.floor(selection.y));
        const w = Math.min(state.canvasWidth, Math.ceil(selection.x + selection.w)) - x;
        const h = Math.min(state.canvasHeight, Math.ceil(selection.y + selection.h)) - y;
        if (w <= 0 || h <= 0) return;
        update(palette.id, {
            ...semantics,
            bindings: [
                ...semantics.bindings,
                {
                    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('binding'),
                    entryId: entry.id,
                    frameId: state.frames[state.activeFrameIndex].id,
                    x,
                    y,
                    w,
                    h
                }
            ]
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
        className: "m-2 p-2 border border-[var(--desk-border)] text-xs text-[var(--text-body)]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                className: "cursor-pointer",
                children: "Roles and index bindings"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                lineNumber: 90,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 flex flex-col gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Name palette registers for game delivery. RGBA painting does not retain duplicate-color identity; bind selections explicitly for indexed export."
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                        lineNumber: 92,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        children: [
                            "Palette register",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                "aria-label": "Semantic palette register",
                                className: "w-full bg-[var(--surface-1)] p-1 text-xs",
                                value: selectedIndex,
                                onChange: (e)=>{
                                    const next = Number(e.target.value);
                                    setIndex(next);
                                    setRole(semantics.entries[next].role);
                                },
                                children: palette.colors.map((color, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: i,
                                        children: [
                                            "#",
                                            i,
                                            ": ",
                                            color,
                                            " ",
                                            semantics.entries[i].role
                                        ]
                                    }, i, true, {
                                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                        lineNumber: 96,
                                        columnNumber: 43
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                lineNumber: 94,
                                columnNumber: 30
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                        lineNumber: 94,
                        columnNumber: 7
                    }, this),
                    isDuplicate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-[#2b1f14] border border-[#f0be7c] p-2 rounded-[2px] text-[10px] flex flex-col gap-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "font-semibold text-[#f0be7c] flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PixelIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PixelIcon"], {
                                        name: "warning",
                                        size: 11
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                        lineNumber: 103,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Duplicate Color Register"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                        lineNumber: 104,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                lineNumber: 102,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-[#f0ded0]",
                                children: [
                                    "Color ",
                                    palette.colors[selectedIndex],
                                    " is shared by registers: ",
                                    duplicateIndices.map((i)=>`#${i}`).join(', '),
                                    ". Indexed export requires binding selections to assign ambiguous pixels."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                lineNumber: 106,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-1.5 pt-0.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                        size: "sm",
                                        onClick: locatePixels,
                                        children: "Locate on canvas"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                        lineNumber: 111,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                        size: "sm",
                                        variant: "primary",
                                        disabled: !selection || semantics.bindings.length >= 128,
                                        onClick: bind,
                                        children: "Assign selection"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                        lineNumber: 114,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                lineNumber: 110,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                        lineNumber: 101,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "break-words",
                        children: [
                            "Saved role: ",
                            entry.role || 'unnamed'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                        lineNumber: 121,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                children: [
                                    "Role name",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        "aria-label": "Palette role name",
                                        className: "w-full bg-[var(--surface-1)] p-1 text-xs",
                                        maxLength: 64,
                                        value: role,
                                        onChange: (e)=>setRole(e.target.value)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                        lineNumber: 124,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                lineNumber: 124,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap gap-1 mt-0.5",
                                children: COMMON_ROLE_SUGGESTIONS.map((suggestion)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setRole(suggestion),
                                        className: "px-1.5 py-0.5 text-[9px] bg-[var(--surface-2)] hover:bg-[var(--surface-3)] text-[var(--text-body)] rounded-[1px] border border-[var(--desk-border)] cursor-pointer",
                                        children: suggestion
                                    }, suggestion, false, {
                                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                        lineNumber: 130,
                                        columnNumber: 13
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                lineNumber: 128,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                        lineNumber: 123,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap gap-1.5 pt-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                onClick: ()=>update(palette.id, {
                                        ...semantics,
                                        entries: semantics.entries.map((e)=>e.id === entry.id ? {
                                                ...e,
                                                role: role.trim()
                                            } : e)
                                    }),
                                children: "Save palette role"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                lineNumber: 143,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                onClick: locatePixels,
                                title: "Locate pixels matching this register on the active frame",
                                children: "Locate on canvas"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                lineNumber: 146,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                size: "sm",
                                disabled: !selection || semantics.bindings.length >= 128,
                                onClick: bind,
                                children: "Bind selection to register"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                lineNumber: 149,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                        lineNumber: 142,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[10px] text-[var(--text-muted)]",
                        children: "Bindings use the selection's bounding box on the current frame. Only pixels exactly matching this register's RGB are assigned; alpha stays separate. Later matching bindings win. Drawing remains editable."
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                        lineNumber: 152,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            semantics.bindings.length,
                            " saved index bindings"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                        lineNumber: 153,
                        columnNumber: 7
                    }, this),
                    semantics.bindings.map((binding)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1 border-t border-[var(--desk-border)] pt-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "break-words",
                                    children: [
                                        frames.some((f)=>f.id === binding.frameId) ? `Frame ${frames.findIndex((f)=>f.id === binding.frameId) + 1}` : 'Removed frame',
                                        ": #",
                                        semantics.entries.findIndex((e)=>e.id === binding.entryId),
                                        " at (",
                                        binding.x,
                                        ", ",
                                        binding.y,
                                        "), ",
                                        binding.w,
                                        " × ",
                                        binding.h
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                    lineNumber: 155,
                                    columnNumber: 9
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$TactileButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TactileButton"], {
                                    size: "sm",
                                    "aria-label": `Remove index binding ${binding.id}`,
                                    onClick: ()=>update(palette.id, {
                                            ...semantics,
                                            bindings: semantics.bindings.filter((b)=>b.id !== binding.id)
                                        }),
                                    children: "Remove binding"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                                    lineNumber: 156,
                                    columnNumber: 9
                                }, this)
                            ]
                        }, binding.id, true, {
                            fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                            lineNumber: 154,
                            columnNumber: 42
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
                lineNumber: 91,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/inspector/PaletteRolesSection.tsx",
        lineNumber: 89,
        columnNumber: 10
    }, this);
}
_s(PaletteRolesSection, "T/txqNYmA6omMBLQSimDoMgaBEI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
_c = PaletteRolesSection;
var _c;
__turbopack_context__.k.register(_c, "PaletteRolesSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_layout_1-pbl2r._.js.map