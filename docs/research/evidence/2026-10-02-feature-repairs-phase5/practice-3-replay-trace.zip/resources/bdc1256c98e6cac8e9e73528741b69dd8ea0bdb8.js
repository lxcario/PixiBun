(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/hooks/studio/useStudioAutosave.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AUTOSAVE_DEBOUNCE_MS",
    ()=>AUTOSAVE_DEBOUNCE_MS,
    "requestPersistentStorage",
    ()=>requestPersistentStorage,
    "useStudioAutosave",
    ()=>useStudioAutosave
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/stores/onboardingStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/storage/db.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/project/serialize.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/persistenceRevisions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$saveRevision$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/saveRevision.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$practiceSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/practiceSession.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/studioRouteSession.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$storageResilience$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/storageResilience.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$projectAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/recovery/projectAdmission.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLedger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/recovery/recoveryLedger.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
async function requestPersistentStorage() {
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
        try {
            const isPersisted = await navigator.storage.persisted();
            if (!isPersisted) {
                return await navigator.storage.persist();
            }
            return isPersisted;
        } catch  {
            return false;
        }
    }
    return false;
}
const AUTOSAVE_DEBOUNCE_MS = 800;
function useStudioAutosave() {
    _s();
    const [autosaveError, setAutosaveError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [storageWarning, setStorageWarning] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [saveConflict, setSaveConflict] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const storageVersionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    const conflictRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const autosaveTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const autosaveInFlightRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const autosavePendingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const inFlightPromiseRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const autosaveFailCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    // Single authoritative reactive lifecycle state & synchronous ref mirror
    const lifecycleRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        phase: 'idle'
    });
    const [lifecycleState, setLifecycleState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        phase: 'idle'
    });
    const restorePromiseRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const updateLifecycle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioAutosave.useCallback[updateLifecycle]": (next)=>{
            lifecycleRef.current = next;
            setLifecycleState(next);
        }
    }["useStudioAutosave.useCallback[updateLifecycle]"], []);
    // Hook-local request epoch and AbortController coordinator
    const isMountedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(true);
    const openEpochRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const openAbortRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const beginOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioAutosave.useCallback[beginOpen]": ()=>{
            openEpochRef.current += 1;
            if (openAbortRef.current) {
                openAbortRef.current.abort();
            }
            openAbortRef.current = new AbortController();
            if (!isMountedRef.current) {
                openAbortRef.current.abort();
            }
            return {
                epoch: openEpochRef.current,
                signal: openAbortRef.current.signal
            };
        }
    }["useStudioAutosave.useCallback[beginOpen]"], []);
    const isOpenStale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioAutosave.useCallback[isOpenStale]": (epoch)=>{
            return epoch !== openEpochRef.current;
        }
    }["useStudioAutosave.useCallback[isOpenStale]"], []);
    const runAutosave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioAutosave.useCallback[runAutosave]": async ()=>{
            if (restorePromiseRef.current) {
                try {
                    await restorePromiseRef.current;
                } catch  {
                // Handled in restore promise
                }
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$practiceSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPracticeActive"])()) {
                return {
                    ok: false,
                    reason: 'lifecycle-suspended',
                    error: 'Studio autosave is suspended during practice.'
                };
            }
            const currentPhase = lifecycleRef.current.phase;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$projectAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAutosavePermitted"])(currentPhase)) {
                return {
                    ok: false,
                    reason: 'lifecycle-suspended',
                    error: `Autosave suspended: workspace is in '${currentPhase}' phase.`
                };
            }
            const currentProjId = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId;
            if (conflictRef.current === currentProjId) {
                return {
                    ok: false,
                    reason: 'conflict',
                    error: 'Save a copy to preserve your work.'
                };
            }
            if (lifecycleRef.current.phase === 'active' && lifecycleRef.current.pendingRecovery?.sourceProjectId && currentProjId === lifecycleRef.current.pendingRecovery.sourceProjectId) {
                return {
                    ok: false,
                    reason: 'restore-invalid',
                    error: 'Active project restore failed and is preserved read-only.'
                };
            }
            if (autosaveInFlightRef.current) {
                autosavePendingRef.current = true;
                if (inFlightPromiseRef.current) {
                    return await inFlightPromiseRef.current;
                }
                return {
                    ok: false,
                    reason: 'unknown',
                    error: 'Save already in-flight'
                };
            }
            autosaveInFlightRef.current = true;
            const savePromise = ({
                "useStudioAutosave.useCallback[runAutosave].savePromise": async ()=>{
                    let finalResult = {
                        ok: false,
                        reason: 'unknown'
                    };
                    try {
                        do {
                            autosavePendingRef.current = false;
                            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$practiceSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPracticeActive"])()) {
                                return {
                                    ok: false,
                                    reason: 'lifecycle-suspended',
                                    error: 'Studio autosave is suspended during practice.'
                                };
                            }
                            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                            const expectedVersion = storageVersionsRef.current.get(state.currentProjectId) ?? null;
                            const { setSaveStatus } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                            setSaveStatus('saving');
                            try {
                                const thumbnailDataUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateCompositeThumbnail"])(128, 128);
                                let payload;
                                try {
                                    payload = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildAutosavePayloadAsync"])();
                                } catch (serErr) {
                                    setSaveStatus('error');
                                    finalResult = {
                                        ok: false,
                                        reason: 'serialization',
                                        error: serErr instanceof Error ? serErr.message : 'Serialization failed'
                                    };
                                    continue;
                                }
                                const { project, layerBlobs, capturedRevisions } = payload;
                                const saveOutcome = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["autoSaveWorkspaceDetailed"])(state.currentProjectId, project, thumbnailDataUrl, layerBlobs, undefined, expectedVersion);
                                if (saveOutcome.ok) {
                                    if (saveOutcome.storageVersion) storageVersionsRef.current.set(state.currentProjectId, saveOutcome.storageVersion);
                                    if (typeof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["commitPersistedRevisions"] === 'function') {
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$persistenceRevisions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["commitPersistedRevisions"])(state.currentProjectId, capturedRevisions);
                                    }
                                    autosaveFailCountRef.current = 0;
                                    setAutosaveError(null);
                                    const savedCurrent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$saveRevision$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCurrentSaveRevision"])(state);
                                    if (savedCurrent) {
                                        setSaveStatus('saved');
                                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().markClean();
                                        finalResult = {
                                            ok: true,
                                            status: 'saved'
                                        };
                                    } else {
                                        autosavePendingRef.current = true;
                                    }
                                // Keep the last confirmed write visible until a new edit or save attempt.
                                } else {
                                    setSaveStatus('error');
                                    if (saveOutcome.reason === 'conflict') {
                                        conflictRef.current = state.currentProjectId;
                                        setSaveConflict(state.currentProjectId);
                                        setAutosaveError(saveOutcome.error);
                                        autosavePendingRef.current = false;
                                        finalResult = {
                                            ok: false,
                                            reason: 'conflict',
                                            error: saveOutcome.error
                                        };
                                    } else if (saveOutcome.reason === 'memory-limit') {
                                        setAutosaveError(saveOutcome.error);
                                        finalResult = {
                                            ok: false,
                                            reason: 'memory-limit',
                                            error: saveOutcome.error
                                        };
                                    } else if (saveOutcome.reason === 'invariant-invalid') {
                                        const errorMsg = saveOutcome.error || 'Autosave halted: workspace exceeds safety limits. Last valid save preserved.';
                                        setAutosaveError(errorMsg);
                                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                                            type: 'error',
                                            message: errorMsg
                                        });
                                        finalResult = {
                                            ok: false,
                                            reason: 'invariant-invalid',
                                            error: errorMsg
                                        };
                                    } else {
                                        autosaveFailCountRef.current += 1;
                                        if (autosaveFailCountRef.current >= 2) {
                                            setAutosaveError('Autosave warning: Browser local storage write failed (disk quota or privacy restriction). Please export your drawing as PNG or .pixibun to avoid data loss.');
                                        }
                                        finalResult = {
                                            ok: false,
                                            reason: saveOutcome.reason === 'quota-exceeded' ? 'quota' : 'storage-unavailable',
                                            error: saveOutcome.error || 'Storage write returned false'
                                        };
                                    }
                                }
                            } catch (err) {
                                console.error('Autosave failed:', err);
                                autosaveFailCountRef.current += 1;
                                setSaveStatus('error');
                                if (autosaveFailCountRef.current >= 2) {
                                    setAutosaveError('Autosave warning: Browser local storage write failed (disk quota or privacy restriction). Please export your drawing as PNG or .pixibun to avoid data loss.');
                                }
                                const isQuota = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$storageResilience$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageResilience"].isQuotaExceeded(err);
                                finalResult = {
                                    ok: false,
                                    reason: isQuota ? 'quota' : 'transaction',
                                    error: err instanceof Error ? err.message : String(err)
                                };
                            }
                        }while (autosavePendingRef.current)
                        return finalResult;
                    } finally{
                        autosaveInFlightRef.current = false;
                        inFlightPromiseRef.current = null;
                    }
                }
            })["useStudioAutosave.useCallback[runAutosave].savePromise"]();
            inFlightPromiseRef.current = savePromise;
            return await savePromise;
        }
    }["useStudioAutosave.useCallback[runAutosave]"], []);
    const saveConflictCopy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioAutosave.useCallback[saveConflictCopy]": async ()=>{
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            if (autosaveInFlightRef.current || conflictRef.current !== state.currentProjectId) return;
            const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
            // A new identity makes every raster dirty without clearing the live artwork/history.
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                currentProjectId: newId,
                projectName: `${state.projectName.slice(0, 100)} (conflict copy)`
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setDirty(true);
            conflictRef.current = null;
            setSaveConflict(null);
            updateLifecycle({
                phase: 'active',
                projectId: newId
            });
            await runAutosave();
        }
    }["useStudioAutosave.useCallback[saveConflictCopy]"], [
        runAutosave,
        updateLifecycle
    ]);
    // Keep only the latest Studio's save coordinator for the practice route handoff.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioAutosave.useEffect": ()=>{
            if (lifecycleState.phase !== 'active') return;
            const projectId = lifecycleState.projectId;
            const resume = {
                "useStudioAutosave.useEffect.resume": ()=>({
                        projectId,
                        storageVersions: new Map(storageVersionsRef.current),
                        lifecycle: lifecycleRef.current,
                        conflictProjectId: conflictRef.current
                    })
            }["useStudioAutosave.useEffect.resume"];
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerStudioRouteSession"])({
                projectId,
                resume,
                checkpoint: {
                    "useStudioAutosave.useEffect": async ()=>{
                        if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId !== projectId) throw new Error('Studio no longer owns this drawing.');
                        const result = await runAutosave();
                        if (!result.ok || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().isDirty || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId !== projectId) {
                            throw new Error(result.ok ? 'Your drawing changed while saving. Try again from Studio.' : result.error || 'Your drawing could not be saved. Return to Studio and export a backup.');
                        }
                        return resume();
                    }
                }["useStudioAutosave.useEffect"]
            });
        }
    }["useStudioAutosave.useEffect"], [
        lifecycleState,
        runAutosave
    ]);
    const scheduleAutosave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioAutosave.useCallback[scheduleAutosave]": ()=>{
            if (autosaveTimerRef.current !== null) {
                window.clearTimeout(autosaveTimerRef.current);
            }
            autosaveTimerRef.current = window.setTimeout({
                "useStudioAutosave.useCallback[scheduleAutosave]": ()=>{
                    autosaveTimerRef.current = null;
                    void runAutosave();
                }
            }["useStudioAutosave.useCallback[scheduleAutosave]"], AUTOSAVE_DEBOUNCE_MS);
        }
    }["useStudioAutosave.useCallback[scheduleAutosave]"], [
        runAutosave
    ]);
    const handleCommitHistory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioAutosave.useCallback[handleCommitHistory]": ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setDirty(true);
        }
    }["useStudioAutosave.useCallback[handleCommitHistory]"], []);
    // Persist every document mutation, including layer metadata and animation
    // changes that do not create a pixel-history entry.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioAutosave.useEffect": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].subscribe({
                "useStudioAutosave.useEffect": (state, previousState)=>{
                    if (state.editRevision !== previousState.editRevision && state.isDirty) {
                        scheduleAutosave();
                    }
                }
            }["useStudioAutosave.useEffect"])
    }["useStudioAutosave.useEffect"], [
        scheduleAutosave
    ]);
    // An edit made while startup restore is still finishing can miss the
    // subscription or have its first timer expire before autosave is permitted.
    // Retry the dirty revision once the workspace becomes active.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioAutosave.useEffect": ()=>{
            if (lifecycleState.phase === 'active' && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().isDirty) {
                scheduleAutosave();
            }
        }
    }["useStudioAutosave.useEffect"], [
        lifecycleState,
        scheduleAutosave
    ]);
    // Native exit guard when changes are unsaved (UX-2)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioAutosave.useEffect": ()=>{
            const handleBeforeUnload = {
                "useStudioAutosave.useEffect.handleBeforeUnload": (e)=>{
                    if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().isDirty) {
                        e.preventDefault();
                        e.returnValue = '';
                    }
                }
            }["useStudioAutosave.useEffect.handleBeforeUnload"];
            window.addEventListener('beforeunload', handleBeforeUnload);
            return ({
                "useStudioAutosave.useEffect": ()=>window.removeEventListener('beforeunload', handleBeforeUnload)
            })["useStudioAutosave.useEffect"];
        }
    }["useStudioAutosave.useEffect"], []);
    // Remote co-draw strokes mutate pixel buffers without a local history
    // commit, so schedule the same debounced autosave when a peer changes the
    // canvas — otherwise peer artwork would only persist on the next local edit.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioAutosave.useEffect": ()=>{
            const unsub = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:remote-change', {
                "useStudioAutosave.useEffect.unsub": ()=>handleCommitHistory()
            }["useStudioAutosave.useEffect.unsub"]);
            return unsub;
        }
    }["useStudioAutosave.useEffect"], [
        handleCommitHistory
    ]);
    // Best-effort flush when the tab is hidden or closed mid-debounce.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioAutosave.useEffect": ()=>{
            const onVisibilityChange = {
                "useStudioAutosave.useEffect.onVisibilityChange": ()=>{
                    if (document.visibilityState === 'hidden') {
                        void runAutosave();
                    }
                }
            }["useStudioAutosave.useEffect.onVisibilityChange"];
            const onPageHide = {
                "useStudioAutosave.useEffect.onPageHide": ()=>void runAutosave()
            }["useStudioAutosave.useEffect.onPageHide"];
            document.addEventListener('visibilitychange', onVisibilityChange);
            window.addEventListener('pagehide', onPageHide);
            return ({
                "useStudioAutosave.useEffect": ()=>{
                    document.removeEventListener('visibilitychange', onVisibilityChange);
                    window.removeEventListener('pagehide', onPageHide);
                }
            })["useStudioAutosave.useEffect"];
        }
    }["useStudioAutosave.useEffect"], [
        runAutosave
    ]);
    // Abort any in-flight open operation when the hook unmounts
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioAutosave.useEffect": ()=>{
            isMountedRef.current = true;
            return ({
                "useStudioAutosave.useEffect": ()=>{
                    isMountedRef.current = false;
                    if (autosaveTimerRef.current !== null) {
                        window.clearTimeout(autosaveTimerRef.current);
                        autosaveTimerRef.current = null;
                    }
                    if (openAbortRef.current) {
                        openAbortRef.current.abort();
                    }
                }
            })["useStudioAutosave.useEffect"];
        }
    }["useStudioAutosave.useEffect"], []);
    const clearPendingRecovery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioAutosave.useCallback[clearPendingRecovery]": ()=>{
            try {
                if ("TURBOPACK compile-time truthy", 1) {
                    sessionStorage.removeItem('pixibun:pending-recovery-source');
                }
            } catch  {
            // ignore sessionStorage restrictions
            }
            if (lifecycleRef.current.phase === 'active' && lifecycleRef.current.pendingRecovery) {
                updateLifecycle({
                    phase: 'active',
                    projectId: lifecycleRef.current.projectId,
                    pendingRecovery: undefined
                });
            }
        }
    }["useStudioAutosave.useCallback[clearPendingRecovery]"], [
        updateLifecycle
    ]);
    // Coordinated project opener for Gallery, startup, and recovery opening
    const openStoredProject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioAutosave.useCallback[openStoredProject]": async (targetProjectId, isRecoveredCopy = false)=>{
            if (!isMountedRef.current) return {
                success: false,
                reason: 'cancelled'
            };
            const previousActiveState = lifecycleRef.current;
            // Suspend debounced autosave timer
            if (autosaveTimerRef.current !== null) {
                window.clearTimeout(autosaveTimerRef.current);
                autosaveTimerRef.current = null;
            }
            // Preserve unsaved edits before replacing the live workspace.
            if (previousActiveState.phase === 'active' && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().isDirty) {
                try {
                    const result = await runAutosave();
                    if (!result.ok || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().isDirty) {
                        return {
                            success: false,
                            reason: 'blocked',
                            projectId: targetProjectId,
                            reasonCode: 'unsaved-workspace',
                            message: 'The current drawing could not be saved. Export a backup before opening another project.'
                        };
                    }
                } catch  {
                    return {
                        success: false,
                        reason: 'blocked',
                        projectId: targetProjectId,
                        reasonCode: 'unsaved-workspace',
                        message: 'The current drawing could not be saved. Export a backup before opening another project.'
                    };
                }
            }
            if (!isMountedRef.current) return {
                success: false,
                reason: 'cancelled'
            };
            const { epoch, signal } = beginOpen();
            updateLifecycle({
                phase: 'loading',
                projectId: targetProjectId
            });
            if (isOpenStale(epoch)) return {
                success: false,
                reason: 'superseded'
            };
            updateLifecycle({
                phase: 'assessing',
                projectId: targetProjectId
            });
            if (isOpenStale(epoch)) return {
                success: false,
                reason: 'superseded'
            };
            const admission = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$projectAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inspectAndAdmitStoredProject"])(targetProjectId, {
                signal
            });
            if (isOpenStale(epoch)) return {
                success: false,
                reason: 'superseded'
            };
            if (signal.aborted) return {
                success: false,
                reason: 'cancelled'
            };
            if (admission.status === 'admitted') {
                updateLifecycle({
                    phase: 'hydrating',
                    projectId: targetProjectId
                });
                try {
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["hydrateProject"])(admission.project, admission.projectId, admission.sourceBlobs, {
                        "useStudioAutosave.useCallback[openStoredProject]": ()=>!isOpenStale(epoch) && !signal.aborted
                    }["useStudioAutosave.useCallback[openStoredProject]"]);
                } catch (err) {
                    if (isOpenStale(epoch)) return {
                        success: false,
                        reason: 'superseded'
                    };
                    if (signal.aborted) return {
                        success: false,
                        reason: 'cancelled'
                    };
                    console.error('Hydration failed after admission:', err);
                    const message = err instanceof Error ? err.message : 'Hydration failed';
                    if (previousActiveState.phase === 'active') {
                        // Restore previous active workspace (Correction #6)
                        updateLifecycle(previousActiveState);
                        return {
                            success: false,
                            reason: 'hydration-failure',
                            projectId: targetProjectId,
                            message: `Project could not be loaded into the workspace: ${message}`
                        };
                    }
                    const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().resetToNewProject(newId);
                    setAutosaveError(`Project could not be loaded into the workspace: ${message}`);
                    updateLifecycle({
                        phase: 'active',
                        projectId: newId,
                        startupIssue: {
                            kind: 'hydration-failure',
                            sourceProjectId: targetProjectId,
                            message
                        }
                    });
                    return {
                        success: false,
                        reason: 'hydration-failure',
                        projectId: targetProjectId,
                        message
                    };
                }
                if (isOpenStale(epoch)) return {
                    success: false,
                    reason: 'superseded'
                };
                if (signal.aborted) return {
                    success: false,
                    reason: 'cancelled'
                };
                if (admission.storageVersion) storageVersionsRef.current.set(targetProjectId, admission.storageVersion);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearPracticeReturnProject"])();
                if (isRecoveredCopy) {
                    try {
                        if ("TURBOPACK compile-time truthy", 1) {
                            sessionStorage.removeItem('pixibun:pending-recovery-source');
                        }
                    } catch  {
                    // ignore
                    }
                }
                updateLifecycle({
                    phase: 'active',
                    projectId: targetProjectId,
                    pendingRecovery: isRecoveredCopy ? undefined : previousActiveState.phase === 'active' ? previousActiveState.pendingRecovery : undefined
                });
                return {
                    success: true,
                    projectId: targetProjectId
                };
            }
            // Not admitted: restore previous workspace if active (Gallery flow)
            if (previousActiveState.phase === 'active') {
                updateLifecycle(previousActiveState);
            }
            switch(admission.status){
                case 'recovery-required':
                    if (Array.isArray(admission.assessment.reasonCodes) && admission.assessment.reasonCodes.length > 0) {
                        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLedger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["recordRecoveryAssessment"])(admission.assessment).catch({
                            "useStudioAutosave.useCallback[openStoredProject]": (e)=>{
                                console.warn('Failed to record recovery assessment in ledger:', e);
                            }
                        }["useStudioAutosave.useCallback[openStoredProject]"]);
                    }
                    try {
                        if ("TURBOPACK compile-time truthy", 1) {
                            sessionStorage.setItem('pixibun:pending-recovery-source', targetProjectId);
                        }
                    } catch  {
                    // ignore
                    }
                    if (previousActiveState.phase === 'active') {
                        updateLifecycle({
                            ...previousActiveState,
                            pendingRecovery: {
                                sourceProjectId: targetProjectId,
                                assessment: admission.assessment
                            }
                        });
                    }
                    return {
                        success: false,
                        reason: 'recovery-required',
                        projectId: targetProjectId,
                        assessment: admission.assessment,
                        message: 'This project requires recovery and cannot be opened directly.'
                    };
                case 'unsupported-version':
                    return {
                        success: false,
                        reason: 'unsupported-version',
                        projectId: targetProjectId,
                        foundVersion: admission.foundVersion,
                        supportedVersion: admission.supportedVersion,
                        message: admission.message
                    };
                case 'blocked':
                    return {
                        success: false,
                        reason: 'blocked',
                        projectId: targetProjectId,
                        reasonCode: admission.reasonCode,
                        message: admission.message
                    };
                case 'transient-failure':
                    return {
                        success: false,
                        reason: 'transient-failure',
                        projectId: targetProjectId,
                        message: admission.message
                    };
                case 'not-found':
                    return {
                        success: false,
                        reason: 'not-found',
                        projectId: targetProjectId,
                        message: 'Project not found in storage.'
                    };
                case 'cancelled':
                    return {
                        success: false,
                        reason: 'cancelled'
                    };
            }
        }
    }["useStudioAutosave.useCallback[openStoredProject]"], [
        beginOpen,
        isOpenStale,
        runAutosave,
        updateLifecycle
    ]);
    // Restore the last session on mount and request persistent storage.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioAutosave.useEffect": ()=>{
            void requestPersistentStorage().then({
                "useStudioAutosave.useEffect": (persisted)=>{
                    if (!persisted) {
                        if (typeof navigator !== 'undefined' && navigator.storage) {
                            console.warn('Persistent storage request was denied or not granted. Artwork remains saved locally in IndexedDB but may be subject to browser storage eviction under disk pressure.');
                        }
                        let dismissed = false;
                        try {
                            dismissed = ("TURBOPACK compile-time value", "object") !== 'undefined' && sessionStorage.getItem('pixibun:storage-dismissed') === '1';
                        } catch  {
                        // sessionStorage may be blocked in strict privacy modes
                        }
                        if (!dismissed) {
                            setStorageWarning('Persistent storage not granted: artwork is saved in IndexedDB but may be evicted by the browser under disk pressure (common on iOS / Safari). Please export backups regularly.');
                        }
                    }
                }
            }["useStudioAutosave.useEffect"]);
            // Studio mode must never display playground tracing stencils
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"].setState({
                isPlaygroundActive: false,
                showStencilGuide: false
            });
            const resume = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStudioResume"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId);
            if (resume) {
                let cancelled = false;
                const applyResume = {
                    "useStudioAutosave.useEffect.applyResume": (ticket)=>{
                        if (cancelled || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId !== ticket.projectId) return;
                        storageVersionsRef.current = new Map(ticket.storageVersions);
                        conflictRef.current = ticket.conflictProjectId;
                        setSaveConflict(ticket.conflictProjectId);
                        setAutosaveError(ticket.error ?? null);
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setStudioResume"])(ticket);
                        updateLifecycle(ticket.lifecycle);
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearPracticeReturnProject"])();
                    }
                }["useStudioAutosave.useEffect.applyResume"];
                if (resume.checkpoint) {
                    updateLifecycle({
                        phase: 'loading',
                        projectId: resume.projectId
                    });
                    restorePromiseRef.current = resume.checkpoint.then(applyResume);
                } else {
                    applyResume(resume);
                }
                return ({
                    "useStudioAutosave.useEffect": ()=>{
                        cancelled = true;
                    }
                })["useStudioAutosave.useEffect"];
            }
            let unmounted = false;
            restorePromiseRef.current = ({
                "useStudioAutosave.useEffect": async ()=>{
                    // 1. Identify latest project ID via bounded metadata query (Correction #1)
                    let targetId = null;
                    try {
                        targetId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPracticeReturnProject"])() ?? (typeof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLatestStoredProjectId"] === 'function' ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLatestStoredProjectId"])() : (await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadLatestSavedWorkspace"]?.())?.id ?? null);
                    } catch (err) {
                        if (unmounted) return;
                        console.error('Storage read error on startup:', err);
                        const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().resetToNewProject(newId);
                        setAutosaveError('Browser storage is unavailable; your workspace could not be restored.');
                        updateLifecycle({
                            phase: 'active',
                            projectId: newId,
                            startupIssue: {
                                kind: 'transient-failure',
                                message: err instanceof Error ? err.message : 'Database error'
                            }
                        });
                        return;
                    }
                    if (unmounted) return;
                    if (!targetId) {
                        // No saved project in database
                        let pendingRecovery;
                        try {
                            const pendingSourceId = ("TURBOPACK compile-time truthy", 1) ? sessionStorage.getItem('pixibun:pending-recovery-source') : "TURBOPACK unreachable";
                            if (pendingSourceId !== null) {
                                if (pendingSourceId.trim().length > 0) {
                                    const pendingAdmission = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$projectAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inspectAndAdmitStoredProject"])(pendingSourceId);
                                    if (pendingAdmission.status === 'recovery-required') {
                                        pendingRecovery = {
                                            sourceProjectId: pendingSourceId,
                                            assessment: pendingAdmission.assessment
                                        };
                                    } else {
                                        sessionStorage.removeItem('pixibun:pending-recovery-source');
                                    }
                                } else {
                                    sessionStorage.removeItem('pixibun:pending-recovery-source');
                                }
                            }
                        } catch  {
                        // ignore
                        }
                        updateLifecycle({
                            phase: 'active',
                            projectId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId,
                            pendingRecovery
                        });
                        return;
                    }
                    // 2. Begin open request with epoch & abort controller
                    const { epoch, signal } = beginOpen();
                    updateLifecycle({
                        phase: 'loading',
                        projectId: targetId
                    });
                    if (unmounted || isOpenStale(epoch)) return;
                    updateLifecycle({
                        phase: 'assessing',
                        projectId: targetId
                    });
                    if (unmounted || isOpenStale(epoch)) return;
                    const admission = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$projectAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inspectAndAdmitStoredProject"])(targetId, {
                        signal
                    });
                    if (unmounted || isOpenStale(epoch) || signal.aborted) return;
                    if (admission.status === 'admitted') {
                        updateLifecycle({
                            phase: 'hydrating',
                            projectId: targetId
                        });
                        try {
                            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["hydrateProject"])(admission.project, admission.projectId, admission.sourceBlobs, {
                                "useStudioAutosave.useEffect": ()=>!unmounted && !isOpenStale(epoch) && !signal.aborted
                            }["useStudioAutosave.useEffect"]);
                            if (!unmounted && !isOpenStale(epoch)) {
                                if (admission.storageVersion) storageVersionsRef.current.set(targetId, admission.storageVersion);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearPracticeReturnProject"])();
                                let pendingRecovery;
                                try {
                                    const pendingSourceId = ("TURBOPACK compile-time truthy", 1) ? sessionStorage.getItem('pixibun:pending-recovery-source') : "TURBOPACK unreachable";
                                    if (pendingSourceId !== null && pendingSourceId !== targetId) {
                                        if (pendingSourceId.trim().length > 0) {
                                            const pendingAdmission = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$projectAdmission$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inspectAndAdmitStoredProject"])(pendingSourceId, {
                                                signal
                                            });
                                            if (pendingAdmission.status === 'recovery-required') {
                                                pendingRecovery = {
                                                    sourceProjectId: pendingSourceId,
                                                    assessment: pendingAdmission.assessment
                                                };
                                            } else {
                                                sessionStorage.removeItem('pixibun:pending-recovery-source');
                                            }
                                        } else {
                                            sessionStorage.removeItem('pixibun:pending-recovery-source');
                                        }
                                    }
                                } catch  {
                                // ignore
                                }
                                if (unmounted || isOpenStale(epoch)) return;
                                updateLifecycle({
                                    phase: 'active',
                                    projectId: targetId,
                                    pendingRecovery
                                });
                            }
                        } catch (hydErr) {
                            if (unmounted || isOpenStale(epoch) || signal.aborted) return;
                            console.error('Startup project restore failed during hydration:', hydErr);
                            const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().resetToNewProject(newId);
                            setAutosaveError('Saved workspace could not be validated or restored. The original stored project has been preserved for recovery. A fresh workspace has been prepared.');
                            updateLifecycle({
                                phase: 'active',
                                projectId: newId,
                                startupIssue: {
                                    kind: 'hydration-failure',
                                    sourceProjectId: targetId,
                                    message: hydErr instanceof Error ? hydErr.message : 'Hydration failed'
                                }
                            });
                        }
                    } else if (admission.status === 'recovery-required') {
                        if (unmounted || isOpenStale(epoch)) return;
                        if (Array.isArray(admission.assessment.reasonCodes) && admission.assessment.reasonCodes.length > 0) {
                            void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$recovery$2f$recoveryLedger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["recordRecoveryAssessment"])(admission.assessment).catch({
                                "useStudioAutosave.useEffect": (e)=>{
                                    console.warn('Failed to record recovery assessment in ledger:', e);
                                }
                            }["useStudioAutosave.useEffect"]);
                        }
                        try {
                            if ("TURBOPACK compile-time truthy", 1) {
                                sessionStorage.setItem('pixibun:pending-recovery-source', targetId);
                            }
                        } catch  {
                        // ignore
                        }
                        const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().resetToNewProject(newId);
                        setAutosaveError('Saved workspace could not be validated or restored. The original stored project has been preserved for recovery. A fresh workspace has been prepared.');
                        updateLifecycle({
                            phase: 'active',
                            projectId: newId,
                            pendingRecovery: {
                                sourceProjectId: targetId,
                                assessment: admission.assessment
                            }
                        });
                    } else if (admission.status === 'unsupported-version') {
                        if (unmounted || isOpenStale(epoch)) return;
                        const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().resetToNewProject(newId);
                        setAutosaveError(admission.message);
                        updateLifecycle({
                            phase: 'active',
                            projectId: newId,
                            startupIssue: {
                                kind: 'unsupported-version',
                                sourceProjectId: targetId,
                                reasonCode: 'UNSUPPORTED_FUTURE_VERSION',
                                message: admission.message
                            }
                        });
                    } else if (admission.status === 'blocked') {
                        if (unmounted || isOpenStale(epoch)) return;
                        const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().resetToNewProject(newId);
                        setAutosaveError('Saved workspace could not be validated or restored. The original stored project has been preserved for recovery. A fresh workspace has been prepared.');
                        updateLifecycle({
                            phase: 'active',
                            projectId: newId,
                            startupIssue: {
                                kind: 'blocked',
                                sourceProjectId: targetId,
                                reasonCode: admission.reasonCode,
                                message: admission.message
                            }
                        });
                    } else if (admission.status === 'transient-failure') {
                        if (unmounted || isOpenStale(epoch)) return;
                        const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('proj');
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().resetToNewProject(newId);
                        setAutosaveError('Browser storage is unavailable; your workspace could not be restored.');
                        updateLifecycle({
                            phase: 'active',
                            projectId: newId,
                            startupIssue: {
                                kind: 'transient-failure',
                                sourceProjectId: targetId,
                                message: admission.message
                            }
                        });
                    } else if (admission.status === 'not-found') {
                        if (unmounted || isOpenStale(epoch)) return;
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPracticeReturnProject"])() === targetId) {
                            // A missing original cannot be recovered through a permanent pointer.
                            // Release it so new drawings can restore normally after a later save.
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$studioRouteSession$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearPracticeReturnProject"])();
                            setAutosaveError('The saved drawing you were returning to is no longer available in this browser. A fresh drawing is open. If you have a Project Backup, import it to restore your artwork.');
                        }
                        updateLifecycle({
                            phase: 'active',
                            projectId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId
                        });
                    }
                }
            })["useStudioAutosave.useEffect"]();
            return ({
                "useStudioAutosave.useEffect": ()=>{
                    unmounted = true;
                    if (openAbortRef.current) {
                        openAbortRef.current.abort();
                    }
                }
            })["useStudioAutosave.useEffect"];
        }
    }["useStudioAutosave.useEffect"], [
        beginOpen,
        isOpenStale,
        runAutosave,
        updateLifecycle
    ]);
    return {
        autosaveTimerRef,
        runAutosave,
        handleCommitHistory,
        autosaveError,
        saveConflict: lifecycleState.phase === 'active' && saveConflict === lifecycleState.projectId,
        saveConflictCopy,
        setAutosaveError,
        storageWarning,
        setStorageWarning,
        lifecycleState,
        openStoredProject,
        clearPendingRecovery
    };
}
_s(useStudioAutosave, "7uzyQ/nHAqOCBtj2IBPVafqMBJA=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/studio/useStudioClipboard.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStudioClipboard",
    ()=>useStudioClipboard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/importFile.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function useStudioClipboard(handleOpenImport) {
    _s();
    // Global Clipboard Paste (Ctrl+V) for Image Files
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioClipboard.useEffect": ()=>{
            const handlePaste = {
                "useStudioClipboard.useEffect.handlePaste": (e)=>{
                    if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA' || document.activeElement?.tagName === 'SELECT') {
                        return;
                    }
                    const items = e.clipboardData?.items;
                    if (!items) return;
                    for(let i = 0; i < items.length; i++){
                        const item = items[i];
                        if (item.type.startsWith('image/')) {
                            const file = item.getAsFile();
                            if (file) {
                                e.preventDefault();
                                void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readImportFile"])(file).then(handleOpenImport).catch(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$importFile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportImportError"]);
                                break;
                            }
                        }
                    }
                }
            }["useStudioClipboard.useEffect.handlePaste"];
            window.addEventListener('paste', handlePaste);
            return ({
                "useStudioClipboard.useEffect": ()=>window.removeEventListener('paste', handlePaste)
            })["useStudioClipboard.useEffect"];
        }
    }["useStudioClipboard.useEffect"], [
        handleOpenImport
    ]);
}
_s(useStudioClipboard, "OD7bBpZva5O2jO+Puf00hKivP7c=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/studio/useStudioFileSystem.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStudioFileSystem",
    ()=>useStudioFileSystem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/project/serialize.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$saveRevision$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/saveRevision.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$desktopFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/storage/desktopFileSystem.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function useStudioFileSystem() {
    _s();
    const projectName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useStudioFileSystem.useStudioStore[projectName]": (s)=>s.projectName
    }["useStudioFileSystem.useStudioStore[projectName]"]);
    const [saveToast, setSaveToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const saveToastTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Affirmative explicit save confirmation toast helper (UX-14)
    const triggerSaveToast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioFileSystem.useCallback[triggerSaveToast]": ()=>{
            if (saveToastTimerRef.current !== null) {
                window.clearTimeout(saveToastTimerRef.current);
            }
            setSaveToast(`✦ Saved "${projectName || 'project'}" to browser storage`);
            saveToastTimerRef.current = window.setTimeout({
                "useStudioFileSystem.useCallback[triggerSaveToast]": ()=>{
                    setSaveToast(null);
                    saveToastTimerRef.current = null;
                }
            }["useStudioFileSystem.useCallback[triggerSaveToast]"], 2500);
        }
    }["useStudioFileSystem.useCallback[triggerSaveToast]"], [
        projectName
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioFileSystem.useEffect": ()=>{
            return ({
                "useStudioFileSystem.useEffect": ()=>{
                    if (saveToastTimerRef.current !== null) {
                        window.clearTimeout(saveToastTimerRef.current);
                    }
                }
            })["useStudioFileSystem.useEffect"];
        }
    }["useStudioFileSystem.useEffect"], []);
    // Desktop In-Place Save (File System Access API)
    const handleSaveDesktopProject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStudioFileSystem.useCallback[handleSaveDesktopProject]": async (forceSaveAs = false)=>{
            try {
                const snapshot = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                const project = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$serialize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildProjectFileAsync"])();
                const jsonStr = JSON.stringify(project, null, 2);
                const filename = `${(projectName || 'project').toLowerCase().replace(/\s+/g, '-')}.pixibun`;
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2f$desktopFileSystem$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DesktopFileSystem"].saveProject(jsonStr, filename, forceSaveAs, snapshot.currentProjectId);
                if (res.success && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$saveRevision$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCurrentSaveRevision"])(snapshot)) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setSaveStatus('saved');
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().markClean();
                }
            } catch (err) {
                console.error('Desktop save error:', err);
            }
        }
    }["useStudioFileSystem.useCallback[handleSaveDesktopProject]"], [
        projectName
    ]);
    return {
        saveToast,
        triggerSaveToast,
        handleSaveDesktopProject
    };
}
_s(useStudioFileSystem, "Y1o1cFtF19ke7cEKgjNtxI2x8Ug=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/studio/useStudioKeyboard.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStudioKeyboard",
    ()=>useStudioKeyboard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/zoom.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/cvdLens.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function useStudioKeyboard(options) {
    _s();
    const optionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(options);
    optionsRef.current = options;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStudioKeyboard.useEffect": ()=>{
            const handleKeyDown = {
                "useStudioKeyboard.useEffect.handleKeyDown": (e)=>{
                    // Ignore shortcut if typing in an input or textarea
                    if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA' || document.activeElement?.tagName === 'SELECT') {
                        return;
                    }
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    // Save now flushes browser storage. Save As explicitly creates a project file.
                    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
                        e.preventDefault();
                        if (optionsRef.current.autosaveTimerRef.current !== null) {
                            window.clearTimeout(optionsRef.current.autosaveTimerRef.current);
                            optionsRef.current.autosaveTimerRef.current = null;
                        }
                        // Flush browser storage first. Only Save As opens the OS file picker.
                        void ({
                            "useStudioKeyboard.useEffect.handleKeyDown": async ()=>{
                                const res = await optionsRef.current.runAutosave();
                                if (typeof res === 'boolean' ? res : res.ok) optionsRef.current.triggerSaveToast();
                                if (e.shiftKey) await optionsRef.current.handleSaveDesktopProject(true);
                            }
                        })["useStudioKeyboard.useEffect.handleKeyDown"]();
                        return;
                    }
                    // Help / Shortcuts
                    if (e.key === '?' || e.shiftKey && e.key === '/') {
                        e.preventDefault();
                        optionsRef.current.setIsShortcutsOpen({
                            "useStudioKeyboard.useEffect.handleKeyDown": (prev)=>!prev
                        }["useStudioKeyboard.useEffect.handleKeyDown"]);
                        return;
                    }
                    // Command Palette: Ctrl/Cmd + K
                    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
                        e.preventDefault();
                        optionsRef.current.setIsCommandPaletteOpen?.({
                            "useStudioKeyboard.useEffect.handleKeyDown": (prev)=>!prev
                        }["useStudioKeyboard.useEffect.handleKeyDown"]);
                        return;
                    }
                    // Undo / Redo
                    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
                        e.preventDefault();
                        if (e.shiftKey) {
                            optionsRef.current.handleRedo();
                        } else {
                            optionsRef.current.handleUndo();
                        }
                        return;
                    }
                    // Redo Alternate (Ctrl/Cmd + Y)
                    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
                        e.preventDefault();
                        optionsRef.current.handleRedo();
                        return;
                    }
                    // Zoom Shortcuts: Ctrl/Cmd + (+, -, 0, 1)
                    if (e.ctrlKey || e.metaKey) {
                        if (e.key === '=' || e.key === '+') {
                            e.preventDefault();
                            state.setZoom((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNextZoomStep"])(state.zoom));
                            return;
                        }
                        if (e.key === '-' || e.key === '_') {
                            e.preventDefault();
                            state.setZoom((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPrevZoomStep"])(state.zoom));
                            return;
                        }
                        if (e.key === '0') {
                            e.preventDefault();
                            const fitZoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateFitZoom"])(state.canvasWidth, state.canvasHeight);
                            state.setZoom(fitZoom);
                            state.setPan(0, 0);
                            return;
                        }
                        if (e.key === '1') {
                            e.preventDefault();
                            state.setZoom(100);
                            state.setPan(0, 0);
                            return;
                        }
                    }
                    // Single Key & Shift Key Shortcuts
                    const key = e.key.toLowerCase();
                    switch(key){
                        case 'h':
                            {
                                if (!e.ctrlKey && !e.metaKey) {
                                    const hasSelection = !!state.selection;
                                    if (e.shiftKey || !hasSelection) {
                                        e.preventDefault();
                                        state.toggleSymmetryH();
                                    }
                                }
                                break;
                            }
                        case 'v':
                            {
                                if (!e.ctrlKey && !e.metaKey) {
                                    const hasSelection = !!state.selection;
                                    if (e.shiftKey || !hasSelection) {
                                        e.preventDefault();
                                        state.toggleSymmetryV();
                                    }
                                }
                                break;
                            }
                        case 'b':
                            state.setActiveTool('pen');
                            break;
                        case 'c':
                            state.setActiveTool('curve');
                            break;
                        case 'e':
                            state.setActiveTool('eraser');
                            break;
                        case 'g':
                            state.setActiveTool('bucket');
                            break;
                        case 'd':
                            if (e.shiftKey) {
                                state.setPrimaryColor('#000000');
                                state.setSecondaryColor('#ffffff');
                            } else {
                                state.setActiveTool('dither');
                            }
                            break;
                        case 'i':
                            state.setActiveTool('eyedropper');
                            break;
                        case 'm':
                            state.setActiveTool('select-box');
                            break;
                        case 'q':
                            state.setActiveTool('select-lasso');
                            break;
                        case 'w':
                            state.setActiveTool('select-wand');
                            break;
                        case 'l':
                            state.setActiveTool('line');
                            break;
                        case 'j':
                            state.setActiveTool('isometric-line');
                            break;
                        case 'u':
                            state.setActiveTool('rectangle');
                            break;
                        case 'o':
                            state.setActiveTool('ellipse');
                            break;
                        case 'r':
                            state.setActiveTool(e.shiftKey ? 'erase-color' : 'color-replace');
                            break;
                        case 'k':
                            state.setActiveTool('normal-chisel');
                            break;
                        case 's':
                            {
                                // Silhouette / Squint Mode (DESIGN.md §13) — display-only viewport lens
                                if (!e.ctrlKey && !e.metaKey) {
                                    state.toggleSquintMode();
                                }
                                break;
                            }
                        case 'p':
                            {
                                // CVD Colorblindness Lens (DESIGN.md §12) — cycle display-only lens
                                state.setCvdLens((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cycleCvdLens"])(state.cvdLens));
                                break;
                            }
                        case 'x':
                            state.swapColors();
                            break;
                        case '[':
                            state.setBrushSize(Math.max(1, state.tools.brushSize - 1));
                            break;
                        case ']':
                            state.setBrushSize(Math.min(32, state.tools.brushSize + 1));
                            break;
                        case ' ':
                            // Space activates a focused menu button; it must not start playback.
                            if (e.target instanceof Element && e.target.closest('button, summary, [role="button"]')) return;
                            e.preventDefault();
                            state.setIsPlaying(!state.isPlaying);
                            break;
                        case ',':
                            state.setActiveFrame((state.activeFrameIndex - 1 + state.frames.length) % state.frames.length);
                            break;
                        case '.':
                            state.setActiveFrame((state.activeFrameIndex + 1) % state.frames.length);
                            break;
                        default:
                            break;
                    }
                }
            }["useStudioKeyboard.useEffect.handleKeyDown"];
            window.addEventListener('keydown', handleKeyDown);
            return ({
                "useStudioKeyboard.useEffect": ()=>window.removeEventListener('keydown', handleKeyDown)
            })["useStudioKeyboard.useEffect"];
        }
    }["useStudioKeyboard.useEffect"], []);
}
_s(useStudioKeyboard, "KPDgAyAUyS6eETy8HiKSeTjQP1Q=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useCoDrawStatus.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCoDrawStatus",
    ()=>useCoDrawStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sync/coDrawBridge.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function useCoDrawStatus() {
    _s();
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useCoDrawStatus.useState": ()=>{
            const conn = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].getConnectionState();
            const r = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].getRole();
            return {
                connectionState: conn,
                role: r,
                isCoDrawActive: conn === 'connected',
                isHost: conn === 'connected' && r === 'host',
                isGuest: conn === 'connected' && r === 'guest'
            };
        }
    }["useCoDrawStatus.useState"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useCoDrawStatus.useEffect": ()=>{
            const sync = {
                "useCoDrawStatus.useEffect.sync": ()=>{
                    const conn = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].getConnectionState();
                    const r = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].getRole();
                    setStatus({
                        connectionState: conn,
                        role: r,
                        isCoDrawActive: conn === 'connected',
                        isHost: conn === 'connected' && r === 'host',
                        isGuest: conn === 'connected' && r === 'guest'
                    });
                }
            }["useCoDrawStatus.useEffect.sync"];
            sync();
            const unsub = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:codraw-state', sync);
            return unsub;
        }
    }["useCoDrawStatus.useEffect"], []);
    return status;
}
_s(useCoDrawStatus, "C9bZmsnJ4Y/JIwBike6W7oXjCCY=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useRadialContextMenu.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRadialContextMenu",
    ()=>useRadialContextMenu
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function useRadialContextMenu(containerRef) {
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [position, setPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    });
    const handleContextMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useRadialContextMenu.useCallback[handleContextMenu]": (e)=>{
            // Prevent default context menu
            e.preventDefault();
            setPosition({
                x: e.clientX,
                y: e.clientY
            });
            setIsOpen(true);
        }
    }["useRadialContextMenu.useCallback[handleContextMenu]"], []);
    const closeMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useRadialContextMenu.useCallback[closeMenu]": ()=>{
            setIsOpen(false);
        }
    }["useRadialContextMenu.useCallback[closeMenu]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useRadialContextMenu.useEffect": ()=>{
            const target = containerRef?.current ?? document;
            // Also support long-press via touch events
            let timer = null;
            let isMoving = false;
            const handleTouchStart = {
                "useRadialContextMenu.useEffect.handleTouchStart": (e)=>{
                    const te = e;
                    isMoving = false;
                    if (te.touches.length === 1) {
                        timer = window.setTimeout({
                            "useRadialContextMenu.useEffect.handleTouchStart": ()=>{
                                if (!isMoving) {
                                    setPosition({
                                        x: te.touches[0].clientX,
                                        y: te.touches[0].clientY
                                    });
                                    setIsOpen(true);
                                }
                            }
                        }["useRadialContextMenu.useEffect.handleTouchStart"], 500); // 500ms long press
                    }
                }
            }["useRadialContextMenu.useEffect.handleTouchStart"];
            const handleTouchMove = {
                "useRadialContextMenu.useEffect.handleTouchMove": ()=>{
                    isMoving = true;
                    if (timer) {
                        clearTimeout(timer);
                        timer = null;
                    }
                }
            }["useRadialContextMenu.useEffect.handleTouchMove"];
            const handleTouchEnd = {
                "useRadialContextMenu.useEffect.handleTouchEnd": ()=>{
                    if (timer) {
                        clearTimeout(timer);
                        timer = null;
                    }
                }
            }["useRadialContextMenu.useEffect.handleTouchEnd"];
            // Attach touch events to container (scoped) or document (fallback)
            target.addEventListener('touchstart', handleTouchStart, {
                passive: true
            });
            target.addEventListener('touchmove', handleTouchMove, {
                passive: true
            });
            target.addEventListener('touchend', handleTouchEnd);
            target.addEventListener('touchcancel', handleTouchEnd);
            return ({
                "useRadialContextMenu.useEffect": ()=>{
                    target.removeEventListener('touchstart', handleTouchStart);
                    target.removeEventListener('touchmove', handleTouchMove);
                    target.removeEventListener('touchend', handleTouchEnd);
                    target.removeEventListener('touchcancel', handleTouchEnd);
                    if (timer) clearTimeout(timer);
                }
            })["useRadialContextMenu.useEffect"];
        }
    }["useRadialContextMenu.useEffect"], [
        containerRef
    ]);
    return {
        isOpen,
        position,
        handleContextMenu,
        closeMenu
    };
}
_s(useRadialContextMenu, "aI+fSsubJPulZ0OLj4vx1evAMEY=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/events/useArtisanEvents.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useArtisanEvents",
    ()=>useArtisanEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/pixelAiEngine.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$smartMathEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/smartMathEngine.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/dithering.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$morphology$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/morphology.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$workerDispatcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/workerDispatcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/workspaceEnvelopeGuard.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function useArtisanEvents({ canvasWidth, canvasHeight, activeLayerId, getOrCreateLayerCanvas, renderComposite, captureSnapshot, commitSnapshot, bumpBufferVersion, compositeSourceSnapshot, updateTaggedLayer }) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useArtisanEvents.useEffect": ()=>{
            const handleCleanJaggiesEvent = {
                "useArtisanEvents.useEffect.handleCleanJaggiesEvent": ()=>{
                    captureSnapshot('AI Clean Jaggies');
                    const currentLayerCanvas = getOrCreateLayerCanvas(activeLayerId);
                    const ctx = currentLayerCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    if (ctx) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["cleanJaggiesOnCanvas"])(ctx, canvasWidth, canvasHeight);
                        commitSnapshot();
                        renderComposite();
                        bumpBufferVersion();
                    }
                }
            }["useArtisanEvents.useEffect.handleCleanJaggiesEvent"];
            const handle47BlobEvent = {
                "useArtisanEvents.useEffect.handle47BlobEvent": ()=>{
                    const srcCtx = compositeSourceSnapshot('blob-edges');
                    if (!srcCtx) return;
                    const { blobPixels } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generate47BlobEdgeData"])(srcCtx, canvasWidth, canvasHeight);
                    updateTaggedLayer('47-Blob Contours', 'blob-edges', {
                        "useArtisanEvents.useEffect.handle47BlobEvent": (outCtx)=>{
                            blobPixels.forEach({
                                "useArtisanEvents.useEffect.handle47BlobEvent": (p)=>{
                                    outCtx.fillStyle = `rgba(${p.r}, ${p.g}, ${p.b}, ${p.a / 255})`;
                                    outCtx.fillRect(p.x, p.y, 1, 1);
                                }
                            }["useArtisanEvents.useEffect.handle47BlobEvent"]);
                        }
                    }["useArtisanEvents.useEffect.handle47BlobEvent"], {
                        kind: 'autotile',
                        version: 1,
                        sourceMode: 'composite-excluding-self',
                        params: {
                            mode: '47-blob-contours'
                        }
                    });
                }
            }["useArtisanEvents.useEffect.handle47BlobEvent"];
            const handleAtkinsonDitherEvent = {
                "useArtisanEvents.useEffect.handleAtkinsonDitherEvent": (e)=>{
                    const customEvent = e;
                    const paletteColors = customEvent.detail?.colors || [];
                    captureSnapshot('Atkinson Dither');
                    const targetCanvas = getOrCreateLayerCanvas(activeLayerId);
                    const tCtx = targetCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    if (tCtx) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyAtkinsonDither"])(tCtx, canvasWidth, canvasHeight, paletteColors);
                        commitSnapshot();
                        renderComposite();
                        bumpBufferVersion();
                    }
                }
            }["useArtisanEvents.useEffect.handleAtkinsonDitherEvent"];
            const handleRiemersmaDitherEvent = {
                "useArtisanEvents.useEffect.handleRiemersmaDitherEvent": (e)=>{
                    const customEvent = e;
                    const paletteColors = customEvent.detail?.colors || [];
                    captureSnapshot('Riemersma Dither');
                    const targetCanvas = getOrCreateLayerCanvas(activeLayerId);
                    const tCtx = targetCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    if (tCtx) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$dithering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyRiemersmaDither"])(tCtx, canvasWidth, canvasHeight, paletteColors);
                        commitSnapshot();
                        renderComposite();
                        bumpBufferVersion();
                    }
                }
            }["useArtisanEvents.useEffect.handleRiemersmaDitherEvent"];
            const handleSkeletonThinningEvent = {
                "useArtisanEvents.useEffect.handleSkeletonThinningEvent": ()=>{
                    captureSnapshot('1px Skeleton Thinning');
                    const targetCanvas = getOrCreateLayerCanvas(activeLayerId);
                    const tCtx = targetCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    if (tCtx) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$morphology$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyZhangSuenThinning"])(tCtx, canvasWidth, canvasHeight);
                        commitSnapshot();
                        renderComposite();
                        bumpBufferVersion();
                    }
                }
            }["useArtisanEvents.useEffect.handleSkeletonThinningEvent"];
            const handleColorGradeEvent = {
                "useArtisanEvents.useEffect.handleColorGradeEvent": (e)=>{
                    const customEvent = e;
                    const grade = customEvent.detail?.grade || 'sunset';
                    captureSnapshot(`AI Color Grade (${grade})`);
                    const targetCanvas = getOrCreateLayerCanvas(activeLayerId);
                    const tCtx = targetCanvas.getContext('2d');
                    if (tCtx) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["applyAtmosphericColorGrade"])(tCtx, canvasWidth, canvasHeight, grade);
                        commitSnapshot();
                        renderComposite();
                        bumpBufferVersion();
                    }
                }
            }["useArtisanEvents.useEffect.handleColorGradeEvent"];
            const handleQuantizePaletteEvent = {
                "useArtisanEvents.useEffect.handleQuantizePaletteEvent": (e)=>{
                    const customEvent = e;
                    const paletteColors = customEvent.detail?.colors || [];
                    captureSnapshot('AI Snap to Palette');
                    const targetCanvas = getOrCreateLayerCanvas(activeLayerId);
                    const tCtx = targetCanvas.getContext('2d');
                    if (tCtx) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["quantizeToActivePalette"])(tCtx, canvasWidth, canvasHeight, paletteColors);
                        commitSnapshot();
                        renderComposite();
                        bumpBufferVersion();
                    }
                }
            }["useArtisanEvents.useEffect.handleQuantizePaletteEvent"];
            const handleRemoveStraysEvent = {
                "useArtisanEvents.useEffect.handleRemoveStraysEvent": ()=>{
                    captureSnapshot('AI Remove Stray Pixels');
                    const targetCanvas = getOrCreateLayerCanvas(activeLayerId);
                    const tCtx = targetCanvas.getContext('2d');
                    if (tCtx) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["cleanStrayPixelsOnCanvas"])(tCtx, canvasWidth, canvasHeight);
                        commitSnapshot();
                        renderComposite();
                        bumpBufferVersion();
                    }
                }
            }["useArtisanEvents.useEffect.handleRemoveStraysEvent"];
            const handleInBetweenFrameEvent = {
                "useArtisanEvents.useEffect.handleInBetweenFrameEvent": async ()=>{
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    const currentIdx = state.activeFrameIndex;
                    const totalFrames = state.frames.length;
                    const frameA = state.frames[currentIdx];
                    if (!frameA) return;
                    const capacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAddFramesToProject"])(state.frames, canvasWidth, canvasHeight, [
                        {
                            layerCount: frameA.layers.length
                        }
                    ]);
                    if (!capacity.ok) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                            message: capacity.reason || 'Cannot insert an in-between frame.',
                            type: 'error'
                        });
                        return;
                    }
                    let nextIdx = (currentIdx + 1) % totalFrames;
                    if (totalFrames === 1) {
                        nextIdx = 0;
                    }
                    const frameB = state.frames[nextIdx];
                    const getCleanCtx = {
                        "useArtisanEvents.useEffect.handleInBetweenFrameEvent.getCleanCtx": (frame)=>{
                            const scratch = document.createElement('canvas');
                            scratch.width = canvasWidth;
                            scratch.height = canvasHeight;
                            const ctx = scratch.getContext('2d');
                            ctx.imageSmoothingEnabled = false;
                            frame.layers.slice().reverse().forEach({
                                "useArtisanEvents.useEffect.handleInBetweenFrameEvent.getCleanCtx": (l)=>{
                                    if (!l.visible || l.tag) return;
                                    const lCanvas = getOrCreateLayerCanvas(l.id);
                                    ctx.globalAlpha = l.opacity;
                                    ctx.globalCompositeOperation = l.blendMode;
                                    ctx.drawImage(lCanvas, 0, 0);
                                }
                            }["useArtisanEvents.useEffect.handleInBetweenFrameEvent.getCleanCtx"]);
                            return ctx;
                        }
                    }["useArtisanEvents.useEffect.handleInBetweenFrameEvent.getCleanCtx"];
                    const ctxA = getCleanCtx(frameA);
                    const ctxB = getCleanCtx(frameB);
                    const dataA = ctxA.getImageData(0, 0, canvasWidth, canvasHeight).data;
                    const dataB = ctxB.getImageData(0, 0, canvasWidth, canvasHeight).data;
                    const preparedState = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    const origin = {
                        projectId: preparedState.currentProjectId,
                        activeFrameId: preparedState.frames[preparedState.activeFrameIndex]?.id,
                        revision: preparedState.editRevision
                    };
                    let morphed;
                    try {
                        [morphed] = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$workerDispatcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runMorphInWorker"])({
                            width: canvasWidth,
                            height: canvasHeight,
                            data: dataA
                        }, {
                            width: canvasWidth,
                            height: canvasHeight,
                            data: dataB
                        }, 1);
                        if (!morphed || morphed.width !== canvasWidth || morphed.height !== canvasHeight || morphed.data.length !== canvasWidth * canvasHeight * 4) {
                            throw new Error('In-between generation returned invalid pixels.');
                        }
                    } catch (error) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                            message: error instanceof Error ? error.message : 'In-between generation failed; artwork was preserved.',
                            type: 'error'
                        });
                        return;
                    }
                    const latest = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    if (latest.currentProjectId !== origin.projectId || latest.frames[latest.activeFrameIndex]?.id !== origin.activeFrameId || latest.editRevision !== origin.revision) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                            message: 'In-between result was discarded because the animation changed while it was processing.',
                            type: 'error'
                        });
                        latest.addAiMessage({
                            sender: 'assistant',
                            text: 'In-between result was discarded because the animation changed while it was processing.'
                        });
                        return;
                    }
                    const inserted = latest.duplicateFrame(currentIdx, morphed);
                    if (!inserted) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                            message: 'Could not insert in-between frame: project capacity limit reached.',
                            type: 'error'
                        });
                        return;
                    }
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                        type: 'success',
                        message: 'In-between frame inserted',
                        action: {
                            label: 'Undo',
                            onClick: {
                                "useArtisanEvents.useEffect.handleInBetweenFrameEvent": ()=>{
                                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:undo');
                                }
                            }["useArtisanEvents.useEffect.handleInBetweenFrameEvent"]
                        }
                    });
                    renderComposite();
                    bumpBufferVersion();
                    if (frameA.layers.some({
                        "useArtisanEvents.useEffect.handleInBetweenFrameEvent": (l)=>l.tag === 'photometric'
                    }["useArtisanEvents.useEffect.handleInBetweenFrameEvent"])) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:photometric-lighting', {});
                    }
                    if (frameA.layers.some({
                        "useArtisanEvents.useEffect.handleInBetweenFrameEvent": (l)=>l.tag === 'cast-shadow'
                    }["useArtisanEvents.useEffect.handleInBetweenFrameEvent"])) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:render-cast-shadow', {});
                    }
                }
            }["useArtisanEvents.useEffect.handleInBetweenFrameEvent"];
            const unsubs = [
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:clean-jaggies', handleCleanJaggiesEvent),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:apply-47-blob', handle47BlobEvent),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:atkinson-dither', {
                    "useArtisanEvents.useEffect": (detail)=>handleAtkinsonDitherEvent({
                            detail
                        })
                }["useArtisanEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:riemersma-dither', {
                    "useArtisanEvents.useEffect": (detail)=>handleRiemersmaDitherEvent({
                            detail
                        })
                }["useArtisanEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:skeleton-thinning', handleSkeletonThinningEvent),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:color-grade', {
                    "useArtisanEvents.useEffect": (detail)=>handleColorGradeEvent({
                            detail
                        })
                }["useArtisanEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:quantize-palette', {
                    "useArtisanEvents.useEffect": (detail)=>handleQuantizePaletteEvent({
                            detail
                        })
                }["useArtisanEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:remove-strays', handleRemoveStraysEvent),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:in-between-frame', handleInBetweenFrameEvent)
            ];
            return ({
                "useArtisanEvents.useEffect": ()=>{
                    unsubs.forEach({
                        "useArtisanEvents.useEffect": (unsub)=>unsub()
                    }["useArtisanEvents.useEffect"]);
                }
            })["useArtisanEvents.useEffect"];
        }
    }["useArtisanEvents.useEffect"], [
        activeLayerId,
        bumpBufferVersion,
        canvasHeight,
        canvasWidth,
        captureSnapshot,
        commitSnapshot,
        compositeSourceSnapshot,
        getOrCreateLayerCanvas,
        renderComposite,
        updateTaggedLayer
    ]);
}
_s(useArtisanEvents, "OD7bBpZva5O2jO+Puf00hKivP7c=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/events/useGeometricEvents.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGeometricEvents",
    ()=>useGeometricEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/pixelAiEngine.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$smartMathEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/smartMathEngine.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/math/photometricLighting.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/edtNormalMap.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$shadowRayMarcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/shadowRayMarcher.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$shadowAuto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/shadowAuto.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/structuralHistory.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rotSpriteLayer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/rotSpriteLayer.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$workerDispatcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/workerDispatcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
function useGeometricEvents({ canvasWidth, canvasHeight, activeLayerId, getOrCreateLayerCanvas, renderComposite, captureSnapshot, commitSnapshot, bumpBufferVersion, compositeSourceSnapshot, updateTaggedLayer }) {
    _s();
    const rotationInFlightRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGeometricEvents.useEffect": ()=>{
            let disposed = false;
            const handleAutoShadeEvent = {
                "useGeometricEvents.useEffect.handleAutoShadeEvent": (e)=>{
                    const customEvent = e;
                    const tools = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().tools;
                    const lightAz = customEvent.detail?.lightAzimuth ?? tools.lightAzimuth;
                    const lightEl = customEvent.detail?.lightElevation ?? tools.lightElevation;
                    const srcCtx = compositeSourceSnapshot('auto-shade');
                    if (!srcCtx) return;
                    const { shadedPixels } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["renderParametric2p5DLighting"])(srcCtx, canvasWidth, canvasHeight, {
                        azimuthDeg: lightAz,
                        elevationDeg: lightEl,
                        shadowIntensity: 0.8,
                        specularShininess: 16
                    });
                    updateTaggedLayer(`Auto Shade ${lightAz}°`, 'auto-shade', {
                        "useGeometricEvents.useEffect.handleAutoShadeEvent": (outCtx)=>{
                            shadedPixels.forEach({
                                "useGeometricEvents.useEffect.handleAutoShadeEvent": (p)=>{
                                    outCtx.fillStyle = `rgba(${p.r}, ${p.g}, ${p.b}, ${p.a / 255})`;
                                    outCtx.fillRect(p.x, p.y, 1, 1);
                                }
                            }["useGeometricEvents.useEffect.handleAutoShadeEvent"]);
                        }
                    }["useGeometricEvents.useEffect.handleAutoShadeEvent"], {
                        kind: 'auto-shade',
                        version: 1,
                        sourceMode: 'composite-excluding-self',
                        params: {
                            lightAzimuth: lightAz,
                            lightElevation: lightEl,
                            shadowIntensity: 0.8
                        }
                    });
                }
            }["useGeometricEvents.useEffect.handleAutoShadeEvent"];
            const handleHighlightEvent = {
                "useGeometricEvents.useEffect.handleHighlightEvent": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:photometric-gizmo-start', {
                        auto: false,
                        glintOnly: true
                    });
                }
            }["useGeometricEvents.useEffect.handleHighlightEvent"];
            const handleSelOutEvent = {
                "useGeometricEvents.useEffect.handleSelOutEvent": (e)=>{
                    const customEvent = e;
                    const tools = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().tools;
                    const lightAz = customEvent.detail?.lightAzimuth ?? tools.lightAzimuth;
                    const srcCtx = compositeSourceSnapshot('sel-out');
                    if (!srcCtx) return;
                    const { selOutPixels } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateSelOutData"])(srcCtx, canvasWidth, canvasHeight, lightAz);
                    updateTaggedLayer('Selective Outline', 'sel-out', {
                        "useGeometricEvents.useEffect.handleSelOutEvent": (outCtx)=>{
                            selOutPixels.forEach({
                                "useGeometricEvents.useEffect.handleSelOutEvent": (p)=>{
                                    outCtx.fillStyle = `rgba(${p.r}, ${p.g}, ${p.b}, ${p.a / 255})`;
                                    outCtx.fillRect(p.x, p.y, 1, 1);
                                }
                            }["useGeometricEvents.useEffect.handleSelOutEvent"]);
                        }
                    }["useGeometricEvents.useEffect.handleSelOutEvent"], {
                        kind: 'sel-out',
                        version: 1,
                        sourceMode: 'composite-excluding-self',
                        params: {
                            lightAzimuth: lightAz
                        }
                    });
                }
            }["useGeometricEvents.useEffect.handleSelOutEvent"];
            const handleAutoOutlineEvent = {
                "useGeometricEvents.useEffect.handleAutoOutlineEvent": (e)=>{
                    const customEvent = e;
                    const strokeColor = customEvent.detail?.color || '#2B2038';
                    const thickness = Math.max(1, Math.min(8, Math.round(customEvent.detail?.thickness ?? 1)));
                    const srcCtx = compositeSourceSnapshot('auto-outline');
                    if (!srcCtx) return;
                    const { strokePixels } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateOuterStrokeData"])(srcCtx, canvasWidth, canvasHeight, strokeColor, thickness);
                    updateTaggedLayer(`Outline ${thickness}px`, 'auto-outline', {
                        "useGeometricEvents.useEffect.handleAutoOutlineEvent": (outCtx)=>{
                            strokePixels.forEach({
                                "useGeometricEvents.useEffect.handleAutoOutlineEvent": (p)=>{
                                    outCtx.fillStyle = `rgba(${p.r}, ${p.g}, ${p.b}, ${p.a / 255})`;
                                    outCtx.fillRect(p.x, p.y, 1, 1);
                                }
                            }["useGeometricEvents.useEffect.handleAutoOutlineEvent"]);
                        }
                    }["useGeometricEvents.useEffect.handleAutoOutlineEvent"], {
                        kind: 'outline',
                        version: 1,
                        sourceMode: 'composite-excluding-self',
                        params: {
                            color: strokeColor,
                            thickness
                        }
                    });
                }
            }["useGeometricEvents.useEffect.handleAutoOutlineEvent"];
            const handleGroundShadowEvent = {
                "useGeometricEvents.useEffect.handleGroundShadowEvent": ()=>{
                    const srcCtx = compositeSourceSnapshot('ground-shadow');
                    if (!srcCtx) return;
                    const { shadowPixels } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$pixelAiEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateGroundShadowData"])(srcCtx, canvasWidth, canvasHeight);
                    updateTaggedLayer('Ground Shadow', 'ground-shadow', {
                        "useGeometricEvents.useEffect.handleGroundShadowEvent": (outCtx)=>{
                            shadowPixels.forEach({
                                "useGeometricEvents.useEffect.handleGroundShadowEvent": (p)=>{
                                    outCtx.fillStyle = `rgba(${p.r}, ${p.g}, ${p.b}, ${p.a / 255})`;
                                    outCtx.fillRect(p.x, p.y, 1, 1);
                                }
                            }["useGeometricEvents.useEffect.handleGroundShadowEvent"]);
                        }
                    }["useGeometricEvents.useEffect.handleGroundShadowEvent"], {
                        kind: 'ground-shadow',
                        version: 1,
                        sourceMode: 'composite-excluding-self',
                        params: {}
                    });
                }
            }["useGeometricEvents.useEffect.handleGroundShadowEvent"];
            const handleRenderCastShadowEvent = {
                "useGeometricEvents.useEffect.handleRenderCastShadowEvent": (e)=>{
                    const customEvent = e;
                    const detail = customEvent.detail || {};
                    const srcCtx = compositeSourceSnapshot('cast-shadow');
                    if (!srcCtx) return;
                    const imgData = srcCtx.getImageData(0, 0, canvasWidth, canvasHeight);
                    const data = imgData.data;
                    const isOpaque = {
                        "useGeometricEvents.useEffect.handleRenderCastShadowEvent.isOpaque": (x, y)=>{
                            if (x < 0 || x >= canvasWidth || y < 0 || y >= canvasHeight) return false;
                            return data[(y * canvasWidth + x) * 4 + 3] > 30;
                        }
                    }["useGeometricEvents.useEffect.handleRenderCastShadowEvent.isOpaque"];
                    const edt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])({
                        "useGeometricEvents.useEffect.handleRenderCastShadowEvent.edt": (x, y)=>!isOpaque(x, y)
                    }["useGeometricEvents.useEffect.handleRenderCastShadowEvent.edt"], canvasWidth, canvasHeight);
                    const shadowImgData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$shadowRayMarcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["renderBoundedSpriteCastShadow"])(edt, canvasWidth, canvasHeight, {
                        lightX: detail.lightX ?? Math.round(canvasWidth / 2),
                        lightY: detail.lightY ?? Math.round(canvasHeight / 4),
                        lightAzimuth: detail.lightAzimuth,
                        lightElevation: detail.lightElevation,
                        lightRadius: detail.lightRadius ?? 16,
                        shadowOpacity: detail.shadowOpacity ?? 0.65,
                        shadowColor: detail.shadowColor ?? '#180B26',
                        ditherMode: detail.ditherMode ?? 'none',
                        shadowStyle: detail.shadowStyle ?? 'cast',
                        mode: detail.mode ?? 'bounded-2.5d'
                    });
                    updateTaggedLayer('Cast Shadow', 'cast-shadow', {
                        "useGeometricEvents.useEffect.handleRenderCastShadowEvent": (outCtx)=>{
                            outCtx.putImageData(shadowImgData, 0, 0);
                        }
                    }["useGeometricEvents.useEffect.handleRenderCastShadowEvent"], {
                        kind: 'cast-shadow',
                        version: 1,
                        sourceMode: 'composite-excluding-self',
                        params: {
                            lightX: detail.lightX ?? Math.round(canvasWidth / 2),
                            lightY: detail.lightY ?? Math.round(canvasHeight / 4),
                            lightAzimuth: detail.lightAzimuth ?? null,
                            lightElevation: detail.lightElevation ?? null,
                            lightRadius: detail.lightRadius ?? 16,
                            shadowOpacity: detail.shadowOpacity ?? 0.65,
                            shadowColor: detail.shadowColor ?? '#180B26',
                            ditherMode: detail.ditherMode ?? 'none',
                            shadowStyle: detail.shadowStyle ?? 'cast',
                            mode: detail.mode ?? 'bounded-2.5d'
                        }
                    });
                }
            }["useGeometricEvents.useEffect.handleRenderCastShadowEvent"];
            const handleRenderCastShadowAutoEvent = {
                "useGeometricEvents.useEffect.handleRenderCastShadowAutoEvent": (e)=>{
                    const customEvent = e;
                    const detail = customEvent?.detail || {};
                    const srcCtx = compositeSourceSnapshot('cast-shadow');
                    if (!srcCtx) return;
                    const imgData = srcCtx.getImageData(0, 0, canvasWidth, canvasHeight);
                    const data = imgData.data;
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    const inferred = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$shadowAuto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inferRaymarchedShadowSettings"])(data, canvasWidth, canvasHeight, {
                        keyLightAzimuth: state.tools.lightAzimuth,
                        keyLightElevation: state.tools.lightElevation
                    });
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:shadow-settings-inferred', {
                        ...inferred,
                        shadowStyle: detail?.shadowStyle ?? 'cast'
                    });
                    const isOpaque = {
                        "useGeometricEvents.useEffect.handleRenderCastShadowAutoEvent.isOpaque": (x, y)=>{
                            if (x < 0 || x >= canvasWidth || y < 0 || y >= canvasHeight) return false;
                            return data[(y * canvasWidth + x) * 4 + 3] > 30;
                        }
                    }["useGeometricEvents.useEffect.handleRenderCastShadowAutoEvent.isOpaque"];
                    const edt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$edtNormalMap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSeparableEDT"])({
                        "useGeometricEvents.useEffect.handleRenderCastShadowAutoEvent.edt": (x, y)=>!isOpaque(x, y)
                    }["useGeometricEvents.useEffect.handleRenderCastShadowAutoEvent.edt"], canvasWidth, canvasHeight);
                    const shadowImgData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$shadowRayMarcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["renderBoundedSpriteCastShadow"])(edt, canvasWidth, canvasHeight, {
                        lightX: inferred.lightX,
                        lightY: inferred.lightY,
                        lightAzimuth: inferred.lightAzimuth,
                        lightElevation: inferred.lightElevation,
                        lightRadius: inferred.lightRadius,
                        shadowOpacity: inferred.shadowOpacity,
                        shadowColor: inferred.shadowColor,
                        ditherMode: detail.ditherMode ?? inferred.ditherMode ?? 'none',
                        shadowStyle: detail.shadowStyle ?? 'cast',
                        mode: 'bounded-2.5d'
                    });
                    updateTaggedLayer('Cast Shadow', 'cast-shadow', {
                        "useGeometricEvents.useEffect.handleRenderCastShadowAutoEvent": (outCtx)=>{
                            outCtx.putImageData(shadowImgData, 0, 0);
                        }
                    }["useGeometricEvents.useEffect.handleRenderCastShadowAutoEvent"], {
                        kind: 'cast-shadow',
                        version: 1,
                        sourceMode: 'composite-excluding-self',
                        params: {
                            lightX: inferred.lightX,
                            lightY: inferred.lightY,
                            lightAzimuth: inferred.lightAzimuth ?? null,
                            lightElevation: inferred.lightElevation ?? null,
                            lightRadius: inferred.lightRadius,
                            shadowOpacity: inferred.shadowOpacity,
                            shadowColor: inferred.shadowColor,
                            ditherMode: detail.ditherMode ?? inferred.ditherMode ?? 'none',
                            shadowStyle: detail.shadowStyle ?? 'cast',
                            mode: 'bounded-2.5d'
                        },
                        analysis: {
                            rationale: inferred.rationale
                        }
                    });
                }
            }["useGeometricEvents.useEffect.handleRenderCastShadowAutoEvent"];
            const handleRotSpriteEvent = {
                "useGeometricEvents.useEffect.handleRotSpriteEvent": async (e)=>{
                    if (rotationInFlightRef.current) return;
                    const customEvent = e;
                    const angle = customEvent.detail?.angle ?? (typeof customEvent.detail === 'number' ? customEvent.detail : 45);
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    const currentFrame = state.frames[state.activeFrameIndex];
                    const taggedIds = currentFrame ? currentFrame.layers.filter({
                        "useGeometricEvents.useEffect.handleRotSpriteEvent": (layer)=>layer.id !== activeLayerId && layer.tag
                    }["useGeometricEvents.useEffect.handleRotSpriteEvent"]).map({
                        "useGeometricEvents.useEffect.handleRotSpriteEvent": (layer)=>layer.id
                    }["useGeometricEvents.useEffect.handleRotSpriteEvent"]) : [];
                    const affectedLayerIds = [
                        activeLayerId,
                        ...taggedIds
                    ];
                    const angleRad = angle * Math.PI / 180;
                    const originalRevision = state.editRevision;
                    const originalFrameIndex = state.activeFrameIndex;
                    const prepared = [];
                    for (const id of affectedLayerIds){
                        const canvas = getOrCreateLayerCanvas(id);
                        const ctx = canvas.getContext('2d', {
                            willReadFrequently: true
                        });
                        if (!ctx) return;
                        const pixels = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
                        const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rotSpriteLayer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["planLayerRotation"])({
                            width: canvasWidth,
                            height: canvasHeight,
                            data: pixels.data
                        }, angleRad);
                        if (result.error) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                                type: 'error',
                                message: result.error
                            });
                            return;
                        }
                        if (result.plan) prepared.push({
                            id,
                            canvas,
                            plan: result.plan
                        });
                    }
                    if (prepared.length === 0) return;
                    const originalBufferRevisions = new Map(affectedLayerIds.map({
                        "useGeometricEvents.useEffect.handleRotSpriteEvent": (id)=>[
                                id,
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBufferRevision"])(id)
                            ]
                    }["useGeometricEvents.useEffect.handleRotSpriteEvent"]));
                    rotationInFlightRef.current = true;
                    try {
                        const rotated = [];
                        for (const item of prepared){
                            const plan = item.plan;
                            const output = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$workerDispatcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runRotSpriteInWorker"])(plan.source, angleRad, plan.sourcePivotX, plan.sourcePivotY, plan.targetWidth, plan.targetHeight, {
                                outPivotX: plan.outputPivotX,
                                outPivotY: plan.outputPivotY,
                                timeoutMs: 30_000
                            });
                            rotated.push({
                                ...item,
                                data: output.data
                            });
                        }
                        const latest = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                        if (disposed) return;
                        if (latest.editRevision !== originalRevision || latest.activeFrameIndex !== originalFrameIndex || affectedLayerIds.some({
                            "useGeometricEvents.useEffect.handleRotSpriteEvent": (id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBufferRevision"])(id) !== originalBufferRevisions.get(id)
                        }["useGeometricEvents.useEffect.handleRotSpriteEvent"]) || latest.canvasWidth !== canvasWidth || latest.canvasHeight !== canvasHeight) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                                type: 'error',
                                message: 'The canvas changed during rotation. No artwork was replaced; please try again.'
                            });
                            return;
                        }
                        const ready = rotated.map({
                            "useGeometricEvents.useEffect.handleRotSpriteEvent.ready": (item)=>{
                                const ctx = item.canvas.getContext('2d', {
                                    willReadFrequently: true
                                });
                                if (!ctx) throw new Error('A layer canvas is unavailable.');
                                const image = ctx.createImageData(item.plan.targetWidth, item.plan.targetHeight);
                                image.data.set(item.data);
                                return {
                                    ...item,
                                    ctx,
                                    image
                                };
                            }
                        }["useGeometricEvents.useEffect.handleRotSpriteEvent.ready"]);
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])(`RotSprite ${angle}°`, {
                            opKind: 'rotsprite',
                            affectedLayerIds,
                            canvasWidth,
                            canvasHeight
                        })) return;
                        for (const item of ready){
                            item.ctx.clearRect(0, 0, canvasWidth, canvasHeight);
                            item.ctx.putImageData(item.image, item.plan.destX, item.plan.destY);
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(item.id);
                        }
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                            "useGeometricEvents.useEffect.handleRotSpriteEvent": (draft)=>{
                                const frame = draft.frames[draft.activeFrameIndex];
                                if (!frame) return;
                                frame.layers.forEach({
                                    "useGeometricEvents.useEffect.handleRotSpriteEvent": (layer)=>{
                                        if (affectedLayerIds.includes(layer.id)) layer.effect = undefined;
                                    }
                                }["useGeometricEvents.useEffect.handleRotSpriteEvent"]);
                                draft.isDirty = true;
                                draft.editRevision += 1;
                            }
                        }["useGeometricEvents.useEffect.handleRotSpriteEvent"]);
                        renderComposite();
                        bumpBufferVersion();
                    } catch (error) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                            type: 'error',
                            message: error instanceof Error ? `Rotation failed: ${error.message}` : 'Rotation failed.'
                        });
                    } finally{
                        rotationInFlightRef.current = false;
                    }
                }
            }["useGeometricEvents.useEffect.handleRotSpriteEvent"];
            const unsubs = [
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:auto-shade', {
                    "useGeometricEvents.useEffect": (detail)=>handleAutoShadeEvent({
                            detail
                        })
                }["useGeometricEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:highlight', handleHighlightEvent),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:sel-out', {
                    "useGeometricEvents.useEffect": (detail)=>handleSelOutEvent({
                            detail
                        })
                }["useGeometricEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:auto-outline', {
                    "useGeometricEvents.useEffect": (detail)=>handleAutoOutlineEvent({
                            detail
                        })
                }["useGeometricEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:ground-shadow', handleGroundShadowEvent),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:render-cast-shadow', {
                    "useGeometricEvents.useEffect": (detail)=>handleRenderCastShadowEvent({
                            detail
                        })
                }["useGeometricEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:render-cast-shadow-auto', {
                    "useGeometricEvents.useEffect": (detail)=>handleRenderCastShadowAutoEvent({
                            detail
                        })
                }["useGeometricEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:rot-sprite', {
                    "useGeometricEvents.useEffect": (detail)=>handleRotSpriteEvent({
                            detail
                        })
                }["useGeometricEvents.useEffect"])
            ];
            return ({
                "useGeometricEvents.useEffect": ()=>{
                    disposed = true;
                    unsubs.forEach({
                        "useGeometricEvents.useEffect": (unsub)=>unsub()
                    }["useGeometricEvents.useEffect"]);
                }
            })["useGeometricEvents.useEffect"];
        }
    }["useGeometricEvents.useEffect"], [
        activeLayerId,
        bumpBufferVersion,
        canvasHeight,
        canvasWidth,
        captureSnapshot,
        commitSnapshot,
        compositeSourceSnapshot,
        getOrCreateLayerCanvas,
        renderComposite,
        updateTaggedLayer
    ]);
}
_s(useGeometricEvents, "1+U99rNp806yl8Nk5yt1kW7ojuo=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/events/usePhotometricEvents.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePhotometricEvents",
    ()=>usePhotometricEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$smartMathEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/smartMathEngine.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/math/photometricLighting.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$minecraftSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/minecraftSkin.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$workerDispatcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/workerDispatcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricAuto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/photometricAuto.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$lightGizmoMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/lightGizmoMath.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$pixelGlint$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/math/pixelGlint.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/workspaceEnvelopeGuard.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
function renderLightPreview(srcCtx, width, height, params, paletteColors, glintOnly) {
    if (!glintOnly) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["executePhotometricPipeline"])(srcCtx, width, height, params, paletteColors);
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    const image = ctx.createImageData(width, height);
    const geometry = params.precomputedAnalysis ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["computePhotometricAnalysis"])(srcCtx, width, height, params);
    const source = srcCtx.getImageData(0, 0, width, height).data;
    for (const pixel of (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$pixelGlint$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderPixelGlints"])(source, width, height, {
        ...params,
        glintStyle: params.glintStyle ?? 'soft'
    }, geometry)){
        image.data.set([
            pixel.r,
            pixel.g,
            pixel.b,
            pixel.a
        ], (pixel.y * width + pixel.x) * 4);
    }
    ctx.putImageData(image, 0, 0);
    return canvas;
}
function usePhotometricEvents({ canvasWidth, canvasHeight, getOrCreateLayerCanvas, renderComposite, captureSnapshot, commitSnapshot, bumpBufferVersion, compositeSourceSnapshot, updateTaggedLayer, compositeNormalMapSnapshot, discardSnapshot }) {
    _s();
    const photometricSessionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePhotometricEvents.useEffect": ()=>{
            const handlePhotometricGizmoStartEvent = {
                "usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent": (detail)=>{
                    if (photometricSessionRef.current) return;
                    const srcCtx = compositeSourceSnapshot('photometric');
                    if (!srcCtx) return;
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    const currentFrame = state.frames[state.activeFrameIndex];
                    if (!currentFrame) return;
                    const previousActiveLayerId = state.activeLayerId;
                    const requestedLayer = detail?.layerId ? currentFrame.layers.find({
                        "usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent": (layer)=>layer.id === detail.layerId
                    }["usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent"]) : undefined;
                    const glintOnly = detail?.glintOnly || requestedLayer?.effect?.kind === 'specular' || false;
                    const existing = requestedLayer ?? currentFrame.layers.find({
                        "usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent": (layer)=>layer.tag === (glintOnly ? 'specular' : 'photometric')
                    }["usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent"]);
                    if (existing?.locked) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                            message: 'Unlock the effect layer before previewing changes.',
                            type: 'error'
                        });
                        return;
                    }
                    const savedParams = existing?.effect?.params;
                    state.setGlintStyle(savedParams?.glintStyle === 'off' || savedParams?.glintStyle === 'soft' || savedParams?.glintStyle === 'crisp' ? savedParams.glintStyle : glintOnly ? 'crisp' : state.tools.glintStyle ?? 'soft');
                    const readNumber = {
                        "usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent.readNumber": (key, fallback)=>typeof savedParams?.[key] === 'number' ? savedParams[key] : fallback
                    }["usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent.readNumber"];
                    const readString = {
                        "usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent.readString": (key, fallback)=>typeof savedParams?.[key] === 'string' ? savedParams[key] : fallback
                    }["usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent.readString"];
                    let azimuth = state.tools.lightAzimuth;
                    let elevation = state.tools.lightElevation;
                    let material = state.tools.materialPreset;
                    let brightness = state.tools.lightBrightness;
                    let cavityStrength = state.tools.cavityStrength;
                    let ditherModulation = state.tools.ditherModulation;
                    let sourceShadingRemoval = state.tools.sourceShadingRemoval;
                    let minecraftSkinMode = state.tools.minecraftSkinMode ?? 'auto';
                    const imgData = srcCtx.getImageData(0, 0, canvasWidth, canvasHeight);
                    const inferred = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricAuto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inferPhotometricSettings"])(imgData.data, canvasWidth, canvasHeight);
                    let formType = state.tools.formType && state.tools.formType !== 'auto' ? state.tools.formType : inferred.formType;
                    if (!detail?.auto && savedParams) {
                        azimuth = readNumber('lightAzimuth', azimuth);
                        elevation = readNumber('lightElevation', elevation);
                        brightness = readNumber('lightBrightness', brightness);
                        cavityStrength = readNumber('cavityStrength', cavityStrength);
                        ditherModulation = readNumber('ditherModulation', ditherModulation);
                        sourceShadingRemoval = readNumber('sourceShadingRemoval', sourceShadingRemoval);
                        const savedMaterial = readString('material', material);
                        if (savedMaterial === 'matte' || savedMaterial === 'metal' || savedMaterial === 'gold' || savedMaterial === 'glass' || savedMaterial === 'fabric') {
                            material = savedMaterial;
                        }
                        const savedForm = readString('formType', formType);
                        if (savedForm === 'character' || savedForm === 'orb' || savedForm === 'prop') formType = savedForm;
                        const savedSkinMode = readString('minecraftSkinMode', minecraftSkinMode);
                        if (savedSkinMode === 'auto' || savedSkinMode === 'enabled' || savedSkinMode === 'disabled') {
                            minecraftSkinMode = savedSkinMode;
                        }
                        const savedBands = readNumber('shadingBands', state.tools.shadingBands);
                        if (savedBands === 1 || savedBands === 2 || savedBands === 3) {
                            state.setShadingBands(savedBands);
                        }
                    }
                    if (detail?.auto) {
                        azimuth = inferred.lightAzimuth;
                        elevation = inferred.lightElevation;
                        material = inferred.material;
                        brightness = inferred.brightness;
                        // Strong categorical cavity bands read as fixed painted shadows when
                        // the bulb moves. Auto mode keeps AO restrained; artists can raise it
                        // explicitly in Manual mode when the sprite genuinely needs it.
                        cavityStrength = Math.min(inferred.cavityStrength, 0.5);
                        // Single-image albedo recovery is ambiguous. Auto mode must preserve
                        // authored colors and details; destructive ramp normalization remains
                        // an explicit Manual control only.
                        sourceShadingRemoval = 0;
                    }
                    state.setLightAzimuth(azimuth);
                    state.setLightElevation(elevation);
                    state.setMaterialPreset(material);
                    state.setLightBrightness(brightness);
                    state.setCavityStrength(cavityStrength);
                    state.setDitherModulation(ditherModulation);
                    state.setSourceShadingRemoval(sourceShadingRemoval);
                    state.setMinecraftSkinMode(minecraftSkinMode);
                    if (savedParams) state.setFormType(formType);
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:photometric-analysis', {
                        formType: inferred.formType,
                        material: inferred.material,
                        sourceLightAzimuth: inferred.lightAzimuth,
                        sourceLightElevation: inferred.lightElevation,
                        cueStrength: inferred.directionalShadingCue,
                        cavityStrength: inferred.cavityStrength,
                        rationale: inferred.rationale
                    });
                    let targetLayerId;
                    let isNewLayer = false;
                    const tag = glintOnly ? 'specular' : 'photometric';
                    const displayName = glintOnly ? 'Glint' : `Photometric ${material}`;
                    if (existing) {
                        targetLayerId = existing.id;
                        const existingIndex = currentFrame.layers.findIndex({
                            "usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent.existingIndex": (layer)=>layer.id === targetLayerId
                        }["usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent.existingIndex"]);
                        captureSnapshot(displayName, targetLayerId, undefined, tag, true, existingIndex);
                    } else {
                        const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                        const capacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAddLayersToFrame"])(state.frames, state.activeFrameIndex, state.canvasWidth, state.canvasHeight, 1);
                        if (!capacity.ok) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                                message: capacity.reason || 'Cannot create photometric layer: workspace capacity ceiling reached.',
                                type: 'error'
                            });
                            return;
                        }
                        isNewLayer = true;
                        targetLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('layer');
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                            "usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent": (draft)=>{
                                const frame = draft.frames[draft.activeFrameIndex];
                                if (!frame) return;
                                frame.layers.unshift({
                                    id: targetLayerId,
                                    name: displayName,
                                    visible: true,
                                    locked: false,
                                    opacity: 1,
                                    blendMode: 'source-atop',
                                    tag
                                });
                                draft.activeLayerId = targetLayerId;
                            }
                        }["usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent"]);
                        captureSnapshot(displayName, targetLayerId, targetLayerId, tag, true, 0);
                    }
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                        "usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent": (draft)=>{
                            const layer = draft.frames[draft.activeFrameIndex]?.layers.find({
                                "usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent": (candidate)=>candidate.id === targetLayerId
                            }["usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent"]);
                            if (layer) {
                                layer.name = displayName;
                                layer.tag = tag;
                                layer.blendMode = 'source-atop';
                            }
                        }
                    }["usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent"]);
                    const normalMapData = compositeNormalMapSnapshot();
                    const targetCanvas = getOrCreateLayerCanvas(targetLayerId);
                    const targetCtx = targetCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    const previousTargetData = !isNewLayer && targetCtx ? targetCtx.getImageData(0, 0, canvasWidth, canvasHeight) : undefined;
                    const inferredCenter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$lightGizmoMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeArtworkCentroid"])(imgData.data, canvasWidth, canvasHeight);
                    const initialCenter = {
                        x: readNumber('lightCenterX', inferredCenter.x),
                        y: readNumber('lightCenterY', inferredCenter.y)
                    };
                    const params = {
                        glintStyle: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().tools.glintStyle ?? 'soft',
                        lightAzimuth: azimuth,
                        lightElevation: elevation,
                        lightRadius: 64,
                        lightColor: '#FFFFFF',
                        ambientIntensity: 0.48,
                        lightBrightness: brightness,
                        sourceShadingRemoval,
                        material,
                        cavityStrength,
                        ditherModulation,
                        bayerSize: '4x4',
                        formType,
                        minecraftSkinMode,
                        shadingBands: state.tools.shadingBands,
                        lightCenterX: initialCenter.x,
                        lightCenterY: initialCenter.y,
                        normalMapData: normalMapData || undefined
                    };
                    const analysis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["computePhotometricAnalysis"])(srcCtx, canvasWidth, canvasHeight, params, inferred);
                    const shadedCanvas = renderLightPreview(srcCtx, canvasWidth, canvasHeight, {
                        ...params,
                        precomputedAnalysis: analysis
                    }, [], glintOnly);
                    if (targetCtx) {
                        targetCtx.imageSmoothingEnabled = false;
                        targetCtx.clearRect(0, 0, canvasWidth, canvasHeight);
                        targetCtx.drawImage(shadedCanvas, 0, 0);
                    }
                    renderComposite();
                    bumpBufferVersion();
                    photometricSessionRef.current = {
                        srcCtx,
                        targetLayerId,
                        isNewLayer,
                        material,
                        glintOnly,
                        previousTargetBlend: existing?.blendMode,
                        brightness,
                        formType,
                        paletteColors: [],
                        normalMapData,
                        analysis,
                        cachedAzimuth: azimuth,
                        lastCenterX: initialCenter.x,
                        lastCenterY: initialCenter.y,
                        previousTargetData,
                        previousTargetName: existing?.name,
                        previousTargetTag: existing?.tag,
                        previousTargetEffect: existing?.effect ? structuredClone(existing.effect) : undefined,
                        previousActiveLayerId,
                        effectId: existing?.effect?.id ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('effect'),
                        inference: inferred
                    };
                    if (previousActiveLayerId && previousActiveLayerId !== targetLayerId) {
                        state.setActiveLayer(previousActiveLayerId);
                    }
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                        photometricGlintOnly: glintOnly
                    });
                    state.setPhotometricGizmoActive(true);
                }
            }["usePhotometricEvents.useEffect.handlePhotometricGizmoStartEvent"];
            const handlePhotometricLightingLiveEvent = {
                "usePhotometricEvents.useEffect.handlePhotometricLightingLiveEvent": (detail)=>{
                    const session = photometricSessionRef.current;
                    if (!session) return;
                    if (detail.lightCenterX !== undefined) session.lastCenterX = detail.lightCenterX;
                    if (detail.lightCenterY !== undefined) session.lastCenterY = detail.lightCenterY;
                    if (detail.lightBrightness !== undefined) session.brightness = detail.lightBrightness;
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    // Phase 60a: Invalidate/recompute cached analysis when light azimuth drifts past threshold (20°)
                    // on character forms or appendage-bearing sprites, bounding any geometry drift during live drag.
                    if (session.formType === 'character' || session.analysis?.appendageData) {
                        const cachedAz = session.cachedAzimuth ?? detail.lightAzimuth;
                        const diff = Math.abs(detail.lightAzimuth - cachedAz);
                        const angularDrift = Math.min(diff, 360 - diff);
                        if (angularDrift >= 20) {
                            const params = {
                                glintStyle: state.tools.glintStyle ?? 'soft',
                                lightAzimuth: detail.lightAzimuth,
                                lightElevation: detail.lightElevation,
                                lightRadius: 64,
                                lightColor: '#FFFFFF',
                                ambientIntensity: 0.48,
                                lightBrightness: session.brightness,
                                sourceShadingRemoval: state.tools.sourceShadingRemoval,
                                material: session.material,
                                cavityStrength: state.tools.cavityStrength,
                                ditherModulation: state.tools.ditherModulation,
                                bayerSize: '4x4',
                                formType: session.formType,
                                minecraftSkinMode: state.tools.minecraftSkinMode,
                                shadingBands: state.tools.shadingBands,
                                normalMapData: session.normalMapData || undefined
                            };
                            session.analysis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["computePhotometricAnalysis"])(session.srcCtx, canvasWidth, canvasHeight, params, session.inference);
                            session.cachedAzimuth = detail.lightAzimuth;
                        }
                    }
                    const shadedCanvas = renderLightPreview(session.srcCtx, canvasWidth, canvasHeight, {
                        glintStyle: state.tools.glintStyle ?? 'soft',
                        lightAzimuth: detail.lightAzimuth,
                        lightElevation: detail.lightElevation,
                        lightRadius: 64,
                        lightColor: '#FFFFFF',
                        ambientIntensity: 0.48,
                        lightBrightness: session.brightness,
                        sourceShadingRemoval: state.tools.sourceShadingRemoval,
                        material: session.material,
                        cavityStrength: state.tools.cavityStrength,
                        ditherModulation: state.tools.ditherModulation,
                        bayerSize: '4x4',
                        formType: session.formType,
                        minecraftSkinMode: state.tools.minecraftSkinMode,
                        shadingBands: state.tools.shadingBands,
                        lightCenterX: session.lastCenterX,
                        lightCenterY: session.lastCenterY,
                        normalMapData: session.normalMapData || undefined,
                        precomputedAnalysis: session.analysis
                    }, session.paletteColors, session.glintOnly);
                    const lCanvas = getOrCreateLayerCanvas(session.targetLayerId);
                    const lCtx = lCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    if (lCtx) {
                        lCtx.imageSmoothingEnabled = false;
                        lCtx.clearRect(0, 0, canvasWidth, canvasHeight);
                        lCtx.drawImage(shadedCanvas, 0, 0);
                    }
                    renderComposite();
                    bumpBufferVersion();
                }
            }["usePhotometricEvents.useEffect.handlePhotometricLightingLiveEvent"];
            const handlePhotometricGizmoCommitEvent = {
                "usePhotometricEvents.useEffect.handlePhotometricGizmoCommitEvent": ()=>{
                    const session = photometricSessionRef.current;
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    if (session) {
                        // Phase 60a: On drag release commit, perform fresh single-shot analysis recomputation
                        // for character silhouettes / appendage-bearing geometry to ensure 0 azimuth staleness is committed.
                        let commitAnalysis = session.analysis;
                        if (session.formType === 'character' || session.analysis?.appendageData) {
                            commitAnalysis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["computePhotometricAnalysis"])(session.srcCtx, canvasWidth, canvasHeight, {
                                glintStyle: state.tools.glintStyle ?? 'soft',
                                lightAzimuth: state.tools.lightAzimuth,
                                lightElevation: state.tools.lightElevation,
                                lightRadius: 64,
                                lightColor: '#FFFFFF',
                                ambientIntensity: 0.48,
                                lightBrightness: session.brightness,
                                sourceShadingRemoval: state.tools.sourceShadingRemoval,
                                material: session.material,
                                cavityStrength: state.tools.cavityStrength,
                                ditherModulation: state.tools.ditherModulation,
                                bayerSize: '4x4',
                                formType: session.formType,
                                minecraftSkinMode: state.tools.minecraftSkinMode,
                                shadingBands: state.tools.shadingBands,
                                normalMapData: session.normalMapData || undefined
                            }, session.inference);
                        }
                        // Ensure the final commit render strictly aligns with the committed azimuth and elevation
                        const shadedCanvas = renderLightPreview(session.srcCtx, canvasWidth, canvasHeight, {
                            glintStyle: state.tools.glintStyle ?? 'soft',
                            lightAzimuth: state.tools.lightAzimuth,
                            lightElevation: state.tools.lightElevation,
                            lightRadius: 64,
                            lightColor: '#FFFFFF',
                            ambientIntensity: 0.48,
                            lightBrightness: session.brightness,
                            sourceShadingRemoval: state.tools.sourceShadingRemoval,
                            material: session.material,
                            cavityStrength: state.tools.cavityStrength,
                            ditherModulation: state.tools.ditherModulation,
                            bayerSize: '4x4',
                            formType: session.formType,
                            minecraftSkinMode: state.tools.minecraftSkinMode,
                            shadingBands: state.tools.shadingBands,
                            lightCenterX: session.lastCenterX,
                            lightCenterY: session.lastCenterY,
                            normalMapData: session.normalMapData || undefined,
                            precomputedAnalysis: commitAnalysis
                        }, session.paletteColors, session.glintOnly);
                        const lCanvas = getOrCreateLayerCanvas(session.targetLayerId);
                        const lCtx = lCanvas.getContext('2d', {
                            willReadFrequently: true
                        });
                        if (lCtx) {
                            lCtx.imageSmoothingEnabled = false;
                            lCtx.clearRect(0, 0, canvasWidth, canvasHeight);
                            lCtx.drawImage(shadedCanvas, 0, 0);
                        }
                        const committedEffect = {
                            id: session.effectId,
                            kind: session.glintOnly ? 'specular' : 'photometric',
                            version: 1,
                            sourceMode: 'composite-excluding-self',
                            params: {
                                glintStyle: state.tools.glintStyle ?? 'soft',
                                lightAzimuth: state.tools.lightAzimuth,
                                lightElevation: state.tools.lightElevation,
                                lightCenterX: session.lastCenterX ?? null,
                                lightCenterY: session.lastCenterY ?? null,
                                lightBrightness: session.brightness,
                                material: session.material,
                                cavityStrength: state.tools.cavityStrength,
                                ditherModulation: state.tools.ditherModulation,
                                sourceShadingRemoval: state.tools.sourceShadingRemoval,
                                formType: session.formType,
                                minecraftSkinMode: state.tools.minecraftSkinMode ?? 'auto',
                                shadingBands: state.tools.shadingBands
                            },
                            analysis: {
                                formType: session.inference.formType,
                                sourceLightAzimuth: session.inference.lightAzimuth,
                                sourceLightElevation: session.inference.lightElevation,
                                cueStrength: session.inference.directionalShadingCue,
                                rationale: session.inference.rationale
                            },
                            updatedAt: Date.now()
                        };
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                            "usePhotometricEvents.useEffect.handlePhotometricGizmoCommitEvent": (draft)=>{
                                const layer = draft.frames[draft.activeFrameIndex]?.layers.find({
                                    "usePhotometricEvents.useEffect.handlePhotometricGizmoCommitEvent": (candidate)=>candidate.id === session.targetLayerId
                                }["usePhotometricEvents.useEffect.handlePhotometricGizmoCommitEvent"]);
                                if (layer) layer.effect = committedEffect;
                            }
                        }["usePhotometricEvents.useEffect.handlePhotometricGizmoCommitEvent"]);
                        commitSnapshot();
                        state.setLightBrightness(session.brightness);
                        photometricSessionRef.current = null;
                        if (session.previousActiveLayerId) {
                            state.setActiveLayer(session.previousActiveLayerId);
                        }
                    }
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                        photometricGlintOnly: false
                    });
                    state.setPhotometricGizmoActive(false);
                    renderComposite();
                    bumpBufferVersion();
                }
            }["usePhotometricEvents.useEffect.handlePhotometricGizmoCommitEvent"];
            const handlePhotometricGizmoCancelEvent = {
                "usePhotometricEvents.useEffect.handlePhotometricGizmoCancelEvent": ()=>{
                    const session = photometricSessionRef.current;
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    if (session) {
                        if (session.isNewLayer) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                                "usePhotometricEvents.useEffect.handlePhotometricGizmoCancelEvent": (draft)=>{
                                    const frame = draft.frames[draft.activeFrameIndex];
                                    if (!frame) return;
                                    frame.layers = frame.layers.filter({
                                        "usePhotometricEvents.useEffect.handlePhotometricGizmoCancelEvent": (layer)=>layer.id !== session.targetLayerId
                                    }["usePhotometricEvents.useEffect.handlePhotometricGizmoCancelEvent"]);
                                }
                            }["usePhotometricEvents.useEffect.handlePhotometricGizmoCancelEvent"]);
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteBuffers"])([
                                session.targetLayerId
                            ]);
                        } else if (session.previousTargetData) {
                            const targetCanvas = getOrCreateLayerCanvas(session.targetLayerId);
                            const targetCtx = targetCanvas.getContext('2d', {
                                willReadFrequently: true
                            });
                            targetCtx?.putImageData(session.previousTargetData, 0, 0);
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                                "usePhotometricEvents.useEffect.handlePhotometricGizmoCancelEvent": (draft)=>{
                                    const layer = draft.frames[draft.activeFrameIndex]?.layers.find({
                                        "usePhotometricEvents.useEffect.handlePhotometricGizmoCancelEvent": (candidate)=>candidate.id === session.targetLayerId
                                    }["usePhotometricEvents.useEffect.handlePhotometricGizmoCancelEvent"]);
                                    if (!layer) return;
                                    layer.name = session.previousTargetName ?? layer.name;
                                    layer.tag = session.previousTargetTag;
                                    if (session.previousTargetBlend) layer.blendMode = session.previousTargetBlend;
                                    layer.effect = session.previousTargetEffect ? structuredClone(session.previousTargetEffect) : undefined;
                                }
                            }["usePhotometricEvents.useEffect.handlePhotometricGizmoCancelEvent"]);
                        }
                        discardSnapshot();
                        if (session.previousActiveLayerId) {
                            state.setActiveLayer(session.previousActiveLayerId);
                        }
                        photometricSessionRef.current = null;
                    }
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                        photometricGlintOnly: false
                    });
                    state.setPhotometricGizmoActive(false);
                    renderComposite();
                    bumpBufferVersion();
                }
            }["usePhotometricEvents.useEffect.handlePhotometricGizmoCancelEvent"];
            const handlePhotometricAutoEvent = {
                "usePhotometricEvents.useEffect.handlePhotometricAutoEvent": ()=>{
                    handlePhotometricGizmoStartEvent({
                        auto: true
                    });
                }
            }["usePhotometricEvents.useEffect.handlePhotometricAutoEvent"];
            const handlePhotometricLightingEvent = {
                "usePhotometricEvents.useEffect.handlePhotometricLightingEvent": (e)=>{
                    const customEvent = e;
                    const detail = customEvent.detail || {};
                    const srcCtx = compositeSourceSnapshot('photometric');
                    if (!srcCtx) return;
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    const normalMapData = compositeNormalMapSnapshot();
                    const materialName = detail.material ?? state.tools.materialPreset;
                    const sourceData = srcCtx.getImageData(0, 0, canvasWidth, canvasHeight).data;
                    const inferred = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricAuto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inferPhotometricSettings"])(sourceData, canvasWidth, canvasHeight);
                    const lightAzimuth = detail.lightAzimuth ?? state.tools.lightAzimuth;
                    const lightElevation = detail.lightElevation ?? state.tools.lightElevation;
                    const lightBrightness = detail.lightBrightness ?? state.tools.lightBrightness ?? 1.15;
                    const cavityStrength = detail.cavityStrength ?? state.tools.cavityStrength;
                    const ditherModulation = detail.ditherModulation ?? state.tools.ditherModulation;
                    const formType = detail.formType ?? state.tools.formType ?? 'auto';
                    const minecraftSkinMode = detail.minecraftSkinMode ?? state.tools.minecraftSkinMode ?? 'auto';
                    const sourceShadingRemoval = detail.sourceShadingRemoval ?? state.tools.sourceShadingRemoval;
                    const shadingBands = detail.shadingBands ?? state.tools.shadingBands;
                    const pipelineParams = {
                        glintStyle: state.tools.glintStyle ?? 'soft',
                        lightAzimuth,
                        lightElevation,
                        lightRadius: detail.lightRadius ?? state.tools.lightRadius,
                        lightBrightness,
                        sourceShadingRemoval,
                        lightColor: detail.lightColor ?? '#FFFFFF',
                        ambientIntensity: detail.ambientIntensity ?? 0.45,
                        material: materialName,
                        cavityStrength,
                        ditherModulation,
                        bayerSize: detail.bayerSize || '4x4',
                        formType,
                        minecraftSkinMode,
                        shadingBands,
                        normalMapData: normalMapData || undefined
                    };
                    const analysis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["computePhotometricAnalysis"])(srcCtx, canvasWidth, canvasHeight, pipelineParams, inferred);
                    const shadedCanvas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$photometricLighting$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["executePhotometricPipeline"])(srcCtx, canvasWidth, canvasHeight, {
                        ...pipelineParams,
                        precomputedAnalysis: analysis
                    }, detail.paletteColors || []);
                    updateTaggedLayer(`Photometric ${materialName}`, 'photometric', {
                        "usePhotometricEvents.useEffect.handlePhotometricLightingEvent": (outCtx)=>{
                            outCtx.drawImage(shadedCanvas, 0, 0);
                        }
                    }["usePhotometricEvents.useEffect.handlePhotometricLightingEvent"], {
                        kind: 'photometric',
                        version: 1,
                        sourceMode: 'composite-excluding-self',
                        params: {
                            lightAzimuth,
                            lightElevation,
                            lightBrightness,
                            material: materialName,
                            cavityStrength,
                            ditherModulation,
                            sourceShadingRemoval,
                            formType,
                            minecraftSkinMode,
                            shadingBands,
                            paletteColors: detail.paletteColors || []
                        },
                        analysis: {
                            formType: inferred.formType,
                            sourceLightAzimuth: inferred.lightAzimuth,
                            sourceLightElevation: inferred.lightElevation,
                            cueStrength: inferred.directionalShadingCue,
                            rationale: inferred.rationale
                        }
                    });
                }
            }["usePhotometricEvents.useEffect.handlePhotometricLightingEvent"];
            const handleBakeNormalMapEvent = {
                "usePhotometricEvents.useEffect.handleBakeNormalMapEvent": async ()=>{
                    const srcCtx = compositeSourceSnapshot('normal-map');
                    if (!srcCtx) return;
                    const imgData = srcCtx.getImageData(0, 0, canvasWidth, canvasHeight);
                    const data = imgData.data;
                    const isOpaque = {
                        "usePhotometricEvents.useEffect.handleBakeNormalMapEvent.isOpaque": (x, y)=>{
                            if (x < 0 || x >= canvasWidth || y < 0 || y >= canvasHeight) return false;
                            return data[(y * canvasWidth + x) * 4 + 3] > 30;
                        }
                    }["usePhotometricEvents.useEffect.handleBakeNormalMapEvent.isOpaque"];
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    const origin = {
                        projectId: state.currentProjectId,
                        frameId: state.frames[state.activeFrameIndex]?.id,
                        revision: state.editRevision
                    };
                    const skinMode = state.tools.minecraftSkinMode ?? 'auto';
                    let isMcSkin = false;
                    if (canvasWidth === 64 && (canvasHeight === 64 || canvasHeight === 32)) {
                        if (skinMode === 'enabled') {
                            isMcSkin = true;
                        } else if (skinMode === 'auto' && state.tools.formType !== 'character' && state.tools.formType !== 'orb' && state.tools.formType !== 'prop') {
                            isMcSkin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$minecraftSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["detectMinecraftSkin"])(isOpaque, canvasWidth, canvasHeight);
                        }
                    }
                    const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$workerDispatcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runEdtNormalMapInWorker"])(data, canvasWidth, canvasHeight, {
                        isMinecraftSkin: isMcSkin,
                        depthScale: 2.0
                    });
                    const latest = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    if (latest.currentProjectId !== origin.projectId || latest.frames[latest.activeFrameIndex]?.id !== origin.frameId || latest.editRevision !== origin.revision) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                            message: 'Normal-map result was discarded because the source frame changed while it was processing.',
                            type: 'error'
                        });
                        latest.addAiMessage({
                            sender: 'assistant',
                            text: 'Normal-map result was discarded because the source frame changed while it was processing.'
                        });
                        return;
                    }
                    const normalImgData = new ImageData(new Uint8ClampedArray(res.data.buffer), canvasWidth, canvasHeight);
                    updateTaggedLayer('Normal Map', 'normal-map', {
                        "usePhotometricEvents.useEffect.handleBakeNormalMapEvent": (outCtx)=>{
                            outCtx.putImageData(normalImgData, 0, 0);
                        }
                    }["usePhotometricEvents.useEffect.handleBakeNormalMapEvent"], {
                        kind: 'normal-map',
                        version: 1,
                        sourceMode: 'composite-excluding-self',
                        params: {
                            depthScale: 2,
                            minecraftSkinMode: skinMode,
                            minecraftSkinDetected: isMcSkin
                        }
                    });
                }
            }["usePhotometricEvents.useEffect.handleBakeNormalMapEvent"];
            const unsubs = [
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:photometric-lighting', {
                    "usePhotometricEvents.useEffect": (detail)=>handlePhotometricLightingEvent({
                            detail
                        })
                }["usePhotometricEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:photometric-auto', {
                    "usePhotometricEvents.useEffect": ()=>handlePhotometricAutoEvent()
                }["usePhotometricEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:photometric-gizmo-start', {
                    "usePhotometricEvents.useEffect": (detail)=>handlePhotometricGizmoStartEvent(detail || undefined)
                }["usePhotometricEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:photometric-lighting-live', {
                    "usePhotometricEvents.useEffect": (detail)=>handlePhotometricLightingLiveEvent(detail)
                }["usePhotometricEvents.useEffect"]),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:photometric-gizmo-commit', handlePhotometricGizmoCommitEvent),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:photometric-gizmo-cancel', handlePhotometricGizmoCancelEvent),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:bake-normal-map', handleBakeNormalMapEvent)
            ];
            return ({
                "usePhotometricEvents.useEffect": ()=>{
                    unsubs.forEach({
                        "usePhotometricEvents.useEffect": (unsub)=>unsub()
                    }["usePhotometricEvents.useEffect"]);
                }
            })["usePhotometricEvents.useEffect"];
        }
    }["usePhotometricEvents.useEffect"], [
        bumpBufferVersion,
        canvasHeight,
        canvasWidth,
        captureSnapshot,
        commitSnapshot,
        compositeNormalMapSnapshot,
        compositeSourceSnapshot,
        discardSnapshot,
        getOrCreateLayerCanvas,
        renderComposite,
        updateTaggedLayer
    ]);
}
_s(usePhotometricEvents, "Kw0HlcgxyyHm1OdnXWC1l962yuE=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/events/useSpriteCleanupEvents.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSpriteCleanupEvents",
    ()=>useSpriteCleanupEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$spriteCleanup$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai/spriteCleanup.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/historyEngine.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/structuralHistory.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sync/coDrawBridge.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
function useSpriteCleanupEvents({ canvasWidth, canvasHeight, getOrCreateLayerCanvas, renderComposite, captureSnapshot, commitSnapshot, bumpBufferVersion }) {
    _s();
    const lastScanKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useSpriteCleanupEvents.useEffect": ()=>{
            const run = {
                "useSpriteCleanupEvents.useEffect.run": (request, apply)=>{
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    const currentFrame = state.frames[state.activeFrameIndex];
                    const layerIndex = currentFrame?.layers.findIndex({
                        "useSpriteCleanupEvents.useEffect.run": (layer)=>layer.id === state.activeLayerId
                    }["useSpriteCleanupEvents.useEffect.run"]) ?? -1;
                    if (layerIndex < 0) return;
                    const source = {
                        projectId: state.currentProjectId,
                        frameId: currentFrame.id,
                        layerId: state.activeLayerId,
                        editRevision: state.editRevision,
                        bufferVersion: state.bufferVersion,
                        reviewKey: JSON.stringify(state.clips.find({
                            "useSpriteCleanupEvents.useEffect.run": (clip)=>clip.id === state.activeClipId
                        }["useSpriteCleanupEvents.useEffect.run"]) ?? null)
                    };
                    const candidates = request.allFrames ? state.frames.map({
                        "useSpriteCleanupEvents.useEffect.run": (frame)=>frame.layers[layerIndex]
                    }["useSpriteCleanupEvents.useEffect.run"]).filter({
                        "useSpriteCleanupEvents.useEffect.run": (layer)=>Boolean(layer)
                    }["useSpriteCleanupEvents.useEffect.run"]) : [
                        currentFrame.layers[layerIndex]
                    ];
                    const reviewClip = state.clips.find({
                        "useSpriteCleanupEvents.useEffect.run.reviewClip": (clip)=>clip.id === state.activeClipId
                    }["useSpriteCleanupEvents.useEffect.run.reviewClip"]);
                    const scanKey = JSON.stringify({
                        source,
                        options: request.options,
                        allFrames: request.allFrames,
                        reviewClip,
                        targets: candidates.map({
                            "useSpriteCleanupEvents.useEffect.run.scanKey": (layer)=>[
                                    layer.id,
                                    layer.locked
                                ]
                        }["useSpriteCleanupEvents.useEffect.run.scanKey"])
                    });
                    if (apply && lastScanKey.current !== scanKey) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                            type: 'error',
                            message: 'Artwork changed since the preview. Scan again before applying cleanup.'
                        });
                        return;
                    }
                    if (!apply) lastScanKey.current = null;
                    const skippedLocked = candidates.filter({
                        "useSpriteCleanupEvents.useEffect.run": (layer)=>layer.locked
                    }["useSpriteCleanupEvents.useEffect.run"]).length;
                    const targets = candidates.filter({
                        "useSpriteCleanupEvents.useEffect.run.targets": (layer)=>!layer.locked
                    }["useSpriteCleanupEvents.useEffect.run.targets"]);
                    if (targets.length === 0) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                            type: 'error',
                            message: 'Unlock the layer before cleaning it.'
                        });
                        return;
                    }
                    if (request.allFrames && targets.length * canvasWidth * canvasHeight * 8 > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_HISTORY_MAX_BYTES"] / 2) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                            type: 'error',
                            message: 'Too many frame pixels for one undoable cleanup. Choose This frame.'
                        });
                        return;
                    }
                    const stats = {
                        removedFaint: 0,
                        hardenedAlpha: 0,
                        removedSpecks: 0,
                        simplifiedColors: 0,
                        thinnedLinePixels: 0,
                        changedPixels: 0,
                        sourceColors: 0,
                        resultColors: 0
                    };
                    const edits = [];
                    let beforePreview;
                    let afterPreview;
                    const preview = {
                        "useSpriteCleanupEvents.useEffect.run.preview": (pixels)=>{
                            const source = document.createElement('canvas');
                            source.width = canvasWidth;
                            source.height = canvasHeight;
                            const sourceCtx = source.getContext('2d');
                            if (!sourceCtx) return undefined;
                            const image = sourceCtx.createImageData(canvasWidth, canvasHeight);
                            image.data.set(pixels);
                            sourceCtx.putImageData(image, 0, 0);
                            const thumbnail = document.createElement('canvas');
                            const scale = Math.min(1, 160 / Math.max(canvasWidth, canvasHeight));
                            thumbnail.width = Math.max(1, Math.round(canvasWidth * scale));
                            thumbnail.height = Math.max(1, Math.round(canvasHeight * scale));
                            const thumbnailCtx = thumbnail.getContext('2d');
                            if (!thumbnailCtx) return undefined;
                            thumbnailCtx.imageSmoothingEnabled = false;
                            thumbnailCtx.drawImage(source, 0, 0, thumbnail.width, thumbnail.height);
                            return thumbnail.toDataURL('image/png');
                        }
                    }["useSpriteCleanupEvents.useEffect.run.preview"];
                    for (const layer of targets){
                        const ctx = getOrCreateLayerCanvas(layer.id).getContext('2d', {
                            willReadFrequently: true
                        });
                        if (!ctx) continue;
                        const before = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
                        const frameIndex = state.frames.findIndex({
                            "useSpriteCleanupEvents.useEffect.run.frameIndex": (frame)=>frame.layers.some({
                                    "useSpriteCleanupEvents.useEffect.run.frameIndex": (item)=>item.id === layer.id
                                }["useSpriteCleanupEvents.useEffect.run.frameIndex"])
                        }["useSpriteCleanupEvents.useEffect.run.frameIndex"]);
                        const protectedRegions = reviewClip && frameIndex >= reviewClip.startFrame && frameIndex <= reviewClip.endFrame ? reviewClip.review?.regions ?? [] : [];
                        const plan = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$spriteCleanup$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["planSpriteCleanup"])(before, request.options, protectedRegions);
                        stats.removedFaint += plan.stats.removedFaint;
                        stats.hardenedAlpha += plan.stats.hardenedAlpha;
                        stats.removedSpecks += plan.stats.removedSpecks;
                        stats.simplifiedColors += plan.stats.simplifiedColors;
                        stats.thinnedLinePixels += plan.stats.thinnedLinePixels;
                        stats.changedPixels += plan.stats.changedPixels;
                        stats.protectedPixels = (stats.protectedPixels ?? 0) + (plan.stats.protectedPixels ?? 0);
                        stats.sourceColors = Math.max(stats.sourceColors, plan.stats.sourceColors);
                        stats.resultColors = Math.max(stats.resultColors, plan.stats.resultColors);
                        if (!apply && layer.id === state.activeLayerId && canvasWidth * canvasHeight <= 1_000_000) {
                            beforePreview = preview(before.data);
                            afterPreview = preview(plan.data);
                        }
                        if (apply && plan.stats.changedPixels > 0) edits.push({
                            id: layer.id,
                            ctx,
                            before,
                            after: plan.data
                        });
                    }
                    if (apply && edits.length > 0) {
                        if (request.allFrames) {
                            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Analyze & Crisp (All Frames)', {
                                affectedLayerIds: edits.map({
                                    "useSpriteCleanupEvents.useEffect.run": (edit)=>edit.id
                                }["useSpriteCleanupEvents.useEffect.run"])
                            })) return;
                        } else {
                            captureSnapshot('Analyze & Crisp');
                        }
                        for (const edit of edits){
                            const original = new ImageData(new Uint8ClampedArray(edit.before.data), canvasWidth, canvasHeight);
                            edit.before.data.set(edit.after);
                            edit.ctx.putImageData(edit.before, 0, 0);
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(edit.id);
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].notifyStrokeCommitted(edit.id, original);
                        }
                        if (request.allFrames) {
                            const affected = new Set(edits.map({
                                "useSpriteCleanupEvents.useEffect.run": (edit)=>edit.id
                            }["useSpriteCleanupEvents.useEffect.run"]));
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                                "useSpriteCleanupEvents.useEffect.run": (draft)=>{
                                    for (const frame of draft.frames)for (const layer of frame.layers){
                                        if (affected.has(layer.id)) layer.effect = undefined;
                                    }
                                }
                            }["useSpriteCleanupEvents.useEffect.run"]);
                            state.setDirty(true);
                        } else {
                            commitSnapshot();
                        }
                        renderComposite();
                        bumpBufferVersion();
                    }
                    lastScanKey.current = apply ? null : scanKey;
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:sprite-cleanup-report', {
                        phase: apply ? 'applied' : 'scan',
                        stats,
                        frames: targets.length,
                        skippedLocked,
                        source,
                        beforePreview,
                        afterPreview
                    });
                    if (apply) __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                        type: 'success',
                        message: stats.changedPixels > 0 ? `Cleaned ${stats.changedPixels} pixel${stats.changedPixels === 1 ? '' : 's'} across ${targets.length} frame${targets.length === 1 ? '' : 's'}. Undo restores the original.` : 'No cleanup changes were needed.'
                    });
                }
            }["useSpriteCleanupEvents.useEffect.run"];
            const unscan = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:sprite-cleanup-scan', {
                "useSpriteCleanupEvents.useEffect.unscan": (request)=>run(request, false)
            }["useSpriteCleanupEvents.useEffect.unscan"]);
            const unapply = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:sprite-cleanup-apply', {
                "useSpriteCleanupEvents.useEffect.unapply": (request)=>run(request, true)
            }["useSpriteCleanupEvents.useEffect.unapply"]);
            return ({
                "useSpriteCleanupEvents.useEffect": ()=>{
                    unscan();
                    unapply();
                }
            })["useSpriteCleanupEvents.useEffect"];
        }
    }["useSpriteCleanupEvents.useEffect"], [
        canvasWidth,
        canvasHeight,
        getOrCreateLayerCanvas,
        renderComposite,
        captureSnapshot,
        commitSnapshot,
        bumpBufferVersion
    ]);
}
_s(useSpriteCleanupEvents, "BSkI/qn73814FuNGDrMFXN66nos=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useBrushPointerHandler.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useBrushPointerHandler",
    ()=>useBrushPointerHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/canvas/rasterMath.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$ditherMatrix$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/ditherMatrix.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function useBrushPointerHandler({ drawPointsOnActiveLayer, lastPoint, setLastPoint }) {
    _s();
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useBrushPointerHandler.useStudioStore[tools]": (s)=>s.tools
    }["useBrushPointerHandler.useStudioStore[tools]"]);
    const primaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useBrushPointerHandler.useStudioStore[primaryColor]": (s)=>s.primaryColor
    }["useBrushPointerHandler.useStudioStore[primaryColor]"]);
    const secondaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useBrushPointerHandler.useStudioStore[secondaryColor]": (s)=>s.secondaryColor
    }["useBrushPointerHandler.useStudioStore[secondaryColor]"]);
    const onPointerDown = (e, coords)=>{
        const isErase = tools.activeTool === 'eraser';
        const drawColor = e.shiftKey ? secondaryColor : primaryColor;
        if (tools.activeTool === 'pen' || tools.activeTool === 'eraser') {
            drawPointsOnActiveLayer([
                coords
            ], drawColor, isErase);
        } else if (tools.activeTool === 'dither') {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$ditherMatrix$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldDitherPixel"])(coords.x, coords.y, tools.ditherMatrix, tools.ditherDensity)) {
                drawPointsOnActiveLayer([
                    coords
                ], drawColor, false);
            }
        }
    };
    const onPointerMove = (e, coords)=>{
        const isErase = tools.activeTool === 'eraser';
        const drawColor = e.shiftKey ? secondaryColor : primaryColor;
        if (tools.activeTool === 'pen' || tools.activeTool === 'eraser') {
            if (lastPoint) {
                const linePoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getBresenhamLine"])(lastPoint.x, lastPoint.y, coords.x, coords.y);
                const pointsToDraw = tools.pixelPerfect ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["filterPixelPerfect"])(linePoints) : linePoints;
                drawPointsOnActiveLayer(pointsToDraw, drawColor, isErase);
            }
            setLastPoint(coords);
        } else if (tools.activeTool === 'dither') {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$ditherMatrix$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldDitherPixel"])(coords.x, coords.y, tools.ditherMatrix, tools.ditherDensity)) {
                drawPointsOnActiveLayer([
                    coords
                ], drawColor, false);
            }
            setLastPoint(coords);
        }
    };
    const onPointerUp = (_e, _coords)=>{
    // Brush tools don't need explicit up logic besides what main hook does (commit snapshot)
    };
    return {
        onPointerDown,
        onPointerMove,
        onPointerUp
    };
}
_s(useBrushPointerHandler, "7b3srgCEp9uhZFHsCpNZMvATZsM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useChiselPointerHandler.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useChiselPointerHandler",
    ()=>useChiselPointerHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/canvas/rasterMath.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/art/normalSculptor.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function useChiselPointerHandler({ canvasWidth, canvasHeight, chiselSessionRef, currentStrokeSnapshotRef, lastPoint, setLastPoint, getOrCreateLayerCanvas, renderComposite }) {
    _s();
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useChiselPointerHandler.useStudioStore[tools]": (s)=>s.tools
    }["useChiselPointerHandler.useStudioStore[tools]"]);
    const activeLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useChiselPointerHandler.useStudioStore[activeLayerId]": (s)=>s.activeLayerId
    }["useChiselPointerHandler.useStudioStore[activeLayerId]"]);
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useChiselPointerHandler.useStudioStore[frames]": (s)=>s.frames
    }["useChiselPointerHandler.useStudioStore[frames]"]);
    const activeFrameIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useChiselPointerHandler.useStudioStore[activeFrameIndex]": (s)=>s.activeFrameIndex
    }["useChiselPointerHandler.useStudioStore[activeFrameIndex]"]);
    const onPointerDown = (_e, coords)=>{
        const currentFrame = frames[activeFrameIndex];
        const targetLayerId = activeLayerId || currentFrame?.layers[0]?.id;
        if (tools.activeTool === 'normal-chisel') {
            if (targetLayerId) {
                chiselSessionRef.current = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$normalSculptor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChiselStrokeSession"](canvasWidth, canvasHeight);
                chiselSessionRef.current.stampChisel(coords.x, coords.y, {
                    azimuth: tools.chiselAzimuth,
                    incline: tools.chiselIncline,
                    width: tools.chiselWidth,
                    ridgeMode: tools.chiselRidgeMode,
                    blendMode: tools.normalBlendMode
                });
                const lCanvas = getOrCreateLayerCanvas(targetLayerId);
                const lCtx = lCanvas.getContext('2d', {
                    willReadFrequently: true
                });
                if (lCtx && currentStrokeSnapshotRef.current && 'imageData' in currentStrokeSnapshotRef.current) {
                    const workingImg = new ImageData(new Uint8ClampedArray(currentStrokeSnapshotRef.current.imageData.data), canvasWidth, canvasHeight);
                    chiselSessionRef.current.compositeOnto(workingImg, tools.normalBlendMode);
                    lCtx.putImageData(workingImg, 0, 0);
                    renderComposite();
                }
            }
        }
    };
    const onPointerMove = (_e, coords)=>{
        if (tools.activeTool === 'normal-chisel') {
            if (lastPoint && chiselSessionRef.current) {
                const dx = coords.x - lastPoint.x;
                const dy = coords.y - lastPoint.y;
                const linePoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getBresenhamLine"])(lastPoint.x, lastPoint.y, coords.x, coords.y);
                for (const pt of linePoints){
                    chiselSessionRef.current.stampChisel(pt.x, pt.y, {
                        azimuth: tools.chiselAzimuth,
                        incline: tools.chiselIncline,
                        width: tools.chiselWidth,
                        ridgeMode: tools.chiselRidgeMode,
                        blendMode: tools.normalBlendMode
                    }, {
                        dx,
                        dy
                    });
                }
                const currentFrame = frames[activeFrameIndex];
                const targetLayerId = activeLayerId || currentFrame?.layers[0]?.id;
                if (targetLayerId && currentStrokeSnapshotRef.current && 'imageData' in currentStrokeSnapshotRef.current) {
                    const lCanvas = getOrCreateLayerCanvas(targetLayerId);
                    const lCtx = lCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    if (lCtx) {
                        const workingImg = new ImageData(new Uint8ClampedArray(currentStrokeSnapshotRef.current.imageData.data), canvasWidth, canvasHeight);
                        chiselSessionRef.current.compositeOnto(workingImg, tools.normalBlendMode);
                        lCtx.putImageData(workingImg, 0, 0);
                        renderComposite();
                    }
                }
            }
            setLastPoint(coords);
        }
    };
    const onPointerUp = (_e, _coords)=>{
    // Normal chisel handled in main hook via bumpBufferVersion & snapshot commit
    };
    return {
        onPointerDown,
        onPointerMove,
        onPointerUp
    };
}
_s(useChiselPointerHandler, "rXH4w10duu6t0eZDS4hH3/qw96s=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useSelectionPointerHandler.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSelectionPointerHandler",
    ()=>useSelectionPointerHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature();
'use client';
;
function useSelectionPointerHandler({ canvasWidth, canvasHeight, floatingSelection, setFloatingSelection, isDraggingSelection, setIsDraggingSelection, dragOffset, setDragOffset, lassoPoints, setLassoPoints, selectionModifierRef, baseSelectionMaskRef, liftSelectionToFloating, commitFloatingSelection, createBoxMask, mergeSelectionMask, isDrawingRef, setIsDrawing, strokeStart, setStrokeStart, lastPoint: _lastPoint, setLastPoint, getOrCreateLayerCanvas, previewCanvasRef, renderComposite }) {
    _s();
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useSelectionPointerHandler.useStudioStore[tools]": (s)=>s.tools
    }["useSelectionPointerHandler.useStudioStore[tools]"]);
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useSelectionPointerHandler.useStudioStore[selection]": (s)=>s.selection
    }["useSelectionPointerHandler.useStudioStore[selection]"]);
    const selectionMask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useSelectionPointerHandler.useStudioStore[selectionMask]": (s)=>s.selectionMask
    }["useSelectionPointerHandler.useStudioStore[selectionMask]"]);
    const setSelection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useSelectionPointerHandler.useStudioStore[setSelection]": (s)=>s.setSelection
    }["useSelectionPointerHandler.useStudioStore[setSelection]"]);
    const activeLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useSelectionPointerHandler.useStudioStore[activeLayerId]": (s)=>s.activeLayerId
    }["useSelectionPointerHandler.useStudioStore[activeLayerId]"]);
    const onPointerDown = (e, coords)=>{
        // Selection Drag Handler
        if (tools.activeTool.startsWith('select-') && !e.altKey) {
            const activeBox = floatingSelection || selection;
            if (activeBox && coords.x >= activeBox.x && coords.x < activeBox.x + activeBox.w && coords.y >= activeBox.y && coords.y < activeBox.y + activeBox.h) {
                if (!floatingSelection) {
                    liftSelectionToFloating();
                }
                setIsDraggingSelection(true);
                setDragOffset({
                    x: coords.x - activeBox.x,
                    y: coords.y - activeBox.y
                });
                return true; // handled
            }
        }
        if (tools.activeTool === 'select-box') {
            if (floatingSelection) commitFloatingSelection();
            const mode = e.shiftKey ? 'union' : e.altKey ? 'subtract' : 'replace';
            selectionModifierRef.current = mode;
            baseSelectionMaskRef.current = selectionMask ? new Uint8Array(selectionMask) : selection ? createBoxMask(selection) : null;
            isDrawingRef.current = true;
            setIsDrawing(true);
            setStrokeStart(coords);
            setLastPoint(coords);
            if (mode === 'replace') {
                setSelection({
                    x: coords.x,
                    y: coords.y,
                    w: 1,
                    h: 1
                }, null);
            }
            return true;
        }
        if (tools.activeTool === 'select-lasso') {
            if (floatingSelection) commitFloatingSelection();
            const mode = e.shiftKey ? 'union' : e.altKey ? 'subtract' : 'replace';
            selectionModifierRef.current = mode;
            baseSelectionMaskRef.current = selectionMask ? new Uint8Array(selectionMask) : selection ? createBoxMask(selection) : null;
            isDrawingRef.current = true;
            setIsDrawing(true);
            if (mode === 'replace') {
                setSelection(null, null);
            }
            setLassoPoints([
                coords
            ]);
            setStrokeStart(coords);
            return true;
        }
        if (tools.activeTool === 'select-wand') {
            if (floatingSelection) commitFloatingSelection();
            const mode = e.shiftKey ? 'union' : e.altKey ? 'subtract' : 'replace';
            const baseMask = selectionMask ? new Uint8Array(selectionMask) : selection ? createBoxMask(selection) : null;
            const layerCanvas = getOrCreateLayerCanvas(activeLayerId);
            const ctx = layerCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (ctx) {
                const imgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
                const data = imgData.data;
                const targetIdx = (coords.y * canvasWidth + coords.x) * 4;
                const targetR = data[targetIdx];
                const targetG = data[targetIdx + 1];
                const targetB = data[targetIdx + 2];
                const targetA = data[targetIdx + 3];
                const newSelectionMask = new Uint8Array(canvasWidth * canvasHeight);
                const visited = new Uint8Array(canvasWidth * canvasHeight);
                const queue = [
                    coords
                ];
                const { bucketTolerance, bucketContiguous } = tools;
                const colorMatch = (r, g, b, a)=>{
                    if (bucketTolerance === 0) {
                        return r === targetR && g === targetG && b === targetB && a === targetA;
                    }
                    const diff = Math.max(Math.abs(r - targetR), Math.abs(g - targetG), Math.abs(b - targetB), Math.abs(a - targetA));
                    return diff <= bucketTolerance;
                };
                if (bucketContiguous) {
                    visited[coords.y * canvasWidth + coords.x] = 1;
                    let head = 0;
                    while(head < queue.length){
                        const { x, y } = queue[head++];
                        const idx = y * canvasWidth + x;
                        newSelectionMask[idx] = 1;
                        const neighbors = [
                            {
                                nx: x - 1,
                                ny: y
                            },
                            {
                                nx: x + 1,
                                ny: y
                            },
                            {
                                nx: x,
                                ny: y - 1
                            },
                            {
                                nx: x,
                                ny: y + 1
                            }
                        ];
                        for (const { nx, ny } of neighbors){
                            if (nx >= 0 && nx < canvasWidth && ny >= 0 && ny < canvasHeight) {
                                const nIdx = ny * canvasWidth + nx;
                                if (visited[nIdx] === 0) {
                                    visited[nIdx] = 1;
                                    const dataIdx = nIdx * 4;
                                    if (colorMatch(data[dataIdx], data[dataIdx + 1], data[dataIdx + 2], data[dataIdx + 3])) {
                                        queue.push({
                                            x: nx,
                                            y: ny
                                        });
                                    }
                                }
                            }
                        }
                    }
                } else {
                    for(let y = 0; y < canvasHeight; y++){
                        for(let x = 0; x < canvasWidth; x++){
                            const idx = y * canvasWidth + x;
                            const dataIdx = idx * 4;
                            if (colorMatch(data[dataIdx], data[dataIdx + 1], data[dataIdx + 2], data[dataIdx + 3])) {
                                newSelectionMask[idx] = 1;
                            }
                        }
                    }
                }
                const { box, mask } = mergeSelectionMask(baseMask, newSelectionMask, mode);
                setSelection(box, mask);
            }
            return true;
        }
        return false;
    };
    const onPointerMove = (_e, coords)=>{
        if (isDraggingSelection && floatingSelection) {
            const newX = coords.x - dragOffset.x;
            const newY = coords.y - dragOffset.y;
            setFloatingSelection({
                ...floatingSelection,
                x: newX,
                y: newY
            });
            setSelection({
                x: newX,
                y: newY,
                w: floatingSelection.w,
                h: floatingSelection.h
            });
            renderComposite();
            return true;
        }
        if (tools.activeTool === 'select-box' && strokeStart) {
            const minX = Math.min(strokeStart.x, coords.x);
            const minY = Math.min(strokeStart.y, coords.y);
            const width = Math.abs(coords.x - strokeStart.x) + 1;
            const height = Math.abs(coords.y - strokeStart.y) + 1;
            if (selectionModifierRef.current === 'replace') {
                setSelection({
                    x: minX,
                    y: minY,
                    w: width,
                    h: height
                }, null);
            } else {
                const previewCanvas = previewCanvasRef.current;
                if (previewCanvas) {
                    const pCtx = previewCanvas.getContext('2d');
                    if (pCtx) {
                        pCtx.clearRect(0, 0, canvasWidth, canvasHeight);
                        pCtx.imageSmoothingEnabled = false;
                        pCtx.strokeStyle = selectionModifierRef.current === 'union' ? 'rgba(128, 255, 128, 0.85)' : 'rgba(255, 128, 128, 0.85)';
                        pCtx.lineWidth = 1;
                        pCtx.strokeRect(minX, minY, width, height);
                    }
                }
            }
            return true;
        }
        if (tools.activeTool === 'select-lasso' && isDrawingRef.current && strokeStart) {
            setLassoPoints((prev)=>{
                const next = [
                    ...prev,
                    coords
                ];
                const previewCanvas = previewCanvasRef.current;
                if (previewCanvas && next.length > 0) {
                    const pCtx = previewCanvas.getContext('2d');
                    if (pCtx) {
                        pCtx.clearRect(0, 0, canvasWidth, canvasHeight);
                        pCtx.imageSmoothingEnabled = false;
                        pCtx.strokeStyle = 'rgba(199, 146, 223, 0.85)';
                        pCtx.lineWidth = 1;
                        pCtx.beginPath();
                        pCtx.moveTo(next[0].x, next[0].y);
                        for(let i = 1; i < next.length; i++){
                            pCtx.lineTo(next[i].x, next[i].y);
                        }
                        pCtx.stroke();
                    }
                }
                return next;
            });
            return true;
        }
        return false;
    };
    const onPointerUp = (_e, endCoords)=>{
        if (tools.activeTool === 'select-box' && strokeStart && endCoords) {
            const bx = Math.min(strokeStart.x, endCoords.x);
            const by = Math.min(strokeStart.y, endCoords.y);
            const bw = Math.abs(endCoords.x - strokeStart.x) + 1;
            const bh = Math.abs(endCoords.y - strokeStart.y) + 1;
            const boxMask = createBoxMask({
                x: bx,
                y: by,
                w: bw,
                h: bh
            });
            const { box, mask } = mergeSelectionMask(baseSelectionMaskRef.current, boxMask, selectionModifierRef.current);
            setSelection(box, mask);
            baseSelectionMaskRef.current = null;
            selectionModifierRef.current = 'replace';
            return true;
        }
        if (tools.activeTool === 'select-lasso') {
            if (lassoPoints.length > 2) {
                const tempCanvas = document.createElement('canvas');
                tempCanvas.width = canvasWidth;
                tempCanvas.height = canvasHeight;
                const tempCtx = tempCanvas.getContext('2d', {
                    willReadFrequently: true
                });
                if (tempCtx) {
                    tempCtx.fillStyle = 'black';
                    tempCtx.beginPath();
                    tempCtx.moveTo(lassoPoints[0].x, lassoPoints[0].y);
                    for(let i = 1; i < lassoPoints.length; i++){
                        tempCtx.lineTo(lassoPoints[i].x, lassoPoints[i].y);
                    }
                    tempCtx.closePath();
                    tempCtx.fill();
                    const imgData = tempCtx.getImageData(0, 0, canvasWidth, canvasHeight);
                    const data = imgData.data;
                    const newSelectionMask = new Uint8Array(canvasWidth * canvasHeight);
                    for(let y = 0; y < canvasHeight; y++){
                        for(let x = 0; x < canvasWidth; x++){
                            const idx = y * canvasWidth + x;
                            const alpha = data[idx * 4 + 3];
                            if (alpha > 0) {
                                newSelectionMask[idx] = 1;
                            }
                        }
                    }
                    const { box, mask } = mergeSelectionMask(baseSelectionMaskRef.current, newSelectionMask, selectionModifierRef.current);
                    setSelection(box, mask);
                    baseSelectionMaskRef.current = null;
                    selectionModifierRef.current = 'replace';
                }
            }
            setLassoPoints([]);
            return true;
        }
        if (tools.activeTool.startsWith('select-')) return true; // Just in case wand/etc so it skips snapshot commits
        return false;
    };
    return {
        onPointerDown,
        onPointerMove,
        onPointerUp
    };
}
_s(useSelectionPointerHandler, "AWgMQjd2cdf1sqYiHvFVh2a9y5c=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useShapePointerHandler.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useShapePointerHandler",
    ()=>useShapePointerHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/canvas/rasterMath.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$curvesAndLines$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/ai/math/curvesAndLines.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function useShapePointerHandler({ canvasWidth, canvasHeight, strokeStart, previewCanvasRef, drawPointsOnActiveLayer }) {
    _s();
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useShapePointerHandler.useStudioStore[tools]": (s)=>s.tools
    }["useShapePointerHandler.useStudioStore[tools]"]);
    const primaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useShapePointerHandler.useStudioStore[primaryColor]": (s)=>s.primaryColor
    }["useShapePointerHandler.useStudioStore[primaryColor]"]);
    const secondaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useShapePointerHandler.useStudioStore[secondaryColor]": (s)=>s.secondaryColor
    }["useShapePointerHandler.useStudioStore[secondaryColor]"]);
    const onPointerDown = (_e, _coords)=>{
    // Shapes only set strokeStart, which is handled in main hook
    };
    const onPointerMove = (e, coords)=>{
        const drawColor = e.shiftKey ? secondaryColor : primaryColor;
        if ((tools.activeTool === 'line' || tools.activeTool === 'curve' || tools.activeTool === 'isometric-line' || tools.activeTool === 'rectangle' || tools.activeTool === 'ellipse') && strokeStart) {
            const previewCanvas = previewCanvasRef.current;
            if (previewCanvas) {
                const pCtx = previewCanvas.getContext('2d');
                if (pCtx) {
                    pCtx.clearRect(0, 0, canvasWidth, canvasHeight);
                    pCtx.imageSmoothingEnabled = false;
                    let previewPoints = [];
                    if (tools.activeTool === 'line') {
                        previewPoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getClippedLine"])(strokeStart.x, strokeStart.y, coords.x, coords.y, canvasWidth, canvasHeight);
                    } else if (tools.activeTool === 'isometric-line') {
                        previewPoints = tools.isoAngleSnap ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$curvesAndLines$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getIsometric2p1Line"])(strokeStart.x, strokeStart.y, coords.x, coords.y) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getClippedLine"])(strokeStart.x, strokeStart.y, coords.x, coords.y, canvasWidth, canvasHeight);
                    } else if (tools.activeTool === 'curve') {
                        const controlPoint = {
                            x: Math.round((strokeStart.x + coords.x) / 2 + (coords.y - strokeStart.y) * tools.curveTightness),
                            y: Math.round((strokeStart.y + coords.y) / 2 - (coords.x - strokeStart.x) * tools.curveTightness)
                        };
                        previewPoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$curvesAndLines$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getQuadraticBezierPoints"])(strokeStart, controlPoint, coords);
                    } else if (tools.activeTool === 'rectangle') {
                        previewPoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getRectanglePoints"])(strokeStart.x, strokeStart.y, coords.x, coords.y, tools.shapeFilled);
                    } else if (tools.activeTool === 'ellipse') {
                        previewPoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getEllipsePoints"])(strokeStart.x, strokeStart.y, coords.x, coords.y, tools.shapeFilled);
                    }
                    if (tools.symmetryHorizontal || tools.symmetryVertical || tools.symmetryGroup && tools.symmetryGroup !== 'none') {
                        previewPoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["applySymmetry"])(previewPoints, canvasWidth, canvasHeight, tools.symmetryHorizontal, tools.symmetryVertical, tools.symmetryGroup);
                    }
                    pCtx.fillStyle = drawColor;
                    const offset = Math.floor(tools.brushSize / 2);
                    previewPoints.forEach((p)=>{
                        pCtx.fillRect(p.x - offset, p.y - offset, tools.brushSize, tools.brushSize);
                    });
                }
            }
        }
    };
    const onPointerUp = (e, endCoords)=>{
        if ((tools.activeTool === 'line' || tools.activeTool === 'curve' || tools.activeTool === 'isometric-line' || tools.activeTool === 'rectangle' || tools.activeTool === 'ellipse') && strokeStart && endCoords) {
            let shapePoints = [];
            if (tools.activeTool === 'line') {
                shapePoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getClippedLine"])(strokeStart.x, strokeStart.y, endCoords.x, endCoords.y, canvasWidth, canvasHeight);
            } else if (tools.activeTool === 'isometric-line') {
                shapePoints = tools.isoAngleSnap ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$curvesAndLines$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getIsometric2p1Line"])(strokeStart.x, strokeStart.y, endCoords.x, endCoords.y) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getClippedLine"])(strokeStart.x, strokeStart.y, endCoords.x, endCoords.y, canvasWidth, canvasHeight);
            } else if (tools.activeTool === 'curve') {
                const controlPoint = {
                    x: Math.round((strokeStart.x + endCoords.x) / 2 + (endCoords.y - strokeStart.y) * tools.curveTightness),
                    y: Math.round((strokeStart.y + endCoords.y) / 2 - (endCoords.x - strokeStart.x) * tools.curveTightness)
                };
                shapePoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2f$math$2f$curvesAndLines$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getQuadraticBezierPoints"])(strokeStart, controlPoint, endCoords);
            } else if (tools.activeTool === 'rectangle') {
                shapePoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getRectanglePoints"])(strokeStart.x, strokeStart.y, endCoords.x, endCoords.y, tools.shapeFilled);
            } else if (tools.activeTool === 'ellipse') {
                shapePoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getEllipsePoints"])(strokeStart.x, strokeStart.y, endCoords.x, endCoords.y, tools.shapeFilled);
            }
            const drawColor = e?.shiftKey ? secondaryColor : primaryColor;
            drawPointsOnActiveLayer(shapePoints, drawColor, false);
        }
    };
    return {
        onPointerDown,
        onPointerMove,
        onPointerUp
    };
}
_s(useShapePointerHandler, "7b3srgCEp9uhZFHsCpNZMvATZsM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useViewportDrawing.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useViewportDrawing",
    ()=>useViewportDrawing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/canvas/rasterMath.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/historyEngine.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/structuralHistory.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/workspaceEnvelopeGuard.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sync/coDrawBridge.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/memoryBudget.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/animation/reviewMetadata.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/paletteSemantics.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
function useViewportDrawing({ canvasWidth, canvasHeight, renderComposite, getOrCreateLayerCanvas, onCommitHistory, retainHistory = false }) {
    _s();
    const isDrawingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const [isDrawing, setIsDrawing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [strokeStart, setStrokeStart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [lastPoint, setLastPoint] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const cursorCoordsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [lockedWarning, setLockedWarning] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const lockedWarningTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [historyEngine] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useViewportDrawing.useState": ()=>retainHistory ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readViewportHistory"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createHistoryEngine"])(50)
    }["useViewportDrawing.useState"]);
    const historyEngineRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(historyEngine);
    const currentStrokeSnapshotRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const rafBufferBumpRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportDrawing.useStudioStore[frames]": (s)=>s.frames
    }["useViewportDrawing.useStudioStore[frames]"]);
    const activeFrameIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportDrawing.useStudioStore[activeFrameIndex]": (s)=>s.activeFrameIndex
    }["useViewportDrawing.useStudioStore[activeFrameIndex]"]);
    const activeLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportDrawing.useStudioStore[activeLayerId]": (s)=>s.activeLayerId
    }["useViewportDrawing.useStudioStore[activeLayerId]"]);
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportDrawing.useStudioStore[tools]": (s)=>s.tools
    }["useViewportDrawing.useStudioStore[tools]"]);
    const primaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportDrawing.useStudioStore[primaryColor]": (s)=>s.primaryColor
    }["useViewportDrawing.useStudioStore[primaryColor]"]);
    const secondaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportDrawing.useStudioStore[secondaryColor]": (s)=>s.secondaryColor
    }["useViewportDrawing.useStudioStore[secondaryColor]"]);
    const setPrimaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportDrawing.useStudioStore[setPrimaryColor]": (s)=>s.setPrimaryColor
    }["useViewportDrawing.useStudioStore[setPrimaryColor]"]);
    const setCanUndo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportDrawing.useStudioStore[setCanUndo]": (s)=>s.setCanUndo
    }["useViewportDrawing.useStudioStore[setCanUndo]"]);
    const setCanRedo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportDrawing.useStudioStore[setCanRedo]": (s)=>s.setCanRedo
    }["useViewportDrawing.useStudioStore[setCanRedo]"]);
    const bumpBufferVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportDrawing.useStudioStore[bumpBufferVersion]": (s)=>s.bumpBufferVersion
    }["useViewportDrawing.useStudioStore[bumpBufferVersion]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useViewportDrawing.useEffect": ()=>{
            const engine = historyEngineRef.current;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setGlobalHistoryEngine"])(engine);
            if (retainHistory) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rememberViewportHistory"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId, engine);
            // Event listener: Clear history when project changes or a new drawing is opened
            const handleHistoryClear = {
                "useViewportDrawing.useEffect.handleHistoryClear": ()=>{
                    if (engine) {
                        engine.clear();
                    }
                    currentStrokeSnapshotRef.current = null;
                    setCanUndo(false);
                    setCanRedo(false);
                }
            }["useViewportDrawing.useEffect.handleHistoryClear"];
            const unsub = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:history-clear', handleHistoryClear);
            return ({
                "useViewportDrawing.useEffect": ()=>{
                    unsub();
                    if (retainHistory) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rememberViewportHistory"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().currentProjectId, engine);
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalHistoryEngine"])() === engine) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setGlobalHistoryEngine"])(null);
                    if (rafBufferBumpRef.current !== null) {
                        cancelAnimationFrame(rafBufferBumpRef.current);
                    }
                }
            })["useViewportDrawing.useEffect"];
        }
    }["useViewportDrawing.useEffect"], [
        retainHistory,
        setCanUndo,
        setCanRedo
    ]);
    // Capture Undo Snapshot
    const captureSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportDrawing.useCallback[captureSnapshot]": (description = 'Stroke', overrideLayerId, createdLayerId, createdLayerTag, preserveLayerEffect = false, createdLayerIndex)=>{
            const targetLayerId = overrideLayerId || activeLayerId;
            const currentLayerCanvas = getOrCreateLayerCanvas(targetLayerId);
            const ctx = currentLayerCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (!ctx) return;
            const imgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
            const targetLayer = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames[activeFrameIndex]?.layers.find({
                "useViewportDrawing.useCallback[captureSnapshot]": (layer)=>layer.id === targetLayerId
            }["useViewportDrawing.useCallback[captureSnapshot]"]);
            currentStrokeSnapshotRef.current = {
                type: 'pixel',
                layerId: targetLayerId,
                frameIndex: activeFrameIndex,
                imageData: imgData,
                description,
                createdLayerId,
                createdLayerTag,
                createdLayerIndex,
                layerName: targetLayer?.name,
                layerTag: targetLayer?.tag,
                layerBlendMode: targetLayer?.blendMode,
                preserveLayerEffect,
                layerEffect: targetLayer?.effect ? structuredClone(targetLayer.effect) : undefined
            };
        }
    }["useViewportDrawing.useCallback[captureSnapshot]"], [
        activeFrameIndex,
        activeLayerId,
        canvasWidth,
        canvasHeight,
        getOrCreateLayerCanvas
    ]);
    // Commit Undo Snapshot to Stack
    const commitSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportDrawing.useCallback[commitSnapshot]": ()=>{
            if (currentStrokeSnapshotRef.current) {
                const snapshot = currentStrokeSnapshotRef.current;
                if (snapshot.type !== 'structural' && !snapshot.preserveLayerEffect && snapshot.layerId) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                        "useViewportDrawing.useCallback[commitSnapshot]": (state)=>{
                            const layer = state.frames[snapshot.frameIndex]?.layers.find({
                                "useViewportDrawing.useCallback[commitSnapshot]": (candidate)=>candidate.id === snapshot.layerId
                            }["useViewportDrawing.useCallback[commitSnapshot]"]);
                            if (layer) layer.effect = undefined;
                        }
                    }["useViewportDrawing.useCallback[commitSnapshot]"]);
                }
                if (snapshot.type !== 'structural' && snapshot.layerId) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(snapshot.layerId);
                }
                historyEngineRef.current.push(snapshot);
                currentStrokeSnapshotRef.current = null;
                setCanUndo(historyEngineRef.current.canUndo);
                setCanRedo(historyEngineRef.current.canRedo);
                onCommitHistory?.();
                // Broadcast committed pixels to co-draw peers (no-op when disconnected).
                // The snapshot holds the PRE-stroke pixels; the bridge diffs them against
                // the live buffer to extract LWW-CRDT ops.
                if (snapshot.type !== 'structural' && snapshot.layerId && snapshot.imageData) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].notifyStrokeCommitted(snapshot.layerId, snapshot.imageData);
                }
            }
        }
    }["useViewportDrawing.useCallback[commitSnapshot]"], [
        onCommitHistory,
        setCanRedo,
        setCanUndo
    ]);
    // Abandon an in-progress preview without touching the committed undo stack.
    // Long-lived interactive tools restore their own preview buffer, then use
    // this to ensure the captured pre-preview pixels cannot be committed later.
    const discardSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportDrawing.useCallback[discardSnapshot]": ()=>{
            currentStrokeSnapshotRef.current = null;
        }
    }["useViewportDrawing.useCallback[discardSnapshot]"], []);
    // Helper to determine which layer buffers must be captured on undo so redo can restore them
    const getRedoCaptureLayerIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportDrawing.useCallback[getRedoCaptureLayerIds]": (step, currentState)=>{
            switch(step.opKind){
                case 'reorder-layers':
                case 'reorder-frames':
                case 'delete-layer':
                case 'delete-frame':
                    return [];
                case 'add-layer':
                case 'duplicate-layer':
                case 'add-frame':
                case 'duplicate-frame':
                    {
                        const prevIds = new Set();
                        for (const f of step.frames){
                            for (const l of f.layers)prevIds.add(l.id);
                        }
                        const newIds = [];
                        for (const f of currentState.frames){
                            for (const l of f.layers){
                                if (!prevIds.has(l.id)) newIds.push(l.id);
                            }
                        }
                        return newIds;
                    }
                case 'merge-layer':
                    return step.affectedLayerIds && step.affectedLayerIds.length > 1 ? [
                        step.affectedLayerIds[1]
                    ] : [
                        currentState.activeLayerId
                    ];
                case 'rotsprite':
                    return step.affectedLayerIds ?? [
                        currentState.activeLayerId
                    ];
                default:
                    return step.affectedLayerIds ?? [];
            }
        }
    }["useViewportDrawing.useCallback[getRedoCaptureLayerIds]"], []);
    // Undo Action (Supports both Pixel and Structural steps)
    const admitHistoryTransition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportDrawing.useCallback[admitHistoryTransition]": (step, inverseIds)=>{
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            const inverseBytes = (step.type === 'structural' ? new Set(inverseIds).size : 1) * state.canvasWidth * state.canvasHeight * 4;
            const metadataBytes = state.frames.reduce({
                "useViewportDrawing.useCallback[admitHistoryTransition]": (sum, frame)=>sum + 256 + frame.layers.length * 256
            }["useViewportDrawing.useCallback[admitHistoryTransition]"], 1024) + state.clips.reduce({
                "useViewportDrawing.useCallback[admitHistoryTransition]": (sum, clip)=>sum + (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$animation$2f$reviewMetadata$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["estimateClipBytes"])(clip)
            }["useViewportDrawing.useCallback[admitHistoryTransition]"], 0) + (step.type === 'structural' && step.palettes ? state.palettes.reduce({
                "useViewportDrawing.useCallback[admitHistoryTransition]": (sum, palette)=>sum + (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$paletteSemantics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["estimatePaletteBytes"])(palette)
            }["useViewportDrawing.useCallback[admitHistoryTransition]"], 0) : 0);
            const stagingBytes = step.type === 'structural' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["estimateRestorationAllocation"])({
                canvasWidth: step.canvasWidth ?? state.canvasWidth,
                canvasHeight: step.canvasHeight ?? state.canvasHeight,
                frames: step.frames,
                activeFrameIndex: step.activeFrameIndex,
                activeLayerId: step.activeLayerId,
                layerBuffers: step.layerBuffers
            }) : state.canvasWidth * state.canvasHeight * 4;
            try {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$memoryBudget$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertMemoryAvailable"])(inverseBytes + metadataBytes + stagingBytes, 'Undo/redo transition');
                return true;
            } catch (error) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'error',
                    message: error.message
                });
                return false;
            }
        }
    }["useViewportDrawing.useCallback[admitHistoryTransition]"], []);
    const performUndo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportDrawing.useCallback[performUndo]": ()=>{
            const previousStep = historyEngineRef.current.peekUndo();
            if (!previousStep) return;
            if (!admitHistoryTransition(previousStep, previousStep.type === 'structural' ? getRedoCaptureLayerIds(previousStep, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState()) : [])) return;
            let currentStep;
            if (previousStep.type === 'structural') {
                const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                const targetWidth = previousStep.canvasWidth ?? state.canvasWidth;
                const targetHeight = previousStep.canvasHeight ?? state.canvasHeight;
                const targetFrames = previousStep.frames;
                // Prevalidate structural target BEFORE mutating history stacks or workspace
                const validity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateWorkspaceStructure"])(targetWidth, targetHeight, targetFrames);
                if (!validity.ok) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                        type: 'error',
                        message: validity.reason || 'Structural undo target workspace exceeds envelope bounds.'
                    });
                    return;
                }
                const redoCaptureIds = getRedoCaptureLayerIds(previousStep, state);
                currentStep = {
                    type: 'structural',
                    opKind: previousStep.opKind,
                    ...previousStep.palettes ? {
                        palettes: structuredClone(state.palettes),
                        currentPaletteId: state.currentPaletteId
                    } : {},
                    description: previousStep.description,
                    frameIndex: state.activeFrameIndex,
                    frames: structuredClone(state.frames),
                    clips: structuredClone(state.clips),
                    activeClipId: state.activeClipId,
                    activeFrameIndex: state.activeFrameIndex,
                    activeLayerId: state.activeLayerId,
                    canvasWidth: state.canvasWidth,
                    canvasHeight: state.canvasHeight,
                    layerBuffers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureLayerBuffers"])(redoCaptureIds),
                    affectedLayerIds: previousStep.affectedLayerIds
                };
            } else {
                const currentLayerCanvas = getOrCreateLayerCanvas(previousStep.layerId);
                const ctx = currentLayerCanvas.getContext('2d', {
                    willReadFrequently: true
                });
                if (!ctx) return;
                const currentImgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
                currentStep = {
                    type: 'pixel',
                    layerId: previousStep.layerId,
                    frameIndex: previousStep.frameIndex,
                    imageData: currentImgData,
                    description: previousStep.description,
                    createdLayerId: previousStep.createdLayerId,
                    createdLayerTag: previousStep.createdLayerTag,
                    createdLayerIndex: previousStep.createdLayerIndex,
                    layerName: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames[previousStep.frameIndex]?.layers.find({
                        "useViewportDrawing.useCallback[performUndo]": (layer)=>layer.id === previousStep.layerId
                    }["useViewportDrawing.useCallback[performUndo]"])?.name,
                    layerTag: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames[previousStep.frameIndex]?.layers.find({
                        "useViewportDrawing.useCallback[performUndo]": (layer)=>layer.id === previousStep.layerId
                    }["useViewportDrawing.useCallback[performUndo]"])?.tag,
                    layerBlendMode: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames[previousStep.frameIndex]?.layers.find({
                        "useViewportDrawing.useCallback[performUndo]": (layer)=>layer.id === previousStep.layerId
                    }["useViewportDrawing.useCallback[performUndo]"])?.blendMode,
                    preserveLayerEffect: previousStep.preserveLayerEffect,
                    layerEffect: ({
                        "useViewportDrawing.useCallback[performUndo]": ()=>{
                            const effect = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames[previousStep.frameIndex]?.layers.find({
                                "useViewportDrawing.useCallback[performUndo]": (layer)=>layer.id === previousStep.layerId
                            }["useViewportDrawing.useCallback[performUndo]"])?.effect;
                            return effect ? structuredClone(effect) : undefined;
                        }
                    })["useViewportDrawing.useCallback[performUndo]"]()
                };
            }
            const stepToRestore = historyEngineRef.current.undo(currentStep);
            if (!stepToRestore) return;
            if (stepToRestore.type === 'structural') {
                const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                const targetWidth = stepToRestore.canvasWidth ?? state.canvasWidth;
                const targetHeight = stepToRestore.canvasHeight ?? state.canvasHeight;
                const targetFrames = stepToRestore.frames;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["restoreStructuralWorkspace"])({
                    canvasWidth: targetWidth,
                    canvasHeight: targetHeight,
                    frames: targetFrames,
                    clips: stepToRestore.clips,
                    palettes: stepToRestore.palettes,
                    currentPaletteId: stepToRestore.currentPaletteId,
                    activeClipId: stepToRestore.activeClipId,
                    activeFrameIndex: stepToRestore.activeFrameIndex,
                    activeLayerId: stepToRestore.activeLayerId,
                    layerBuffers: stepToRestore.layerBuffers
                });
            } else {
                if (previousStep.type !== 'structural' && previousStep.createdLayerId) {
                    const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                    state.deleteLayer(previousStep.createdLayerId, true);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteBuffers"])([
                        previousStep.createdLayerId
                    ]);
                } else if (stepToRestore.imageData && stepToRestore.layerId) {
                    const targetCanvas = getOrCreateLayerCanvas(stepToRestore.layerId);
                    const targetCtx = targetCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    if (targetCtx) {
                        targetCtx.putImageData(stepToRestore.imageData, stepToRestore.x ?? 0, stepToRestore.y ?? 0);
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(stepToRestore.layerId);
                    }
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                        "useViewportDrawing.useCallback[performUndo]": (state)=>{
                            const layer = state.frames[stepToRestore.frameIndex]?.layers.find({
                                "useViewportDrawing.useCallback[performUndo]": (candidate)=>candidate.id === stepToRestore.layerId
                            }["useViewportDrawing.useCallback[performUndo]"]);
                            if (layer) {
                                layer.name = stepToRestore.layerName ?? layer.name;
                                layer.tag = stepToRestore.layerTag;
                                if (stepToRestore.layerBlendMode) layer.blendMode = stepToRestore.layerBlendMode;
                                layer.effect = stepToRestore.layerEffect ? structuredClone(stepToRestore.layerEffect) : undefined;
                            }
                        }
                    }["useViewportDrawing.useCallback[performUndo]"]);
                }
            }
            if (currentStep.type !== 'structural' && currentStep.imageData) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].notifyStrokeCommitted(currentStep.layerId, currentStep.imageData);
            }
            setCanUndo(historyEngineRef.current.canUndo);
            setCanRedo(historyEngineRef.current.canRedo);
            renderComposite();
            bumpBufferVersion();
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setDirty(true);
        }
    }["useViewportDrawing.useCallback[performUndo]"], [
        admitHistoryTransition,
        bumpBufferVersion,
        canvasHeight,
        canvasWidth,
        getOrCreateLayerCanvas,
        getRedoCaptureLayerIds,
        renderComposite,
        setCanRedo,
        setCanUndo
    ]);
    // Redo Action (Supports both Pixel and Structural steps)
    const performRedo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportDrawing.useCallback[performRedo]": ()=>{
            const nextStep = historyEngineRef.current.peekRedo();
            if (!nextStep) return;
            if (!admitHistoryTransition(nextStep, nextStep.type === 'structural' ? nextStep.affectedLayerIds ?? [] : [])) return;
            let currentStep;
            if (nextStep.type === 'structural') {
                const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                const targetWidth = nextStep.canvasWidth ?? state.canvasWidth;
                const targetHeight = nextStep.canvasHeight ?? state.canvasHeight;
                const targetFrames = nextStep.frames;
                // Prevalidate structural target BEFORE mutating history stacks or workspace
                const validity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateWorkspaceStructure"])(targetWidth, targetHeight, targetFrames);
                if (!validity.ok) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                        type: 'error',
                        message: validity.reason || 'Structural redo target workspace exceeds envelope bounds.'
                    });
                    return;
                }
                currentStep = {
                    type: 'structural',
                    opKind: nextStep.opKind,
                    ...nextStep.palettes ? {
                        palettes: structuredClone(state.palettes),
                        currentPaletteId: state.currentPaletteId
                    } : {},
                    description: nextStep.description,
                    frameIndex: state.activeFrameIndex,
                    frames: structuredClone(state.frames),
                    clips: structuredClone(state.clips),
                    activeClipId: state.activeClipId,
                    activeFrameIndex: state.activeFrameIndex,
                    activeLayerId: state.activeLayerId,
                    canvasWidth: state.canvasWidth,
                    canvasHeight: state.canvasHeight,
                    layerBuffers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureLayerBuffers"])(nextStep.affectedLayerIds ?? []),
                    affectedLayerIds: nextStep.affectedLayerIds
                };
            } else {
                const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                // When redoing a pixel-history step that would recreate a missing createdLayerId,
                // prospective-guard adding one layer to nextStep.frameIndex before mutating stacks, buffers, or state
                if (nextStep.createdLayerId) {
                    const targetFrame = state.frames[nextStep.frameIndex];
                    const layerExists = targetFrame?.layers.some({
                        "useViewportDrawing.useCallback[performRedo]": (l)=>l.id === nextStep.createdLayerId
                    }["useViewportDrawing.useCallback[performRedo]"]);
                    if (!layerExists) {
                        const capacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAddLayersToFrame"])(state.frames, nextStep.frameIndex, state.canvasWidth, state.canvasHeight, 1);
                        if (!capacity.ok) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                                type: 'error',
                                message: capacity.reason || 'Redoing layer creation exceeds workspace envelope.'
                            });
                            return;
                        }
                    }
                }
                const currentLayerCanvas = getOrCreateLayerCanvas(nextStep.layerId);
                const ctx = currentLayerCanvas.getContext('2d', {
                    willReadFrequently: true
                });
                if (!ctx) return;
                const currentImgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
                currentStep = {
                    type: 'pixel',
                    layerId: nextStep.layerId,
                    frameIndex: nextStep.frameIndex,
                    imageData: currentImgData,
                    description: nextStep.description,
                    createdLayerId: nextStep.createdLayerId,
                    createdLayerTag: nextStep.createdLayerTag,
                    createdLayerIndex: nextStep.createdLayerIndex,
                    layerName: state.frames[nextStep.frameIndex]?.layers.find({
                        "useViewportDrawing.useCallback[performRedo]": (layer)=>layer.id === nextStep.layerId
                    }["useViewportDrawing.useCallback[performRedo]"])?.name,
                    layerTag: state.frames[nextStep.frameIndex]?.layers.find({
                        "useViewportDrawing.useCallback[performRedo]": (layer)=>layer.id === nextStep.layerId
                    }["useViewportDrawing.useCallback[performRedo]"])?.tag,
                    layerBlendMode: state.frames[nextStep.frameIndex]?.layers.find({
                        "useViewportDrawing.useCallback[performRedo]": (layer)=>layer.id === nextStep.layerId
                    }["useViewportDrawing.useCallback[performRedo]"])?.blendMode,
                    preserveLayerEffect: nextStep.preserveLayerEffect,
                    layerEffect: ({
                        "useViewportDrawing.useCallback[performRedo]": ()=>{
                            const effect = state.frames[nextStep.frameIndex]?.layers.find({
                                "useViewportDrawing.useCallback[performRedo]": (layer)=>layer.id === nextStep.layerId
                            }["useViewportDrawing.useCallback[performRedo]"])?.effect;
                            return effect ? structuredClone(effect) : undefined;
                        }
                    })["useViewportDrawing.useCallback[performRedo]"]()
                };
            }
            const stepToRestore = historyEngineRef.current.redo(currentStep);
            if (!stepToRestore) return;
            if (stepToRestore.type === 'structural') {
                const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
                const targetWidth = stepToRestore.canvasWidth ?? state.canvasWidth;
                const targetHeight = stepToRestore.canvasHeight ?? state.canvasHeight;
                const targetFrames = stepToRestore.frames;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["restoreStructuralWorkspace"])({
                    canvasWidth: targetWidth,
                    canvasHeight: targetHeight,
                    frames: targetFrames,
                    clips: stepToRestore.clips,
                    palettes: stepToRestore.palettes,
                    currentPaletteId: stepToRestore.currentPaletteId,
                    activeClipId: stepToRestore.activeClipId,
                    activeFrameIndex: stepToRestore.activeFrameIndex,
                    activeLayerId: stepToRestore.activeLayerId,
                    layerBuffers: stepToRestore.layerBuffers
                });
            } else {
                if (stepToRestore.createdLayerId) {
                    const currentFrame = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().frames[stepToRestore.frameIndex];
                    const exists = currentFrame?.layers.some({
                        "useViewportDrawing.useCallback[performRedo]": (l)=>l.id === stepToRestore.createdLayerId
                    }["useViewportDrawing.useCallback[performRedo]"]);
                    if (!exists) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                            "useViewportDrawing.useCallback[performRedo]": (state)=>{
                                const frame = state.frames[stepToRestore.frameIndex];
                                if (!frame) return;
                                const recreatedLayer = {
                                    id: stepToRestore.createdLayerId,
                                    name: stepToRestore.layerName ?? stepToRestore.description,
                                    visible: true,
                                    locked: false,
                                    opacity: 1,
                                    blendMode: stepToRestore.layerBlendMode ?? 'source-over',
                                    ...stepToRestore.createdLayerTag ? {
                                        tag: stepToRestore.createdLayerTag
                                    } : {},
                                    ...stepToRestore.layerEffect ? {
                                        effect: structuredClone(stepToRestore.layerEffect)
                                    } : {}
                                };
                                const insertionIndex = Math.max(0, Math.min(stepToRestore.createdLayerIndex ?? 0, frame.layers.length));
                                frame.layers.splice(insertionIndex, 0, recreatedLayer);
                                if (state.activeFrameIndex === stepToRestore.frameIndex) {
                                    state.activeLayerId = stepToRestore.createdLayerId;
                                }
                            }
                        }["useViewportDrawing.useCallback[performRedo]"]);
                    }
                }
                if (stepToRestore.imageData && stepToRestore.layerId) {
                    const targetCanvas = getOrCreateLayerCanvas(stepToRestore.layerId);
                    const targetCtx = targetCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    if (targetCtx) {
                        targetCtx.putImageData(stepToRestore.imageData, stepToRestore.x ?? 0, stepToRestore.y ?? 0);
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(stepToRestore.layerId);
                    }
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                        "useViewportDrawing.useCallback[performRedo]": (state)=>{
                            const layer = state.frames[stepToRestore.frameIndex]?.layers.find({
                                "useViewportDrawing.useCallback[performRedo]": (candidate)=>candidate.id === stepToRestore.layerId
                            }["useViewportDrawing.useCallback[performRedo]"]);
                            if (layer) {
                                layer.name = stepToRestore.layerName ?? layer.name;
                                layer.tag = stepToRestore.layerTag;
                                if (stepToRestore.layerBlendMode) layer.blendMode = stepToRestore.layerBlendMode;
                                layer.effect = stepToRestore.layerEffect ? structuredClone(stepToRestore.layerEffect) : undefined;
                            }
                        }
                    }["useViewportDrawing.useCallback[performRedo]"]);
                }
            }
            if (currentStep.type !== 'structural' && currentStep.imageData) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].notifyStrokeCommitted(currentStep.layerId, currentStep.imageData);
            }
            setCanUndo(historyEngineRef.current.canUndo);
            setCanRedo(historyEngineRef.current.canRedo);
            renderComposite();
            bumpBufferVersion();
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setDirty(true);
        }
    }["useViewportDrawing.useCallback[performRedo]"], [
        admitHistoryTransition,
        bumpBufferVersion,
        canvasHeight,
        canvasWidth,
        getOrCreateLayerCanvas,
        renderComposite,
        setCanRedo,
        setCanUndo
    ]);
    // Draw points on active layer
    const drawPointsOnActiveLayer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportDrawing.useCallback[drawPointsOnActiveLayer]": (points, color, isErase = false)=>{
            const currentFrame = frames[activeFrameIndex];
            const targetLayerId = activeLayerId || currentFrame?.layers[0]?.id;
            if (!targetLayerId || !currentFrame?.layers.some({
                "useViewportDrawing.useCallback[drawPointsOnActiveLayer]": (layer)=>layer.id === targetLayerId && !layer.locked
            }["useViewportDrawing.useCallback[drawPointsOnActiveLayer]"])) return;
            const layerCanvas = getOrCreateLayerCanvas(targetLayerId);
            const ctx = layerCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (!ctx) return;
            ctx.imageSmoothingEnabled = false;
            let allPoints = points;
            if (tools.symmetryHorizontal || tools.symmetryVertical || tools.symmetryGroup && tools.symmetryGroup !== 'none') {
                allPoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$rasterMath$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["applySymmetry"])(points, canvasWidth, canvasHeight, tools.symmetryHorizontal, tools.symmetryVertical, tools.symmetryGroup);
            }
            const offset = Math.floor(tools.brushSize / 2);
            if (isErase) {
                ctx.globalCompositeOperation = 'destination-out';
                allPoints.forEach({
                    "useViewportDrawing.useCallback[drawPointsOnActiveLayer]": (p)=>{
                        ctx.fillRect(p.x - offset, p.y - offset, tools.brushSize, tools.brushSize);
                    }
                }["useViewportDrawing.useCallback[drawPointsOnActiveLayer]"]);
                ctx.globalCompositeOperation = 'source-over';
            } else {
                ctx.fillStyle = color;
                ctx.globalCompositeOperation = 'source-over';
                allPoints.forEach({
                    "useViewportDrawing.useCallback[drawPointsOnActiveLayer]": (p)=>{
                        ctx.fillRect(p.x - offset, p.y - offset, tools.brushSize, tools.brushSize);
                    }
                }["useViewportDrawing.useCallback[drawPointsOnActiveLayer]"]);
            }
            renderComposite();
            // Throttle bumpBufferVersion via requestAnimationFrame
            if (rafBufferBumpRef.current === null) {
                rafBufferBumpRef.current = requestAnimationFrame({
                    "useViewportDrawing.useCallback[drawPointsOnActiveLayer]": ()=>{
                        rafBufferBumpRef.current = null;
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().bumpBufferVersion();
                    }
                }["useViewportDrawing.useCallback[drawPointsOnActiveLayer]"]);
            }
        }
    }["useViewportDrawing.useCallback[drawPointsOnActiveLayer]"], [
        activeFrameIndex,
        activeLayerId,
        canvasHeight,
        canvasWidth,
        frames,
        getOrCreateLayerCanvas,
        renderComposite,
        tools.brushSize,
        tools.symmetryGroup,
        tools.symmetryHorizontal,
        tools.symmetryVertical
    ]);
    return {
        isDrawingRef,
        isDrawing,
        setIsDrawing,
        strokeStart,
        setStrokeStart,
        lastPoint,
        setLastPoint,
        cursorCoordsRef,
        lockedWarning,
        setLockedWarning,
        lockedWarningTimerRef,
        historyEngineRef,
        currentStrokeSnapshotRef,
        rafBufferBumpRef,
        captureSnapshot,
        commitSnapshot,
        discardSnapshot,
        performUndo,
        performRedo,
        drawPointsOnActiveLayer,
        primaryColor,
        secondaryColor,
        setPrimaryColor
    };
}
_s(useViewportDrawing, "I+xiITma00U8QJ9uua3UGWXCRXU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useViewportOverlays.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useViewportOverlays",
    ()=>useViewportOverlays
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/cvdLens.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/stores/onboardingStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$starterTemplates$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/art/starterTemplates.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/art/playgroundLessons.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/render/compositor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$onionSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/render/onionSkin.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
function useViewportOverlays({ gridCanvasRef, onionCanvasRef, stencilCanvasRef, cursorCanvasRef, canvasWidth, canvasHeight, zoom, selection, selectionMask, floatingSelection, cvdLens, squintMode, activeTool, brushSize }) {
    _s();
    const onionGhostCanvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Matrix-only lens: safe for translucent stacked surfaces (preserves alpha)
    const cvdFilterCss = cvdLens !== 'none' ? `url(#${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CVD_FILTER_IDS"][cvdLens]})` : undefined;
    // Main composite surface: squint (white flood + ink) supersedes the CVD matrix
    const mainFilterCss = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$cvdLens$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getViewportFilterCss"])(cvdLens, squintMode);
    // Render onion-skin ghost frames onto the dedicated underlay canvas
    const renderOnionSkin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportOverlays.useCallback[renderOnionSkin]": ()=>{
            const onionCanvas = onionCanvasRef.current;
            if (!onionCanvas) return;
            const ctx = onionCanvas.getContext('2d');
            if (!ctx) return;
            ctx.clearRect(0, 0, canvasWidth, canvasHeight);
            ctx.imageSmoothingEnabled = false;
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            const specs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$onionSkin$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOnionSkinSpecs"])(state.frames.length, state.activeFrameIndex, state.onionSkin, state.isPlaying);
            if (specs.length === 0) return;
            if (!onionGhostCanvasRef.current) {
                onionGhostCanvasRef.current = document.createElement('canvas');
            }
            const scratchCanvas = onionGhostCanvasRef.current;
            if (scratchCanvas.width !== canvasWidth || scratchCanvas.height !== canvasHeight) {
                scratchCanvas.width = canvasWidth;
                scratchCanvas.height = canvasHeight;
            }
            for (const spec of specs){
                const ghostCanvas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compositeFrame"])(state.frames, spec.frameIndex, canvasWidth, canvasHeight, {}, scratchCanvas);
                if (!ghostCanvas) continue;
                if (spec.tint) {
                    const ghostCtx = ghostCanvas.getContext('2d');
                    if (ghostCtx) {
                        ghostCtx.globalCompositeOperation = 'source-atop';
                        ghostCtx.fillStyle = spec.tint;
                        ghostCtx.fillRect(0, 0, canvasWidth, canvasHeight);
                    }
                }
                ctx.globalAlpha = spec.alpha;
                ctx.globalCompositeOperation = 'source-over';
                ctx.drawImage(ghostCanvas, 0, 0);
            }
            ctx.globalAlpha = 1.0;
        }
    }["useViewportOverlays.useCallback[renderOnionSkin]"], [
        canvasHeight,
        canvasWidth,
        onionCanvasRef
    ]);
    // Render on-canvas interactive lightbox tracing stencil (strictly in playground mode)
    const isPlaygroundActive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"])({
        "useViewportOverlays.useOnboardingStore[isPlaygroundActive]": (state)=>state.isPlaygroundActive
    }["useViewportOverlays.useOnboardingStore[isPlaygroundActive]"]);
    const showStencilGuide = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"])({
        "useViewportOverlays.useOnboardingStore[showStencilGuide]": (state)=>state.showStencilGuide
    }["useViewportOverlays.useOnboardingStore[showStencilGuide]"]);
    const stencilOpacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"])({
        "useViewportOverlays.useOnboardingStore[stencilOpacity]": (state)=>state.stencilOpacity
    }["useViewportOverlays.useOnboardingStore[stencilOpacity]"]);
    const currentStepIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"])({
        "useViewportOverlays.useOnboardingStore[currentStepIndex]": (state)=>state.currentStepIndex
    }["useViewportOverlays.useOnboardingStore[currentStepIndex]"]);
    const activeLessonId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"])({
        "useViewportOverlays.useOnboardingStore[activeLessonId]": (state)=>state.activeLessonId
    }["useViewportOverlays.useOnboardingStore[activeLessonId]"]);
    const activeFrameIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportOverlays.useStudioStore[activeFrameIndex]": (state)=>state.activeFrameIndex
    }["useViewportOverlays.useStudioStore[activeFrameIndex]"]);
    const isPlaying = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportOverlays.useStudioStore[isPlaying]": (state)=>state.isPlaying
    }["useViewportOverlays.useStudioStore[isPlaying]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useViewportOverlays.useEffect": ()=>{
            const canvas = stencilCanvasRef.current;
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            if (!ctx) return;
            ctx.clearRect(0, 0, canvasWidth, canvasHeight);
            if (!showStencilGuide || !isPlaygroundActive) return;
            const currentStep = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"].getState().getCurrentStep();
            const currentLesson = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"].getState().getCurrentLesson();
            // Synchronize studio active frame if out of sync (only when paused in drawing steps)
            if (!isPlaying && currentStep.type === 'DRAW_FRAME') {
                if (currentStep.frameIndex !== undefined && activeFrameIndex !== currentStep.frameIndex) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setActiveFrame(currentStep.frameIndex);
                }
            }
            // Determine which template to render:
            // During active playback, render the template corresponding to activeFrameIndex so the animation animates on the canvas!
            // When paused, render current step's template or activeFrame's template.
            const template = isPlaying ? currentLesson.frames[activeFrameIndex] || currentStep.template : currentStep.template || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"].getState().getCurrentFrameTemplate() || (currentStep.frameIndex !== undefined ? currentLesson.frames[currentStep.frameIndex] : null);
            if (!template) return;
            ctx.imageSmoothingEnabled = false;
            ctx.globalAlpha = stencilOpacity;
            const rows = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTemplateRows"])(template);
            const gridSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$playgroundLessons$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTemplateGridSize"])(template);
            const cellW = canvasWidth / gridSize;
            const cellH = canvasHeight / gridSize;
            rows.forEach({
                "useViewportOverlays.useEffect": (row, y)=>{
                    for(let x = 0; x < row.length; x++){
                        const char = row[x];
                        if (char === '.') continue;
                        const color = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$art$2f$starterTemplates$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TEMPLATE_PALETTE"][char];
                        if (color) {
                            ctx.fillStyle = color;
                            ctx.fillRect(x * cellW, y * cellH, cellW, cellH);
                        }
                    }
                }
            }["useViewportOverlays.useEffect"]);
            ctx.globalAlpha = 1.0;
        }
    }["useViewportOverlays.useEffect"], [
        showStencilGuide,
        isPlaygroundActive,
        stencilOpacity,
        currentStepIndex,
        activeLessonId,
        activeFrameIndex,
        isPlaying,
        canvasWidth,
        canvasHeight,
        stencilCanvasRef
    ]);
    // Render the selection mask tint on a logical-size canvas.
    const renderGridAndSelection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportOverlays.useCallback[renderGridAndSelection]": ()=>{
            const gridCanvas = gridCanvasRef.current;
            if (!gridCanvas) return;
            // Keep the backing store in artwork pixels. CSS stretches this layer with
            // the stage; zoom must never multiply a canvas allocation.
            const scale = 1;
            const width = canvasWidth;
            const height = canvasHeight;
            if (gridCanvas.width !== width) gridCanvas.width = width;
            if (gridCanvas.height !== height) gridCanvas.height = height;
            const ctx = gridCanvas.getContext('2d');
            if (!ctx) return;
            ctx.clearRect(0, 0, width, height);
            // Pixel-grid hairlines are a CSS pattern on the overlay element, so they
            // stay one screen pixel wide even when the logical canvas is enlarged.
            // 4. Selection Bounding Box & Marching Ants
            const activeBox = floatingSelection ? {
                x: floatingSelection.x,
                y: floatingSelection.y,
                w: floatingSelection.w,
                h: floatingSelection.h
            } : selection;
            if (activeBox && !floatingSelection) {
                // Render irregular mask tint
                if (selectionMask) {
                    ctx.fillStyle = 'rgba(100, 150, 255, 0.3)';
                    for(let py = activeBox.y; py < activeBox.y + activeBox.h; py++){
                        for(let px = activeBox.x; px < activeBox.x + activeBox.w; px++){
                            if (py >= 0 && py < canvasHeight && px >= 0 && px < canvasWidth) {
                                if (selectionMask[py * canvasWidth + px] === 1) {
                                    ctx.fillRect(px * scale, py * scale, scale, scale);
                                }
                            }
                        }
                    }
                }
            // The selection gizmo draws its own screen-space marching-ants border.
            // Keeping only the mask tint here avoids a zoom-thick duplicate outline.
            }
        }
    }["useViewportOverlays.useCallback[renderGridAndSelection]"], [
        canvasHeight,
        canvasWidth,
        floatingSelection,
        gridCanvasRef,
        selection,
        selectionMask
    ]);
    // Brush footprint outline per DESIGN.md Section 8
    const renderBrushGhost = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportOverlays.useCallback[renderBrushGhost]": (coords)=>{
            const ghost = cursorCanvasRef.current;
            if (!ghost) return;
            const isBrushTool = activeTool === 'pen' || activeTool === 'eraser' || activeTool === 'dither' || activeTool === 'line' || activeTool === 'curve' || activeTool === 'rectangle' || activeTool === 'ellipse';
            if (!coords || zoom < 400 || !isBrushTool) {
                ghost.style.display = 'none';
                return;
            }
            const scale = zoom / 100;
            const offset = Math.floor(brushSize / 2);
            const bx = coords.x - offset;
            const by = coords.y - offset;
            ghost.style.display = 'block';
            ghost.style.left = `${Math.round(bx * scale)}px`;
            ghost.style.top = `${Math.round(by * scale)}px`;
            ghost.style.width = `${Math.round(brushSize * scale)}px`;
            ghost.style.height = `${Math.round(brushSize * scale)}px`;
        }
    }["useViewportOverlays.useCallback[renderBrushGhost]"], [
        activeTool,
        brushSize,
        cursorCanvasRef,
        zoom
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useViewportOverlays.useEffect": ()=>{
            renderGridAndSelection();
        }
    }["useViewportOverlays.useEffect"], [
        renderGridAndSelection
    ]);
    return {
        onionGhostCanvasRef,
        cvdFilterCss,
        mainFilterCss,
        renderOnionSkin,
        renderGridAndSelection,
        renderBrushGhost
    };
}
_s(useViewportOverlays, "4w4YAket1h7jBEugo6hsU12lIJA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$onboardingStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboardingStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useViewportPointerEvents.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useViewportPointerEvents",
    ()=>useViewportPointerEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sync/coDrawBridge.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$CursorStatusBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/CursorStatusBadge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/floodFill.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$eraseMatchingColor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/eraseMatchingColor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/bufferRegistry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/structuralHistory.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/historyEngine.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/render/compositor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useBrushPointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useBrushPointerHandler.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useSelectionPointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useSelectionPointerHandler.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useShapePointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useShapePointerHandler.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useChiselPointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/useChiselPointerHandler.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function useViewportPointerEvents(props) {
    _s();
    const tools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportPointerEvents.useStudioStore[tools]": (s)=>s.tools
    }["useViewportPointerEvents.useStudioStore[tools]"]);
    const primaryColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportPointerEvents.useStudioStore[primaryColor]": (s)=>s.primaryColor
    }["useViewportPointerEvents.useStudioStore[primaryColor]"]);
    const frames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportPointerEvents.useStudioStore[frames]": (s)=>s.frames
    }["useViewportPointerEvents.useStudioStore[frames]"]);
    const activeFrameIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportPointerEvents.useStudioStore[activeFrameIndex]": (s)=>s.activeFrameIndex
    }["useViewportPointerEvents.useStudioStore[activeFrameIndex]"]);
    const activeLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportPointerEvents.useStudioStore[activeLayerId]": (s)=>s.activeLayerId
    }["useViewportPointerEvents.useStudioStore[activeLayerId]"]);
    const bumpBufferVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportPointerEvents.useStudioStore[bumpBufferVersion]": (s)=>s.bumpBufferVersion
    }["useViewportPointerEvents.useStudioStore[bumpBufferVersion]"]);
    const chiselSessionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const capturedPointerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const brushHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useBrushPointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBrushPointerHandler"])({
        drawPointsOnActiveLayer: props.drawPointsOnActiveLayer,
        lastPoint: props.lastPoint,
        setLastPoint: props.setLastPoint
    });
    const selectionHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useSelectionPointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionPointerHandler"])({
        canvasWidth: props.canvasWidth,
        canvasHeight: props.canvasHeight,
        floatingSelection: props.floatingSelection,
        setFloatingSelection: props.setFloatingSelection,
        isDraggingSelection: props.isDraggingSelection,
        setIsDraggingSelection: props.setIsDraggingSelection,
        dragOffset: props.dragOffset,
        setDragOffset: props.setDragOffset,
        lassoPoints: props.lassoPoints,
        setLassoPoints: props.setLassoPoints,
        selectionModifierRef: props.selectionModifierRef,
        baseSelectionMaskRef: props.baseSelectionMaskRef,
        liftSelectionToFloating: props.liftSelectionToFloating,
        commitFloatingSelection: props.commitFloatingSelection,
        createBoxMask: props.createBoxMask,
        mergeSelectionMask: props.mergeSelectionMask,
        isDrawingRef: props.isDrawingRef,
        setIsDrawing: props.setIsDrawing,
        strokeStart: props.strokeStart,
        setStrokeStart: props.setStrokeStart,
        lastPoint: props.lastPoint,
        setLastPoint: props.setLastPoint,
        getOrCreateLayerCanvas: props.getOrCreateLayerCanvas,
        previewCanvasRef: props.previewCanvasRef,
        renderComposite: props.renderComposite
    });
    const shapeHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useShapePointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShapePointerHandler"])({
        canvasWidth: props.canvasWidth,
        canvasHeight: props.canvasHeight,
        strokeStart: props.strokeStart,
        previewCanvasRef: props.previewCanvasRef,
        drawPointsOnActiveLayer: props.drawPointsOnActiveLayer
    });
    const chiselHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useChiselPointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChiselPointerHandler"])({
        canvasWidth: props.canvasWidth,
        canvasHeight: props.canvasHeight,
        chiselSessionRef,
        currentStrokeSnapshotRef: props.currentStrokeSnapshotRef,
        lastPoint: props.lastPoint,
        setLastPoint: props.setLastPoint,
        getOrCreateLayerCanvas: props.getOrCreateLayerCanvas,
        renderComposite: props.renderComposite
    });
    const handlePointerDown = (e)=>{
        // Suppress drawing tools while live photometric lighting bulb is active
        const { photometricGizmoActive } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
        if (photometricGizmoActive) {
            return;
        }
        // Selection tools own Alt for subtraction; middle-click always pans.
        if (e.button === 1 || e.button === 0 && e.altKey && !tools.activeTool.startsWith('select-')) {
            props.setIsPanning(true);
            props.setPanStart({
                x: e.clientX - props.panX,
                y: e.clientY - props.panY
            });
            return;
        }
        if (e.button !== 0) return;
        const coords = props.clientToCanvasCoords(e.clientX, e.clientY);
        if (!coords) return;
        if (selectionHandler.onPointerDown(e, coords)) {
            return;
        }
        const currentFrame = frames[activeFrameIndex];
        const currentLayer = currentFrame?.layers.find((l)=>l.id === activeLayerId);
        if (!currentLayer && tools.activeTool !== 'eyedropper') return;
        // Prevent edits to locked layers for every pixel-changing tool.
        if (currentLayer?.locked && tools.activeTool !== 'eyedropper') {
            props.setLockedWarning(true);
            if (props.lockedWarningTimerRef.current !== null) {
                window.clearTimeout(props.lockedWarningTimerRef.current);
            }
            props.lockedWarningTimerRef.current = window.setTimeout(()=>{
                props.setLockedWarning(false);
            }, 1600);
            return;
        }
        if (tools.activeTool === 'erase-color') {
            if (!currentLayer) return;
            if (props.floatingSelection) props.commitFloatingSelection();
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            const sourceCanvas = props.getOrCreateLayerCanvas(activeLayerId);
            const sourceCtx = sourceCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (!sourceCtx) return;
            const sourcePixel = sourceCtx.getImageData(coords.x, coords.y, 1, 1).data;
            if (sourcePixel[3] === 0) return;
            const sampled = [
                sourcePixel[0],
                sourcePixel[1],
                sourcePixel[2]
            ];
            let selectionMask = state.selectionMask;
            if (!selectionMask && state.selection) {
                selectionMask = new Uint8Array(props.canvasWidth * props.canvasHeight);
                const box = state.selection;
                for(let y = Math.max(0, box.y); y < Math.min(props.canvasHeight, box.y + box.h); y++){
                    for(let x = Math.max(0, box.x); x < Math.min(props.canvasWidth, box.x + box.w); x++){
                        selectionMask[y * props.canvasWidth + x] = 1;
                    }
                }
            }
            if (selectionMask && !selectionMask[coords.y * props.canvasWidth + coords.x]) return;
            const allFrames = state.tools.eraseColorAllFrames;
            const layerIndex = currentFrame.layers.findIndex((layer)=>layer.id === activeLayerId);
            const targets = allFrames ? state.frames.map((frame)=>frame.layers[layerIndex] || frame.layers.find((layer)=>layer.name === currentLayer.name)).filter((layer)=>Boolean(layer && !layer.locked)) : [
                currentLayer
            ];
            if (allFrames && targets.length * props.canvasWidth * props.canvasHeight * 4 > __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$historyEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_HISTORY_MAX_BYTES"] / 2) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'error',
                    message: 'Too many frame pixels for one undoable color erase. Use This frame.'
                });
                return;
            }
            const edits = [];
            for (const layer of targets){
                const ctx = props.getOrCreateLayerCanvas(layer.id).getContext('2d', {
                    willReadFrequently: true
                });
                if (!ctx) continue;
                const image = ctx.getImageData(0, 0, props.canvasWidth, props.canvasHeight);
                const changed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$eraseMatchingColor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eraseMatchingColor"])(image, sampled, state.tools.eraseColorTolerance, {
                    contiguous: !allFrames && state.tools.eraseColorContiguous,
                    family: state.tools.eraseColorFamily,
                    x: coords.x,
                    y: coords.y,
                    mask: selectionMask
                });
                if (changed > 0) edits.push({
                    id: layer.id,
                    ctx,
                    image
                });
            }
            if (edits.length === 0) return;
            if (allFrames) {
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$structuralHistory$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushStructuralHistoryStep"])('Erase Color (All Frames)', {
                    affectedLayerIds: edits.map((edit)=>edit.id)
                })) return;
            } else {
                props.captureSnapshot('Erase Color');
            }
            for (const edit of edits){
                const before = allFrames ? edit.ctx.getImageData(0, 0, props.canvasWidth, props.canvasHeight) : null;
                edit.ctx.putImageData(edit.image, 0, 0);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$bufferRegistry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchBuffer"])(edit.id);
                if (before) __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].notifyStrokeCommitted(edit.id, before);
            }
            if (allFrames) {
                const affected = new Set(edits.map((edit)=>edit.id));
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState((draft)=>{
                    for (const frame of draft.frames){
                        for (const layer of frame.layers){
                            if (affected.has(layer.id)) layer.effect = undefined;
                        }
                    }
                    draft.isDirty = true;
                    draft.editRevision += 1;
                });
                const lockedCount = state.frames.filter((frame)=>{
                    const l = frame.layers[layerIndex] || frame.layers.find((layer)=>layer.name === currentLayer.name);
                    return l?.locked;
                }).length;
                if (lockedCount > 0) __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                    type: 'default',
                    message: `Skipped ${lockedCount} locked frame layer${lockedCount === 1 ? '' : 's'}.`
                });
            } else {
                props.commitSnapshot();
            }
            props.renderComposite();
            bumpBufferVersion();
            return;
        }
        // Color Replace Tool
        if (tools.activeTool === 'color-replace') {
            if (!currentLayer) return;
            if (props.floatingSelection) props.commitFloatingSelection();
            const targetCanvas = props.getOrCreateLayerCanvas(activeLayerId);
            const ctx = targetCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (ctx) {
                const imgData = ctx.getImageData(0, 0, props.canvasWidth, props.canvasHeight);
                const changed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceLayerColor"])(imgData, coords.x, coords.y, primaryColor, tools.bucketTolerance);
                if (changed > 0) {
                    props.captureSnapshot('Color Replace');
                    ctx.putImageData(imgData, 0, 0);
                    props.commitSnapshot();
                    props.renderComposite();
                    bumpBufferVersion();
                }
            }
            return;
        }
        // Commit floating selection before starting standard drawing tools
        if (props.floatingSelection) {
            props.commitFloatingSelection();
        }
        // Prevent drawing on locked layers
        props.captureSnapshot(`Tool: ${tools.activeTool}`);
        try {
            const el = e.currentTarget;
            el.setPointerCapture(e.pointerId);
            capturedPointerRef.current = {
                target: el,
                pointerId: e.pointerId
            };
        } catch  {
        // fallback
        }
        props.isDrawingRef.current = true;
        props.setIsDrawing(true);
        props.setStrokeStart(coords);
        props.setLastPoint(coords);
        switch(tools.activeTool){
            case 'pen':
            case 'eraser':
            case 'dither':
                {
                    brushHandler.onPointerDown(e, coords);
                    break;
                }
            case 'line':
            case 'curve':
            case 'isometric-line':
            case 'rectangle':
            case 'ellipse':
                {
                    shapeHandler.onPointerDown(e, coords);
                    break;
                }
            case 'normal-chisel':
                {
                    chiselHandler.onPointerDown(e, coords);
                    break;
                }
            case 'eyedropper':
                {
                    const comp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$render$2f$compositor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compositeFrame"])(frames, activeFrameIndex, props.canvasWidth, props.canvasHeight);
                    if (comp) {
                        const ctx = comp.getContext('2d', {
                            willReadFrequently: true
                        });
                        if (ctx) {
                            const pixel = ctx.getImageData(coords.x, coords.y, 1, 1).data;
                            if (pixel[3] > 0) {
                                const hex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbaToHex"])(pixel[0], pixel[1], pixel[2], pixel[3]);
                                props.setPrimaryColor(hex);
                            }
                        }
                    }
                    props.isDrawingRef.current = false;
                    props.setIsDrawing(false);
                    // Eyedropper never changes pixels: drop stale snapshot
                    props.currentStrokeSnapshotRef.current = null;
                    break;
                }
            case 'bucket':
                {
                    const targetLayerId = activeLayerId || currentFrame?.layers[0]?.id;
                    if (targetLayerId) {
                        const layerCanvas = props.getOrCreateLayerCanvas(targetLayerId);
                        const ctx = layerCanvas.getContext('2d', {
                            willReadFrequently: true
                        });
                        if (ctx) {
                            const drawColor = e.shiftKey ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().secondaryColor : primaryColor;
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$floodFill$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["performFloodFill"])(ctx, coords.x, coords.y, drawColor, tools.bucketContiguous, tools.fillTolerance, tools.fillEnclosedSpecks);
                            props.renderComposite();
                            props.commitSnapshot();
                            bumpBufferVersion();
                        }
                    }
                    props.isDrawingRef.current = false;
                    props.setIsDrawing(false);
                    break;
                }
            default:
                break;
        }
    };
    const handlePointerMove = (e)=>{
        if (props.isPanning) {
            props.setPan(e.clientX - props.panStart.x, e.clientY - props.panStart.y);
            return;
        }
        const coords = props.clientToCanvasCoords(e.clientX, e.clientY, props.isDrawing);
        if (coords) {
            props.cursorCoordsRef.current = coords;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$CursorStatusBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateCursorHUD"])(coords);
            props.renderBrushGhost(coords);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sync$2f$coDrawBridge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coDrawBridge"].broadcastCursor(coords.x, coords.y);
        } else {
            props.cursorCoordsRef.current = null;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$CursorStatusBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateCursorHUD"])(null);
            props.renderBrushGhost(null);
        }
        if (selectionHandler.onPointerMove(e, coords || {
            x: 0,
            y: 0
        })) {
            return;
        }
        if (!props.isDrawing || !coords) return;
        if (tools.activeTool === 'pen' || tools.activeTool === 'eraser' || tools.activeTool === 'dither') {
            brushHandler.onPointerMove(e, coords);
        } else if (tools.activeTool === 'normal-chisel') {
            chiselHandler.onPointerMove(e, coords);
        } else if ((tools.activeTool === 'line' || tools.activeTool === 'curve' || tools.activeTool === 'isometric-line' || tools.activeTool === 'rectangle' || tools.activeTool === 'ellipse') && props.strokeStart) {
            shapeHandler.onPointerMove(e, coords);
        }
    };
    const handlePointerUp = (e)=>{
        if (e) {
            try {
                e.currentTarget.releasePointerCapture(e.pointerId);
            } catch  {
            // fallback
            }
        }
        if (capturedPointerRef.current) {
            try {
                capturedPointerRef.current.target.releasePointerCapture(capturedPointerRef.current.pointerId);
            } catch  {
            // fallback
            }
            capturedPointerRef.current = null;
        }
        if (props.isPanning) {
            props.setIsPanning(false);
        }
        if (props.isDraggingSelection) {
            props.setIsDraggingSelection(false);
            return;
        }
        const isDrawingActive = props.isDrawing || props.isDrawingRef.current;
        if (isDrawingActive) {
            props.isDrawingRef.current = false;
            props.setIsDrawing(false);
            let endCoords = props.cursorCoordsRef.current;
            if (e) {
                const upCoords = props.clientToCanvasCoords(e.clientX, e.clientY, true);
                if (upCoords) endCoords = upCoords;
            }
            if (!endCoords && props.strokeStart) endCoords = props.strokeStart;
            if (selectionHandler.onPointerUp(e, endCoords)) {
            // Selection handled its own commit
            } else {
                brushHandler.onPointerUp(e, endCoords);
                shapeHandler.onPointerUp(e, endCoords);
                chiselHandler.onPointerUp(e, endCoords);
                if (tools.activeTool !== 'select-box' && tools.activeTool !== 'select-lasso' && tools.activeTool !== 'select-wand') {
                    props.commitSnapshot();
                    bumpBufferVersion();
                }
            }
            const previewCanvas = props.previewCanvasRef.current;
            if (previewCanvas) {
                const pCtx = previewCanvas.getContext('2d');
                pCtx?.clearRect(0, 0, props.canvasWidth, props.canvasHeight);
            }
        }
        const previewCanvas = props.previewCanvasRef.current;
        if (previewCanvas) {
            const pCtx = previewCanvas.getContext('2d');
            pCtx?.clearRect(0, 0, props.canvasWidth, props.canvasHeight);
        }
        props.setStrokeStart(null);
        props.setLastPoint(null);
        chiselSessionRef.current = null;
    };
    const handlePointerCancel = (e)=>{
        if (e && 'pointerId' in e && 'currentTarget' in e && e.currentTarget) {
            try {
                e.currentTarget.releasePointerCapture(e.pointerId);
            } catch  {
            // fallback
            }
        }
        if (capturedPointerRef.current) {
            try {
                capturedPointerRef.current.target.releasePointerCapture(capturedPointerRef.current.pointerId);
            } catch  {
            // fallback
            }
            capturedPointerRef.current = null;
        }
        if (props.isPanning) {
            props.setIsPanning(false);
        }
        if (props.isDraggingSelection) {
            props.setIsDraggingSelection(false);
        }
        const isDrawingActive = props.isDrawing || props.isDrawingRef.current;
        if (isDrawingActive) {
            props.isDrawingRef.current = false;
            props.setIsDrawing(false);
            const isShapeTool = tools.activeTool === 'line' || tools.activeTool === 'curve' || tools.activeTool === 'isometric-line' || tools.activeTool === 'rectangle' || tools.activeTool === 'ellipse';
            if (isShapeTool) {
                if (props.discardSnapshot) {
                    props.discardSnapshot();
                } else {
                    props.currentStrokeSnapshotRef.current = null;
                }
            } else if (tools.activeTool === 'select-box' || tools.activeTool === 'select-lasso' || tools.activeTool === 'select-wand') {
                props.setLassoPoints([]);
            } else {
                props.commitSnapshot();
                bumpBufferVersion();
            }
            const previewCanvas = props.previewCanvasRef.current;
            if (previewCanvas) {
                const pCtx = previewCanvas.getContext('2d');
                pCtx?.clearRect(0, 0, props.canvasWidth, props.canvasHeight);
            }
        }
        props.setStrokeStart(null);
        props.setLastPoint(null);
        props.cursorCoordsRef.current = null;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$CursorStatusBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateCursorHUD"])(null);
        props.renderBrushGhost(null);
        chiselSessionRef.current = null;
        props.renderComposite();
    };
    return {
        handlePointerDown,
        handlePointerMove,
        handlePointerUp,
        handlePointerCancel
    };
}
_s(useViewportPointerEvents, "GtDldTWZRfPk8Kk8tYmJ17l9H+Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useBrushPointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBrushPointerHandler"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useSelectionPointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectionPointerHandler"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useShapePointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShapePointerHandler"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$useChiselPointerHandler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChiselPointerHandler"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useViewportSelection.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useViewportSelection",
    ()=>useViewportSelection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$selectionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/selectionUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeCanvas$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/safeCanvas.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
function useViewportSelection({ canvasWidth, canvasHeight, activeLayerId, previewCanvasRef, getOrCreateLayerCanvas, renderComposite, captureSnapshot, commitSnapshot }) {
    _s();
    const selection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportSelection.useStudioStore[selection]": (s)=>s.selection
    }["useViewportSelection.useStudioStore[selection]"]);
    const selectionMask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportSelection.useStudioStore[selectionMask]": (s)=>s.selectionMask
    }["useViewportSelection.useStudioStore[selectionMask]"]);
    const setSelection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportSelection.useStudioStore[setSelection]": (s)=>s.setSelection
    }["useViewportSelection.useStudioStore[setSelection]"]);
    const bumpBufferVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportSelection.useStudioStore[bumpBufferVersion]": (s)=>s.bumpBufferVersion
    }["useViewportSelection.useStudioStore[bumpBufferVersion]"]);
    const [floatingSelection, setFloatingSelection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const clipboardRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isDraggingSelection, setIsDraggingSelection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [dragOffset, setDragOffset] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    });
    const [lassoPoints, setLassoPoints] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const selectionModifierRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])('replace');
    const baseSelectionMaskRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const clearPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelection.useCallback[clearPreview]": ()=>{
            const canvas = previewCanvasRef.current;
            canvas?.getContext('2d')?.clearRect(0, 0, canvasWidth, canvasHeight);
        }
    }["useViewportSelection.useCallback[clearPreview]"], [
        canvasHeight,
        canvasWidth,
        previewCanvasRef
    ]);
    const clearSelectedPixels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelection.useCallback[clearSelectedPixels]": ()=>{
            if (!selection || selection.w <= 0 || selection.h <= 0) return;
            const ctx = getOrCreateLayerCanvas(activeLayerId).getContext('2d', {
                willReadFrequently: true
            });
            if (!ctx) return;
            if (!selectionMask) {
                ctx.clearRect(selection.x, selection.y, selection.w, selection.h);
                return;
            }
            for(let y = 0; y < selection.h; y++){
                const rowOffset = (selection.y + y) * canvasWidth + selection.x;
                let x = 0;
                while(x < selection.w){
                    if (selectionMask[rowOffset + x] !== 1) {
                        x++;
                        continue;
                    }
                    const start = x;
                    while(x < selection.w && selectionMask[rowOffset + x] === 1)x++;
                    ctx.clearRect(selection.x + start, selection.y + y, x - start, 1);
                }
            }
        }
    }["useViewportSelection.useCallback[clearSelectedPixels]"], [
        activeLayerId,
        canvasWidth,
        getOrCreateLayerCanvas,
        selection,
        selectionMask
    ]);
    // Lift selected pixels from active layer into floating selection
    const liftSelectionToFloating = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelection.useCallback[liftSelectionToFloating]": ()=>{
            if (!selection) return;
            captureSnapshot('Lift Selection');
            const layerCanvas = getOrCreateLayerCanvas(activeLayerId);
            const ctx = layerCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (!ctx) return;
            const floatCanvas = document.createElement('canvas');
            floatCanvas.width = selection.w;
            floatCanvas.height = selection.h;
            const fCtx = floatCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (!fCtx) return;
            if (selectionMask) {
                const srcData = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeCanvas$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeCanvas"].getImageData(ctx, selection.x, selection.y, selection.w, selection.h);
                const floatData = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeCanvas$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeCanvas"].createImageData(fCtx, selection.w, selection.h);
                for(let dy = 0; dy < selection.h; dy++){
                    for(let dx = 0; dx < selection.w; dx++){
                        const globalX = selection.x + dx;
                        const globalY = selection.y + dy;
                        const maskIdx = globalY * canvasWidth + globalX;
                        const pixelIdx = (dy * selection.w + dx) * 4;
                        if (selectionMask[maskIdx] === 1) {
                            floatData.data[pixelIdx] = srcData.data[pixelIdx];
                            floatData.data[pixelIdx + 1] = srcData.data[pixelIdx + 1];
                            floatData.data[pixelIdx + 2] = srcData.data[pixelIdx + 2];
                            floatData.data[pixelIdx + 3] = srcData.data[pixelIdx + 3];
                            // Clear from source layer
                            srcData.data[pixelIdx + 3] = 0;
                        }
                    }
                }
                fCtx.putImageData(floatData, 0, 0);
                ctx.putImageData(srcData, selection.x, selection.y);
            } else {
                fCtx.drawImage(layerCanvas, selection.x, selection.y, selection.w, selection.h, 0, 0, selection.w, selection.h);
                ctx.clearRect(selection.x, selection.y, selection.w, selection.h);
            }
            setFloatingSelection({
                canvas: floatCanvas,
                x: selection.x,
                y: selection.y,
                w: selection.w,
                h: selection.h
            });
            renderComposite();
            bumpBufferVersion();
        }
    }["useViewportSelection.useCallback[liftSelectionToFloating]"], [
        activeLayerId,
        bumpBufferVersion,
        canvasWidth,
        captureSnapshot,
        getOrCreateLayerCanvas,
        renderComposite,
        selection,
        selectionMask
    ]);
    // Commit floating selection buffer back to active layer
    const commitFloatingSelection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelection.useCallback[commitFloatingSelection]": ()=>{
            if (!floatingSelection) return;
            captureSnapshot('Commit Selection');
            const layerCanvas = getOrCreateLayerCanvas(activeLayerId);
            const ctx = layerCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (ctx) {
                ctx.imageSmoothingEnabled = false;
                ctx.drawImage(floatingSelection.canvas, floatingSelection.x, floatingSelection.y);
            }
            setFloatingSelection(null);
            setSelection(null);
            commitSnapshot();
            renderComposite();
            bumpBufferVersion();
        }
    }["useViewportSelection.useCallback[commitFloatingSelection]"], [
        activeLayerId,
        bumpBufferVersion,
        captureSnapshot,
        commitSnapshot,
        floatingSelection,
        getOrCreateLayerCanvas,
        renderComposite,
        setSelection
    ]);
    const handleCopy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelection.useCallback[handleCopy]": ()=>{
            if (floatingSelection) {
                const copyCanvas = document.createElement('canvas');
                copyCanvas.width = floatingSelection.w;
                copyCanvas.height = floatingSelection.h;
                const cCtx = copyCanvas.getContext('2d');
                cCtx?.drawImage(floatingSelection.canvas, 0, 0);
                clipboardRef.current = {
                    canvas: copyCanvas,
                    w: floatingSelection.w,
                    h: floatingSelection.h
                };
            } else if (selection) {
                const layerCanvas = getOrCreateLayerCanvas(activeLayerId);
                const copyCanvas = document.createElement('canvas');
                copyCanvas.width = selection.w;
                copyCanvas.height = selection.h;
                const cCtx = copyCanvas.getContext('2d', {
                    willReadFrequently: true
                });
                if (!cCtx) return;
                if (selectionMask) {
                    const ctx = layerCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    if (!ctx) return;
                    const srcData = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeCanvas$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeCanvas"].getImageData(ctx, selection.x, selection.y, selection.w, selection.h);
                    const floatData = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$safeCanvas$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeCanvas"].createImageData(cCtx, selection.w, selection.h);
                    for(let dy = 0; dy < selection.h; dy++){
                        for(let dx = 0; dx < selection.w; dx++){
                            const globalX = selection.x + dx;
                            const globalY = selection.y + dy;
                            const maskIdx = globalY * canvasWidth + globalX;
                            const pixelIdx = (dy * selection.w + dx) * 4;
                            if (selectionMask[maskIdx] === 1) {
                                floatData.data[pixelIdx] = srcData.data[pixelIdx];
                                floatData.data[pixelIdx + 1] = srcData.data[pixelIdx + 1];
                                floatData.data[pixelIdx + 2] = srcData.data[pixelIdx + 2];
                                floatData.data[pixelIdx + 3] = srcData.data[pixelIdx + 3];
                            }
                        }
                    }
                    cCtx.putImageData(floatData, 0, 0);
                } else {
                    cCtx.drawImage(layerCanvas, selection.x, selection.y, selection.w, selection.h, 0, 0, selection.w, selection.h);
                }
                clipboardRef.current = {
                    canvas: copyCanvas,
                    w: selection.w,
                    h: selection.h
                };
            }
        }
    }["useViewportSelection.useCallback[handleCopy]"], [
        activeLayerId,
        canvasWidth,
        floatingSelection,
        getOrCreateLayerCanvas,
        selection,
        selectionMask
    ]);
    const handleCut = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelection.useCallback[handleCut]": ()=>{
            handleCopy();
            clearPreview();
            if (floatingSelection) {
                setFloatingSelection(null);
                setSelection(null);
                commitSnapshot();
                renderComposite();
                bumpBufferVersion();
            } else if (selection) {
                captureSnapshot('Cut Selection');
                clearSelectedPixels();
                setSelection(null);
                commitSnapshot();
                renderComposite();
                bumpBufferVersion();
            }
        }
    }["useViewportSelection.useCallback[handleCut]"], [
        bumpBufferVersion,
        captureSnapshot,
        clearPreview,
        clearSelectedPixels,
        commitSnapshot,
        floatingSelection,
        handleCopy,
        renderComposite,
        selection,
        setSelection
    ]);
    const handlePaste = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelection.useCallback[handlePaste]": ()=>{
            if (!clipboardRef.current) return;
            if (floatingSelection) {
                commitFloatingSelection();
            }
            const { canvas, w, h } = clipboardRef.current;
            const pasteCanvas = document.createElement('canvas');
            pasteCanvas.width = w;
            pasteCanvas.height = h;
            const pCtx = pasteCanvas.getContext('2d');
            pCtx?.drawImage(canvas, 0, 0);
            const px = Math.max(0, Math.floor((canvasWidth - w) / 2));
            const py = Math.max(0, Math.floor((canvasHeight - h) / 2));
            setFloatingSelection({
                canvas: pasteCanvas,
                x: px,
                y: py,
                w,
                h
            });
            setSelection({
                x: px,
                y: py,
                w,
                h
            });
            renderComposite();
        }
    }["useViewportSelection.useCallback[handlePaste]"], [
        canvasHeight,
        canvasWidth,
        commitFloatingSelection,
        floatingSelection,
        renderComposite,
        setSelection
    ]);
    const handleDeleteSelection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelection.useCallback[handleDeleteSelection]": ()=>{
            clearPreview();
            if (floatingSelection) {
                setFloatingSelection(null);
                setSelection(null);
                commitSnapshot();
                renderComposite();
                bumpBufferVersion();
            } else if (selection) {
                captureSnapshot('Delete Selection');
                clearSelectedPixels();
                setSelection(null);
                commitSnapshot();
                renderComposite();
                bumpBufferVersion();
            }
        }
    }["useViewportSelection.useCallback[handleDeleteSelection]"], [
        bumpBufferVersion,
        captureSnapshot,
        clearPreview,
        clearSelectedPixels,
        commitSnapshot,
        floatingSelection,
        renderComposite,
        selection,
        setSelection
    ]);
    const handleFlipHorizontal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelection.useCallback[handleFlipHorizontal]": ()=>{
            const active = floatingSelection;
            if (!active) {
                liftSelectionToFloating();
                return;
            }
            const flippedCanvas = document.createElement('canvas');
            flippedCanvas.width = active.w;
            flippedCanvas.height = active.h;
            const fCtx = flippedCanvas.getContext('2d');
            if (!fCtx) return;
            fCtx.imageSmoothingEnabled = false;
            fCtx.translate(active.w, 0);
            fCtx.scale(-1, 1);
            fCtx.drawImage(active.canvas, 0, 0);
            setFloatingSelection({
                ...active,
                canvas: flippedCanvas
            });
            renderComposite();
        }
    }["useViewportSelection.useCallback[handleFlipHorizontal]"], [
        floatingSelection,
        liftSelectionToFloating,
        renderComposite
    ]);
    const handleFlipVertical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelection.useCallback[handleFlipVertical]": ()=>{
            const active = floatingSelection;
            if (!active) {
                liftSelectionToFloating();
                return;
            }
            const flippedCanvas = document.createElement('canvas');
            flippedCanvas.width = active.w;
            flippedCanvas.height = active.h;
            const fCtx = flippedCanvas.getContext('2d');
            if (!fCtx) return;
            fCtx.imageSmoothingEnabled = false;
            fCtx.translate(0, active.h);
            fCtx.scale(1, -1);
            fCtx.drawImage(active.canvas, 0, 0);
            setFloatingSelection({
                ...active,
                canvas: flippedCanvas
            });
            renderComposite();
        }
    }["useViewportSelection.useCallback[handleFlipVertical]"], [
        floatingSelection,
        liftSelectionToFloating,
        renderComposite
    ]);
    // Global Keyboard Shortcuts for Selection
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useViewportSelection.useEffect": ()=>{
            const handleKeyDown = {
                "useViewportSelection.useEffect.handleKeyDown": (e)=>{
                    if ([
                        'INPUT',
                        'TEXTAREA',
                        'SELECT'
                    ].includes(e.target?.tagName)) {
                        return;
                    }
                    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') {
                        e.preventDefault();
                        handleCopy();
                    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'x') {
                        e.preventDefault();
                        handleCut();
                    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v') {
                        e.preventDefault();
                        handlePaste();
                    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') {
                        e.preventDefault();
                        commitFloatingSelection();
                        setSelection(null);
                    } else if (e.key === 'Escape') {
                        commitFloatingSelection();
                        setSelection(null);
                        clearPreview();
                    } else if (e.key === 'Delete' || e.key === 'Backspace') {
                        if (selection || floatingSelection) {
                            e.preventDefault();
                            handleDeleteSelection();
                        } else {
                            clearPreview();
                        }
                    } else if (e.key.toLowerCase() === 'h' && (selection || floatingSelection)) {
                        e.preventDefault();
                        handleFlipHorizontal();
                    } else if (e.key.toLowerCase() === 'v' && (selection || floatingSelection) && !e.ctrlKey) {
                        e.preventDefault();
                        handleFlipVertical();
                    } else if (e.key === 'ArrowUp' || e.key === 'ArrowDown' || e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
                        if (floatingSelection) {
                            e.preventDefault();
                            const step = e.shiftKey ? 5 : 1;
                            const dx = e.key === 'ArrowLeft' ? -step : e.key === 'ArrowRight' ? step : 0;
                            const dy = e.key === 'ArrowUp' ? -step : e.key === 'ArrowDown' ? step : 0;
                            setFloatingSelection({
                                ...floatingSelection,
                                x: floatingSelection.x + dx,
                                y: floatingSelection.y + dy
                            });
                        }
                    }
                }
            }["useViewportSelection.useEffect.handleKeyDown"];
            window.addEventListener('keydown', handleKeyDown);
            return ({
                "useViewportSelection.useEffect": ()=>window.removeEventListener('keydown', handleKeyDown)
            })["useViewportSelection.useEffect"];
        }
    }["useViewportSelection.useEffect"], [
        commitFloatingSelection,
        clearPreview,
        floatingSelection,
        handleCopy,
        handleCut,
        handleDeleteSelection,
        handleFlipHorizontal,
        handleFlipVertical,
        handlePaste,
        selection,
        setSelection
    ]);
    return {
        floatingSelection,
        setFloatingSelection,
        isDraggingSelection,
        setIsDraggingSelection,
        dragOffset,
        setDragOffset,
        lassoPoints,
        setLassoPoints,
        selectionModifierRef,
        baseSelectionMaskRef,
        liftSelectionToFloating,
        commitFloatingSelection,
        handleCopy,
        handleCut,
        handlePaste,
        handleDeleteSelection,
        handleFlipHorizontal,
        handleFlipVertical,
        createBoxMask: (box)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$selectionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBoxMask"])(box, canvasWidth, canvasHeight),
        mergeSelectionMask: (base, incoming, mode)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$selectionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeSelectionMask"])(base, incoming, mode, canvasWidth, canvasHeight)
    };
}
_s(useViewportSelection, "q+mzyM5+pokaWYMYCQ5H6W7tnQs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useViewportSelectionTransform.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useViewportSelectionTransform",
    ()=>useViewportSelectionTransform
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$workerDispatcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/workerDispatcher.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function useViewportSelectionTransform({ canvasWidth, canvasHeight: _canvasHeight, activeLayerId, selection, selectionMask, floatingSelection, setFloatingSelection, setSelection, getOrCreateLayerCanvas, renderComposite, captureSnapshot, commitSnapshot, bumpBufferVersion, liftSelectionToFloating, commitFloatingSelection: _commitFloatingSelection }) {
    _s();
    // Source backup for cancel or crisp high-quality commit
    const originalSourceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Active transform state
    const [transform, setTransform] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0,
        w: 0,
        h: 0,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        pivot: {
            x: 0,
            y: 0
        },
        isTransforming: false,
        activeHandle: null
    });
    const dragStartRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastActiveBoxRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Sync transform state when a new selection box is created
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useViewportSelectionTransform.useEffect": ()=>{
            if (transform.isTransforming) return;
            const box = floatingSelection ? {
                x: floatingSelection.x,
                y: floatingSelection.y,
                w: floatingSelection.w,
                h: floatingSelection.h
            } : selection;
            if (!box) {
                lastActiveBoxRef.current = null;
                return;
            }
            const boxKey = `${box.x},${box.y},${box.w},${box.h}`;
            if (lastActiveBoxRef.current !== boxKey && !floatingSelection) {
                lastActiveBoxRef.current = boxKey;
                setTransform({
                    "useViewportSelectionTransform.useEffect": (prev)=>({
                            ...prev,
                            x: box.x,
                            y: box.y,
                            w: box.w,
                            h: box.h,
                            pivot: {
                                x: box.x + box.w / 2,
                                y: box.y + box.h / 2
                            },
                            rotation: 0,
                            scaleX: 1,
                            scaleY: 1
                        })
                }["useViewportSelectionTransform.useEffect"]);
            }
        }
    }["useViewportSelectionTransform.useEffect"], [
        floatingSelection,
        selection,
        transform.isTransforming
    ]);
    const ensureFloatingSelection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelectionTransform.useCallback[ensureFloatingSelection]": ()=>{
            if (floatingSelection) return floatingSelection;
            if (!selection) return null;
            const layerCanvas = getOrCreateLayerCanvas(activeLayerId);
            const backup = document.createElement('canvas');
            backup.width = selection.w;
            backup.height = selection.h;
            const bCtx = backup.getContext('2d');
            if (bCtx) {
                bCtx.drawImage(layerCanvas, selection.x, selection.y, selection.w, selection.h, 0, 0, selection.w, selection.h);
                if (selectionMask) {
                    const pixels = bCtx.getImageData(0, 0, selection.w, selection.h);
                    for(let y = 0; y < selection.h; y++){
                        for(let x = 0; x < selection.w; x++){
                            if (selectionMask[(selection.y + y) * canvasWidth + selection.x + x] !== 1) {
                                const offset = (y * selection.w + x) * 4;
                                pixels.data[offset] = 0;
                                pixels.data[offset + 1] = 0;
                                pixels.data[offset + 2] = 0;
                                pixels.data[offset + 3] = 0;
                            }
                        }
                    }
                    bCtx.putImageData(pixels, 0, 0);
                }
            }
            originalSourceRef.current = {
                canvas: backup,
                x: selection.x,
                y: selection.y,
                w: selection.w,
                h: selection.h,
                mask: selectionMask ? new Uint8Array(selectionMask) : null,
                layerId: activeLayerId
            };
            liftSelectionToFloating();
            const floatCanvas = document.createElement('canvas');
            floatCanvas.width = selection.w;
            floatCanvas.height = selection.h;
            const fCtx = floatCanvas.getContext('2d');
            if (fCtx) {
                fCtx.drawImage(backup, 0, 0);
            }
            return {
                canvas: floatCanvas,
                x: selection.x,
                y: selection.y,
                w: selection.w,
                h: selection.h
            };
        }
    }["useViewportSelectionTransform.useCallback[ensureFloatingSelection]"], [
        activeLayerId,
        canvasWidth,
        floatingSelection,
        getOrCreateLayerCanvas,
        liftSelectionToFloating,
        selection,
        selectionMask
    ]);
    // Start a transform interaction with a specific handle
    const handlePointerDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelectionTransform.useCallback[handlePointerDown]": (handle, clientPoint, canvasPoint)=>{
            // If not yet floating, lift active selection to floating buffer now
            if (!floatingSelection && selection) {
                ensureFloatingSelection();
            } else if (floatingSelection && !originalSourceRef.current) {
                const backup = document.createElement('canvas');
                backup.width = floatingSelection.w;
                backup.height = floatingSelection.h;
                const bCtx = backup.getContext('2d');
                if (bCtx) {
                    bCtx.drawImage(floatingSelection.canvas, 0, 0);
                }
                originalSourceRef.current = {
                    canvas: backup,
                    x: floatingSelection.x,
                    y: floatingSelection.y,
                    w: floatingSelection.w,
                    h: floatingSelection.h,
                    mask: null,
                    layerId: activeLayerId
                };
            }
            const currentBox = floatingSelection || selection;
            if (!currentBox) return;
            const pivot = transform.pivot.x !== 0 || transform.pivot.y !== 0 ? transform.pivot : {
                x: currentBox.x + currentBox.w / 2,
                y: currentBox.y + currentBox.h / 2
            };
            const initialAngle = Math.atan2(canvasPoint.y - pivot.y, canvasPoint.x - pivot.x);
            const aspectRatio = currentBox.w / Math.max(1, currentBox.h);
            const nextTransform = {
                ...transform,
                x: currentBox.x,
                y: currentBox.y,
                w: currentBox.w,
                h: currentBox.h,
                pivot,
                isTransforming: true,
                activeHandle: handle
            };
            setTransform(nextTransform);
            dragStartRef.current = {
                clientPoint,
                canvasPoint,
                transform: nextTransform,
                initialAngle,
                aspectRatio
            };
        }
    }["useViewportSelectionTransform.useCallback[handlePointerDown]"], [
        activeLayerId,
        ensureFloatingSelection,
        floatingSelection,
        selection,
        transform
    ]);
    // Update transform during pointer move
    const handlePointerMove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelectionTransform.useCallback[handlePointerMove]": (canvasPoint, modifiers)=>{
            if (!dragStartRef.current || !transform.isTransforming || !transform.activeHandle) {
                return;
            }
            const { canvasPoint: startPt, transform: startState, initialAngle, aspectRatio } = dragStartRef.current;
            const handle = transform.activeHandle;
            if (handle === 'pivot') {
                setTransform({
                    "useViewportSelectionTransform.useCallback[handlePointerMove]": (prev)=>({
                            ...prev,
                            pivot: {
                                x: canvasPoint.x,
                                y: canvasPoint.y
                            }
                        })
                }["useViewportSelectionTransform.useCallback[handlePointerMove]"]);
                return;
            }
            if (handle === 'rotate') {
                const currAngle = Math.atan2(canvasPoint.y - startState.pivot.y, canvasPoint.x - startState.pivot.x);
                const delta = currAngle - initialAngle;
                let newRot = startState.rotation + delta;
                // Shift snaps to 15-degree increments (PI / 12)
                if (modifiers.shiftKey) {
                    const step = Math.PI / 12;
                    newRot = Math.round(newRot / step) * step;
                }
                setTransform({
                    "useViewportSelectionTransform.useCallback[handlePointerMove]": (prev)=>({
                            ...prev,
                            rotation: newRot
                        })
                }["useViewportSelectionTransform.useCallback[handlePointerMove]"]);
                renderComposite();
                return;
            }
            if (handle === 'translate') {
                let dx = canvasPoint.x - startPt.x;
                let dy = canvasPoint.y - startPt.y;
                // Shift locks axis to horizontal or vertical
                if (modifiers.shiftKey) {
                    if (Math.abs(dx) > Math.abs(dy)) {
                        dy = 0;
                    } else {
                        dx = 0;
                    }
                }
                const newX = Math.round(startState.x + dx);
                const newY = Math.round(startState.y + dy);
                setTransform({
                    "useViewportSelectionTransform.useCallback[handlePointerMove]": (prev)=>({
                            ...prev,
                            x: newX,
                            y: newY,
                            pivot: {
                                x: startState.pivot.x + dx,
                                y: startState.pivot.y + dy
                            }
                        })
                }["useViewportSelectionTransform.useCallback[handlePointerMove]"]);
                setFloatingSelection({
                    "useViewportSelectionTransform.useCallback[handlePointerMove]": (prev)=>{
                        if (!prev) return null;
                        return {
                            ...prev,
                            x: newX,
                            y: newY
                        };
                    }
                }["useViewportSelectionTransform.useCallback[handlePointerMove]"]);
                renderComposite();
                return;
            }
            // Handle Scaling (Corners and Edges)
            // Transform pointer into local space relative to pivot and rotation
            const rad = -startState.rotation;
            const cos = Math.cos(rad);
            const sin = Math.sin(rad);
            const dxWorld = canvasPoint.x - startPt.x;
            const dyWorld = canvasPoint.y - startPt.y;
            const dxLocal = cos * dxWorld - sin * dyWorld;
            const dyLocal = sin * dxWorld + cos * dyWorld;
            let newW = startState.w;
            let newH = startState.h;
            let newX = startState.x;
            let newY = startState.y;
            const symmetric = modifiers.altKey;
            switch(handle){
                case 'br':
                    {
                        const deltaW = symmetric ? dxLocal * 2 : dxLocal;
                        const deltaH = symmetric ? dyLocal * 2 : dyLocal;
                        newW = Math.max(1, startState.w + deltaW);
                        newH = Math.max(1, startState.h + deltaH);
                        if (modifiers.shiftKey) {
                            const scale = Math.max(newW / startState.w, newH / startState.h);
                            newW = Math.max(1, Math.round(startState.w * scale));
                            newH = Math.max(1, Math.round(newW / aspectRatio));
                        }
                        if (symmetric) {
                            newX = startState.pivot.x - newW / 2;
                            newY = startState.pivot.y - newH / 2;
                        }
                        break;
                    }
                case 'tl':
                    {
                        const deltaW = symmetric ? -dxLocal * 2 : -dxLocal;
                        const deltaH = symmetric ? -dyLocal * 2 : -dyLocal;
                        newW = Math.max(1, startState.w + deltaW);
                        newH = Math.max(1, startState.h + deltaH);
                        if (modifiers.shiftKey) {
                            const scale = Math.max(newW / startState.w, newH / startState.h);
                            newW = Math.max(1, Math.round(startState.w * scale));
                            newH = Math.max(1, Math.round(newW / aspectRatio));
                        }
                        if (symmetric) {
                            newX = startState.pivot.x - newW / 2;
                            newY = startState.pivot.y - newH / 2;
                        } else {
                            newX = startState.x + (startState.w - newW);
                            newY = startState.y + (startState.h - newH);
                        }
                        break;
                    }
                case 'tr':
                    {
                        const deltaW = symmetric ? dxLocal * 2 : dxLocal;
                        const deltaH = symmetric ? -dyLocal * 2 : -dyLocal;
                        newW = Math.max(1, startState.w + deltaW);
                        newH = Math.max(1, startState.h + deltaH);
                        if (modifiers.shiftKey) {
                            const scale = Math.max(newW / startState.w, newH / startState.h);
                            newW = Math.max(1, Math.round(startState.w * scale));
                            newH = Math.max(1, Math.round(newW / aspectRatio));
                        }
                        if (symmetric) {
                            newX = startState.pivot.x - newW / 2;
                            newY = startState.pivot.y - newH / 2;
                        } else {
                            newY = startState.y + (startState.h - newH);
                        }
                        break;
                    }
                case 'bl':
                    {
                        const deltaW = symmetric ? -dxLocal * 2 : -dxLocal;
                        const deltaH = symmetric ? dyLocal * 2 : dyLocal;
                        newW = Math.max(1, startState.w + deltaW);
                        newH = Math.max(1, startState.h + deltaH);
                        if (modifiers.shiftKey) {
                            const scale = Math.max(newW / startState.w, newH / startState.h);
                            newW = Math.max(1, Math.round(startState.w * scale));
                            newH = Math.max(1, Math.round(newW / aspectRatio));
                        }
                        if (symmetric) {
                            newX = startState.pivot.x - newW / 2;
                            newY = startState.pivot.y - newH / 2;
                        } else {
                            newX = startState.x + (startState.w - newW);
                        }
                        break;
                    }
                case 'mr':
                    {
                        const deltaW = symmetric ? dxLocal * 2 : dxLocal;
                        newW = Math.max(1, startState.w + deltaW);
                        if (symmetric) {
                            newX = startState.pivot.x - newW / 2;
                        }
                        break;
                    }
                case 'ml':
                    {
                        const deltaW = symmetric ? -dxLocal * 2 : -dxLocal;
                        newW = Math.max(1, startState.w + deltaW);
                        if (symmetric) {
                            newX = startState.pivot.x - newW / 2;
                        } else {
                            newX = startState.x + (startState.w - newW);
                        }
                        break;
                    }
                case 'tc':
                    {
                        const deltaH = symmetric ? -dyLocal * 2 : -dyLocal;
                        newH = Math.max(1, startState.h + deltaH);
                        if (symmetric) {
                            newY = startState.pivot.y - newH / 2;
                        } else {
                            newY = startState.y + (startState.h - newH);
                        }
                        break;
                    }
                case 'bc':
                    {
                        const deltaH = symmetric ? dyLocal * 2 : dyLocal;
                        newH = Math.max(1, startState.h + deltaH);
                        if (symmetric) {
                            newY = startState.pivot.y - newH / 2;
                        }
                        break;
                    }
            }
            setTransform({
                "useViewportSelectionTransform.useCallback[handlePointerMove]": (prev)=>({
                        ...prev,
                        x: Math.round(newX),
                        y: Math.round(newY),
                        w: Math.round(newW),
                        h: Math.round(newH)
                    })
            }["useViewportSelectionTransform.useCallback[handlePointerMove]"]);
            // Render 60 FPS fast nearest-neighbor preview onto floating canvas
            if (originalSourceRef.current) {
                const source = originalSourceRef.current.canvas;
                const previewCanvas = document.createElement('canvas');
                previewCanvas.width = Math.max(1, Math.round(newW));
                previewCanvas.height = Math.max(1, Math.round(newH));
                const pCtx = previewCanvas.getContext('2d');
                if (pCtx) {
                    pCtx.imageSmoothingEnabled = false;
                    pCtx.drawImage(source, 0, 0, previewCanvas.width, previewCanvas.height);
                    setFloatingSelection({
                        canvas: previewCanvas,
                        x: Math.round(newX),
                        y: Math.round(newY),
                        w: previewCanvas.width,
                        h: previewCanvas.height
                    });
                    renderComposite();
                }
            }
        }
    }["useViewportSelectionTransform.useCallback[handlePointerMove]"], [
        renderComposite,
        setFloatingSelection,
        transform.activeHandle,
        transform.isTransforming
    ]);
    // End pointer drag
    const handlePointerUp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelectionTransform.useCallback[handlePointerUp]": ()=>{
            if (transform.isTransforming) {
                dragStartRef.current = null;
                setTransform({
                    "useViewportSelectionTransform.useCallback[handlePointerUp]": (prev)=>({
                            ...prev,
                            activeHandle: null
                        })
                }["useViewportSelectionTransform.useCallback[handlePointerUp]"]);
            }
        }
    }["useViewportSelectionTransform.useCallback[handlePointerUp]"], [
        transform.isTransforming
    ]);
    // Commit transform: RotSprite 8x if rotated, bake back to active layer with undo
    const commitTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelectionTransform.useCallback[commitTransform]": async ()=>{
            if (!originalSourceRef.current) {
                captureSnapshot('Commit Free Transform');
            }
            const source = floatingSelection?.canvas || originalSourceRef.current?.canvas;
            if (!source) {
                setTransform({
                    "useViewportSelectionTransform.useCallback[commitTransform]": (prev)=>({
                            ...prev,
                            isTransforming: false,
                            activeHandle: null
                        })
                }["useViewportSelectionTransform.useCallback[commitTransform]"]);
                return;
            }
            const curW = transform.w;
            const curH = transform.h;
            const curX = transform.x;
            const curY = transform.y;
            const rotation = transform.rotation;
            let finalCanvas = source;
            // If scaled or stretched, perform nearest neighbor resample first
            if (source.width !== curW || source.height !== curH) {
                const scaledCanvas = document.createElement('canvas');
                scaledCanvas.width = curW;
                scaledCanvas.height = curH;
                const sCtx = scaledCanvas.getContext('2d');
                if (sCtx) {
                    sCtx.imageSmoothingEnabled = false;
                    sCtx.drawImage(source, 0, 0, curW, curH);
                    finalCanvas = scaledCanvas;
                }
            }
            let destX = curX;
            let destY = curY;
            // If rotated, run RotSprite algorithm with unclipped bounding box and user pivot
            if (Math.abs(rotation) > 1e-4) {
                const fCtx = finalCanvas.getContext('2d', {
                    willReadFrequently: true
                });
                if (fCtx) {
                    const imgData = fCtx.getImageData(0, 0, curW, curH);
                    const localPivotX = transform.pivot.x - curX;
                    const localPivotY = transform.pivot.y - curY;
                    const cos = Math.cos(rotation);
                    const sin = Math.sin(rotation);
                    const corners = [
                        {
                            x: 0,
                            y: 0
                        },
                        {
                            x: curW,
                            y: 0
                        },
                        {
                            x: curW,
                            y: curH
                        },
                        {
                            x: 0,
                            y: curH
                        }
                    ].map({
                        "useViewportSelectionTransform.useCallback[commitTransform].corners": (pt)=>{
                            const dx = pt.x - localPivotX;
                            const dy = pt.y - localPivotY;
                            return {
                                x: localPivotX + cos * dx - sin * dy,
                                y: localPivotY + sin * dx + cos * dy
                            };
                        }
                    }["useViewportSelectionTransform.useCallback[commitTransform].corners"]);
                    const minX = Math.floor(Math.min(...corners.map({
                        "useViewportSelectionTransform.useCallback[commitTransform].minX": (c)=>c.x
                    }["useViewportSelectionTransform.useCallback[commitTransform].minX"])));
                    const maxX = Math.ceil(Math.max(...corners.map({
                        "useViewportSelectionTransform.useCallback[commitTransform].maxX": (c)=>c.x
                    }["useViewportSelectionTransform.useCallback[commitTransform].maxX"])));
                    const minY = Math.floor(Math.min(...corners.map({
                        "useViewportSelectionTransform.useCallback[commitTransform].minY": (c)=>c.y
                    }["useViewportSelectionTransform.useCallback[commitTransform].minY"])));
                    const maxY = Math.ceil(Math.max(...corners.map({
                        "useViewportSelectionTransform.useCallback[commitTransform].maxY": (c)=>c.y
                    }["useViewportSelectionTransform.useCallback[commitTransform].maxY"])));
                    const targetW = Math.max(1, maxX - minX);
                    const targetH = Math.max(1, maxY - minY);
                    destX = Math.round(curX + minX);
                    destY = Math.round(curY + minY);
                    const outPivotX = localPivotX - minX;
                    const outPivotY = localPivotY - minY;
                    const rotResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$workerDispatcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runRotSpriteInWorker"])({
                        width: curW,
                        height: curH,
                        data: imgData.data
                    }, rotation, localPivotX, localPivotY, targetW, targetH, outPivotX, outPivotY);
                    const rotatedCanvas = document.createElement('canvas');
                    rotatedCanvas.width = rotResult.width;
                    rotatedCanvas.height = rotResult.height;
                    const rCtx = rotatedCanvas.getContext('2d');
                    if (rCtx) {
                        const outImg = rCtx.createImageData(rotResult.width, rotResult.height);
                        outImg.data.set(rotResult.data);
                        rCtx.putImageData(outImg, 0, 0);
                        finalCanvas = rotatedCanvas;
                    }
                }
            }
            // Bake into active layer
            const layerCanvas = getOrCreateLayerCanvas(activeLayerId);
            const layerCtx = layerCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (layerCtx) {
                layerCtx.imageSmoothingEnabled = false;
                layerCtx.drawImage(finalCanvas, destX, destY);
            }
            // Reset states
            originalSourceRef.current = null;
            lastActiveBoxRef.current = null;
            setFloatingSelection(null);
            setSelection(null);
            setTransform({
                x: 0,
                y: 0,
                w: 0,
                h: 0,
                rotation: 0,
                scaleX: 1,
                scaleY: 1,
                pivot: {
                    x: 0,
                    y: 0
                },
                isTransforming: false,
                activeHandle: null
            });
            commitSnapshot();
            renderComposite();
            bumpBufferVersion();
        }
    }["useViewportSelectionTransform.useCallback[commitTransform]"], [
        activeLayerId,
        bumpBufferVersion,
        captureSnapshot,
        commitSnapshot,
        floatingSelection,
        getOrCreateLayerCanvas,
        renderComposite,
        setFloatingSelection,
        setSelection,
        transform
    ]);
    // Cancel transform: restore original pixels and clear floating selection
    const cancelTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelectionTransform.useCallback[cancelTransform]": ()=>{
            if (originalSourceRef.current) {
                const { canvas, x, y, layerId } = originalSourceRef.current;
                const targetLayer = getOrCreateLayerCanvas(layerId);
                const ctx = targetLayer.getContext('2d');
                if (ctx) {
                    ctx.imageSmoothingEnabled = false;
                    ctx.drawImage(canvas, x, y);
                }
                originalSourceRef.current = null;
            }
            lastActiveBoxRef.current = null;
            setFloatingSelection(null);
            setSelection(null);
            setTransform({
                x: 0,
                y: 0,
                w: 0,
                h: 0,
                rotation: 0,
                scaleX: 1,
                scaleY: 1,
                pivot: {
                    x: 0,
                    y: 0
                },
                isTransforming: false,
                activeHandle: null
            });
            renderComposite();
            bumpBufferVersion();
        }
    }["useViewportSelectionTransform.useCallback[cancelTransform]"], [
        bumpBufferVersion,
        getOrCreateLayerCanvas,
        renderComposite,
        setFloatingSelection,
        setSelection
    ]);
    // Quick Action: Flip Horizontal
    const handleFlipH = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelectionTransform.useCallback[handleFlipH]": ()=>{
            const current = ensureFloatingSelection();
            if (!current) return;
            setTransform({
                "useViewportSelectionTransform.useCallback[handleFlipH]": (prev)=>({
                        ...prev,
                        scaleX: prev.scaleX * -1
                    })
            }["useViewportSelectionTransform.useCallback[handleFlipH]"]);
            const flipped = document.createElement('canvas');
            flipped.width = current.w;
            flipped.height = current.h;
            const fCtx = flipped.getContext('2d');
            if (fCtx) {
                fCtx.imageSmoothingEnabled = false;
                fCtx.translate(current.w, 0);
                fCtx.scale(-1, 1);
                fCtx.drawImage(current.canvas, 0, 0);
            }
            setFloatingSelection({
                "useViewportSelectionTransform.useCallback[handleFlipH]": (prev)=>{
                    const base = prev || current;
                    return {
                        ...base,
                        canvas: flipped
                    };
                }
            }["useViewportSelectionTransform.useCallback[handleFlipH]"]);
            renderComposite();
        }
    }["useViewportSelectionTransform.useCallback[handleFlipH]"], [
        ensureFloatingSelection,
        renderComposite,
        setFloatingSelection
    ]);
    // Quick Action: Flip Vertical
    const handleFlipV = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelectionTransform.useCallback[handleFlipV]": ()=>{
            const current = ensureFloatingSelection();
            if (!current) return;
            setTransform({
                "useViewportSelectionTransform.useCallback[handleFlipV]": (prev)=>({
                        ...prev,
                        scaleY: prev.scaleY * -1
                    })
            }["useViewportSelectionTransform.useCallback[handleFlipV]"]);
            const flipped = document.createElement('canvas');
            flipped.width = current.w;
            flipped.height = current.h;
            const fCtx = flipped.getContext('2d');
            if (fCtx) {
                fCtx.imageSmoothingEnabled = false;
                fCtx.translate(0, current.h);
                fCtx.scale(1, -1);
                fCtx.drawImage(current.canvas, 0, 0);
            }
            setFloatingSelection({
                "useViewportSelectionTransform.useCallback[handleFlipV]": (prev)=>{
                    const base = prev || current;
                    return {
                        ...base,
                        canvas: flipped
                    };
                }
            }["useViewportSelectionTransform.useCallback[handleFlipV]"]);
            renderComposite();
        }
    }["useViewportSelectionTransform.useCallback[handleFlipV]"], [
        ensureFloatingSelection,
        renderComposite,
        setFloatingSelection
    ]);
    // Quick Action: Rotate 90° CW
    const handleRotate90CW = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelectionTransform.useCallback[handleRotate90CW]": ()=>{
            ensureFloatingSelection();
            setTransform({
                "useViewportSelectionTransform.useCallback[handleRotate90CW]": (prev)=>({
                        ...prev,
                        rotation: prev.rotation + Math.PI / 2
                    })
            }["useViewportSelectionTransform.useCallback[handleRotate90CW]"]);
            renderComposite();
        }
    }["useViewportSelectionTransform.useCallback[handleRotate90CW]"], [
        ensureFloatingSelection,
        renderComposite
    ]);
    // Quick Action: Rotate 90° CCW
    const handleRotate90CCW = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportSelectionTransform.useCallback[handleRotate90CCW]": ()=>{
            ensureFloatingSelection();
            setTransform({
                "useViewportSelectionTransform.useCallback[handleRotate90CCW]": (prev)=>({
                        ...prev,
                        rotation: prev.rotation - Math.PI / 2
                    })
            }["useViewportSelectionTransform.useCallback[handleRotate90CCW]"]);
            renderComposite();
        }
    }["useViewportSelectionTransform.useCallback[handleRotate90CCW]"], [
        ensureFloatingSelection,
        renderComposite
    ]);
    // Global Keyboard shortcuts: Enter to commit, Escape to cancel, arrows to nudge
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useViewportSelectionTransform.useEffect": ()=>{
            const handleKeyDown = {
                "useViewportSelectionTransform.useEffect.handleKeyDown": (e)=>{
                    if ([
                        'INPUT',
                        'TEXTAREA',
                        'SELECT'
                    ].includes(e.target?.tagName)) {
                        return;
                    }
                    const active = floatingSelection || selection;
                    if (!active) return;
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        void commitTransform();
                    } else if (e.key === 'Escape') {
                        e.preventDefault();
                        cancelTransform();
                    } else if ([
                        'ArrowUp',
                        'ArrowDown',
                        'ArrowLeft',
                        'ArrowRight'
                    ].includes(e.key)) {
                        e.preventDefault();
                        const step = e.shiftKey ? 10 : 1;
                        const dx = e.key === 'ArrowLeft' ? -step : e.key === 'ArrowRight' ? step : 0;
                        const dy = e.key === 'ArrowUp' ? -step : e.key === 'ArrowDown' ? step : 0;
                        setTransform({
                            "useViewportSelectionTransform.useEffect.handleKeyDown": (prev)=>({
                                    ...prev,
                                    x: prev.x + dx,
                                    y: prev.y + dy,
                                    pivot: {
                                        x: prev.pivot.x + dx,
                                        y: prev.pivot.y + dy
                                    }
                                })
                        }["useViewportSelectionTransform.useEffect.handleKeyDown"]);
                        setFloatingSelection({
                            "useViewportSelectionTransform.useEffect.handleKeyDown": (prev)=>{
                                if (!prev) return null;
                                return {
                                    ...prev,
                                    x: prev.x + dx,
                                    y: prev.y + dy
                                };
                            }
                        }["useViewportSelectionTransform.useEffect.handleKeyDown"]);
                        renderComposite();
                    }
                }
            }["useViewportSelectionTransform.useEffect.handleKeyDown"];
            window.addEventListener('keydown', handleKeyDown);
            return ({
                "useViewportSelectionTransform.useEffect": ()=>window.removeEventListener('keydown', handleKeyDown)
            })["useViewportSelectionTransform.useEffect"];
        }
    }["useViewportSelectionTransform.useEffect"], [
        cancelTransform,
        commitTransform,
        floatingSelection,
        renderComposite,
        selection,
        setFloatingSelection
    ]);
    return {
        transform,
        setTransform,
        handlePointerDown,
        handlePointerMove,
        handlePointerUp,
        commitTransform,
        cancelTransform,
        handleFlipH,
        handleFlipV,
        handleRotate90CW,
        handleRotate90CCW
    };
}
_s(useViewportSelectionTransform, "HMBiNNFz0hfW4BegehBqNLleA6s=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useViewportStudioEvents.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useViewportStudioEvents",
    ()=>useViewportStudioEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$compactPalette$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/color/compactPalette.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$usePhotometricEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/events/usePhotometricEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$useGeometricEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/events/useGeometricEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$useArtisanEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/events/useArtisanEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$useSpriteCleanupEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/viewport/events/useSpriteCleanupEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine/id.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/project/workspaceEnvelopeGuard.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
function useViewportStudioEvents({ mainCanvasRef, canvasWidth, canvasHeight, activeLayerId, getOrCreateLayerCanvas, renderComposite, captureSnapshot, commitSnapshot, discardSnapshot, performUndo, performRedo }) {
    _s();
    const addExtractedPalette = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportStudioEvents.useStudioStore[addExtractedPalette]": (s)=>s.addExtractedPalette
    }["useViewportStudioEvents.useStudioStore[addExtractedPalette]"]);
    const bumpBufferVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"])({
        "useViewportStudioEvents.useStudioStore[bumpBufferVersion]": (s)=>s.bumpBufferVersion
    }["useViewportStudioEvents.useStudioStore[bumpBufferVersion]"]);
    // Helper: composite source snapshot of all layers excluding tagged target
    const compositeSourceSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportStudioEvents.useCallback[compositeSourceSnapshot]": (excludeTag)=>{
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            const currentFrame = state.frames[state.activeFrameIndex];
            if (!currentFrame) return null;
            const scratch = document.createElement('canvas');
            scratch.width = canvasWidth;
            scratch.height = canvasHeight;
            const sCtx = scratch.getContext('2d', {
                willReadFrequently: true
            });
            if (!sCtx) return null;
            sCtx.imageSmoothingEnabled = false;
            // 1. Composite excluding the tag (base artwork)
            currentFrame.layers.slice().reverse().forEach({
                "useViewportStudioEvents.useCallback[compositeSourceSnapshot]": (layer)=>{
                    if (!layer.visible) return;
                    const photometricAuxiliaryLayer = excludeTag === 'photometric' && (layer.tag === 'auto-shade' || layer.tag === 'specular' || layer.tag === 'normal' || layer.tag === 'normal-map' || layer.tag === 'cast-shadow' || layer.tag === 'ground-shadow' || layer.tag === 'optical-output' || layer.tag === 'sel-out' || layer.tag === 'auto-outline');
                    if (excludeTag && (layer.tag === excludeTag || photometricAuxiliaryLayer)) {
                        return;
                    }
                    const lCanvas = getOrCreateLayerCanvas(layer.id);
                    sCtx.globalAlpha = layer.opacity;
                    sCtx.globalCompositeOperation = layer.blendMode;
                    sCtx.drawImage(lCanvas, 0, 0);
                }
            }["useViewportStudioEvents.useCallback[compositeSourceSnapshot]"]);
            // 2. Count opaque pixels in the non-tagged composite
            const nonTaggedData = sCtx.getImageData(0, 0, canvasWidth, canvasHeight).data;
            let nonTaggedPixels = 0;
            for(let i = 3; i < nonTaggedData.length; i += 4){
                if (nonTaggedData[i] > 20) nonTaggedPixels++;
            }
            // A generator must never analyze its own cached output. If an explicit
            // target tag was excluded and no authored source remains, return the
            // empty source rather than recursively baking the old effect into itself.
            if (nonTaggedPixels > 0 || excludeTag) {
                sCtx.globalAlpha = 1.0;
                sCtx.globalCompositeOperation = 'source-over';
                return sCtx;
            }
            // 3. Untargeted tools may still fall back to the complete visible composite.
            const fullScratch = document.createElement('canvas');
            fullScratch.width = canvasWidth;
            fullScratch.height = canvasHeight;
            const fullCtx = fullScratch.getContext('2d', {
                willReadFrequently: true
            });
            if (!fullCtx) return sCtx;
            fullCtx.imageSmoothingEnabled = false;
            currentFrame.layers.slice().reverse().forEach({
                "useViewportStudioEvents.useCallback[compositeSourceSnapshot]": (layer)=>{
                    if (!layer.visible) return;
                    const lCanvas = getOrCreateLayerCanvas(layer.id);
                    fullCtx.globalAlpha = layer.opacity;
                    fullCtx.globalCompositeOperation = layer.blendMode;
                    fullCtx.drawImage(lCanvas, 0, 0);
                }
            }["useViewportStudioEvents.useCallback[compositeSourceSnapshot]"]);
            fullCtx.globalAlpha = 1.0;
            fullCtx.globalCompositeOperation = 'source-over';
            return fullCtx;
        }
    }["useViewportStudioEvents.useCallback[compositeSourceSnapshot]"], [
        canvasHeight,
        canvasWidth,
        getOrCreateLayerCanvas
    ]);
    // Helper: composite manual normal sculpt layers (e.g. tag === 'normal')
    const compositeNormalMapSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportStudioEvents.useCallback[compositeNormalMapSnapshot]": ()=>{
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            const currentFrame = state.frames[state.activeFrameIndex];
            if (!currentFrame) return null;
            const normalLayers = currentFrame.layers.filter({
                "useViewportStudioEvents.useCallback[compositeNormalMapSnapshot].normalLayers": (l)=>l.visible && (l.tag === 'normal' || l.tag === 'normal-map')
            }["useViewportStudioEvents.useCallback[compositeNormalMapSnapshot].normalLayers"]);
            if (normalLayers.length === 0) return null;
            const scratch = document.createElement('canvas');
            scratch.width = canvasWidth;
            scratch.height = canvasHeight;
            const sCtx = scratch.getContext('2d', {
                willReadFrequently: true
            });
            if (!sCtx) return null;
            sCtx.imageSmoothingEnabled = false;
            normalLayers.slice().reverse().forEach({
                "useViewportStudioEvents.useCallback[compositeNormalMapSnapshot]": (layer)=>{
                    const lCanvas = getOrCreateLayerCanvas(layer.id);
                    sCtx.globalAlpha = layer.opacity;
                    sCtx.globalCompositeOperation = layer.blendMode;
                    sCtx.drawImage(lCanvas, 0, 0);
                }
            }["useViewportStudioEvents.useCallback[compositeNormalMapSnapshot]"]);
            return sCtx.getImageData(0, 0, canvasWidth, canvasHeight);
        }
    }["useViewportStudioEvents.useCallback[compositeNormalMapSnapshot]"], [
        canvasHeight,
        canvasWidth,
        getOrCreateLayerCanvas
    ]);
    // Helper: write AI generated content to a dedicated tagged layer
    const updateTaggedLayer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportStudioEvents.useCallback[updateTaggedLayer]": (displayName, tag, drawFn, effect)=>{
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            const currentFrame = state.frames[state.activeFrameIndex];
            if (!currentFrame) return;
            const previousActiveLayerId = state.activeLayerId;
            let targetLayerId;
            let targetLayerIndex;
            // Find existing tagged layer strictly by explicit tag
            const existing = currentFrame.layers.find({
                "useViewportStudioEvents.useCallback[updateTaggedLayer].existing": (l)=>l.tag === tag
            }["useViewportStudioEvents.useCallback[updateTaggedLayer].existing"]);
            if (existing) {
                targetLayerId = existing.id;
                targetLayerIndex = currentFrame.layers.findIndex({
                    "useViewportStudioEvents.useCallback[updateTaggedLayer]": (layer)=>layer.id === targetLayerId
                }["useViewportStudioEvents.useCallback[updateTaggedLayer]"]);
                // Capture raster and metadata before changing the generated layer so a
                // single undo restores the complete pre-command state.
                captureSnapshot(displayName, targetLayerId, undefined, tag, true, targetLayerIndex);
            } else {
                const capacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$project$2f$workspaceEnvelopeGuard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAddLayersToFrame"])(state.frames, state.activeFrameIndex, canvasWidth, canvasHeight, 1);
                if (!capacity.ok) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                        message: capacity.reason || 'Cannot create shadow layer: workspace capacity ceiling reached.',
                        type: 'error'
                    });
                    return;
                }
                targetLayerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('layer');
                targetLayerIndex = tag === 'cast-shadow' || tag === 'ground-shadow' ? currentFrame.layers.length : 0;
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                    "useViewportStudioEvents.useCallback[updateTaggedLayer]": (draft)=>{
                        const frame = draft.frames[draft.activeFrameIndex];
                        if (!frame) return;
                        frame.layers.splice(targetLayerIndex, 0, {
                            id: targetLayerId,
                            name: displayName,
                            visible: true,
                            locked: false,
                            opacity: 1,
                            blendMode: 'source-over',
                            tag
                        });
                        draft.activeLayerId = targetLayerId;
                    }
                }["useViewportStudioEvents.useCallback[updateTaggedLayer]"]);
                captureSnapshot(displayName, targetLayerId, targetLayerId, tag, true, targetLayerIndex);
            }
            const lCanvas = getOrCreateLayerCanvas(targetLayerId);
            const lCtx = lCanvas.getContext('2d', {
                willReadFrequently: true
            });
            if (lCtx) {
                lCtx.imageSmoothingEnabled = false;
                lCtx.clearRect(0, 0, canvasWidth, canvasHeight);
                drawFn(lCtx);
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].setState({
                "useViewportStudioEvents.useCallback[updateTaggedLayer]": (draft)=>{
                    const layer = draft.frames[draft.activeFrameIndex]?.layers.find({
                        "useViewportStudioEvents.useCallback[updateTaggedLayer]": (candidate)=>candidate.id === targetLayerId
                    }["useViewportStudioEvents.useCallback[updateTaggedLayer]"]);
                    if (!layer) return;
                    layer.name = displayName;
                    layer.tag = tag;
                    layer.effect = effect ? {
                        ...structuredClone(effect),
                        id: existing?.effect?.id ?? effect.id ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2f$id$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createId"])('effect'),
                        updatedAt: effect.updatedAt ?? Date.now()
                    } : undefined;
                }
            }["useViewportStudioEvents.useCallback[updateTaggedLayer]"]);
            commitSnapshot();
            renderComposite();
            bumpBufferVersion();
            if (previousActiveLayerId && previousActiveLayerId !== targetLayerId) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState().setActiveLayer(previousActiveLayerId);
            }
        }
    }["useViewportStudioEvents.useCallback[updateTaggedLayer]"], [
        bumpBufferVersion,
        canvasHeight,
        canvasWidth,
        captureSnapshot,
        commitSnapshot,
        getOrCreateLayerCanvas,
        renderComposite
    ]);
    // Mount domain event hooks
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$usePhotometricEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePhotometricEvents"])({
        canvasWidth,
        canvasHeight,
        activeLayerId,
        getOrCreateLayerCanvas,
        renderComposite,
        captureSnapshot,
        commitSnapshot,
        bumpBufferVersion,
        compositeSourceSnapshot,
        updateTaggedLayer,
        compositeNormalMapSnapshot,
        discardSnapshot
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$useGeometricEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGeometricEvents"])({
        canvasWidth,
        canvasHeight,
        activeLayerId,
        getOrCreateLayerCanvas,
        renderComposite,
        captureSnapshot,
        commitSnapshot,
        bumpBufferVersion,
        compositeSourceSnapshot,
        updateTaggedLayer
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$useArtisanEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useArtisanEvents"])({
        canvasWidth,
        canvasHeight,
        activeLayerId,
        getOrCreateLayerCanvas,
        renderComposite,
        captureSnapshot,
        commitSnapshot,
        bumpBufferVersion,
        compositeSourceSnapshot,
        updateTaggedLayer
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$useSpriteCleanupEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSpriteCleanupEvents"])({
        canvasWidth,
        canvasHeight,
        activeLayerId,
        getOrCreateLayerCanvas,
        renderComposite,
        captureSnapshot,
        commitSnapshot,
        bumpBufferVersion,
        compositeSourceSnapshot,
        updateTaggedLayer
    });
    // Core session undo, redo, and palette extraction listeners
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useViewportStudioEvents.useEffect": ()=>{
            const handleUndoEvent = {
                "useViewportStudioEvents.useEffect.handleUndoEvent": ()=>performUndo()
            }["useViewportStudioEvents.useEffect.handleUndoEvent"];
            const handleRedoEvent = {
                "useViewportStudioEvents.useEffect.handleRedoEvent": ()=>performRedo()
            }["useViewportStudioEvents.useEffect.handleRedoEvent"];
            const handleExtractPaletteEvent = {
                "useViewportStudioEvents.useEffect.handleExtractPaletteEvent": ()=>{
                    const mainCanvas = mainCanvasRef.current;
                    if (!mainCanvas) return;
                    const ctx = mainCanvas.getContext('2d', {
                        willReadFrequently: true
                    });
                    if (!ctx) return;
                    const imgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
                    const data = imgData.data;
                    const colorsArr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$color$2f$compactPalette$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractCompactPalette"])(data, 6);
                    if (colorsArr.length > 0) {
                        addExtractedPalette('Artwork colors', colorsArr);
                    } else __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:toast', {
                        type: 'default',
                        message: 'Draw or import some artwork first.'
                    });
                }
            }["useViewportStudioEvents.useEffect.handleExtractPaletteEvent"];
            const unsubs = [
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:undo', handleUndoEvent),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:redo', handleRedoEvent),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].on('pixibun:extract-palette', handleExtractPaletteEvent)
            ];
            return ({
                "useViewportStudioEvents.useEffect": ()=>{
                    unsubs.forEach({
                        "useViewportStudioEvents.useEffect": (unsub)=>unsub()
                    }["useViewportStudioEvents.useEffect"]);
                }
            })["useViewportStudioEvents.useEffect"];
        }
    }["useViewportStudioEvents.useEffect"], [
        addExtractedPalette,
        canvasHeight,
        canvasWidth,
        mainCanvasRef,
        performRedo,
        performUndo
    ]);
}
_s(useViewportStudioEvents, "0Ijl0d+HVAK5NRMmayUEpbbGdGg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$usePhotometricEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePhotometricEvents"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$useGeometricEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGeometricEvents"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$useArtisanEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useArtisanEvents"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$viewport$2f$events$2f$useSpriteCleanupEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSpriteCleanupEvents"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/viewport/useViewportTransform.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useViewportTransform",
    ()=>useViewportTransform
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/stores/studioStore.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events/studioEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/safety/mathInvariants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/zoom.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function useViewportTransform({ containerRef, mainCanvasRef, canvasWidth, canvasHeight, zoom, setZoom, panX, panY, setPan, setZoomAndPan }) {
    _s();
    const [isPanning, setIsPanning] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [panStart, setPanStart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    });
    // Convert client viewport coordinates (e.g. mouse event) directly to canvas pixel space
    const clientToCanvasCoords = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportTransform.useCallback[clientToCanvasCoords]": (clientX, clientY, clamped = false)=>{
            const canvas = mainCanvasRef.current;
            if (!canvas) return null;
            const rect = canvas.getBoundingClientRect();
            const scaleX = canvasWidth / rect.width;
            const scaleY = canvasHeight / rect.height;
            let x = Math.floor((clientX - rect.left) * scaleX);
            let y = Math.floor((clientY - rect.top) * scaleY);
            if (clamped) {
                x = Math.max(0, Math.min(canvasWidth - 1, x));
                y = Math.max(0, Math.min(canvasHeight - 1, y));
                return {
                    x,
                    y
                };
            }
            if (x < 0 || x >= canvasWidth || y < 0 || y >= canvasHeight) {
                return null;
            }
            return {
                x,
                y
            };
        }
    }["useViewportTransform.useCallback[clientToCanvasCoords]"], [
        canvasHeight,
        canvasWidth,
        mainCanvasRef
    ]);
    // Wheel Handler: Mouse Wheel / Ctrl+Wheel = Zoom to cursor; Shift+Wheel = Pan Horizontally
    const handleWheel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportTransform.useCallback[handleWheel]": (e)=>{
            // Intercept wheel when photometric lighting gizmo is active and route to bulb strength
            const { photometricGizmoActive } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$stores$2f$studioStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useStudioStore"].getState();
            if (photometricGizmoActive) {
                const delta = e.deltaY < 0 ? 0.05 : -0.05;
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2f$studioEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioEvents"].emit('pixibun:photometric-strength-delta', delta);
                return;
            }
            e.preventDefault();
            if (e.shiftKey) {
                // Shift + Wheel = Pan horizontally
                setPan(panX - (e.deltaX || e.deltaY), panY);
                return;
            }
            // If purely horizontal scroll (e.g. tilt wheel), pan horizontally
            if (e.deltaY === 0 && e.deltaX !== 0) {
                setPan(panX - e.deltaX, panY);
                return;
            }
            // Mouse Wheel scrolling (and Ctrl/Cmd+Wheel) = Zoom in/out anchored to cursor
            const safeCurrentZoom = Math.max(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MIN_ZOOM"], Math.min(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_ZOOM"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MathInvariants"].isSafeFinite(zoom) ? zoom : 100));
            const newZoom = e.deltaY < 0 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNextZoomStep"])(safeCurrentZoom) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPrevZoomStep"])(safeCurrentZoom);
            if (newZoom === safeCurrentZoom) return;
            // Instant cursor-anchored zooming (1:1 deterministic, zero animation lag)
            const container = containerRef.current;
            if (container) {
                const rect = container.getBoundingClientRect();
                const safePanX = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MathInvariants"].isSafeFinite(panX) ? panX : 0;
                const safePanY = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MathInvariants"].isSafeFinite(panY) ? panY : 0;
                // Cursor position relative to canvas center on screen
                const cursorOffsetX = e.clientX - (rect.left + rect.width / 2) - safePanX;
                const cursorOffsetY = e.clientY - (rect.top + rect.height / 2) - safePanY;
                const ratio = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$safety$2f$mathInvariants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MathInvariants"].safeDivide(newZoom, safeCurrentZoom, 1);
                const newPanX = Math.round(safePanX + cursorOffsetX * (1 - ratio));
                const newPanY = Math.round(safePanY + cursorOffsetY * (1 - ratio));
                if (setZoomAndPan) {
                    setZoomAndPan(newZoom, newPanX, newPanY);
                } else {
                    setPan(newPanX, newPanY);
                    setZoom(newZoom);
                }
            } else {
                setZoom(newZoom);
            }
        }
    }["useViewportTransform.useCallback[handleWheel]"], [
        containerRef,
        panX,
        panY,
        setPan,
        setZoom,
        setZoomAndPan,
        zoom
    ]);
    // Fit to Screen
    const handleFitToScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportTransform.useCallback[handleFitToScreen]": ()=>{
            const container = containerRef.current;
            if (!container) return;
            setZoom((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$zoom$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateFitZoom"])(canvasWidth, canvasHeight, container.clientWidth, container.clientHeight));
            setPan(0, 0);
        }
    }["useViewportTransform.useCallback[handleFitToScreen]"], [
        canvasHeight,
        canvasWidth,
        containerRef,
        setPan,
        setZoom
    ]);
    // Reset to 100% (or default)
    const handleResetZoom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useViewportTransform.useCallback[handleResetZoom]": ()=>{
            setZoom(1600);
            setPan(0, 0);
        }
    }["useViewportTransform.useCallback[handleResetZoom]"], [
        setPan,
        setZoom
    ]);
    return {
        isPanning,
        setIsPanning,
        panStart,
        setPanStart,
        clientToCanvasCoords,
        handleWheel,
        handleFitToScreen,
        handleResetZoom
    };
}
_s(useViewportTransform, "YmbveEGNaRnMskCRDjUTw7X0NDE=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_hooks_1q3h1ce._.js.map