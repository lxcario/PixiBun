(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/layout/inspector/AiToolsPanel.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_0kj5y5b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/layout/inspector/AiToolsPanel.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/modals/CanvasResizeModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_modals_CanvasResizeModal_tsx_0-c-_xo._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/modals/CanvasResizeModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/modals/CoDrawModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_modals_CoDrawModal_tsx_10q6avb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/modals/CoDrawModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/modals/ColorPickerModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_modals_ColorPickerModal_tsx_0fg5-4-._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/modals/ColorPickerModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/modals/CommandPaletteModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_modals_CommandPaletteModal_tsx_02_ttwa._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/modals/CommandPaletteModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/modals/DiagnosticsModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_modals_DiagnosticsModal_tsx_1xp58p-._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/modals/DiagnosticsModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/modals/ExportModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_0anop_w._.js",
  "static/chunks/node_modules_zustand_esm_0scmywx._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/modals/ExportModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/modals/ImportModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_1ichn9z._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/modals/ImportModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/modals/ProjectsGalleryModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_modals_ProjectsGalleryModal_tsx_0vzlpcs._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/modals/ProjectsGalleryModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/modals/RecoveryModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_0asp959._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/modals/RecoveryModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/modals/ShortcutsModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_modals_ShortcutsModal_tsx_1jv9ino._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/modals/ShortcutsModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/lib/diagnostics/capture.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/diagnostics/capture.ts [app-client] (ecmascript)");
    });
});
}),
]);