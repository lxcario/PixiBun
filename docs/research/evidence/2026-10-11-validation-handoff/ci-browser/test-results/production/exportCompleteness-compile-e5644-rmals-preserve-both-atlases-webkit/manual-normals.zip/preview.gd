extends Node2D
var data: Dictionary
var player: AnimatedSprite2D
var reference: AnimatedSprite2D
var palette_material: ShaderMaterial
var elapsed_seconds := 0.0
var runtime_light: PointLight2D

func _ready():
    data = JSON.parse_string(FileAccess.get_file_as_string("res://manifest.json"))
    var frames: SpriteFrames = load("res://sprite_frames.tres")
    reference = AnimatedSprite2D.new()
    reference.sprite_frames = frames
    reference.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    reference.centered = false
    reference.offset = -Vector2(data.width * data.pivot.x, data.height * data.pivot.y)
    reference.position = Vector2(180, 280)
    var display_scale: float = min(8.0, 200.0 / max(data.width, data.height))
    reference.scale = Vector2.ONE * display_scale
    add_child(reference)
    player = reference.duplicate()
    player.position = Vector2(460, 280)
    player.sprite_frames = frames.duplicate(true)
    add_child(player)
    if data.normals:
        var normal_atlas: Texture2D = load("res://normal.png")
        for animation in player.sprite_frames.get_animation_names():
            for i in player.sprite_frames.get_frame_count(animation):
                var diffuse: AtlasTexture = player.sprite_frames.get_frame_texture(animation, i)
                var pair := CanvasTexture.new()
                pair.diffuse_texture = diffuse.atlas
                pair.normal_texture = normal_atlas
                pair.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
                # AtlasTexture must wrap CanvasTexture so its draw call preserves atlas UVs.
                var combined := AtlasTexture.new()
                combined.atlas = pair
                combined.region = diffuse.region
                combined.filter_clip = true
                player.sprite_frames.set_frame(animation, i, combined, player.sprite_frames.get_frame_duration(animation, i))
    if data.indexed:
        palette_material = ShaderMaterial.new()
        palette_material.shader = load("res://palette.gdshader")
        palette_material.set_shader_parameter("index_texture", load("res://indices.png"))
        palette_material.set_shader_parameter("alpha_texture", load("res://alpha.png"))
        palette_material.set_shader_parameter("palette_texture", load("res://palette.png"))
        player.material = palette_material
    var choices := OptionButton.new()
    choices.position = Vector2(20, 20)
    for clip in data.animation.clips:
        choices.add_item(clip.name)
    choices.item_selected.connect(func(i): play_clip(data.animation.clips[i].name))
    add_child(choices)
    var title := Label.new()
    title.text = "Original                         Godot runtime"
    title.position = Vector2(100, 70)
    add_child(title)
    if data.indexed:
        var cycle := CheckButton.new()
        cycle.text = "Runtime palette"
        cycle.button_pressed = true
        cycle.position = Vector2(20, 400)
        cycle.toggled.connect(func(enabled): player.material = palette_material if enabled else null)
        add_child(cycle)
    if data.normals:
        runtime_light = PointLight2D.new()
        var light_image := Image.create(256, 256, false, Image.FORMAT_RGBA8)
        light_image.fill(Color.WHITE)
        runtime_light.texture = ImageTexture.create_from_image(light_image)
        runtime_light.position = Vector2(440, 240)
        runtime_light.energy = 0.7
        runtime_light.enabled = false
        add_child(runtime_light)
        var light_toggle := CheckButton.new()
        light_toggle.text = "Normal-map light"
        light_toggle.position = Vector2(250, 400)
        light_toggle.toggled.connect(func(enabled): runtime_light.enabled = enabled)
        add_child(light_toggle)
    player.frame_changed.connect(func(): reference.set_frame_and_progress(player.frame, player.frame_progress))
    play_clip(data.animation.clips[0].name)

func play_clip(animation: String):
    player.stop()
    reference.animation = animation
    player.animation = animation
    player.set_frame_and_progress(0, 0.0)
    reference.set_frame_and_progress(0, 0.0)
    player.play(animation)

func _process(delta: float):
    elapsed_seconds += delta
    if palette_material:
        palette_material.set_shader_parameter("elapsed_seconds", elapsed_seconds * data.palette.speedMultiplier)
