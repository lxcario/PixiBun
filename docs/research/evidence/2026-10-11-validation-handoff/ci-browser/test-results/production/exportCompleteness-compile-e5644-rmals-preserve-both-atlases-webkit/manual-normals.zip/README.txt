Open project.godot with Godot 4.7 and run the main scene. Choose a named clip. Left: original color. Right: game runtime.
Holds use SpriteFrames relative duration in milliseconds at speed 1000. Ping-pong periods contain each endpoint once.
Textures are untrimmed, lossless, nearest, without mipmaps or alpha-border changes. Anchors are normalized in manifest.json.
Indices store raw register bytes in RED; alpha.png stores source alpha in RED, independently. Both data textures are opaque.
Roles and index bindings are explicit. Non-palette and unresolved duplicate pixels refuse indexed export. No quantization is hidden.
Normal atlases are exported as stored; Godot expects X+ Y+ Z+. Generated lighting is not inferred or guaranteed.
Godot itself is not included; its license is available at https://godotengine.org/license/.
Unity/Phaser metadata remains unverified; this kit targets Godot 4.7 only.
